import { base44 } from './base44Client';


export const antiRiftEngine = base44.functions.antiRiftEngine;

export const dualRiftEngine = base44.functions.dualRiftEngine;

export const globalSystemHealth = base44.functions.globalSystemHealth;

