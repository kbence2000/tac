import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle2, Clock, XCircle, 
  DollarSign, MessageSquare, Code2
} from "lucide-react";

const TIP_API = import.meta.env.VITE_TIP_BACKEND_URL || "http://localhost:3004";

const STATUS_CONFIG = {
  "pending-answer": {
    icon: Clock,
    label: "Pending Answer",
    className: "bg-yellow-600/20 text-yellow-400 border-yellow-600/30"
  },
  "answered": {
    icon: CheckCircle2,
    label: "Answered",
    className: "bg-green-600/20 text-green-400 border-green-600/30"
  },
  "expired": {
    icon: XCircle,
    label: "Expired",
    className: "bg-red-600/20 text-red-400 border-red-600/30"
  },
  "cancelled": {
    icon: XCircle,
    label: "Cancelled",
    className: "bg-gray-600/20 text-gray-400 border-gray-600/30"
  }
};

export default function TipHistory({ userId }) {
  const { data: tips = [], isLoading } = useQuery({
    queryKey: ['userTips', userId],
    queryFn: async () => {
      if (!userId) return [];
      const res = await fetch(`${TIP_API}/api/tip/user/${userId}`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!userId,
    refetchInterval: 15000,
  });

  if (isLoading) {
    return (
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="text-center py-8">
          <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </Card>
    );
  }

  const myRequests = tips.filter(t => t.requesterId === userId);
  const myAnswers = tips.filter(t => t.assignedDemigodId === userId);

  return (
    <div className="space-y-6">
      {/* My Requests */}
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="flex items-center gap-3 mb-4">
          <MessageSquare className="w-5 h-5 text-blue-400" />
          <h3 className="text-lg font-bold text-white">My Tip Requests</h3>
          <Badge className="bg-blue-600/20 text-blue-400 border-blue-600/30">
            {myRequests.length}
          </Badge>
        </div>

        {myRequests.length === 0 ? (
          <div className="text-center py-8 text-gray-500 text-sm">
            No tip requests yet
          </div>
        ) : (
          <div className="space-y-3">
            {myRequests.map((tip) => {
              const statusCfg = STATUS_CONFIG[tip.status] || STATUS_CONFIG["pending-answer"];
              const StatusIcon = statusCfg.icon;

              return (
                <div key={tip.id} className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Code2 className="w-4 h-4 text-gray-400" />
                        <span className="text-sm font-semibold text-white">
                          Tip to {tip.assignedDemigodName || 'Demigod'}
                        </span>
                      </div>
                      {tip.question && (
                        <div className="text-xs text-gray-400 italic mb-2">"{tip.question}"</div>
                      )}
                    </div>
                    <Badge className={statusCfg.className}>
                      <StatusIcon className="w-3 h-3 mr-1" />
                      {statusCfg.label}
                    </Badge>
                  </div>

                  <pre className="text-xs text-gray-500 font-mono bg-[#0a0a0f] p-2 rounded border border-[#1a1f2e] overflow-x-auto mb-2">
                    {tip.codeSnippet.slice(0, 100)}...
                  </pre>

                  {tip.answerText && (
                    <div className="mt-3 p-3 rounded-lg bg-green-600/10 border border-green-600/30">
                      <div className="text-xs font-bold text-green-400 mb-1">Demigod Answer:</div>
                      <div className="text-sm text-gray-300 whitespace-pre-wrap">
                        {tip.answerText}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(tip.createdAt).toLocaleDateString('en-US')}
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      €{tip.priceEUR}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* My Answers (if demigod) */}
      {myAnswers.length > 0 && (
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
          <div className="flex items-center gap-3 mb-4">
            <CheckCircle2 className="w-5 h-5 text-green-400" />
            <h3 className="text-lg font-bold text-white">My Answers</h3>
            <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
              {myAnswers.filter(t => t.status === "answered").length}
            </Badge>
          </div>

          <div className="space-y-3">
            {myAnswers.slice(0, 5).map((tip) => {
              const statusCfg = STATUS_CONFIG[tip.status] || STATUS_CONFIG["pending-answer"];
              const StatusIcon = statusCfg.icon;

              return (
                <div key={tip.id} className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-white">
                      From {tip.requesterName}
                    </span>
                    <Badge className={statusCfg.className}>
                      <StatusIcon className="w-3 h-3 mr-1" />
                      {statusCfg.label}
                    </Badge>
                  </div>

                  {tip.status === "answered" && tip.answerText && (
                    <div className="text-sm text-gray-300 mb-2">
                      {tip.answerText.slice(0, 100)}
                      {tip.answerText.length > 100 && "..."}
                    </div>
                  )}

                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>
                      {new Date(tip.answeredAt || tip.createdAt).toLocaleDateString('en-US')}
                    </span>
                    <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                      +€{tip.demigodShareEUR}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}