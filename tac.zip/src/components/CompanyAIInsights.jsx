import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Lightbulb, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { companyAPI } from "./CompanyAPIClient";
import ReactMarkdown from "react-markdown";

export default function CompanyAIInsights({ companyId }) {
  const [context, setContext] = useState("");
  const [insights, setInsights] = useState(null);
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    setGenerating(true);
    setInsights(null);

    try {
      const result = await companyAPI.getAIInsights(companyId, context);
      setInsights(result);
      toast.success("AI insights generated!");
    } catch (error) {
      console.error("Failed to generate insights:", error);
      toast.error("Failed to generate insights: " + error.message);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
          <Lightbulb className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">AI Strategic Insights</h3>
          <p className="text-sm text-gray-400">Get personalized recommendations</p>
        </div>
      </div>

      {/* Context Input */}
      <div className="mb-4">
        <label className="text-sm text-gray-300 mb-2 block">
          Additional Context (Optional)
        </label>
        <Textarea
          value={context}
          onChange={(e) => setContext(e.target.value)}
          placeholder="Tell us about your goals, challenges, or specific questions..."
          className="bg-[#0f0a1f] border-[#1a1f2e] text-white min-h-[100px]"
        />
      </div>

      <Button
        onClick={handleGenerate}
        disabled={generating}
        className="w-full mb-6"
        style={{
          background: generating ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
          color: 'white'
        }}
      >
        {generating ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Generating Insights...
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4 mr-2" />
            Generate AI Insights
          </>
        )}
      </Button>

      {/* Results */}
      {insights && (
        <div className="p-5 rounded-lg border" style={{
          background: 'rgba(5, 8, 22, 0.5)',
          borderColor: 'rgba(139, 92, 255, 0.4)'
        }}>
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <h4 className="font-semibold text-white">Strategic Recommendations</h4>
          </div>

          {insights.insightsText ? (
            <ReactMarkdown 
              className="prose prose-sm prose-invert max-w-none"
              components={{
                h1: ({children}) => <h1 className="text-lg font-bold text-purple-300 mb-3">{children}</h1>,
                h2: ({children}) => <h2 className="text-base font-bold text-cyan-300 mb-2 mt-3">{children}</h2>,
                p: ({children}) => <p className="text-gray-300 mb-3 leading-relaxed">{children}</p>,
                ul: ({children}) => <ul className="list-disc ml-6 mb-3 text-gray-300 space-y-2">{children}</ul>,
                li: ({children}) => <li className="leading-relaxed">{children}</li>,
                strong: ({children}) => <strong className="text-white font-semibold">{children}</strong>,
              }}
            >
              {insights.insightsText}
            </ReactMarkdown>
          ) : (
            <p className="text-gray-300">
              {insights.insights?.join('\n') || "No insights available"}
            </p>
          )}
        </div>
      )}
    </Card>
  );
}