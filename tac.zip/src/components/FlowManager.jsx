/**
 * MDC Flow Manager
 * Smooth section navigation with fade transitions
 * Perfect for multi-section pages without full route changes
 * 
 * Usage:
 * 1. Add "section" class to your sections: <div id="home" className="section">...</div>
 * 2. Add data-nav to buttons: <button data-nav="home">Home</button>
 * 3. Initialize: Flow.initMenu() in useEffect
 * 4. Manual control: Flow.setSection("home")
 */

export const Flow = {
  /**
   * Switch to a specific section with fade animation
   * @param {string} id - Section ID to show
   */
  setSection(id) {
    // Hide all sections
    document.querySelectorAll(".section").forEach(s => {
      s.style.display = "none";
    });

    // Show and fade in target section
    const target = document.getElementById(id);
    if (!target) {
      console.warn(`Flow: Section "${id}" not found`);
      return;
    }

    target.style.opacity = "0";
    target.style.display = "";
    target.style.transition = "opacity 0.3s ease-in-out";
    
    // Trigger fade-in after DOM update
    setTimeout(() => {
      target.style.opacity = "1";
    }, 10);
  },

  /**
   * Initialize automatic menu navigation
   * Finds all elements with data-nav attribute and sets up click handlers
   */
  initMenu() {
    document.querySelectorAll("[data-nav]").forEach(btn => {
      btn.onclick = () => {
        const target = btn.getAttribute("data-nav");
        Flow.setSection(target);
        
        // Optional: Update active state on nav buttons
        document.querySelectorAll("[data-nav]").forEach(b => {
          b.classList.remove("active-nav");
        });
        btn.classList.add("active-nav");
      };
    });
  },

  /**
   * Get current visible section ID
   * @returns {string|null} Current section ID or null
   */
  getCurrentSection() {
    const visible = Array.from(document.querySelectorAll(".section")).find(
      s => s.style.display !== "none" && s.style.opacity !== "0"
    );
    return visible ? visible.id : null;
  },

  /**
   * Initialize with a default section
   * @param {string} defaultSection - Default section ID to show
   */
  init(defaultSection = null) {
    // Hide all sections initially
    document.querySelectorAll(".section").forEach(s => {
      s.style.display = "none";
    });

    // Show default section if provided
    if (defaultSection) {
      Flow.setSection(defaultSection);
    }

    // Setup menu
    Flow.initMenu();
  }
};

// Named exports for convenience
export const setSection = Flow.setSection.bind(Flow);
export const initMenu = Flow.initMenu.bind(Flow);
export const initFlow = Flow.init.bind(Flow);

export default Flow;