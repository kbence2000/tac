import React, { useState } from 'react';
import { X, Layers, Shuffle } from 'lucide-react';
import { useTriMind } from './TriMindContext';

export default function ParallelArchitectPanel({ isOpen, onClose }) {
  const triMind = useTriMind();
  const [parallelLayouts, setParallelLayouts] = useState('No multiverse yet.');

  const universes = [
    "Toxic Neon",
    "Stealth Matte",
    "Impossible Geometry",
    "Wireframe Only",
    "Particle Cloud",
    "Glass Morphism",
    "Brutalist Concrete"
  ];

  const generateParallel = () => {
    const focus = universes[Math.floor(Math.random() * universes.length)];
    const count = 3 + Math.floor(Math.random() * 3);

    let desc = `Parallel layouts:\n\n`;
    for (let i = 0; i < count; i++) {
      const u = universes[(i + Math.floor(Math.random() * universes.length)) % universes.length];
      desc += `• Universe ${i + 1}: ${u} mode\n`;
    }
    desc += `\nUser can 'phase shift' between realities by swiping upward or using a hotkey (Alt + Shift + P).`;

    setParallelLayouts(desc);

    // Update Tri-Mind state
    if (triMind) {
      triMind.setParallelState({
        count,
        focus,
        universes: desc
      });
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
        onClick={onClose}
      />

      {/* Panel */}
      <div 
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[460px] max-w-[90vw] h-[540px] max-h-[85vh] z-[201] overflow-y-auto"
        style={{
          background: 'rgba(5, 12, 18, 0.96)',
          borderRadius: '18px',
          border: '1px solid rgba(36, 228, 255, 0.3)',
          backdropFilter: 'blur(16px)',
          boxShadow: '0 0 80px rgba(36, 228, 255, 0.4)',
          padding: '20px',
          animation: 'panelSlideIn 0.35s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <style>{`
          @keyframes panelSlideIn {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }
        `}</style>

        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-[0.9rem] tracking-[0.2em] uppercase" style={{ color: '#24e4ff' }}>
            PARALLEL ARCHITECT
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Parallel Layouts */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#7dd8ff' }}>
            PARALLEL LAYOUTS
          </h3>
          <pre 
            className="p-3 rounded-lg text-xs whitespace-pre-wrap"
            style={{
              background: 'rgba(0, 0, 0, 0.5)',
              border: '1px solid rgba(36, 228, 255, 0.3)',
              color: '#d5f5ff',
              fontFamily: 'monospace'
            }}
          >
            {parallelLayouts}
          </pre>
        </div>

        {/* Info */}
        <div 
          className="p-3 rounded-lg mb-6"
          style={{
            background: 'rgba(36, 228, 255, 0.1)',
            border: '1px solid rgba(36, 228, 255, 0.3)'
          }}
        >
          <div className="flex items-start gap-2">
            <Shuffle className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-semibold text-white">Parallel Architect:</span> Generates multiple UI/UX reality variants that coexist in parallel. Users can 'phase shift' between different visual themes and interaction paradigms without leaving the page.
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button 
          onClick={generateParallel}
          className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02]"
          style={{
            background: 'linear-gradient(135deg, rgba(36, 228, 255, 0.6), rgba(59, 211, 255, 0.4))',
            border: '1px solid rgba(36, 228, 255, 0.6)',
            boxShadow: '0 0 20px rgba(36, 228, 255, 0.5)',
            color: '#fff'
          }}
        >
          <Layers className="w-4 h-4 inline mr-2" />
          Generate Multiverse Layouts
        </button>
      </div>
    </>
  );
}