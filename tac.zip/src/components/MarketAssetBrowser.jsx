import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Package, Star, Download, Search, Loader2, ExternalLink } from "lucide-react";
import { marketAPI } from "./MarketAPIClient";
import { toast } from "sonner";

export default function MarketAssetBrowser() {
  const [assets, setAssets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAsset, setSelectedAsset] = useState(null);

  useEffect(() => {
    fetchAssets();
  }, []);

  const fetchAssets = async () => {
    try {
      const data = await marketAPI.getAssets({
        search: searchQuery || undefined,
      });
      setAssets(data || []);
    } catch (error) {
      console.error("Failed to fetch assets:", error);
      toast.error("Failed to load assets");
    } finally {
      setLoading(false);
    }
  };

  const viewAssetDetails = async (assetId) => {
    try {
      const details = await marketAPI.getAsset(assetId);
      setSelectedAsset(details);
    } catch (error) {
      console.error("Failed to fetch asset details:", error);
      toast.error("Failed to load asset details");
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case "codebase": return "bg-blue-600/20 text-blue-300 border-blue-600/30";
      case "bot-core": return "bg-purple-600/20 text-purple-300 border-purple-600/30";
      case "code-snippet": return "bg-green-600/20 text-green-300 border-green-600/30";
      case "template": return "bg-yellow-600/20 text-yellow-300 border-yellow-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  if (selectedAsset) {
    return (
      <div className="space-y-6">
        <Button
          onClick={() => setSelectedAsset(null)}
          variant="outline"
          className="border-[#1a1f2e] text-gray-400 hover:text-white"
        >
          ← Back to Assets
        </Button>

        <Card className="border p-6" style={{
          background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
          borderColor: 'rgba(139, 92, 255, 0.3)'
        }}>
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">{selectedAsset.title}</h2>
              <div className="flex items-center gap-2">
                <Badge className={getTypeColor(selectedAsset.type)}>
                  {selectedAsset.type}
                </Badge>
                <span className="text-sm text-gray-400">by {selectedAsset.ownerHandle}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-cyan-400">
                {selectedAsset.currency} {selectedAsset.price}
              </div>
              <div className="flex items-center gap-1 text-sm text-gray-400 mt-1">
                <Star className="w-4 h-4 text-yellow-400" />
                {selectedAsset.rating}
                <span className="mx-1">•</span>
                <Download className="w-4 h-4" />
                {selectedAsset.downloads}
              </div>
            </div>
          </div>

          <p className="text-gray-300 leading-relaxed mb-4">
            {selectedAsset.description}
          </p>

          <div className="flex flex-wrap gap-2">
            {selectedAsset.tags?.map((tag, idx) => (
              <Badge key={idx} className="bg-gray-600/20 text-gray-300 border-gray-600/30 text-xs">
                {tag}
              </Badge>
            ))}
          </div>

          <div className="mt-6 pt-6 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
            <Button
              className="w-full"
              style={{
                background: 'linear-gradient(135deg, #8b5cff, #24e4ff)',
                color: 'white'
              }}
            >
              <Package className="w-4 h-4 mr-2" />
              Purchase Asset
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <Card className="border p-6" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Package className="w-5 h-5 text-purple-400" />
        Browse Assets
      </h3>

      <div className="mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && fetchAssets()}
            placeholder="Search assets..."
            className="pl-10 bg-[#0f0a1f] border-[#1a1f2e] text-white"
          />
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-purple-400" />
          <p className="text-gray-400">Loading assets...</p>
        </div>
      ) : assets.length === 0 ? (
        <div className="text-center py-12">
          <Package className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">No assets found</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {assets.map((asset) => (
            <div
              key={asset.id}
              onClick={() => viewAssetDetails(asset.id)}
              className="p-4 rounded-lg border hover:shadow-lg transition-all cursor-pointer group"
              style={{
                background: 'rgba(5, 8, 22, 0.5)',
                borderColor: 'rgba(148, 163, 184, 0.2)'
              }}
            >
              <div className="flex items-start justify-between mb-3">
                <h4 className="font-bold text-white group-hover:text-cyan-400 transition-colors">
                  {asset.title}
                </h4>
                <Badge className={getTypeColor(asset.type)}>
                  {asset.type}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-yellow-400" />
                    {asset.rating}
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {asset.tags?.slice(0, 2).map((tag, idx) => (
                      <span key={idx} className="text-xs text-gray-500">#{tag}</span>
                    ))}
                  </div>
                </div>

                <div className="text-cyan-400 font-bold">
                  {asset.currency} {asset.price}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}