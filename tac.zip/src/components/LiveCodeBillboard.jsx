import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Github, Linkedin, TrendingUp, ExternalLink, Copy, Check, Code2, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

// Fallback mock data if fetch fails
const fallbackSnippets = [
  {
    title: "Async pipeline helper",
    source: "github/trending",
    language: "javascript",
    code: `async function pipeline(...fns) {
  return async (input) => {
    let result = input;
    for (const fn of fns) {
      result = await fn(result);
    }
    return result;
  };
}`,
    originId: "github-async",
    url: "https://github.com/trending",
    upvotes: 1247
  }
];

export default function LiveCodeBillboard({ 
  autoRotate = true, 
  rotateInterval = 8000
}) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [data, setData] = useState(fallbackSnippets);
  const [loading, setLoading] = useState(true);

  // Fetch snippets from backend
  useEffect(() => {
    const fetchSnippets = async () => {
      try {
        const snippets = await base44.entities.TrendingSnippet.filter(
          { isActive: true },
          '-created_date',
          20
        );
        
        if (snippets && snippets.length > 0) {
          setData(snippets);
        } else {
          // If no data in DB, use fallback
          setData(fallbackSnippets);
        }
      } catch (error) {
        console.error('Failed to fetch snippets:', error);
        setData(fallbackSnippets);
      } finally {
        setLoading(false);
      }
    };

    fetchSnippets();
  }, []);

  const currentSnippet = data[currentIndex];

  useEffect(() => {
    if (!autoRotate || isPaused || loading) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % data.length);
    }, rotateInterval);

    return () => clearInterval(interval);
  }, [autoRotate, rotateInterval, isPaused, data.length, loading]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(currentSnippet.code);
      setCopied(true);
      toast.success("Code copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error("Failed to copy code");
    }
  };

  const getSourceIcon = (source) => {
    const lower = source.toLowerCase();
    if (lower.includes('github')) return <Github className="w-4 h-4" />;
    if (lower.includes('linkedin')) return <Linkedin className="w-4 h-4" />;
    if (lower.includes('dev.to')) return <Code2 className="w-4 h-4" />;
    return <TrendingUp className="w-4 h-4" />;
  };

  const getLanguageColor = (lang) => {
    if (!lang) return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    
    switch (lang.toLowerCase()) {
      case "javascript": return "bg-yellow-600/20 text-yellow-300 border-yellow-600/30";
      case "typescript": return "bg-blue-600/20 text-blue-300 border-blue-600/30";
      case "python": return "bg-green-600/20 text-green-300 border-green-600/30";
      case "css": return "bg-pink-600/20 text-pink-300 border-pink-600/30";
      case "rust": return "bg-orange-600/20 text-orange-300 border-orange-600/30";
      case "go": return "bg-cyan-600/20 text-cyan-300 border-cyan-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  if (loading) {
    return (
      <Card 
        className="relative border p-12 text-center"
        style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(139, 92, 255, 0.3)'
        }}
      >
        <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-400" />
        <p className="text-gray-400">Loading trending code...</p>
      </Card>
    );
  }

  if (!currentSnippet) {
    return null;
  }

  return (
    <Card 
      className="relative border overflow-hidden animate-fade-in"
      style={{
        background: 'radial-gradient(circle at 0% 0%, rgba(139, 92, 255, 0.08), transparent 50%), radial-gradient(circle at 100% 100%, rgba(36, 228, 255, 0.08), transparent 50%), rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(139, 92, 255, 0.3)'
      }}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Animated border */}
      <div 
        className="absolute inset-0 opacity-50 pointer-events-none"
        style={{
          background: 'linear-gradient(90deg, transparent, rgba(139, 92, 255, 0.5), transparent)',
          animation: 'shimmer 3s infinite'
        }}
      />

      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        
        @keyframes pulse-dot {
          0%, 100% { opacity: 1; box-shadow: 0 0 8px rgba(36, 228, 255, 0.8); }
          50% { opacity: 0.5; box-shadow: 0 0 4px rgba(36, 228, 255, 0.4); }
        }
      `}</style>

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-3 border-b" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
        <div className="flex items-center gap-3">
          <div 
            className="w-2 h-2 rounded-full"
            style={{
              background: 'var(--accent-alt)',
              animation: 'pulse-dot 2s infinite'
            }}
          />
          <span className="text-xs uppercase tracking-[0.15em] text-gray-400 font-mono">
            LIVE FEED
          </span>
          <span className="text-xs text-gray-500">
            GitHub · Dev.to · Reddit · LinkedIn
          </span>
        </div>

        {/* Pagination dots */}
        <div className="flex items-center gap-1.5">
          {data.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-1.5 h-1.5 rounded-full transition-all ${
                idx === currentIndex 
                  ? 'w-4 bg-cyan-400' 
                  : 'bg-gray-600 hover:bg-gray-500'
              }`}
              aria-label={`Go to snippet ${idx + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Meta */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-bold text-white">{currentSnippet.title}</h3>
            {currentSnippet.language && (
              <Badge className={getLanguageColor(currentSnippet.language)}>
                {currentSnippet.language}
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-3">
            <Badge className="bg-gray-800/50 text-gray-300 border-gray-700 flex items-center gap-1.5">
              {getSourceIcon(currentSnippet.source)}
              {currentSnippet.source}
            </Badge>
            
            {currentSnippet.upvotes && (
              <div className="flex items-center gap-1 text-sm text-gray-400">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span>{currentSnippet.upvotes.toLocaleString()}</span>
              </div>
            )}
          </div>
        </div>

        {/* Code */}
        <div className="relative group">
          <pre 
            className="p-4 rounded-lg border overflow-x-auto text-sm font-mono leading-relaxed"
            style={{
              background: 'rgba(5, 8, 22, 0.9)',
              borderColor: 'rgba(148, 163, 184, 0.2)',
              maxHeight: '400px'
            }}
          >
            <code className="text-gray-300">{currentSnippet.code}</code>
          </pre>

          {/* Copy button */}
          <button
            onClick={handleCopy}
            className="absolute top-3 right-3 p-2 rounded-lg opacity-0 group-hover:opacity-100 transition-all"
            style={{
              background: 'rgba(15, 23, 42, 0.95)',
              border: '1px solid rgba(148, 163, 184, 0.3)'
            }}
            aria-label="Copy code"
          >
            {copied ? (
              <Check className="w-4 h-4 text-green-400" />
            ) : (
              <Copy className="w-4 h-4 text-gray-400 hover:text-white" />
            )}
          </button>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentIndex((prev) => (prev - 1 + data.length) % data.length)}
              className="px-3 py-1.5 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-gray-800/50 transition-all"
            >
              ← Prev
            </button>
            <button
              onClick={() => setCurrentIndex((prev) => (prev + 1) % data.length)}
              className="px-3 py-1.5 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-gray-800/50 transition-all"
            >
              Next →
            </button>
          </div>

          {currentSnippet.url && (
            <a
              href={currentSnippet.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-all"
              style={{
                background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.2), rgba(36, 228, 255, 0.2))',
                border: '1px solid rgba(139, 92, 255, 0.4)',
                color: 'var(--accent-alt)'
              }}
            >
              View Source
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>

        {/* Origin ID (hidden, for tracking) */}
        <div className="hidden" data-origin-id={currentSnippet.originId} />
      </div>
    </Card>
  );
}