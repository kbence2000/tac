import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Shield, Loader2, Sparkles, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";

export default function DevGuardianAudit() {
  const [auditing, setAuditing] = useState(false);
  const [auditType, setAuditType] = useState("manual");
  const queryClient = useQueryClient();

  const buildHealthSnapshot = async () => {
    // Get metrics from APCActivity (proxy for Mastermind metrics)
    const activities = await base44.entities.APCActivity.list('-created_date', 100);
    
    const byModule = {};
    
    activities.forEach(m => {
      const moduleName = m.activityType || 'unknown';
      if (!byModule[moduleName]) {
        byModule[moduleName] = {
          moduleName,
          calls: 0,
          errors: 0,
          latencySum: 0,
          latencyCount: 0,
          lastError: null
        };
      }
      
      const mod = byModule[moduleName];
      mod.calls++;
      
      if (m.status === 'error') {
        mod.errors++;
        mod.lastError = m.errorMessage || mod.lastError;
      }
      
      if (m.duration) {
        mod.latencySum += m.duration;
        mod.latencyCount++;
      }
    });

    return Object.values(byModule).map(m => ({
      moduleName: m.moduleName,
      calls: m.calls,
      errorRate: m.calls ? m.errors / m.calls : 0,
      avgLatency: m.latencyCount ? m.latencySum / m.latencyCount : null,
      lastError: m.lastError
    }));
  };

  const buildPatternSnapshot = async () => {
    const patterns = await base44.entities.APCPattern.list('-created_date', 1000);
    
    const byCategory = {};
    const byLang = {};
    
    patterns.forEach(p => {
      if (p.category) byCategory[p.category] = (byCategory[p.category] || 0) + 1;
      if (p.language) byLang[p.language] = (byLang[p.language] || 0) + 1;
    });

    return {
      totalPatterns: patterns.length,
      categories: byCategory,
      languages: byLang
    };
  };

  const runAudit = async () => {
    setAuditing(true);

    try {
      // 1. Gather health and pattern data
      const health = await buildHealthSnapshot();
      const patterns = await buildPatternSnapshot();

      // 2. AI Audit
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are DEV-GUARDIAN, a senior AI architect. You receive system health + pattern stats.

Analyze the current state and provide:
- Overall system assessment
- Specific improvement recommendations
- Code patches if needed
- Why these changes are better
- Potential risks

Audit type: ${auditType}

SYSTEM HEALTH (per module):
${JSON.stringify(health, null, 2)}

PATTERN SNAPSHOT (APC):
${JSON.stringify(patterns, null, 2)}

Be specific, actionable, and technical. Focus on real improvements.`,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            severity: { 
              type: "string",
              enum: ["low", "medium", "high", "critical"]
            },
            summary: { type: "string" },
            improvementPlan: {
              type: "array",
              items: { type: "string" }
            },
            patches: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  rationale: { type: "string" },
                  codeBlock: { type: "string" }
                }
              }
            },
            whyBetter: { type: "string" },
            risks: { type: "string" }
          }
        }
      });

      // 3. Create task
      const taskId = `dg-${Date.now()}`;
      
      await base44.entities.DevGuardianTask.create({
        taskId,
        title: response.title || 'System Audit',
        type: auditType,
        severity: response.severity || 'medium',
        status: 'pending',
        summary: response.summary || '',
        improvementPlan: response.improvementPlan || [],
        patches: response.patches || [],
        whyBetter: response.whyBetter || '',
        risks: response.risks || '',
        healthSnapshot: { modules: health },
        patternSnapshot: patterns
      });

      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ['devGuardianTasks'] });

      toast.success('✅ DevGuardian audit completed!');
    } catch (error) {
      console.error('DevGuardian audit failed:', error);
      toast.error('Audit failed: ' + error.message);
    } finally {
      setAuditing(false);
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{
            background: 'linear-gradient(135deg, #8b5cff, #24e4ff)'
          }}>
            <Shield className="w-6 h-6 text-white" />
          </div>
          
          <div>
            <h3 className="font-bold text-white text-lg">Run System Audit</h3>
            <p className="text-sm text-gray-400">
              AI-powered analysis of system health and patterns
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Select value={auditType} onValueChange={setAuditType}>
            <SelectTrigger className="w-40 bg-[#141923] border-[#1a1f2e] text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="manual">Manual Audit</SelectItem>
              <SelectItem value="daily">Daily Check</SelectItem>
              <SelectItem value="post-release">Post-Release</SelectItem>
              <SelectItem value="on-issue">Issue Investigation</SelectItem>
            </SelectContent>
          </Select>

          <Button
            onClick={runAudit}
            disabled={auditing}
            className="flex items-center gap-2"
            style={{
              background: auditing ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
              color: 'white'
            }}
          >
            {auditing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Auditing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Run Audit
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Info */}
      <div className="mt-4 p-4 rounded-lg border" style={{
        background: 'rgba(5, 8, 22, 0.6)',
        borderColor: 'rgba(148, 163, 184, 0.2)'
      }}>
        <div className="flex items-start gap-2 text-sm text-gray-300">
          <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
          <div>
            <strong className="text-white">What DevGuardian does:</strong>
            <ul className="list-disc ml-5 mt-1 space-y-1">
              <li>Analyzes system health from activity logs</li>
              <li>Reviews code patterns from APC vault</li>
              <li>Generates improvement recommendations</li>
              <li>Proposes code patches with rationale</li>
              <li>Flags potential risks</li>
            </ul>
          </div>
        </div>
      </div>
    </Card>
  );
}