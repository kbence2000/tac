import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Zap, TrendingUp, Sparkles } from "lucide-react";
import RankBadge from "./RankBadge";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function DemigodRoyaltyPanel({ userId }) {
  const { data: royaltyData, isLoading } = useQuery({
    queryKey: ['demigodRoyalty', userId],
    queryFn: async () => {
      if (!userId) return null;
      try {
        const res = await fetch(`${BACKEND_URL}/api/royalty/${userId}`);
        if (!res.ok) return null;
        return res.json();
      } catch {
        return null;
      }
    },
    enabled: !!userId,
    refetchInterval: 30000, // Refresh every 30s
  });

  if (isLoading) {
    return (
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="flex items-center justify-center py-8">
          <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </Card>
    );
  }

  if (!royaltyData) {
    return null;
  }

  const { user, royalty } = royaltyData;
  const credits = royalty.credits || 0;

  // Demigod tier check (R6+)
  const isDemigod = user?.tier?.id === "R6" || user?.tier?.id === "R7";

  if (!isDemigod) {
    return (
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="text-center py-8">
          <Award className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-gray-400 mb-2">Demigod Royalty</h3>
          <p className="text-sm text-gray-500">
            Reach <RankBadge rank="R6" size="xs" /> or <RankBadge rank="R7" size="xs" /> to earn royalties
          </p>
        </div>
      </Card>
    );
  }

  const getTier = () => {
    if (credits >= 100) return { label: "Legend", color: "text-yellow-400", bg: "bg-yellow-600/20", border: "border-yellow-600/30" };
    if (credits >= 50) return { label: "Elite", color: "text-purple-400", bg: "bg-purple-600/20", border: "border-purple-600/30" };
    if (credits >= 10) return { label: "Rising", color: "text-cyan-400", bg: "bg-cyan-600/20", border: "border-cyan-600/30" };
    return { label: "Starter", color: "text-gray-400", bg: "bg-gray-600/20", border: "border-gray-600/30" };
  };

  const tier = getTier();

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500/20 to-indigo-500/20">
          <Award className="w-6 h-6 text-purple-400" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-black text-white">Demigod Royalty</h3>
          <p className="text-sm text-gray-400">Credits from shared knowledge</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Total Credits */}
        <div className="text-center p-6 rounded-xl bg-gradient-to-br from-purple-600/10 to-indigo-600/10 border border-purple-600/30">
          <div className="text-5xl font-black mb-2" style={{
            background: "linear-gradient(135deg, #A855F7, #6366F1)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            {credits.toFixed(2)}
          </div>
          <div className="text-sm text-gray-400 mb-3">Total Credits Earned</div>
          <Badge className={`${tier.bg} ${tier.color} border ${tier.border}`}>
            <Sparkles className="w-3 h-3 mr-1" />
            {tier.label} Contributor
          </Badge>
        </div>

        {/* How It Works */}
        <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
          <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
            <Zap className="w-4 h-4 text-purple-400" />
            How Royalty Works
          </h4>
          <div className="space-y-2 text-xs text-gray-400">
            <div className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-[10px] font-bold text-purple-400">1</span>
              </div>
              <div>
                Your code examples (Godlike Insights, Moments, Flexes) are indexed
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-[10px] font-bold text-purple-400">2</span>
              </div>
              <div>
                When users debug, AI searches for relevant demigod patterns
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-[10px] font-bold text-purple-400">3</span>
              </div>
              <div>
                Your examples enhance the analysis → you earn credits
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-[10px] font-bold text-purple-400">4</span>
              </div>
              <div>
                Credits = reputation + future monetization potential
              </div>
            </div>
          </div>
        </div>

        {/* Credit Tiers */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-gray-400 mb-2">Credit Tiers</h4>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between p-2 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <span className="text-xs text-gray-400">Starter</span>
              <Badge className="bg-gray-600/20 text-gray-400 border-gray-600/30 text-xs">
                0-10 credits
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <span className="text-xs text-gray-400">Rising</span>
              <Badge className="bg-cyan-600/20 text-cyan-400 border-cyan-600/30 text-xs">
                10-50 credits
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <span className="text-xs text-gray-400">Elite</span>
              <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30 text-xs">
                50-100 credits
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <span className="text-xs text-gray-400">Legend</span>
              <Badge className="bg-yellow-600/20 text-yellow-400 border-yellow-600/30 text-xs">
                100+ credits
              </Badge>
            </div>
          </div>
        </div>

        {/* Impact Stats */}
        <div className="p-4 rounded-lg bg-gradient-to-br from-indigo-600/10 to-purple-600/10 border border-indigo-600/30">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-bold text-white">Your Impact</span>
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            Your knowledge has enhanced <strong className="text-white">{Math.floor(credits * 10)}</strong> debug sessions. 
            Keep sharing insights to earn more credits and help the community.
          </p>
        </div>
      </div>
    </Card>
  );
}