import React from "react";
import { Button } from "@/components/ui/button";
import { ShoppingBag, ExternalLink } from "lucide-react";

/**
 * Shopify Buy Button with Affiliate UTM Tracking
 * Generates checkout URL with affiliate code in UTM parameters
 */
export default function ShopifyBuyButton({ 
  app, 
  affiliateCode = null,
  variant = "default",
  size = "default",
  className = "",
  children = "Vásárlás Shopify-on"
}) {
  if (!app.shopify_store_url || !app.shopify_handle) {
    return null;
  }

  const baseUrl = `https://${app.shopify_store_url}/products/${app.shopify_handle}`;
  
  // Build checkout URL with UTM tracking
  const params = new URLSearchParams({
    utm_source: affiliateCode || 'codemarket',
    utm_medium: 'affiliate',
    utm_campaign: app.id,
    utm_content: app.name
  });

  // Add affiliate code as additional parameter for tracking
  if (affiliateCode) {
    params.set('ref', affiliateCode);
  }

  const checkoutUrl = `${baseUrl}?${params.toString()}`;

  const handleClick = () => {
    // Track click event (optional - could send to analytics)
    console.log('Shopify checkout initiated:', {
      app: app.id,
      affiliate: affiliateCode,
      url: checkoutUrl
    });

    // Open in new tab
    window.open(checkoutUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <Button
      onClick={handleClick}
      variant={variant}
      size={size}
      className={`flex items-center gap-2 ${className}`}
    >
      <ShoppingBag className="w-5 h-5" />
      {children}
      <ExternalLink className="w-4 h-4" />
    </Button>
  );
}

// Utility function to extract affiliate code from URL
export function getAffiliateCodeFromUrl() {
  if (typeof window === 'undefined') return null;
  
  const params = new URLSearchParams(window.location.search);
  return params.get('ref') || params.get('aff');
}

// Utility function to get affiliate cookie
export function getAffiliateCookie() {
  if (typeof document === 'undefined') return null;
  
  const match = document.cookie.match(/affiliate=([^;]+)/);
  return match ? match[1] : null;
}