import React from 'react';

export default function CodeRepoTopBar() {
  return (
    <header className="relative z-20 border-b border-purple-900/70 bg-black/70 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-purple-500 to-fuchsia-600 flex items-center justify-center" style={{
            boxShadow: '0 0 18px rgba(168,85,247,0.85)'
          }}>
            <div className="w-4 h-4 rounded-full bg-black border border-purple-100" style={{
              boxShadow: '0 0 14px rgba(34,197,94,0.9)'
            }}></div>
          </div>
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full border border-purple-400/70" style={{
              boxShadow: '0 0 12px rgba(168,85,247,0.55)'
            }}>
              <span className="text-[11px] uppercase tracking-[0.22em] text-purple-100">TAC</span>
              <span className="w-1.5 h-1.5 rounded-full bg-green-500" style={{
                boxShadow: '0 0 14px rgba(34,197,94,0.9)'
              }}></span>
              <span className="text-[10px] text-slate-300">3D Repo Interface</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">AI-driven GitHub-style code universe</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <input
            type="text"
            placeholder="Search TAC repo..."
            className="hidden sm:block w-56 px-4 py-1.5 rounded-full bg-black/60 border border-purple-800/80 text-[12px] placeholder:text-slate-500 focus:outline-none focus:border-purple-500 transition-all"
            style={{
              boxShadow: '0 0 12px rgba(168,85,247,0.55)'
            }}
          />
          <div className="flex items-center gap-2 border border-slate-600/80 rounded-full px-2 py-1 bg-black/60" style={{
            boxShadow: '0 0 12px rgba(168,85,247,0.55)'
          }}>
            <span className="w-7 h-7 rounded-full bg-gradient-to-br from-slate-400 to-slate-200 border border-white/40"></span>
            <span className="hidden sm:inline text-[12px] pr-1">Founder</span>
          </div>
        </div>
      </div>
    </header>
  );
}