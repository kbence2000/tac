import React, { createContext, useContext, useState } from 'react';

const TriMindContext = createContext(null);

export function useTriMind() {
  return useContext(TriMindContext);
}

export function TriMindProvider({ children }) {
  // Original Tri-Mind states
  const [triNeuroState, setTriNeuroState] = useState(null);
  const [triChaosIdeas, setTriChaosIdeas] = useState([]);
  const [triBlueprint, setTriBlueprint] = useState(null);

  // Extended Mind states
  const [triGlitchState, setTriGlitchState] = useState(null);
  const [triShadowState, setTriShadowState] = useState(null);
  const [triTemporalState, setTriTemporalState] = useState(null);
  const [triParallelState, setTriParallelState] = useState(null);
  const [triFractalState, setTriFractalState] = useState(null);

  // Logic Arbiter state (9th brain)
  const [triArbiterState, setTriArbiterState] = useState(null);

  const value = {
    // Neuro Evolution
    neuroState: triNeuroState,
    setNeuroState: setTriNeuroState,
    
    // Chaos Architect
    chaosIdeas: triChaosIdeas,
    setChaosIdeas: setTriChaosIdeas,
    
    // Dream Renderer
    blueprint: triBlueprint,
    setBlueprint: setTriBlueprint,

    // Glitch Engineer
    glitchState: triGlitchState,
    setGlitchState: setTriGlitchState,

    // Shadow Archivist
    shadowState: triShadowState,
    setShadowState: setTriShadowState,

    // Temporal Engine
    temporalState: triTemporalState,
    setTemporalState: setTriTemporalState,

    // Parallel Architect
    parallelState: triParallelState,
    setParallelState: setTriParallelState,

    // Fractal Engineer
    fractalState: triFractalState,
    setFractalState: setTriFractalState,

    // Logic Arbiter (9th brain)
    arbiterState: triArbiterState,
    setArbiterState: setTriArbiterState,
  };

  return (
    <TriMindContext.Provider value={value}>
      {children}
    </TriMindContext.Provider>
  );
}