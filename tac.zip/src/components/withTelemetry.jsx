import React from 'react';
import { logMetric } from './MastermindTelemetry';

/**
 * Higher-Order Component to add telemetry tracking to React components
 * 
 * @param {React.Component} Component - Component to wrap
 * @param {string} moduleName - Name of the module
 * @param {string} role - Module role
 * 
 * @example
 * const FutureMindWithTelemetry = withTelemetry(FutureMindComponent, 'FutureMind', 'pattern');
 */
export function withTelemetry(Component, moduleName, role = 'component') {
  return class extends React.Component {
    componentDidMount() {
      this.mountTime = Date.now();
      
      // Log component mount
      logMetric(moduleName, {
        role,
        latencyMs: 0,
        success: true,
        meta: {
          event: 'mount',
          component: Component.displayName || Component.name
        }
      }).catch(console.error);
    }

    componentWillUnmount() {
      if (this.mountTime) {
        const lifetime = Date.now() - this.mountTime;
        
        // Log component unmount with lifetime
        logMetric(moduleName, {
          role,
          latencyMs: lifetime,
          success: true,
          meta: {
            event: 'unmount',
            component: Component.displayName || Component.name,
            lifetime_ms: lifetime
          }
        }).catch(console.error);
      }
    }

    componentDidCatch(error, errorInfo) {
      // Log component error
      logMetric(moduleName, {
        role,
        latencyMs: Date.now() - (this.mountTime || Date.now()),
        success: false,
        errorCode: 'COMPONENT_ERROR',
        meta: {
          event: 'error',
          component: Component.displayName || Component.name,
          error: error.message,
          errorInfo: errorInfo.componentStack
        }
      }).catch(console.error);

      // Re-throw error
      throw error;
    }

    render() {
      return <Component {...this.props} />;
    }
  };
}

/**
 * Hook to track operations within a component
 * 
 * @param {string} moduleName - Name of the module
 * @param {string} role - Module role
 * 
 * @returns {Function} - Tracking function
 * 
 * @example
 * const Component = () => {
 *   const track = useTelemetry('FutureMind', 'pattern');
 *   
 *   const handleAnalyze = async () => {
 *     await track(async () => {
 *       // Your operation here
 *     }, { operation: 'analyze' });
 *   };
 * };
 */
export function useTelemetry(moduleName, role = 'component') {
  return React.useCallback(
    async (operation, meta = {}) => {
      const start = Date.now();
      
      try {
        const result = await operation();
        
        await logMetric(moduleName, {
          role,
          latencyMs: Date.now() - start,
          success: true,
          meta
        });
        
        return result;
      } catch (error) {
        await logMetric(moduleName, {
          role,
          latencyMs: Date.now() - start,
          success: false,
          errorCode: error.code || error.name || 'UNKNOWN',
          meta: {
            ...meta,
            error_message: error.message
          }
        });
        
        throw error;
      }
    },
    [moduleName, role]
  );
}

export default withTelemetry;