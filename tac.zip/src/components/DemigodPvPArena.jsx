import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Swords, Trophy, Code2, Loader2, Send, Clock } from "lucide-react";
import { toast } from "sonner";
import { demigodAPI } from "./DemigodAPIClient";

export default function DemigodPvPArena({ battleId, userId, battleData }) {
  const [solution, setSolution] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!solution.trim()) {
      toast.error("Please provide a solution");
      return;
    }

    setSubmitting(true);

    try {
      await demigodAPI.submitPvPSolution({
        battleId,
        userId,
        solution,
      });

      toast.success("Solution submitted successfully!");
      setSolution("");
    } catch (error) {
      console.error("Submission failed:", error);
      toast.error("Submission failed: " + error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const getBattleTypeColor = (type) => {
    switch (type) {
      case "coding": return "from-green-500 to-emerald-500";
      case "innovation": return "from-purple-500 to-pink-500";
      default: return "from-gray-500 to-slate-500";
    }
  };

  return (
    <div className="space-y-6">
      {/* Battle Header */}
      <Card className="border p-6" style={{
        background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
        borderColor: 'rgba(139, 92, 255, 0.3)'
      }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Swords className="w-5 h-5 text-orange-400" />
            {battleData?.title || "PvP Battle"}
          </h3>
          <Badge className={`bg-gradient-to-r ${getBattleTypeColor(battleData?.type)} text-white border-0`}>
            {battleData?.type?.toUpperCase() || "BATTLE"}
          </Badge>
        </div>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-cyan-400">
              {battleData?.participants || 2}
            </div>
            <div className="text-xs text-gray-400">Participants</div>
          </div>

          <div>
            <div className="text-2xl font-bold text-yellow-400">
              {battleData?.prize || 0} pts
            </div>
            <div className="text-xs text-gray-400">Prize Pool</div>
          </div>

          <div>
            <div className="text-2xl font-bold text-orange-400 flex items-center justify-center gap-1">
              <Clock className="w-4 h-4" />
              {battleData?.timeLeft || "∞"}
            </div>
            <div className="text-xs text-gray-400">Time Left</div>
          </div>
        </div>
      </Card>

      {/* Challenge Description */}
      {battleData?.challenge && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h4 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-400" />
            Challenge
          </h4>
          <p className="text-gray-300 leading-relaxed">
            {battleData.challenge}
          </p>

          {battleData.testCases && (
            <div className="mt-4 pt-4 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
              <h5 className="text-sm font-semibold text-gray-300 mb-2">Test Cases:</h5>
              <pre className="bg-[#0f0a1f] border border-[#1a1f2e] rounded-lg p-3 text-xs overflow-x-auto font-mono text-gray-300">
                {JSON.stringify(battleData.testCases, null, 2)}
              </pre>
            </div>
          )}
        </Card>
      )}

      {/* Solution Submission */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Code2 className="w-5 h-5 text-green-400" />
          Your Solution
        </h4>

        <Textarea
          value={solution}
          onChange={(e) => setSolution(e.target.value)}
          placeholder={battleData?.type === "coding" 
            ? "Write your code here..."
            : "Describe your innovative solution..."
          }
          className="bg-[#0f0a1f] border-[#1a1f2e] text-white font-mono text-sm min-h-[200px] mb-4"
        />

        <Button
          onClick={handleSubmit}
          disabled={submitting || !solution.trim()}
          className="w-full"
          style={{
            background: submitting ? '#4a5568' : 'linear-gradient(135deg, #10b981, #059669)',
            color: 'white'
          }}
        >
          {submitting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Submitting...
            </>
          ) : (
            <>
              <Send className="w-4 h-4 mr-2" />
              Submit Solution
            </>
          )}
        </Button>
      </Card>

      {/* Leaderboard */}
      {battleData?.leaderboard && battleData.leaderboard.length > 0 && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-400" />
            Leaderboard
          </h4>

          <div className="space-y-2">
            {battleData.leaderboard.map((entry, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-lg border"
                style={{
                  background: entry.userId === userId ? 'rgba(139, 92, 255, 0.1)' : 'rgba(5, 8, 22, 0.5)',
                  borderColor: entry.userId === userId ? 'rgba(139, 92, 255, 0.4)' : 'rgba(148, 163, 184, 0.2)'
                }}
              >
                <div className="flex items-center gap-3">
                  <div className={`text-xl font-bold ${
                    idx === 0 ? 'text-yellow-400' :
                    idx === 1 ? 'text-gray-300' :
                    idx === 2 ? 'text-orange-400' :
                    'text-gray-500'
                  }`}>
                    #{idx + 1}
                  </div>
                  <div>
                    <div className="font-semibold text-white">{entry.name}</div>
                    <div className="text-xs text-gray-400">
                      Score: {entry.score || 0}
                    </div>
                  </div>
                </div>

                {entry.submitted && (
                  <Badge className="bg-green-600/20 text-green-300 border-green-600/30 text-xs">
                    Submitted
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}