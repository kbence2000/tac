import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, User, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { demigodAPI } from "./DemigodAPIClient";

export default function DemigodMentoringBooker({ mentorId, mentorName }) {
  const [datetime, setDatetime] = useState("");
  const [topic, setTopic] = useState("");
  const [notes, setNotes] = useState("");
  const [booking, setBooking] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleBook = async () => {
    if (!datetime || !topic) {
      toast.error("Please fill in date/time and topic");
      return;
    }

    setBooking(true);
    setSuccess(false);

    try {
      const result = await demigodAPI.bookMentoring({
        mentorId,
        datetime,
        topic,
        notes: notes || undefined,
      });

      toast.success("Mentoring session booked successfully!");
      setSuccess(true);
      
      // Reset form
      setTimeout(() => {
        setDatetime("");
        setTopic("");
        setNotes("");
        setSuccess(false);
      }, 3000);
    } catch (error) {
      console.error("Booking failed:", error);
      toast.error("Booking failed: " + error.message);
    } finally {
      setBooking(false);
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Calendar className="w-5 h-5 text-purple-400" />
        Book Mentoring Session
        {mentorName && (
          <span className="text-sm text-gray-400 ml-2">with {mentorName}</span>
        )}
      </h3>

      {success ? (
        <div className="py-8 text-center">
          <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4" />
          <h4 className="text-xl font-bold text-green-300 mb-2">Session Booked!</h4>
          <p className="text-gray-400">You'll receive a confirmation email shortly.</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <label className="text-sm text-gray-300 mb-2 block flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Date & Time
            </label>
            <Input
              type="datetime-local"
              value={datetime}
              onChange={(e) => setDatetime(e.target.value)}
              className="bg-[#0f0a1f] border-[#1a1f2e] text-white"
            />
          </div>

          <div>
            <label className="text-sm text-gray-300 mb-2 block">Session Topic *</label>
            <Input
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., React performance optimization"
              className="bg-[#0f0a1f] border-[#1a1f2e] text-white"
            />
          </div>

          <div>
            <label className="text-sm text-gray-300 mb-2 block">Additional Notes (Optional)</label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Specific questions or areas you want to focus on..."
              className="bg-[#0f0a1f] border-[#1a1f2e] text-white min-h-[80px]"
            />
          </div>

          <Button
            onClick={handleBook}
            disabled={booking || !datetime || !topic}
            className="w-full"
            style={{
              background: booking ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
              color: 'white'
            }}
          >
            {booking ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Booking...
              </>
            ) : (
              <>
                <Calendar className="w-4 h-4 mr-2" />
                Book Session
              </>
            )}
          </Button>
        </div>
      )}
    </Card>
  );
}