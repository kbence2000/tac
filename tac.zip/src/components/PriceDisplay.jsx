import React from "react";
import { Badge } from "@/components/ui/badge";
import { Globe } from "lucide-react";

// Currency conversion rates
const FX_RATES = {
  USD_TO_HUF: 380,
  USD_TO_EUR: 0.92
};

function detectRegion(language = 'en') {
  const lang = language.toLowerCase();
  
  if (lang.includes('hu')) {
    return { lang: 'hu', currency: 'HUF', fx: FX_RATES.USD_TO_HUF, symbol: 'Ft' };
  }
  
  if (lang.includes('de') || lang.includes('fr') || lang.includes('es') || lang.includes('it')) {
    return { lang: 'en', currency: 'EUR', fx: FX_RATES.USD_TO_EUR, symbol: '€' };
  }
  
  return { lang: 'en', currency: 'USD', fx: 1, symbol: '$' };
}

function convertFromUSD(amountUSD, currency = 'HUF') {
  if (currency === 'USD') return amountUSD;
  if (currency === 'HUF') return Math.round(amountUSD * FX_RATES.USD_TO_HUF);
  if (currency === 'EUR') return Math.round(amountUSD * FX_RATES.USD_TO_EUR * 100) / 100;
  return amountUSD;
}

function formatPrice(amountUSD, region) {
  const converted = convertFromUSD(amountUSD, region.currency);
  
  if (region.currency === 'HUF') {
    return `${converted.toLocaleString('hu-HU')} Ft`;
  }
  
  if (region.currency === 'EUR') {
    return `€${converted.toLocaleString('de-DE')}`;
  }
  
  return `$${converted.toLocaleString('en-US')}`;
}

export default function PriceDisplay({ priceUSD, showCurrencyBadge = false, className = "" }) {
  // Detect region based on browser language (client-side only)
  const browserLang = typeof navigator !== 'undefined' ? (navigator.language || 'en') : 'en';
  const region = React.useMemo(() => detectRegion(browserLang), [browserLang]);

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <span>{formatPrice(priceUSD, region)}</span>
      {showCurrencyBadge && (
        <Badge variant="outline" className="border-[#1a1f2e] text-gray-400 flex items-center gap-1">
          <Globe className="w-3 h-3" />
          {region.currency}
        </Badge>
      )}
    </div>
  );
}