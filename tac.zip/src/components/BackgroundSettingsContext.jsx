import React, { createContext, useContext, useState, useEffect } from 'react';

const BackgroundSettingsContext = createContext(null);

export function BackgroundSettingsProvider({ children }) {
  const [hasWebGPU, setHasWebGPU] = useState(false);
  const [settings, setSettings] = useState(() => {
    // Load from localStorage
    const saved = localStorage.getItem('mdc-background-settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse settings:', e);
      }
    }
    return {
      type: 'particles', // '3d-neural' | 'webgpu' | 'particles' | 'minimal'
      speed: 1.0,
      intensity: 1.0,
      branchCount: 10,
      nodeCount: 160,
      connectionsPerNode: 4,
      rotationSpeed: 1.0
    };
  });

  // Check WebGPU support
  useEffect(() => {
    (async () => {
      if ('gpu' in navigator) {
        try {
          const adapter = await navigator.gpu.requestAdapter();
          setHasWebGPU(!!adapter);
          
          // Auto-upgrade to 3D Neural if available and user hasn't set preference
          const saved = localStorage.getItem('mdc-background-settings');
          if (!saved && adapter) {
            setSettings(prev => ({ ...prev, type: '3d-neural' }));
          }
        } catch (e) {
          console.error('WebGPU check failed:', e);
          setHasWebGPU(false);
        }
      }
    })();
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('mdc-background-settings', JSON.stringify(settings));
  }, [settings]);

  const updateSettings = (updates) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  return (
    <BackgroundSettingsContext.Provider value={{ settings, updateSettings, hasWebGPU }}>
      {children}
    </BackgroundSettingsContext.Provider>
  );
}

export function useBackgroundSettings() {
  const context = useContext(BackgroundSettingsContext);
  if (!context) {
    throw new Error('useBackgroundSettings must be used within BackgroundSettingsProvider');
  }
  return context;
}