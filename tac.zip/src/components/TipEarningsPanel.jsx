import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, Award, Zap } from "lucide-react";

const TIP_API = import.meta.env.VITE_TIP_BACKEND_URL || "http://localhost:3004";

export default function TipEarningsPanel({ demigodId }) {
  const { data: ledger, isLoading } = useQuery({
    queryKey: ['demigodLedger', demigodId],
    queryFn: async () => {
      if (!demigodId) return null;
      const res = await fetch(`${TIP_API}/api/ledger/${demigodId}`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!demigodId,
    refetchInterval: 30000,
  });

  if (isLoading) {
    return (
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="text-center py-8">
          <div className="w-8 h-8 border-2 border-green-500 border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </Card>
    );
  }

  if (!ledger) return null;

  const totalEarned = ledger.totalEarnedEUR || 0;
  const totalAnswered = ledger.totalAnswered || 0;
  const avgPerTip = totalAnswered > 0 ? totalEarned / totalAnswered : 0;

  const getTier = () => {
    if (totalEarned >= 100) return { label: "Legend", color: "text-yellow-400", bg: "bg-yellow-600/20", border: "border-yellow-600/30" };
    if (totalEarned >= 50) return { label: "Elite", color: "text-purple-400", bg: "bg-purple-600/20", border: "border-purple-600/30" };
    if (totalEarned >= 20) return { label: "Rising", color: "text-cyan-400", bg: "bg-cyan-600/20", border: "border-cyan-600/30" };
    return { label: "Starter", color: "text-gray-400", bg: "bg-gray-600/20", border: "border-gray-600/30" };
  };

  const tier = getTier();

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-gradient-to-br from-green-500/20 to-emerald-500/20">
          <DollarSign className="w-6 h-6 text-green-400" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-black text-white">Tip Earnings</h3>
          <p className="text-sm text-gray-400">Revenue from expert advice</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Total Earned */}
        <div className="text-center p-6 rounded-xl bg-gradient-to-br from-green-600/10 to-emerald-600/10 border border-green-600/30">
          <div className="text-5xl font-black mb-2" style={{
            background: "linear-gradient(135deg, #10B981, #059669)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            €{totalEarned.toFixed(2)}
          </div>
          <div className="text-sm text-gray-400 mb-3">Total Earned (80% share)</div>
          <Badge className={`${tier.bg} ${tier.color} border ${tier.border}`}>
            <Award className="w-3 h-3 mr-1" />
            {tier.label} Earner
          </Badge>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e] text-center">
            <div className="text-2xl font-bold text-white mb-1">{totalAnswered}</div>
            <div className="text-xs text-gray-400">Tips Answered</div>
          </div>

          <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e] text-center">
            <div className="text-2xl font-bold text-green-400 mb-1">€{avgPerTip.toFixed(2)}</div>
            <div className="text-xs text-gray-400">Avg per Tip</div>
          </div>
        </div>

        {/* Earning Tiers */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-gray-400 mb-2">Earning Tiers</h4>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between p-2 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <span className="text-xs text-gray-400">Starter</span>
              <Badge className="bg-gray-600/20 text-gray-400 border-gray-600/30 text-xs">
                €0-20
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <span className="text-xs text-gray-400">Rising</span>
              <Badge className="bg-cyan-600/20 text-cyan-400 border-cyan-600/30 text-xs">
                €20-50
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <span className="text-xs text-gray-400">Elite</span>
              <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30 text-xs">
                €50-100
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <span className="text-xs text-gray-400">Legend</span>
              <Badge className="bg-yellow-600/20 text-yellow-400 border-yellow-600/30 text-xs">
                €100+
              </Badge>
            </div>
          </div>
        </div>

        {/* How It Works */}
        <div className="p-4 rounded-lg bg-gradient-to-br from-green-600/10 to-emerald-600/10 border border-green-600/30">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-green-400" />
            <span className="text-xs font-bold text-white">How Tips Work</span>
          </div>
          <div className="text-xs text-gray-400 space-y-1">
            <div>• Users pay €1-5 for expert advice</div>
            <div>• Platform takes 20%, you earn 80%</div>
            <div>• Answer within 1 hour to maintain rating</div>
            <div>• Fast + quality answers = more requests</div>
          </div>
        </div>

        {/* Impact */}
        {totalAnswered > 0 && (
          <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-xs font-bold text-white">Your Impact</span>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              You've helped <strong className="text-white">{totalAnswered}</strong> developers 
              with expert advice, earning <strong className="text-green-400">€{totalEarned.toFixed(2)}</strong> total.
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}