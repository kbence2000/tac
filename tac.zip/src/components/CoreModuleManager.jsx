import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Grid3x3, Play, Loader2, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { coreAPI } from "./CoreAPIClient";

export default function CoreModuleManager() {
  const [modules, setModules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedModule, setSelectedModule] = useState(null);
  const [moduleInput, setModuleInput] = useState("{}");
  const [executing, setExecuting] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    fetchModules();
  }, []);

  const fetchModules = async () => {
    try {
      const data = await coreAPI.listModules();
      setModules(data.modules || []);
    } catch (error) {
      console.error("Failed to fetch modules:", error);
      toast.error("Failed to load modules");
    } finally {
      setLoading(false);
    }
  };

  const handleRunModule = async () => {
    if (!selectedModule) {
      toast.error("Please select a module");
      return;
    }

    let input;
    try {
      input = JSON.parse(moduleInput);
    } catch (error) {
      toast.error("Invalid JSON input");
      return;
    }

    setExecuting(true);
    setResult(null);

    try {
      const data = await coreAPI.runModule({
        moduleId: selectedModule.id,
        input,
      });

      setResult(data);
      toast.success("Module executed successfully");
    } catch (error) {
      console.error("Module execution failed:", error);
      toast.error("Module execution failed: " + error.message);
      setResult({ error: error.message });
    } finally {
      setExecuting(false);
    }
  };

  if (loading) {
    return (
      <Card className="border p-6 text-center" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-purple-400" />
        <p className="text-gray-400">Loading modules...</p>
      </Card>
    );
  }

  return (
    <div className="grid lg:grid-cols-[1fr_1.5fr] gap-6">
      {/* Module List */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Grid3x3 className="w-5 h-5 text-purple-400" />
          Available Modules
          <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs ml-auto">
            {modules.length}
          </Badge>
        </h3>

        <div className="space-y-2 max-h-96 overflow-y-auto">
          {modules.map((module) => (
            <button
              key={module.id}
              onClick={() => {
                setSelectedModule(module);
                setModuleInput(JSON.stringify(module.exampleInput || {}, null, 2));
              }}
              className={`w-full text-left p-3 rounded-lg border transition-all ${
                selectedModule?.id === module.id
                  ? 'bg-purple-600/20 border-purple-600/50'
                  : 'bg-[#0f0a1f] border-[#1a1f2e] hover:border-purple-600/30'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-white text-sm">{module.name}</span>
                <Badge className={`text-xs ${
                  module.status === 'active'
                    ? 'bg-green-600/20 text-green-300 border-green-600/30'
                    : 'bg-gray-600/20 text-gray-300 border-gray-600/30'
                }`}>
                  {module.status}
                </Badge>
              </div>
              <p className="text-xs text-gray-400 line-clamp-2">{module.description}</p>
            </button>
          ))}
        </div>
      </Card>

      {/* Module Execution */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Play className="w-5 h-5 text-cyan-400" />
          {selectedModule ? `Run: ${selectedModule.name}` : 'Select Module'}
        </h3>

        {selectedModule ? (
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Module Input (JSON)</label>
              <Textarea
                value={moduleInput}
                onChange={(e) => setModuleInput(e.target.value)}
                className="bg-[#0f0a1f] border-[#1a1f2e] text-white font-mono text-xs min-h-[120px]"
                placeholder='{"param": "value"}'
              />
            </div>

            <Button
              onClick={handleRunModule}
              disabled={executing}
              className="w-full"
              style={{
                background: executing ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
                color: 'white'
              }}
            >
              {executing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Executing...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Run Module
                </>
              )}
            </Button>

            {result && (
              <div className={`p-4 rounded-lg border ${
                result.error
                  ? 'bg-red-600/10 border-red-600/30'
                  : 'bg-green-600/10 border-green-600/30'
              }`}>
                <div className="flex items-center gap-2 mb-2">
                  {result.error ? (
                    <XCircle className="w-4 h-4 text-red-400" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                  )}
                  <span className={`text-sm font-semibold ${
                    result.error ? 'text-red-300' : 'text-green-300'
                  }`}>
                    {result.error ? 'Execution Failed' : 'Execution Successful'}
                  </span>
                </div>
                <pre className="text-xs overflow-x-auto text-gray-300">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-12 text-gray-400">
            <Grid3x3 className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Select a module to execute</p>
          </div>
        )}
      </Card>
    </div>
  );
}