import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export default function GlobalHealthWidget() {
  const [health, setHealth] = useState(null);

  const fetchHealth = async () => {
    try {
      const response = await base44.functions.invoke('globalSystemHealth', {
        snapshot: {
          source: "TAC-Core",
          layers: [
            { name: "logic", baseValue: 0.8, drift: 0.2 },
            { name: "creative", baseValue: 1.1, drift: 0.3 },
            { name: "resonance", baseValue: 0.5, drift: 0.1 }
          ],
          paradoxCheck: { exprA: "2+2", exprB: "4" }
        }
      });
      setHealth(response.data?.globalHealth);
    } catch (err) {
      console.error('Health fetch error:', err);
    }
  };

  useEffect(() => {
    fetchHealth();
    const interval = setInterval(fetchHealth, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!health) return null;

  return (
    <div className="p-6 rounded-xl border shadow-xl" style={{
      background: 'rgba(0, 0, 0, 0.9)',
      borderColor: 'rgba(147, 51, 234, 0.8)'
    }}>
      <h2 className="text-xl font-bold mb-4" style={{ color: 'rgb(216, 180, 254)' }}>
        GLOBAL SYSTEM HEALTH
      </h2>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-lg border shadow-md" style={{
          background: 'rgba(0, 0, 0, 0.6)',
          borderColor: 'rgba(88, 28, 135, 1)'
        }}>
          <p className="text-xs text-gray-400">Neural Stability</p>
          <p className="text-2xl font-bold" style={{ color: 'rgb(216, 180, 254)' }}>
            {(health.neuralStability * 100).toFixed(1)}%
          </p>
        </div>

        <div className="p-4 rounded-lg border shadow-md" style={{
          background: 'rgba(0, 0, 0, 0.6)',
          borderColor: 'rgba(88, 28, 135, 1)'
        }}>
          <p className="text-xs text-gray-400">Coherence Flow</p>
          <p className="text-2xl font-bold" style={{ color: 'rgb(216, 180, 254)' }}>
            {(health.coherenceFlow * 100).toFixed(1)}%
          </p>
        </div>

        <div className="p-4 rounded-lg border shadow-md" style={{
          background: 'rgba(0, 0, 0, 0.6)',
          borderColor: 'rgba(88, 28, 135, 1)'
        }}>
          <p className="text-xs text-gray-400">Entropy Pressure</p>
          <p className="text-2xl font-bold" style={{ color: 'rgb(252, 165, 165)' }}>
            {(health.entropyPressure * 100).toFixed(1)}%
          </p>
        </div>

        <div className="p-4 rounded-lg border shadow-md" style={{
          background: 'rgba(0, 0, 0, 0.6)',
          borderColor: 'rgba(88, 28, 135, 1)'
        }}>
          <p className="text-xs text-gray-400">Vitality Pulse</p>
          <p className="text-2xl font-bold" style={{ color: 'rgb(134, 239, 172)' }}>
            {(health.vitalityPulse * 100).toFixed(1)}
          </p>
        </div>
      </div>

      {/* Vitality Pulse Bar */}
      <div className="mt-6">
        <div className="text-xs text-gray-400 mb-2">Pulse Activity</div>
        <div className="w-full h-3 rounded-full overflow-hidden" style={{ background: 'rgb(31, 41, 55)' }}>
          <div 
            className="h-full transition-all duration-300"
            style={{
              width: `${health.vitalityPulse * 100}%`,
              background: 'linear-gradient(to right, rgb(192, 132, 252), rgb(232, 121, 249))'
            }}
          />
        </div>
      </div>
    </div>
  );
}