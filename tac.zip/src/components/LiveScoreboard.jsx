import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, TrendingUp, Zap } from "lucide-react";

export default function LiveScoreboard({ scores, matchFinishedData, isFinished }) {
  const displayScores = isFinished && matchFinishedData?.finalScores 
    ? matchFinishedData.finalScores 
    : scores;

  if (!displayScores || displayScores.length === 0) {
    return (
      <Card className="border-[#1a1f2e] bg-[#141923] p-4">
        <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-cyan-400" />
          Live Scoreboard
        </h3>
        <div className="text-xs text-gray-500 text-center py-4">
          No submissions yet. Submit your code to appear on the board!
        </div>
      </Card>
    );
  }

  const sortedScores = [...displayScores].sort((a, b) => b.score - a.score);

  return (
    <Card className="border-[#1a1f2e] bg-[#141923] p-4">
      <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
        {isFinished ? (
          <>
            <Trophy className="w-4 h-4 text-yellow-400" />
            Final Results
          </>
        ) : (
          <>
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            Live Scores
          </>
        )}
      </h3>

      <div className="space-y-2">
        {sortedScores.map((entry, index) => {
          const isWinner = index === 0 && isFinished;
          const isTop3 = index < 3;
          
          return (
            <div
              key={entry.playerId}
              className={`flex items-center justify-between p-3 rounded-lg border transition-all ${
                isWinner 
                  ? 'bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border-yellow-500/50' 
                  : 'bg-[#0a0a0f] border-[#1a1f2e]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${
                  isWinner 
                    ? 'bg-yellow-500 text-black'
                    : isTop3
                    ? 'bg-gray-600 text-white'
                    : 'bg-[#141923] text-gray-400'
                }`}>
                  {index + 1}
                </div>
                
                <div>
                  <div className={`text-sm font-semibold ${
                    isWinner ? 'text-yellow-400' : 'text-white'
                  }`}>
                    {entry.username}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Badge className={
                  entry.score >= 80 
                    ? 'bg-green-600/20 text-green-400 border-green-600/30'
                    : entry.score >= 60
                    ? 'bg-yellow-600/20 text-yellow-400 border-yellow-600/30'
                    : 'bg-gray-600/20 text-gray-400 border-gray-600/30'
                }>
                  {entry.score} pts
                </Badge>
                
                {isWinner && (
                  <Trophy className="w-5 h-5 text-yellow-400" />
                )}
              </div>
            </div>
          );
        })}
      </div>

      {!isFinished && (
        <div className="mt-3 p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e]">
          <div className="flex items-center gap-2">
            <Zap className="w-3 h-3 text-purple-400" />
            <span className="text-xs text-gray-400">
              Scores update in real-time as players submit code
            </span>
          </div>
        </div>
      )}
    </Card>
  );
}