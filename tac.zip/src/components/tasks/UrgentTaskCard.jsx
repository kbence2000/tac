import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Zap, TrendingUp, AlertCircle, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

/**
 * Urgent Task Card with Dynamic Pricing
 * As time runs out, the bid increases from starting_bid to max_bid
 */
export default function UrgentTaskCard({ task }) {
  const [timeLeft, setTimeLeft] = useState(0);
  const [currentBid, setCurrentBid] = useState(task.urgent_starting_bid || 0);
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    if (!task.urgent_expires_at) return;

    const calculateTimeAndBid = () => {
      const now = new Date().getTime();
      const expiresAt = new Date(task.urgent_expires_at).getTime();
      const createdAt = new Date(task.created_date).getTime();
      const totalDuration = expiresAt - createdAt;
      const remaining = expiresAt - now;

      if (remaining <= 0) {
        setIsExpired(true);
        setTimeLeft(0);
        setCurrentBid(task.urgent_max_bid || task.urgent_starting_bid || 0);
        return;
      }

      setTimeLeft(remaining);

      // Calculate current bid based on elapsed time
      const elapsed = now - createdAt;
      const progress = Math.min(elapsed / totalDuration, 1);
      
      const startBid = task.urgent_starting_bid || 0;
      const maxBid = task.urgent_max_bid || startBid;
      const bidIncrease = (maxBid - startBid) * progress;
      
      setCurrentBid(Math.round(startBid + bidIncrease));
    };

    calculateTimeAndBid();
    const interval = setInterval(calculateTimeAndBid, 1000);

    return () => clearInterval(interval);
  }, [task]);

  const formatTime = (ms) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((ms % (1000 * 60)) / 1000);
    
    if (hours > 0) {
      return `${hours}ó ${minutes}p ${seconds}mp`;
    }
    return `${minutes}p ${seconds}mp`;
  };

  const getUrgencyColor = () => {
    const hoursLeft = timeLeft / (1000 * 60 * 60);
    if (hoursLeft <= 2) return "text-red-500";
    if (hoursLeft <= 6) return "text-orange-500";
    if (hoursLeft <= 12) return "text-yellow-500";
    return "text-green-500";
  };

  const getProgressPercentage = () => {
    if (!task.urgent_expires_at) return 0;
    const now = new Date().getTime();
    const expiresAt = new Date(task.urgent_expires_at).getTime();
    const createdAt = new Date(task.created_date).getTime();
    const totalDuration = expiresAt - createdAt;
    const elapsed = now - createdAt;
    return Math.min((elapsed / totalDuration) * 100, 100);
  };

  return (
    <Card className="border-2 border-red-500/50 bg-gradient-to-br from-red-950/20 to-orange-950/20 p-6 hover:border-red-500 transition-all relative overflow-hidden">
      {/* Animated background pulse */}
      <div className="absolute inset-0 bg-gradient-to-r from-red-500/5 to-orange-500/5 animate-pulse pointer-events-none" />
      
      {/* Urgent Badge */}
      <div className="flex items-center justify-between mb-4 relative z-10">
        <Badge className="bg-red-600 text-white border-0 flex items-center gap-1 px-3 py-1">
          <Zap className="w-4 h-4" />
          SÜRGŐS
        </Badge>
        {isExpired ? (
          <Badge variant="outline" className="border-gray-600 text-gray-400">
            <AlertCircle className="w-4 h-4 mr-1" />
            Lejárt
          </Badge>
        ) : (
          <Badge className="bg-green-600/20 text-green-400 border border-green-600/50 flex items-center gap-1">
            <TrendingUp className="w-4 h-4" />
            Díj növekszik
          </Badge>
        )}
      </div>

      {/* Title & Description */}
      <div className="mb-4 relative z-10">
        <h3 className="text-xl font-bold text-white mb-2 line-clamp-2">{task.title}</h3>
        <p className="text-gray-400 text-sm line-clamp-3">{task.description}</p>
      </div>

      {/* Timer & Bid */}
      <div className="space-y-4 mb-4 relative z-10">
        {/* Countdown Timer */}
        <div className="flex items-center justify-between p-4 bg-[#0f1419] rounded-lg border border-[#1a1f2e]">
          <div className="flex items-center gap-2">
            <Clock className={`w-5 h-5 ${getUrgencyColor()}`} />
            <span className="text-gray-400 text-sm">Hátralévő idő:</span>
          </div>
          <span className={`text-lg font-black ${getUrgencyColor()}`}>
            {isExpired ? "0ó 0p 0mp" : formatTime(timeLeft)}
          </span>
        </div>

        {/* Dynamic Bid Display */}
        <div className="p-4 bg-gradient-to-r from-green-600/10 to-emerald-600/10 rounded-lg border border-green-600/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-400 text-sm">Jelenlegi díj:</span>
            <span className="text-3xl font-black text-green-400">
              {currentBid} {task.currency || 'EUR'}
            </span>
          </div>
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>Kezdő: {task.urgent_starting_bid} {task.currency || 'EUR'}</span>
            <span>Max: {task.urgent_max_bid} {task.currency || 'EUR'}</span>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-3 h-2 bg-[#1a1f2e] rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-1000"
              style={{ width: `${getProgressPercentage()}%` }}
            />
          </div>
        </div>
      </div>

      {/* Tech Stack */}
      {task.tech_stack && task.tech_stack.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4 relative z-10">
          {task.tech_stack.slice(0, 3).map((tech, idx) => (
            <Badge key={idx} variant="outline" className="border-[#1a1f2e] text-gray-400 text-xs">
              {tech}
            </Badge>
          ))}
          {task.tech_stack.length > 3 && (
            <Badge variant="outline" className="border-[#1a1f2e] text-gray-400 text-xs">
              +{task.tech_stack.length - 3}
            </Badge>
          )}
        </div>
      )}

      {/* CTA Button */}
      <Link to={createPageUrl("TaskDetail") + `?id=${task.id}`} className="relative z-10">
        <Button 
          disabled={isExpired}
          className={`w-full font-bold ${
            isExpired 
              ? 'bg-gray-700 text-gray-400 cursor-not-allowed' 
              : 'bg-gradient-to-r from-red-600 to-orange-600 text-white hover:from-red-700 hover:to-orange-700'
          }`}
        >
          {isExpired ? (
            <>
              <AlertCircle className="w-4 h-4 mr-2" />
              Lejárt Feladat
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 mr-2" />
              Gyors Jelentkezés
              <ExternalLink className="w-4 h-4 ml-2" />
            </>
          )}
        </Button>
      </Link>

      {/* Warning for low time */}
      {!isExpired && timeLeft < 2 * 60 * 60 * 1000 && (
        <div className="mt-3 p-2 bg-red-600/20 border border-red-600/50 rounded text-xs text-red-300 flex items-center gap-2 relative z-10">
          <AlertCircle className="w-4 h-4" />
          Figyelem! Kevesebb mint 2 óra van hátra!
        </div>
      )}
    </Card>
  );
}