import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollText, Info, AlertTriangle, XCircle, CheckCircle2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function MissionLogs({ logs }) {
  if (!logs || logs.length === 0) {
    return null;
  }

  const getLevelIcon = (level) => {
    switch (level) {
      case "error": return <XCircle className="w-4 h-4 text-red-400" />;
      case "warn": return <AlertTriangle className="w-4 h-4 text-orange-400" />;
      case "info": return <Info className="w-4 h-4 text-blue-400" />;
      case "success": return <CheckCircle2 className="w-4 h-4 text-green-400" />;
      default: return <Info className="w-4 h-4 text-gray-400" />;
    }
  };

  const getLevelColor = (level) => {
    switch (level) {
      case "error": return "bg-red-600/20 text-red-300 border-red-600/30";
      case "warn": return "bg-orange-600/20 text-orange-300 border-orange-600/30";
      case "info": return "bg-blue-600/20 text-blue-300 border-blue-600/30";
      case "success": return "bg-green-600/20 text-green-300 border-green-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <ScrollText className="w-5 h-5 text-purple-400" />
        Execution Logs
        <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs ml-auto">
          {logs.length} entries
        </Badge>
      </h3>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {logs.map((log, index) => (
          <div
            key={index}
            className="flex items-start gap-3 p-3 rounded-lg border hover:bg-white/5 transition-colors"
            style={{
              background: 'rgba(5, 8, 22, 0.5)',
              borderColor: 'rgba(148, 163, 184, 0.2)'
            }}
          >
            <div className="mt-0.5">
              {getLevelIcon(log.level)}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Badge className={`${getLevelColor(log.level)} text-xs`}>
                  {log.level || 'info'}
                </Badge>
                {log.phase && (
                  <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30 text-xs">
                    {log.phase}
                  </Badge>
                )}
                <span className="text-xs text-gray-500 ml-auto">
                  {log.at 
                    ? formatDistanceToNow(new Date(log.at), { addSuffix: true })
                    : 'now'
                  }
                </span>
              </div>
              
              <p className="text-sm text-gray-300 leading-relaxed">
                {log.message}
              </p>

              {log.meta && (
                <pre className="mt-2 p-2 rounded bg-[#0f0a1f] text-xs overflow-x-auto text-gray-400 border border-gray-800">
                  {JSON.stringify(log.meta, null, 2)}
                </pre>
              )}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}