import React from "react";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

// Currency conversion rates
const FX_RATES = {
  USD_TO_HUF: 380,
  USD_TO_EUR: 0.92
};

function convertFromUSD(amountUSD, currency = 'HUF') {
  if (currency === 'USD') return amountUSD;
  if (currency === 'HUF') return Math.round(amountUSD * FX_RATES.USD_TO_HUF);
  if (currency === 'EUR') return Math.round(amountUSD * FX_RATES.USD_TO_EUR * 100) / 100;
  return amountUSD;
}

function detectUserRegion() {
  const lang = (navigator.language || 'en').toLowerCase();
  
  if (lang.includes('hu')) {
    return { lang: 'hu', currency: 'HUF', fx: FX_RATES.USD_TO_HUF };
  }
  
  if (lang.includes('de') || lang.includes('fr') || lang.includes('es') || lang.includes('it')) {
    return { lang: 'en', currency: 'EUR', fx: FX_RATES.USD_TO_EUR };
  }
  
  return { lang: 'en', currency: 'USD', fx: 1 };
}

/**
 * Generate Revolut Pay payment link
 * Template: https://revolut.me/USERNAME/{AMOUNT}{CURRENCY}?desc={REF}
 */
function buildRevolutLink({ amountUSD, username, title, ref, region }) {
  if (!username) return null;
  
  const converted = convertFromUSD(amountUSD, region.currency);
  const amount = Math.round(converted);
  const currency = region.currency.toLowerCase(); // revolut.me expects lowercase
  const description = encodeURIComponent((title || 'CodeMarket Purchase').slice(0, 80));
  const reference = encodeURIComponent(ref || `CM-${Date.now()}`);
  
  return `https://revolut.me/${username}/${amount}${currency}?desc=${reference}`;
}

export default function RevolutPayButton({ 
  amountUSD, 
  revolutUsername, 
  projectTitle, 
  onPaymentInitiated,
  className = "",
  disabled = false 
}) {
  const handleClick = () => {
    const region = detectUserRegion();
    const ref = `CM-${Date.now().toString(36)}`;
    
    const link = buildRevolutLink({
      amountUSD,
      username: revolutUsername,
      title: projectTitle,
      ref,
      region
    });
    
    if (!link) {
      alert('Revolut payment not configured');
      return;
    }
    
    // Callback before redirect (optional - can track pending payment)
    if (onPaymentInitiated) {
      onPaymentInitiated({ ref, link, region });
    }
    
    // Redirect to Revolut payment page
    window.location.href = link;
  };
  
  if (!revolutUsername) {
    return null;
  }
  
  return (
    <Button
      type="button"
      onClick={handleClick}
      disabled={disabled}
      className={`bg-black hover:bg-gray-800 text-white flex items-center gap-2 ${className}`}
    >
      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
        <path d="M12.5 7H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
      </svg>
      Fizetés Revolut-tal
      <ExternalLink className="w-4 h-4" />
    </Button>
  );
}

// Export utilities for external use
export { buildRevolutLink, detectUserRegion, convertFromUSD };