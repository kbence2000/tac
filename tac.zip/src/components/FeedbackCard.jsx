import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import RankBadge from "./RankBadge";
import { MessageSquare, Weight, Sparkles, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function FeedbackCard({ feedback, showTarget = false }) {
  const {
    id,
    fromUserId,
    targetUserId,
    text,
    weight = 1,
    aiQuality = 50,
    createdAt,
    fromUserRank = "R4", // default assumption
  } = feedback;

  const weightColor = weight >= 4 ? "#F4C76A" : weight >= 2 ? "#8C46FF" : "#3B82F6";

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 hover:border-[#262637] transition-all">
      <div className="flex items-start gap-4">
        {/* Rank badge */}
        <div className="flex-shrink-0 pt-1">
          <RankBadge rank={fromUserRank} size="sm" showName={false} animated={false} />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span className="text-sm font-semibold text-white">
              {showTarget ? `To: ${targetUserId}` : `From: ${fromUserId}`}
            </span>
            
            <Badge 
              className="text-xs border-0"
              style={{
                background: `${weightColor}22`,
                color: weightColor,
              }}
            >
              <Weight className="w-3 h-3 mr-1" />
              Weight: {weight}x
            </Badge>

            <Badge 
              className="text-xs border-0"
              style={{
                background: "rgba(36, 228, 255, 0.15)",
                color: "#24E4FF",
              }}
            >
              <Sparkles className="w-3 h-3 mr-1" />
              Quality: {aiQuality}
            </Badge>
          </div>

          <p className="text-sm text-gray-300 leading-relaxed mb-3">
            {text}
          </p>

          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Clock className="w-3 h-3" />
            {formatDistanceToNow(new Date(createdAt), { addSuffix: true })}
          </div>
        </div>
      </div>
    </Card>
  );
}