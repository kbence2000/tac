import React from 'react';

export default function CodeRepoFileTree({ selectedFile, onFileSelect }) {
  const files = [
    { name: 'README.md', icon: '📄', path: 'README.md' },
    { 
      name: 'src/',
      icon: '📁',
      children: [
        { name: 'paradoxEngine.js', icon: '📄', path: 'paradoxEngine.js' },
        { name: 'chaosArchitect.js', icon: '📄', path: 'chaosArchitect.js' },
        { name: 'hallucinator.js', icon: '📄', path: 'hallucinator.js' },
      ]
    },
    { 
      name: 'ai-modules/',
      icon: '📁',
      children: [
        { name: 'valueAnalyst.py', icon: '📄', path: 'valueAnalyst.py' },
        { name: 'agentOrchestrator.py', icon: '📄', path: 'agentOrchestrator.py' },
        { name: 'evaluatorCore.py', icon: '📄', path: 'evaluatorCore.py' },
      ]
    },
  ];

  return (
    <div className="w-72 border-r border-purple-900/60 bg-[#0a0112] p-3 hidden lg:block">
      <div className="text-xs text-gray-400 uppercase tracking-widest mb-2">Files</div>

      <ul className="text-sm space-y-1">
        {files.map((item, idx) => (
          <li key={idx}>
            {item.children ? (
              <>
                <span className="block font-semibold mt-2 text-gray-300">{item.name}</span>
                <ul className="pl-4 space-y-1">
                  {item.children.map((child, childIdx) => (
                    <li 
                      key={childIdx}
                      onClick={() => onFileSelect(child.path)}
                      className={`cursor-pointer transition-colors ${
                        selectedFile === child.path ? 'text-purple-500' : 'hover:text-purple-500'
                      }`}
                    >
                      {child.icon} {child.name}
                    </li>
                  ))}
                </ul>
              </>
            ) : (
              <span 
                onClick={() => onFileSelect(item.path)}
                className={`cursor-pointer transition-colors ${
                  selectedFile === item.path ? 'text-purple-500' : 'hover:text-purple-500'
                }`}
              >
                {item.icon}  {item.name}
              </span>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}