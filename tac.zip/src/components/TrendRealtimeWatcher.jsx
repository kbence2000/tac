import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  Clock,
  TrendingUp,
  Zap,
  Radio
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function TrendRealtimeWatcher() {
  const [liveStatus, setLiveStatus] = useState('monitoring');
  const [lastUpdate, setLastUpdate] = useState(null);
  const [stats, setStats] = useState({
    totalSnippets: 0,
    activeSnippets: 0,
    activeSources: 0,
    lastHarvest: null
  });

  // Fetch snippets with auto-refresh
  const { data: snippets } = useQuery({
    queryKey: ['trendingSnippets'],
    queryFn: () => base44.entities.TrendingSnippet.list('-created_date', 100),
    initialData: [],
    refetchInterval: 30000 // Auto-refresh every 30 seconds
  });

  // Fetch sources with auto-refresh
  const { data: sources } = useQuery({
    queryKey: ['trendSources'],
    queryFn: () => base44.entities.TrendSource.list('-created_date'),
    initialData: [],
    refetchInterval: 30000
  });

  // Update stats when data changes
  useEffect(() => {
    if (snippets && sources) {
      const activeSnippets = snippets.filter(s => s.isActive).length;
      const activeSources = sources.filter(s => s.enabled).length;
      const recentSnippet = snippets[0];
      
      setStats({
        totalSnippets: snippets.length,
        activeSnippets,
        activeSources,
        lastHarvest: recentSnippet?.created_date || null
      });

      setLastUpdate(new Date().toISOString());
      
      // Set status based on activity
      if (activeSources === 0) {
        setLiveStatus('idle');
      } else if (activeSnippets > 0) {
        setLiveStatus('active');
      } else {
        setLiveStatus('monitoring');
      }
    }
  }, [snippets, sources]);

  const getStatusConfig = () => {
    switch (liveStatus) {
      case 'active':
        return {
          color: 'bg-green-600/20 text-green-300 border-green-600/30',
          icon: <Radio className="w-4 h-4 animate-pulse" />,
          text: 'LIVE',
          dot: 'bg-green-400'
        };
      case 'monitoring':
        return {
          color: 'bg-blue-600/20 text-blue-300 border-blue-600/30',
          icon: <Activity className="w-4 h-4" />,
          text: 'MONITORING',
          dot: 'bg-blue-400'
        };
      case 'idle':
        return {
          color: 'bg-gray-600/20 text-gray-400 border-gray-600/30',
          icon: <Clock className="w-4 h-4" />,
          text: 'IDLE',
          dot: 'bg-gray-400'
        };
      default:
        return {
          color: 'bg-purple-600/20 text-purple-300 border-purple-600/30',
          icon: <Zap className="w-4 h-4" />,
          text: 'READY',
          dot: 'bg-purple-400'
        };
    }
  };

  const statusConfig = getStatusConfig();

  const getTimeSince = (dateString) => {
    if (!dateString) return 'Never';
    
    const now = new Date();
    const then = new Date(dateString);
    const diffMs = now - then;
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffSecs < 60) return `${diffSecs}s ago`;
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  return (
    <Card className="border p-6 relative overflow-hidden" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      {/* Animated background pulse */}
      <div 
        className="absolute inset-0 opacity-20 pointer-events-none"
        style={{
          background: 'radial-gradient(circle at 50% 50%, rgba(139, 92, 255, 0.3), transparent 70%)',
          animation: liveStatus === 'active' ? 'pulse 3s ease-in-out infinite' : 'none'
        }}
      />

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.2; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.05); }
        }
      `}</style>

      {/* Header */}
      <div className="flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Activity className="w-8 h-8 text-purple-400" />
            <div 
              className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${statusConfig.dot}`}
              style={{
                boxShadow: `0 0 10px ${statusConfig.dot.includes('green') ? '#4ade80' : statusConfig.dot.includes('blue') ? '#60a5fa' : '#9ca3af'}`,
                animation: liveStatus === 'active' ? 'pulse 2s ease-in-out infinite' : 'none'
              }}
            />
          </div>
          <div>
            <h3 className="font-bold text-white text-lg">Real-Time Watcher</h3>
            <p className="text-xs text-gray-400">Auto-monitoring trending sources</p>
          </div>
        </div>

        <Badge className={statusConfig.color}>
          {statusConfig.icon}
          <span className="ml-2">{statusConfig.text}</span>
        </Badge>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 relative z-10">
        <div className="p-4 rounded-xl border" style={{
          background: 'rgba(15, 23, 42, 0.8)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            <span className="text-xs text-gray-400">Total</span>
          </div>
          <div className="text-2xl font-bold text-white">{stats.totalSnippets}</div>
          <div className="text-xs text-gray-500">snippets</div>
        </div>

        <div className="p-4 rounded-xl border" style={{
          background: 'rgba(15, 23, 42, 0.8)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle2 className="w-4 h-4 text-green-400" />
            <span className="text-xs text-gray-400">Active</span>
          </div>
          <div className="text-2xl font-bold text-white">{stats.activeSnippets}</div>
          <div className="text-xs text-gray-500">live</div>
        </div>

        <div className="p-4 rounded-xl border" style={{
          background: 'rgba(15, 23, 42, 0.8)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-purple-400" />
            <span className="text-xs text-gray-400">Sources</span>
          </div>
          <div className="text-2xl font-bold text-white">{stats.activeSources}</div>
          <div className="text-xs text-gray-500">enabled</div>
        </div>

        <div className="p-4 rounded-xl border" style={{
          background: 'rgba(15, 23, 42, 0.8)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-orange-400" />
            <span className="text-xs text-gray-400">Last Harvest</span>
          </div>
          <div className="text-sm font-bold text-white">
            {getTimeSince(stats.lastHarvest)}
          </div>
          <div className="text-xs text-gray-500">updated</div>
        </div>
      </div>

      {/* Status Messages */}
      <div className="space-y-2 relative z-10">
        <div className="flex items-center gap-2 text-sm">
          <div className={`w-2 h-2 rounded-full ${statusConfig.dot}`} />
          <span className="text-gray-300">
            {liveStatus === 'active' && 'System is actively monitoring and harvesting trends'}
            {liveStatus === 'monitoring' && 'Watching for new trending content across sources'}
            {liveStatus === 'idle' && 'No active sources configured - enable sources to start'}
          </span>
        </div>

        {lastUpdate && (
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Clock className="w-3 h-3" />
            <span>Last refresh: {getTimeSince(lastUpdate)}</span>
            <span className="text-gray-600">•</span>
            <span>Auto-refresh every 30s</span>
          </div>
        )}

        {stats.activeSources === 0 && (
          <div className="flex items-center gap-2 p-3 rounded-lg border mt-3" style={{
            background: 'rgba(245, 158, 11, 0.1)',
            borderColor: 'rgba(245, 158, 11, 0.3)'
          }}>
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <span className="text-sm text-yellow-300">
              No active sources - Enable sources to start real-time monitoring
            </span>
          </div>
        )}
      </div>
    </Card>
  );
}