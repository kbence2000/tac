import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Lock, Unlock, TrendingUp, DollarSign,
  Award, AlertCircle, CheckCircle2, Target
} from "lucide-react";
import { toast } from "sonner";

const STAKE_API = import.meta.env.VITE_STAKE_BACKEND_URL || "http://localhost:3005";

const STAKE_TIER_CONFIG = {
  S0: { label: "Rejected", color: "text-red-400", bg: "bg-red-600/20", border: "border-red-600/30" },
  S1: { label: "Acceptable", color: "text-gray-400", bg: "bg-gray-600/20", border: "border-gray-600/30" },
  S2: { label: "Good", color: "text-blue-400", bg: "bg-blue-600/20", border: "border-blue-600/30" },
  S3: { label: "High-Value", color: "text-cyan-400", bg: "bg-cyan-600/20", border: "border-cyan-600/30" },
  S4: { label: "Enterprise-Ready", color: "text-purple-400", bg: "bg-purple-600/20", border: "border-purple-600/30" },
  S5: { label: "Godlike-Enterprise", color: "text-yellow-400", bg: "bg-yellow-600/20", border: "border-yellow-600/30" }
};

export default function StakePanel({ project, onStakeComplete }) {
  const [isProcessing, setIsProcessing] = useState(false);
  const queryClient = useQueryClient();

  const stakeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${STAKE_API}/api/project/stake`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId: project.id })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Stake failed');
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      queryClient.invalidateQueries({ queryKey: ['stakedProjects'] });
      toast.success(`Staked! Tier: ${data.project.stakeTier} - ${data.project.stakeTierName}`);
      if (onStakeComplete) onStakeComplete(data.project);
    },
    onError: (error) => {
      toast.error(error.message);
    }
  });

  const unstakeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${STAKE_API}/api/project/unstake`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId: project.id })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Unstake failed');
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      queryClient.invalidateQueries({ queryKey: ['stakedProjects'] });
      toast.success("Project unstaked from enterprise pool");
      if (onStakeComplete) onStakeComplete(data.project);
    },
    onError: (error) => {
      toast.error(error.message);
    }
  });

  const handleStake = () => {
    setIsProcessing(true);
    stakeMutation.mutate();
    setTimeout(() => setIsProcessing(false), 1000);
  };

  const handleUnstake = () => {
    setIsProcessing(true);
    unstakeMutation.mutate();
    setTimeout(() => setIsProcessing(false), 1000);
  };

  const tierConfig = STAKE_TIER_CONFIG[project.stakeTier] || STAKE_TIER_CONFIG.S0;

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 rounded-lg bg-gradient-to-br from-indigo-500/20 to-purple-500/20">
          {project.isStaked ? (
            <Lock className="w-6 h-6 text-indigo-400" />
          ) : (
            <Unlock className="w-6 h-6 text-gray-400" />
          )}
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-black text-white">
            {project.isStaked ? "Staked for Enterprise" : "Stake Project"}
          </h3>
          <p className="text-sm text-gray-400">
            {project.isStaked 
              ? "Listed in enterprise pool for companies" 
              : "Add to enterprise pool for visibility"}
          </p>
        </div>
      </div>

      {!project.isStaked ? (
        <div className="space-y-4">
          <div className="p-4 rounded-lg bg-gradient-to-br from-indigo-600/10 to-purple-600/10 border border-indigo-600/30">
            <div className="flex items-start gap-2">
              <Target className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-bold text-white mb-2">How Staking Works</div>
                <ul className="text-xs text-gray-300 space-y-1">
                  <li>• Your project gets evaluated (S0-S5 tier)</li>
                  <li>• Listed in enterprise pool for companies</li>
                  <li>• AI suggests budget range based on quality</li>
                  <li>• Companies can request engagement</li>
                  <li>• You accept/reject offers</li>
                  <li>• Platform takes 18% fee on accepted deals</li>
                </ul>
              </div>
            </div>
          </div>

          <Button
            onClick={handleStake}
            disabled={isProcessing || stakeMutation.isPending}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold text-lg py-6"
          >
            {stakeMutation.isPending ? (
              <>Evaluating & Staking...</>
            ) : (
              <>
                <Lock className="w-5 h-5 mr-2" />
                Stake for Enterprise Pool
              </>
            )}
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Stake Tier Badge */}
          <div className="flex items-center justify-center mb-4">
            <Badge className={`${tierConfig.bg} ${tierConfig.color} border ${tierConfig.border} text-lg px-4 py-2`}>
              <Award className="w-5 h-5 mr-2" />
              {project.stakeTier} - {tierConfig.label}
            </Badge>
          </div>

          {/* Stake Score */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e] text-center">
              <div className="text-2xl font-bold text-white mb-1">{project.stakeScore}/100</div>
              <div className="text-xs text-gray-400">Stake Score</div>
            </div>

            <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e] text-center">
              <div className="text-2xl font-bold text-indigo-400 mb-1">{project.enterpriseFitScore}/100</div>
              <div className="text-xs text-gray-400">Enterprise Fit</div>
            </div>
          </div>

          {/* Budget Estimation */}
          <div className="p-4 rounded-lg bg-gradient-to-br from-green-600/10 to-emerald-600/10 border border-green-600/30">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-green-400" />
              <span className="text-sm font-bold text-white">AI Budget Estimate</span>
            </div>
            <div className="text-xs text-gray-400 mb-2">
              Range: €{project.basePriceMinEUR?.toLocaleString()} - €{project.basePriceMaxEUR?.toLocaleString()}
            </div>
            <div className="text-lg font-bold text-green-400">
              Suggested: €{project.suggestedBudgetEUR?.toLocaleString()}
            </div>
          </div>

          {/* Stake Notes */}
          {project.stakeNotes && (
            <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
              <div className="flex items-start gap-2">
                {project.stakeTier === "S0" ? (
                  <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                )}
                <p className="text-sm text-gray-300">{project.stakeNotes}</p>
              </div>
            </div>
          )}

          {/* Unstake Button */}
          <Button
            onClick={handleUnstake}
            disabled={isProcessing || unstakeMutation.isPending}
            variant="outline"
            className="w-full border-[#1a1f2e] text-white hover:bg-[#1a1f2e]"
          >
            {unstakeMutation.isPending ? (
              <>Unstaking...</>
            ) : (
              <>
                <Unlock className="w-5 h-5 mr-2" />
                Remove from Enterprise Pool
              </>
            )}
          </Button>

          {/* Performance Tip */}
          {project.stakeTier !== "S5" && (
            <div className="p-3 rounded-lg bg-blue-600/10 border border-blue-600/30">
              <div className="flex items-start gap-2">
                <TrendingUp className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-blue-300">
                  <strong>Improve stake tier:</strong> Add tests, docs, increase quality score
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}