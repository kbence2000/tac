import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Sparkles, Zap, TrendingUp, DollarSign, Loader2, CheckCircle2, Lightbulb, Code2, Save } from "lucide-react";
import { toast } from "sonner";

export default function AIAnalyzer({ code, onAnalysisComplete }) {
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [saving, setSaving] = useState(false);
  const [assetTitle, setAssetTitle] = useState("");

  const handleAnalyze = async () => {
    if (!code || code.trim().length === 0) {
      toast.error("Adj meg kódot az elemzéshez!");
      return;
    }

    setAnalyzing(true);
    
    try {
      const response = await fetch('/api/ai/fm-analyze-value', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code })
      });

      if (!response.ok) {
        throw new Error('AI analysis failed');
      }

      const data = await response.json();
      
      // Parse hybrid result (FutureMind + Snippet Analyzer)
      const qualityScore = parseQualityScore(data.value.quality, data.value.score);
      const complexity = parseComplexity(data.value.complexity);
      const estimatedPrice = parsePrice(data.value.price_estimate);

      const result = {
        // Value assessment
        qualityScore,
        complexity,
        estimatedPrice,
        fullAnalysis: data.value,
        
        // FutureMind data
        summary: data.summary || '',
        patterns: data.patterns || [],
        suggestions: data.suggestions || [],
        
        // Raw data
        raw: data
      };

      setAnalysis(result);
      
      if (onAnalysisComplete) {
        onAnalysisComplete(result);
      }

      toast.success("AI elemzés kész!");
    } catch (error) {
      console.error('AI Analysis error:', error);
      toast.error("AI elemzés sikertelen. Próbáld újra!");
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSaveAsset = async () => {
    if (!analysis) {
      toast.error("Nincs elemzés mentésre!");
      return;
    }

    if (!assetTitle || assetTitle.trim().length === 0) {
      toast.error("Add meg az asset címét!");
      return;
    }

    setSaving(true);

    try {
      const response = await fetch('/api/market/save-asset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: assetTitle,
          summary: analysis.summary,
          patterns: analysis.patterns,
          suggestions: analysis.suggestions,
          value: {
            quality: analysis.qualityScore,
            complexity: analysis.complexity,
            price_estimate: analysis.estimatedPrice,
            score: analysis.qualityScore
          }
        })
      });

      if (!response.ok) {
        throw new Error('Failed to save asset');
      }

      const result = await response.json();
      
      if (result.success) {
        toast.success("Asset sikeresen mentve a Pattern Library-be!");
        setAssetTitle("");
      }
    } catch (error) {
      console.error('Save asset error:', error);
      toast.error("Asset mentése sikertelen!");
    } finally {
      setSaving(false);
    }
  };

  // Helper: parse quality score to 1-5 number
  const parseQualityScore = (quality, score) => {
    // Try score first
    if (score && typeof score === 'number') return Math.round(score);
    if (score && typeof score === 'string') {
      const match = score.match(/(\d+)/);
      if (match) return Math.min(5, parseInt(match[1]));
    }
    
    // Try quality string
    if (typeof quality === 'string') {
      const lower = quality.toLowerCase();
      if (lower.includes('excellent') || lower.includes('5')) return 5;
      if (lower.includes('good') || lower.includes('4')) return 4;
      if (lower.includes('average') || lower.includes('3')) return 3;
      if (lower.includes('below') || lower.includes('2')) return 2;
      if (lower.includes('poor') || lower.includes('1')) return 1;
    }
    
    return 3; // default
  };

  // Helper: parse complexity to low/medium/high
  const parseComplexity = (complexity) => {
    if (!complexity) return 'medium';
    const str = String(complexity).toLowerCase();
    if (str.includes('low') || str.includes('simple')) return 'low';
    if (str.includes('high') || str.includes('complex') || str.includes('advanced')) return 'high';
    return 'medium';
  };

  // Helper: parse price estimate
  const parsePrice = (price) => {
    if (!price || price === 'N/A') return 0;
    
    // If it's already a number
    if (typeof price === 'number') return Math.round(price);
    
    // Extract number from string
    const match = String(price).match(/(\d+)/);
    return match ? parseInt(match[1]) : 0;
  };

  return (
    <div className="space-y-4">
      <Card className="border p-4" style={{
        background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
        borderColor: 'rgba(139, 92, 255, 0.3)'
      }}>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{
            background: 'linear-gradient(135deg, #8b5cff, #24e4ff)',
          }}>
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-white">AI Hybrid Analyzer</h3>
            <p className="text-xs text-gray-400">FutureMind + Snippet Analyzer</p>
          </div>
        </div>

        <p className="text-sm text-gray-300 mb-4">
          Hibrid AI elemzés: minőség, ár, komplexitás + pattern extraction és javaslatok.
        </p>

        <Button 
          onClick={handleAnalyze}
          disabled={analyzing || !code}
          className="w-full"
          style={{
            background: analyzing ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
            color: 'white'
          }}
        >
          {analyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Elemzés folyamatban...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 mr-2" />
              Hibrid AI Elemzés Indítása
            </>
          )}
        </Button>
      </Card>

      {analysis && (
        <div className="space-y-4 animate-fade-in">
          {/* Save Asset Card */}
          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(139, 92, 255, 0.4)'
          }}>
            <div className="flex items-center gap-2 mb-3">
              <Save className="w-5 h-5 text-purple-400" />
              <h4 className="font-bold text-white">Save to Pattern Library</h4>
            </div>
            <p className="text-sm text-gray-400 mb-3">
              Save this analysis for future reference and reuse
            </p>
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Asset title (e.g., 'React State Management Pattern')"
                value={assetTitle}
                onChange={(e) => setAssetTitle(e.target.value)}
                className="bg-[#141923] border-[#1a1f2e] text-white"
              />
              <Button
                onClick={handleSaveAsset}
                disabled={saving || !assetTitle}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                {saving ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Value Metrics */}
          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle2 className="w-5 h-5 text-green-400" />
              <h4 className="font-bold text-white">Érték Értékelés</h4>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="p-3 rounded-xl border text-center" style={{
                background: 'rgba(15, 23, 42, 0.9)',
                borderColor: 'rgba(148, 163, 184, 0.25)'
              }}>
                <div className="text-2xl font-bold mb-1" style={{
                  background: 'linear-gradient(135deg, #8b5cff, #24e4ff)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent'
                }}>
                  {analysis.qualityScore}/5
                </div>
                <div className="text-xs text-gray-400">Quality</div>
              </div>

              <div className="p-3 rounded-xl border text-center" style={{
                background: 'rgba(15, 23, 42, 0.9)',
                borderColor: 'rgba(148, 163, 184, 0.25)'
              }}>
                <Badge className={`mb-1 ${
                  analysis.complexity === 'low' ? 'bg-green-600/20 text-green-300 border-green-600/30' :
                  analysis.complexity === 'medium' ? 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30' :
                  'bg-red-600/20 text-red-300 border-red-600/30'
                }`}>
                  {analysis.complexity.toUpperCase()}
                </Badge>
                <div className="text-xs text-gray-400">Complexity</div>
              </div>

              <div className="p-3 rounded-xl border text-center" style={{
                background: 'rgba(15, 23, 42, 0.9)',
                borderColor: 'rgba(148, 163, 184, 0.25)'
              }}>
                <div className="flex items-center justify-center gap-1 mb-1">
                  <DollarSign className="w-4 h-4 text-green-400" />
                  <span className="text-lg font-bold text-white">{analysis.estimatedPrice}</span>
                </div>
                <div className="text-xs text-gray-400">Est. Value</div>
              </div>
            </div>
          </Card>

          {/* FutureMind Summary */}
          {analysis.summary && (
            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(139, 92, 255, 0.4)'
            }}>
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-5 h-5 text-purple-400" />
                <h4 className="font-bold text-white">FutureMind Summary</h4>
              </div>
              <p className="text-sm text-gray-300 leading-relaxed">
                {analysis.summary}
              </p>
            </Card>
          )}

          {/* Patterns */}
          {analysis.patterns && analysis.patterns.length > 0 && (
            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(36, 228, 255, 0.4)'
            }}>
              <div className="flex items-center gap-2 mb-3">
                <Code2 className="w-5 h-5 text-cyan-400" />
                <h4 className="font-bold text-white">Detected Patterns</h4>
              </div>
              <div className="space-y-3">
                {analysis.patterns.map((pattern, idx) => (
                  <div key={idx} className="p-3 rounded-lg border" style={{
                    background: 'rgba(5, 8, 22, 0.9)',
                    borderColor: 'rgba(148, 163, 184, 0.2)'
                  }}>
                    <div className="font-semibold text-cyan-300 mb-1 text-sm">
                      {pattern.name || `Pattern ${idx + 1}`}
                    </div>
                    {pattern.description && (
                      <p className="text-xs text-gray-400 mb-2">
                        {pattern.description}
                      </p>
                    )}
                    {pattern.when_to_use && (
                      <div className="text-xs text-gray-500">
                        <span className="text-gray-400">When to use:</span> {pattern.when_to_use}
                      </div>
                    )}
                    {pattern.language && (
                      <Badge className="mt-2 bg-cyan-600/20 text-cyan-300 border-cyan-600/30 text-xs">
                        {pattern.language}
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Suggestions */}
          {analysis.suggestions && analysis.suggestions.length > 0 && (
            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(255, 184, 77, 0.4)'
            }}>
              <div className="flex items-center gap-2 mb-3">
                <Lightbulb className="w-5 h-5 text-yellow-400" />
                <h4 className="font-bold text-white">Improvement Suggestions</h4>
              </div>
              <ul className="space-y-2">
                {analysis.suggestions.map((suggestion, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-gray-300">
                    <TrendingUp className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                    <span>{typeof suggestion === 'string' ? suggestion : suggestion.text || suggestion.description}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}