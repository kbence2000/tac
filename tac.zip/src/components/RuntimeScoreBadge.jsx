import React from "react";
import { Badge } from "@/components/ui/badge";
import { Zap, TrendingUp, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Runtime Score Badge Component
 * Visual indicator for runtime performance
 */
export default function RuntimeScoreBadge({ 
  score = 0, 
  showIcon = true,
  showLabel = true,
  size = "md",
  className = ""
}) {
  const getScoreColor = (score) => {
    if (score >= 80) return {
      bg: "bg-green-600/20",
      text: "text-green-400",
      border: "border-green-600/30",
      icon: Zap,
    };
    if (score >= 60) return {
      bg: "bg-cyan-600/20",
      text: "text-cyan-400",
      border: "border-cyan-600/30",
      icon: TrendingUp,
    };
    if (score >= 40) return {
      bg: "bg-yellow-600/20",
      text: "text-yellow-400",
      border: "border-yellow-600/30",
      icon: AlertTriangle,
    };
    return {
      bg: "bg-red-600/20",
      text: "text-red-400",
      border: "border-red-600/30",
      icon: AlertTriangle,
    };
  };

  const config = getScoreColor(score);
  const Icon = config.icon;

  const sizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  };

  const iconSizes = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5",
  };

  return (
    <Badge 
      className={cn(
        "border",
        config.bg,
        config.text,
        config.border,
        sizeClasses[size],
        className
      )}
    >
      {showIcon && <Icon className={cn(iconSizes[size], "mr-1")} />}
      {showLabel && "Runtime: "}
      <span className="font-bold">{score}</span>
    </Badge>
  );
}