import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle2, 
  Loader2, 
  RefreshCw,
  Zap,
  Lock,
  Unlock,
  Code2,
  XCircle,
  Activity,
  TrendingDown,
  Clock
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export default function SecurityDashboard() {
  const [scanning, setScanning] = useState(false);
  const [scanConfig, setScanConfig] = useState({
    successThreshold: 0.8,
    latencyThresholdMs: 2000
  });
  const [selectedModule, setSelectedModule] = useState(null);
  const [fixCode, setFixCode] = useState("");
  const [fixIssue, setFixIssue] = useState("");
  const [autoRelease, setAutoRelease] = useState(false);

  const queryClient = useQueryClient();

  // Fetch quarantine records
  const { data: quarantineRecords, isLoading } = useQuery({
    queryKey: ['securityQuarantine'],
    queryFn: async () => {
      const records = await base44.entities.SecurityQuarantine.list('-created_date');
      return records;
    },
    initialData: [],
    refetchInterval: 30000 // Auto-refresh every 30s
  });

  // Scan mutation
  const handleScan = async () => {
    setScanning(true);
    try {
      // Get all Mastermind metrics
      const metrics = await base44.entities.MastermindMetric.list('-created_date', 1000);
      
      // Compute module status
      const perModule = {};
      
      for (const m of metrics) {
        if (!perModule[m.moduleName]) {
          perModule[m.moduleName] = {
            moduleName: m.moduleName,
            role: m.role || 'unknown',
            count: 0,
            successCount: 0,
            errorCount: 0,
            latencySum: 0,
            latencyCount: 0,
            lastErrorCode: null,
            lastTs: null
          };
        }

        const agg = perModule[m.moduleName];
        agg.count++;

        if (m.success) agg.successCount++;
        else {
          agg.errorCount++;
          agg.lastErrorCode = m.errorCode || agg.lastErrorCode;
        }

        if (typeof m.latencyMs === 'number') {
          agg.latencySum += m.latencyMs;
          agg.latencyCount++;
        }

        agg.lastTs = m.created_date;
      }

      const summary = Object.values(perModule);
      let quarantinedCount = 0;

      // Check each module against thresholds
      for (const mod of summary) {
        const successRate = mod.count ? mod.successCount / mod.count : 1;
        const avgLatency = mod.latencyCount ? mod.latencySum / mod.latencyCount : null;

        const shouldQuarantine =
          successRate < scanConfig.successThreshold ||
          (avgLatency && avgLatency > scanConfig.latencyThresholdMs);

        if (shouldQuarantine) {
          const reason = [];
          if (successRate < scanConfig.successThreshold) {
            reason.push(`low success rate (${(successRate * 100).toFixed(1)}%)`);
          }
          if (avgLatency && avgLatency > scanConfig.latencyThresholdMs) {
            reason.push(`high latency (${Math.round(avgLatency)}ms)`);
          }

          // Check if already quarantined
          const existing = quarantineRecords.find(q => q.moduleName === mod.moduleName);
          
          if (existing) {
            // Update existing record
            await base44.entities.SecurityQuarantine.update(existing.id, {
              reason: reason.join(' & '),
              lastScan: new Date().toISOString(),
              lastErrorCode: mod.lastErrorCode,
              lastTs: mod.lastTs,
              successRate,
              avgLatency: avgLatency || 0
            });
          } else {
            // Create new quarantine record
            await base44.entities.SecurityQuarantine.create({
              moduleName: mod.moduleName,
              role: mod.role,
              status: 'quarantined',
              reason: reason.join(' & '),
              lastTs: mod.lastTs,
              lastErrorCode: mod.lastErrorCode,
              lastScan: new Date().toISOString(),
              successRate,
              avgLatency: avgLatency || 0
            });
          }
          
          quarantinedCount++;
        }
      }

      queryClient.invalidateQueries({ queryKey: ['securityQuarantine'] });
      toast.success(`Security scan complete! ${quarantinedCount} module(s) quarantined.`);
    } catch (error) {
      console.error('Scan error:', error);
      toast.error('Security scan failed!');
    } finally {
      setScanning(false);
    }
  };

  // Auto-fix mutation
  const handleAutoFix = async () => {
    if (!selectedModule || !fixCode) {
      toast.error('Please select a module and provide code!');
      return;
    }

    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are SECURITY-CODE-FIX AI. You receive module code and issue description.
        
Module: ${selectedModule.moduleName}
Issue: ${fixIssue || 'auto-detected by metrics'}

Code:
\`\`\`js
${fixCode}
\`\`\`

Return a JSON object with:
{
  "improved_code": "the fixed code",
  "explanation": "explanation of what was fixed"
}`,
        response_json_schema: {
          type: "object",
          properties: {
            improved_code: { type: "string" },
            explanation: { type: "string" }
          }
        }
      });

      // Update quarantine record with fix
      await base44.entities.SecurityQuarantine.update(selectedModule.id, {
        fix: {
          suggestedAt: new Date().toISOString(),
          improvedCode: response.improved_code,
          explanation: response.explanation,
          autoReleased: autoRelease
        },
        status: autoRelease ? 'released' : 'fixed_waiting_release',
        releasedAt: autoRelease ? new Date().toISOString() : null
      });

      queryClient.invalidateQueries({ queryKey: ['securityQuarantine'] });
      toast.success(autoRelease ? 'Module fixed and released!' : 'Fix generated! Awaiting release.');
      setSelectedModule(null);
      setFixCode("");
      setFixIssue("");
    } catch (error) {
      console.error('Auto-fix error:', error);
      toast.error('Auto-fix failed!');
    }
  };

  // Manual release mutation
  const handleRelease = async (record) => {
    try {
      await base44.entities.SecurityQuarantine.update(record.id, {
        status: 'released',
        releasedAt: new Date().toISOString()
      });

      queryClient.invalidateQueries({ queryKey: ['securityQuarantine'] });
      toast.success(`${record.moduleName} released from quarantine!`);
    } catch (error) {
      console.error('Release error:', error);
      toast.error('Release failed!');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'quarantined': return 'bg-red-600/20 text-red-300 border-red-600/30';
      case 'fixed_waiting_release': return 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30';
      case 'released': return 'bg-green-600/20 text-green-300 border-green-600/30';
      default: return 'bg-gray-600/20 text-gray-300 border-gray-600/30';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'quarantined': return <Lock className="w-5 h-5 text-red-400" />;
      case 'fixed_waiting_release': return <Clock className="w-5 h-5 text-yellow-400" />;
      case 'released': return <Unlock className="w-5 h-5 text-green-400" />;
      default: return <AlertTriangle className="w-5 h-5 text-gray-400" />;
    }
  };

  const activeQuarantine = quarantineRecords.filter(r => r.status === 'quarantined');
  const fixedWaiting = quarantineRecords.filter(r => r.status === 'fixed_waiting_release');
  const released = quarantineRecords.filter(r => r.status === 'released');

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center animate-pulse-glow" style={{
                background: 'linear-gradient(135deg, #ef4444, #dc2626)'
              }}>
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-black gradient-text">SECURITY AI</h1>
                <p className="text-sm text-gray-400">Auto-quarantine & code fixing</p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex items-center gap-3">
              <Lock className="w-8 h-8 text-red-400" />
              <div>
                <div className="text-2xl font-bold text-white">{activeQuarantine.length}</div>
                <div className="text-sm text-gray-400">Quarantined</div>
              </div>
            </div>
          </Card>

          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex items-center gap-3">
              <Clock className="w-8 h-8 text-yellow-400" />
              <div>
                <div className="text-2xl font-bold text-white">{fixedWaiting.length}</div>
                <div className="text-sm text-gray-400">Awaiting Release</div>
              </div>
            </div>
          </Card>

          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-8 h-8 text-green-400" />
              <div>
                <div className="text-2xl font-bold text-white">{released.length}</div>
                <div className="text-sm text-gray-400">Released</div>
              </div>
            </div>
          </Card>

          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex items-center gap-3">
              <Activity className="w-8 h-8 text-cyan-400" />
              <div>
                <div className="text-2xl font-bold text-white">{quarantineRecords.length}</div>
                <div className="text-sm text-gray-400">Total Records</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Scan Configuration */}
        <Card className="border p-6" style={{
          background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.05), rgba(220, 38, 38, 0.05))',
          borderColor: 'rgba(239, 68, 68, 0.3)'
        }}>
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-red-400" />
            <h2 className="text-xl font-bold text-white">Security Scan</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div>
              <Label className="text-white mb-2 block">Success Rate Threshold</Label>
              <Input
                type="number"
                step="0.1"
                min="0"
                max="1"
                value={scanConfig.successThreshold}
                onChange={(e) => setScanConfig(prev => ({ ...prev, successThreshold: parseFloat(e.target.value) }))}
                className="bg-[#141923] border-[#1a1f2e] text-white"
              />
              <p className="text-xs text-gray-500 mt-1">Modules below this rate will be quarantined</p>
            </div>

            <div>
              <Label className="text-white mb-2 block">Latency Threshold (ms)</Label>
              <Input
                type="number"
                value={scanConfig.latencyThresholdMs}
                onChange={(e) => setScanConfig(prev => ({ ...prev, latencyThresholdMs: parseInt(e.target.value) }))}
                className="bg-[#141923] border-[#1a1f2e] text-white"
              />
              <p className="text-xs text-gray-500 mt-1">Modules above this latency will be quarantined</p>
            </div>
          </div>

          <Button
            onClick={handleScan}
            disabled={scanning}
            className="w-full"
            style={{
              background: scanning ? '#4a5568' : 'linear-gradient(135deg, #ef4444, #dc2626)',
              color: 'white'
            }}
          >
            {scanning ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Scanning modules...
              </>
            ) : (
              <>
                <Shield className="w-4 h-4 mr-2" />
                Run Security Scan
              </>
            )}
          </Button>
        </Card>

        {/* Quarantine Records */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Lock className="w-5 h-5 text-red-400" />
            <h2 className="text-xl font-bold text-white">Quarantine Records</h2>
          </div>

          {isLoading ? (
            <div className="text-center py-20">
              <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-red-400" />
              <p className="text-gray-400">Loading quarantine records...</p>
            </div>
          ) : quarantineRecords.length === 0 ? (
            <Card className="border p-12 text-center" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(148, 163, 184, 0.35)'
            }}>
              <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">All Clear!</h3>
              <p className="text-gray-400">No modules in quarantine</p>
            </Card>
          ) : (
            <div className="space-y-4">
              {quarantineRecords.map(record => (
                <Card key={record.id} className="border p-6 hover:shadow-lg transition-all" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(record.status)}
                      <div>
                        <h3 className="font-bold text-white text-lg">{record.moduleName}</h3>
                        <p className="text-sm text-gray-500">{record.role}</p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(record.status)}>
                      {record.status.toUpperCase().replace(/_/g, ' ')}
                    </Badge>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <div className="text-sm text-gray-500 mb-1">Reason</div>
                      <div className="text-white flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-red-400" />
                        {record.reason}
                      </div>
                    </div>

                    {record.successRate != null && (
                      <div>
                        <div className="text-sm text-gray-500 mb-1">Success Rate</div>
                        <div className="text-white flex items-center gap-2">
                          <TrendingDown className="w-4 h-4 text-yellow-400" />
                          {(record.successRate * 100).toFixed(1)}%
                        </div>
                      </div>
                    )}

                    {record.avgLatency != null && (
                      <div>
                        <div className="text-sm text-gray-500 mb-1">Avg Latency</div>
                        <div className="text-white flex items-center gap-2">
                          <Clock className="w-4 h-4 text-orange-400" />
                          {Math.round(record.avgLatency)}ms
                        </div>
                      </div>
                    )}

                    {record.lastErrorCode && (
                      <div>
                        <div className="text-sm text-gray-500 mb-1">Last Error</div>
                        <div className="text-red-400 flex items-center gap-2">
                          <XCircle className="w-4 h-4" />
                          {record.lastErrorCode}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Fix Section */}
                  {record.fix && (
                    <div className="mt-4 pt-4 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
                      <div className="flex items-center gap-2 mb-3">
                        <Zap className="w-4 h-4 text-green-400" />
                        <h4 className="font-bold text-white">AI Fix Applied</h4>
                      </div>
                      <p className="text-sm text-gray-300 mb-3">{record.fix.explanation}</p>
                      <details className="text-sm">
                        <summary className="text-cyan-400 cursor-pointer hover:text-cyan-300">View Fixed Code</summary>
                        <pre className="mt-2 p-3 rounded-lg border overflow-x-auto text-xs" style={{
                          background: 'rgba(5, 8, 22, 0.9)',
                          borderColor: 'rgba(148, 163, 184, 0.2)'
                        }}>
                          <code className="text-gray-300">{record.fix.improvedCode}</code>
                        </pre>
                      </details>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-3 mt-4">
                    {record.status === 'quarantined' && (
                      <Button
                        onClick={() => setSelectedModule(record)}
                        variant="outline"
                        className="border-cyan-600/50 text-cyan-400 hover:bg-cyan-600/20"
                      >
                        <Code2 className="w-4 h-4 mr-2" />
                        Auto-Fix
                      </Button>
                    )}

                    {(record.status === 'quarantined' || record.status === 'fixed_waiting_release') && (
                      <Button
                        onClick={() => handleRelease(record)}
                        variant="outline"
                        className="border-green-600/50 text-green-400 hover:bg-green-600/20"
                      >
                        <Unlock className="w-4 h-4 mr-2" />
                        Release
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </section>

        {/* Auto-Fix Modal */}
        {selectedModule && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <Card className="border p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto" style={{
              background: 'rgba(15, 23, 42, 0.98)',
              borderColor: 'rgba(148, 163, 184, 0.35)'
            }}>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-white">Auto-Fix: {selectedModule.moduleName}</h2>
                  <p className="text-sm text-gray-400">Provide code for AI analysis</p>
                </div>
                <Button
                  onClick={() => setSelectedModule(null)}
                  variant="ghost"
                  size="icon"
                  className="text-gray-400 hover:text-white"
                >
                  <XCircle className="w-5 h-5" />
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="text-white mb-2 block">Module Code</Label>
                  <Textarea
                    value={fixCode}
                    onChange={(e) => setFixCode(e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white min-h-[300px] font-mono text-sm"
                    placeholder="Paste your module code here..."
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Issue Description (optional)</Label>
                  <Input
                    value={fixIssue}
                    onChange={(e) => setFixIssue(e.target.value)}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                    placeholder="Describe the issue (or leave blank for auto-detection)"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="autoRelease"
                    checked={autoRelease}
                    onChange={(e) => setAutoRelease(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <Label htmlFor="autoRelease" className="text-white cursor-pointer">
                    Auto-release after fix
                  </Label>
                </div>

                <Button
                  onClick={handleAutoFix}
                  disabled={!fixCode}
                  className="w-full"
                  style={{
                    background: 'linear-gradient(135deg, #8b5cff, #24e4ff)',
                    color: 'white'
                  }}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Generate AI Fix
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}