import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Code2, Lock, Unlock, Server, Shield, Copy, Check,
  ChevronRight, AlertCircle, Zap, Eye, EyeOff, Layers, Brain, RefreshCw, Sparkles, Bot, Activity
} from "lucide-react";
import { toast } from "sonner";

const IntegrationExample = ({ title, description, code, language = "javascript" }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    toast.success("Kod a vagolapa masolt!");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="mb-6">
      <div className="flex items-start justify-between mb-2">
        <div>
          <h4 className="font-bold text-white mb-1">{title}</h4>
          {description && <p className="text-sm text-gray-400">{description}</p>}
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-purple-500/30 hover:border-purple-500/50 transition-all"
        >
          {copied ? (
            <Check className="w-4 h-4 text-green-400" />
          ) : (
            <Copy className="w-4 h-4 text-gray-400" />
          )}
          <span className="text-xs text-gray-400">{copied ? "Copied!" : "Copy"}</span>
        </button>
      </div>
      <pre className="bg-[#0a0318] rounded-lg p-4 overflow-x-auto text-xs font-mono text-purple-200 border border-purple-500/20">
        {code}
      </pre>
    </div>
  );
};

export default function AlmightyIntegrationGuide() {
  const [activeTab, setActiveTab] = useState("overview");
  const [showRootKey, setShowRootKey] = useState(false);

  const tabs = [
    { id: "overview", label: "Overview", icon: Eye },
    { id: "public", label: "Public API", icon: Unlock },
    { id: "private", label: "Private API", icon: Lock },
    { id: "bridge", label: "Bridge.js", icon: Layers },
    { id: "overseer", label: "Meta Overseer", icon: Bot },
    { id: "examples", label: "Examples", icon: Code2 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-purple-500/30 bg-gradient-to-br from-purple-900/20 to-pink-900/20">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Server className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Backend Integracio</h2>
              <p className="text-sm text-gray-400">Teljes DarkBox Bridge + Meta Overseer AI Ecosystem</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-purple-600/20 border-purple-500/50 text-white'
                  : 'border-purple-500/20 text-gray-400 hover:border-purple-500/40'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="space-y-6">
        {/* Overview Tab */}
        {activeTab === "overview" && (
          <Card className="border-purple-500/30 bg-[#0b0816]">
            <div className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">Architektura Attekintes</h3>
              
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-purple-900/20 border border-purple-500/30">
                  <div className="flex items-start gap-3">
                    <Shield className="w-5 h-5 text-purple-400 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-purple-300 mb-2">Ketszintu Biztonsag</h4>
                      <div className="space-y-2 text-sm text-gray-300">
                        <div className="flex items-start gap-2">
                          <Unlock className="w-4 h-4 text-green-400 mt-0.5" />
                          <div>
                            <strong className="text-green-300">Public API:</strong> Minden user hivhatja - 
                            automatikus kodtanulas (<code className="text-xs bg-black/30 px-1 py-0.5 rounded">safeObserveCodeEvent</code>)
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <Lock className="w-4 h-4 text-red-400 mt-0.5" />
                          <div>
                            <strong className="text-red-300">Private API:</strong> Csak ROOT_MASTER_KEY-jel - 
                            privilegizalt hivások (<code className="text-xs bg-black/30 px-1 py-0.5 rounded">callAlmighty</code>)
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg border border-cyan-500/30 bg-cyan-900/10">
                    <div className="flex items-center gap-2 mb-3">
                      <Zap className="w-5 h-5 text-cyan-400" />
                      <h4 className="font-semibold text-white">Auto-Observation</h4>
                    </div>
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Snippet upload</li>
                      <li>• Project save (multi-file)</li>
                      <li>• PvP submission</li>
                      <li>• Debug fix</li>
                      <li>• App upload</li>
                      <li>• Cloud runtime</li>
                    </ul>
                  </div>

                  <div className="p-4 rounded-lg border border-pink-500/30 bg-pink-900/10">
                    <div className="flex items-center gap-2 mb-3">
                      <Lock className="w-5 h-5 text-pink-400" />
                      <h4 className="font-semibold text-white">Privileged Methods</h4>
                    </div>
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• <code className="text-xs">snapshot</code> - Get patterns</li>
                      <li>• <code className="text-xs">suggest</code> - Generate ideas</li>
                      <li>• <code className="text-xs">export</code> / <code className="text-xs">import</code> - State</li>
                      <li>• <code className="text-xs">self_reflect</code> - Platform code</li>
                      <li>• <code className="text-xs">module_reflection</code> - AI modules</li>
                      <li>• <code className="text-xs">hybrid_superpatterns</code> - Merge</li>
                      <li>• <code className="text-xs">meta_analysis</code> - Analyze all</li>
                      <li>• <code className="text-xs">meta_improvement_plan</code> - Plan</li>
                    </ul>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-gradient-to-br from-cyan-900/20 to-blue-900/20 border border-cyan-500/30">
                  <div className="flex items-start gap-3">
                    <Bot className="w-5 h-5 text-cyan-400 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-cyan-300 mb-2">Meta Overseer AI - Autonomous Ecosystem</h4>
                      <p className="text-sm text-gray-300 mb-3">
                        A <strong className="text-cyan-200">Meta Overseer</strong> egy autonóm AI orchestrator, 
                        ami a háttérben összefogja, fejleszti és innoválja az összes AI modult. 
                        Belső tesztekkel validál, majd csendesen frissít - <strong>zero user intervention</strong>.
                      </p>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="flex items-center gap-1">
                          <Activity className="w-3 h-3 text-green-400" />
                          <span className="text-gray-300">Autonóm működés</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Shield className="w-3 h-3 text-blue-400" />
                          <span className="text-gray-300">Belső tesztelés</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Zap className="w-3 h-3 text-purple-400" />
                          <span className="text-gray-300">Csendes frissítés</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="w-3 h-3 text-pink-400" />
                          <span className="text-gray-300">Show, don't tell</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-yellow-900/20 border border-yellow-500/30">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-yellow-400 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-yellow-300 mb-2">Fire-and-Forget Pattern</h4>
                      <p className="text-sm text-gray-300">
                        Az <code className="text-xs bg-black/30 px-1 py-0.5 rounded">observeCode</code> mindig 
                        async/background - <strong>soha nem blokkol</strong> user flowt. Ha AlmightyCore nem elerheto, 
                        silent fail, az app tovabb mukodik.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Public API Tab */}
        {activeTab === "public" && (
          <Card className="border-green-500/30 bg-[#0b0816]">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Unlock className="w-6 h-6 text-green-400" />
                <h3 className="text-xl font-bold text-white">Public API Endpoints</h3>
              </div>

              <IntegrationExample
                title="1. Snippet Upload"
                description="User kod feltoltese - auto observation"
                code={`app.post("/api/snippets/new", (req, res) => {
  const { userId, rank } = getUserContext(req);
  const { language, code, title } = req.body;
  
  const snippetId = "sn_" + crypto.randomBytes(4).toString("hex");
  
  // DB save logic...
  
  // AlmightyCore observation
  safeObserveCodeEvent({
    userId,
    rank,
    language: language || "unknown",
    code,
    sourceType: "snippet_upload",
    meta: { title, snippetId }
  });
  
  res.json({ ok: true, snippetId });
});`}
              />

              <IntegrationExample
                title="2. Project Save (Multi-File)"
                description="Teljes project mentese - minden file elemzesre kerul"
                code={`app.post("/api/projects/save", (req, res) => {
  const { userId, rank } = getUserContext(req);
  const { projectId, name, files } = req.body;
  
  // DB save logic...
  
  // Observe all files
  if (Array.isArray(files)) {
    files.forEach(file => {
      if (file.code) {
        safeObserveCodeEvent({
          userId,
          rank,
          language: file.language || "unknown",
          code: file.code,
          sourceType: "project_file",
          meta: { projectId, filePath: file.path }
        });
      }
    });
  }
  
  res.json({ ok: true, projectId });
});`}
              />

              <IntegrationExample
                title="3. PvP Submission"
                description="Coding PvP megoldas - rank-weighted observation"
                code={`app.post("/api/pvp/submit", (req, res) => {
  const { userId, rank } = getUserContext(req);
  const { matchId, language, solutionCode, score } = req.body;
  
  // PvP logic + scoring...
  
  safeObserveCodeEvent({
    userId,
    rank, // demigod = 3.0x weight!
    language,
    code: solutionCode,
    sourceType: "pvp_solution",
    meta: { matchId, score }
  });
  
  res.json({ ok: true, message: "Solution submitted" });
});`}
              />

              <IntegrationExample
                title="4. Debug Fix"
                description="Debug konzolbol jovo javitasok"
                code={`app.post("/api/debug/fix", (req, res) => {
  const { userId, rank } = getUserContext(req);
  const { language, fixedCode, issueId } = req.body;
  
  // Close ticket, notify user...
  
  safeObserveCodeEvent({
    userId,
    rank,
    language,
    code: fixedCode,
    sourceType: "debug_fix",
    meta: { issueId }
  });
  
  res.json({ ok: true });
});`}
              />
            </div>
          </Card>
        )}

        {/* Private API Tab */}
        {activeTab === "private" && (
          <Card className="border-red-500/30 bg-[#0b0816]">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Lock className="w-6 h-6 text-red-400" />
                <h3 className="text-xl font-bold text-white">Private API - ROOT Only</h3>
              </div>

              <div className="mb-6 p-4 rounded-lg bg-red-900/20 border border-red-500/30">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-400 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-red-300 mb-2">Security Warning</h4>
                    <p className="text-sm text-gray-300 mb-3">
                      Az alabbi endpointok <strong>CSAK a ROOT_MASTER_KEY</strong>-jel hivhatók. 
                      Ez a kulcs <strong>SOHA</strong> nem kerulhet client-side kod resze!
                    </p>
                    <div className="flex items-center gap-2">
                      <code className="text-xs bg-black/30 px-2 py-1 rounded text-red-200">
                        {showRootKey ? "AC_ROOT_KEY=your_secret_key_here_change_me" : "AC_ROOT_KEY=*********************"}
                      </code>
                      <button
                        onClick={() => setShowRootKey(!showRootKey)}
                        className="p-1 hover:bg-white/10 rounded"
                      >
                        {showRootKey ? (
                          <EyeOff className="w-4 h-4 text-gray-400" />
                        ) : (
                          <Eye className="w-4 h-4 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="p-3 rounded-lg border border-purple-500/30 bg-purple-900/10">
                  <h4 className="text-sm font-semibold text-purple-300 mb-2">Core Methods</h4>
                  <ul className="text-xs text-gray-300 space-y-1">
                    <li>• snapshot</li>
                    <li>• suggest</li>
                    <li>• export / import</li>
                  </ul>
                </div>
                <div className="p-3 rounded-lg border border-cyan-500/30 bg-cyan-900/10">
                  <h4 className="text-sm font-semibold text-cyan-300 mb-2">Advanced Methods</h4>
                  <ul className="text-xs text-gray-300 space-y-1">
                    <li>• self_reflect</li>
                    <li>• module_reflection</li>
                    <li>• hybrid_superpatterns</li>
                  </ul>
                </div>
                <div className="p-3 rounded-lg border border-pink-500/30 bg-pink-900/10">
                  <h4 className="text-sm font-semibold text-pink-300 mb-2">Meta Overseer</h4>
                  <ul className="text-xs text-gray-300 space-y-1">
                    <li>• meta_analysis</li>
                    <li>• meta_improvement_plan</li>
                  </ul>
                </div>
                <div className="p-3 rounded-lg border border-yellow-500/30 bg-yellow-900/10">
                  <h4 className="text-sm font-semibold text-yellow-300 mb-2">Future Methods</h4>
                  <ul className="text-xs text-gray-300 space-y-1">
                    <li>• meta_orchestrate</li>
                    <li>• auto_deploy</li>
                  </ul>
                </div>
              </div>

              <IntegrationExample
                title="Get Mastery Snapshot"
                code={`curl -X POST http://localhost:9400/_root/almighty/snapshot \\
  -H "Content-Type: application/json" \\
  -H "X-AC-Root-Key: YOUR_SECRET_KEY" \\
  -d '{"limit": 50}'`}
              />

              <IntegrationExample
                title="Self Reflect (Platform Code)"
                code={`curl -X POST http://localhost:9400/_root/almighty/self_reflect \\
  -H "Content-Type: application/json" \\
  -H "X-AC-Root-Key: YOUR_SECRET_KEY" \\
  -d '{
    "projectRoot": "/app",
    "meta": { "version": "1.0.0" }
  }'`}
              />

              <IntegrationExample
                title="Module Reflection (AI Modules)"
                code={`curl -X POST http://localhost:9400/_root/almighty/module_reflection \\
  -H "Content-Type: application/json" \\
  -H "X-AC-Root-Key: YOUR_SECRET_KEY" \\
  -d '{
    "roots": ["./core/ai_modules", "./modules/ai"],
    "meta": { "scan_type": "full" }
  }'`}
              />

              <IntegrationExample
                title="Hybrid Superpatterns"
                code={`curl -X POST http://localhost:9400/_root/almighty/hybrid_superpatterns \\
  -H "Content-Type: application/json" \\
  -H "X-AC-Root-Key: YOUR_SECRET_KEY" \\
  -d '{"limit": 20}'`}
              />

              <IntegrationExample
                title="Meta Analysis"
                code={`curl -X POST http://localhost:9400/_root/almighty/meta_analysis \\
  -H "Content-Type: application/json" \\
  -H "X-AC-Root-Key: YOUR_SECRET_KEY" \\
  -d '{"limit": 30}'`}
              />

              <IntegrationExample
                title="Meta Improvement Plan"
                code={`curl -X POST http://localhost:9400/_root/almighty/meta_improvement_plan \\
  -H "X-AC-Root-Key: YOUR_SECRET_KEY"`}
              />
            </div>
          </Card>
        )}

        {/* Bridge.js Tab */}
        {activeTab === "bridge" && (
          <Card className="border-purple-500/30 bg-[#0b0816]">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Layers className="w-6 h-6 text-purple-400" />
                <div>
                  <h3 className="text-xl font-bold text-white">Bridge.js - Complete Integration</h3>
                  <p className="text-sm text-gray-400">Osszes modul osszefogasa egy interfaceben</p>
                </div>
              </div>

              <IntegrationExample
                title="Complete bridge.js Implementation"
                description="Production-ready bridge osszes metoddal"
                code={`// core/almighty/bridge.js
const {
  observeCodeEvent,
  getMasterySnapshot,
  generateSuggestions,
  exportState,
  importState
} = require("./engine");
const { selfReflect } = require("./self_reflect");
const { reflectModules } = require("./module_reflection");
const { buildHybridSuperpatterns } = require("./hybrid_superpatterns");
const { analyzeModules, generateModuleImprovementPlan } = require("./meta_overseer");

// Root kulcs
const ROOT_MASTER_KEY = process.env.AC_ROOT_KEY || "CHANGE_ME_SECRET_KEY";

// PUBLIC: Safe observation wrapper
function safeObserveCodeEvent(payload) {
  try {
    return observeCodeEvent(payload);
  } catch (err) {
    console.error("safeObserveCodeEvent error:", err.message);
    return null;
  }
}

// PRIVATE: Privileged calls (ROOT only)
function callAlmighty(method, args, masterKey) {
  if (!masterKey || masterKey !== ROOT_MASTER_KEY) {
    throw new Error("Unauthorized AlmightyCollective access");
  }

  switch (method) {
    // Core methods
    case "snapshot":
      return getMasterySnapshot(args && args.limit);
    
    case "suggest":
      return generateSuggestions(args.goal, args.language);
    
    case "export":
      return exportState();
    
    case "import":
      importState(args.snapshot);
      return { ok: true };
    
    // Self Reflection
    case "self_reflect":
      return selfReflect(args.projectRoot || process.cwd(), args.meta);
    
    // Module Reflection
    case "module_reflection":
      return reflectModules({
        roots: args.roots || [],
        meta: args.meta || {}
      });
    
    // Hybrid Superpatterns
    case "hybrid_superpatterns":
      return buildHybridSuperpatterns(args && args.limit);
    
    // Meta Overseer
    case "meta_analysis":
      return analyzeModules(args && args.limit);
    
    case "meta_improvement_plan":
      return generateModuleImprovementPlan();
    
    default:
      throw new Error("Unknown AlmightyCollective method");
  }
}

module.exports = {
  safeObserveCodeEvent,
  callAlmighty
};`}
              />

              <div className="mt-6 p-4 rounded-lg bg-cyan-900/20 border border-cyan-500/30">
                <div className="flex items-start gap-3">
                  <Zap className="w-5 h-5 text-cyan-400 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-cyan-300 mb-2">Method Categories</h4>
                    <div className="space-y-3 text-sm text-gray-300">
                      <div>
                        <strong className="text-cyan-200">Core (4):</strong> snapshot, suggest, export, import
                      </div>
                      <div>
                        <strong className="text-purple-200">Reflection (2):</strong> self_reflect, module_reflection
                      </div>
                      <div>
                        <strong className="text-pink-200">Hybrid (1):</strong> hybrid_superpatterns
                      </div>
                      <div>
                        <strong className="text-yellow-200">Meta (2):</strong> meta_analysis, meta_improvement_plan
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 rounded-lg bg-yellow-900/20 border border-yellow-500/30">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-yellow-400 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-yellow-300 mb-2">Security Best Practices</h4>
                    <ul className="text-sm text-gray-300 space-y-2">
                      <li>✅ ROOT_MASTER_KEY csak server-side environment variable</li>
                      <li>✅ safeObserveCodeEvent public, soha nem throw error</li>
                      <li>✅ callAlmighty private, mindig ellenorzi a master key-t</li>
                      <li>✅ Minden privileged method auth-olva van</li>
                      <li>✅ Client soha nem lathaja a ROOT_MASTER_KEY-t</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Meta Overseer Tab */}
        {activeTab === "overseer" && (
          <Card className="border-cyan-500/30 bg-[#0b0816]">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Bot className="w-6 h-6 text-cyan-400" />
                <div>
                  <h3 className="text-xl font-bold text-white">Meta Overseer AI</h3>
                  <p className="text-sm text-gray-400">Autonom AI orchestrator - osszefogas, fejlesztes, innovacio</p>
                </div>
              </div>

              <div className="mb-6 p-4 rounded-lg bg-gradient-to-br from-cyan-900/20 to-blue-900/20 border border-cyan-500/30">
                <div className="flex items-start gap-3">
                  <Bot className="w-5 h-5 text-cyan-400 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-cyan-300 mb-2">Autonomous Orchestration</h4>
                    <p className="text-sm text-gray-300 mb-3">
                      A Meta Overseer a <strong className="text-cyan-200">"Show, Don't Tell"</strong> elvet követi. 
                      A user csak a javulast latja: jobb javaslatok, pontosabb AI, optimalizaltabb modulok.
                    </p>
                    <div className="space-y-2 text-sm text-gray-300">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-cyan-400" />
                        <span><strong>analyzeModules:</strong> Osszes AI modul elemzese</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-blue-400" />
                        <span><strong>generateModuleImprovementPlan:</strong> Fejlesztesi terv generalasa</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-purple-400" />
                        <span><strong>Internal Testing:</strong> Benchmark validation</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-pink-400" />
                        <span><strong>Silent Deploy:</strong> Csendes frissites (ha sikeres)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <IntegrationExample
                title="Meta Analysis"
                description="Osszes modul elemzese es cross-pollination lehetosegek"
                code={`// Minimal meta_overseer.js example
function analyzeModules(limit = 30) {
  const snapshot = exportState();
  const patterns = snapshot.patterns || [];
  
  // Group by sourceType (ai_module, self_reflection, user, etc)
  const groups = {};
  patterns.forEach(p => {
    const st = p.sourceType || "unknown";
    if (!groups[st]) groups[st] = [];
    groups[st].push(p);
  });
  
  // Find top patterns per group
  const analysis = Object.keys(groups).map(sourceType => {
    const group = groups[sourceType];
    const top = group
      .sort((a, b) => (b.weight || 0) - (a.weight || 0))
      .slice(0, limit);
    
    return {
      sourceType,
      totalPatterns: group.length,
      topPatterns: top.map(p => ({
        pattern: p.normalized,
        weight: p.weight,
        language: p.language
      }))
    };
  });
  
  return { ok: true, analysis };
}

module.exports = { analyzeModules };`}
              />

              <IntegrationExample
                title="Generate Module Improvement Plan"
                description="Fejlesztesi terv AI modulokhoz"
                code={`function generateModuleImprovementPlan() {
  const analysis = analyzeModules(50);
  const improvements = [];
  
  // Compare ai_module patterns with self_reflection
  const aiModules = analysis.analysis.find(a => a.sourceType === "ai_module");
  const selfReflect = analysis.analysis.find(a => a.sourceType === "self_reflection");
  
  if (aiModules && selfReflect) {
    // Find patterns in platform code that AI modules should adopt
    selfReflect.topPatterns.slice(0, 10).forEach(pattern => {
      improvements.push({
        type: "adopt_platform_pattern",
        pattern: pattern.pattern,
        language: pattern.language,
        suggestion: \`AI modules should adopt this platform pattern: \${pattern.pattern}\`,
        priority: Math.round(pattern.weight / 10)
      });
    });
  }
  
  // Cross-module opportunities
  if (aiModules && aiModules.totalPatterns > 100) {
    improvements.push({
      type: "consolidate_ai_modules",
      suggestion: \`AI modules have \${aiModules.totalPatterns} patterns. Consider consolidation.\`,
      priority: 8
    });
  }
  
  return {
    ok: true,
    improvements: improvements.sort((a, b) => b.priority - a.priority)
  };
}

module.exports = { generateModuleImprovementPlan };`}
              />

              <div className="mt-6 p-4 rounded-lg bg-purple-900/20 border border-purple-500/30">
                <div className="flex items-start gap-3">
                  <Activity className="w-5 h-5 text-purple-400 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-purple-300 mb-2">Workflow Example</h4>
                    <div className="space-y-2 text-sm text-gray-300 font-mono">
                      <div>1. Run <code className="bg-black/30 px-1 rounded">self_reflect</code> → platform patterns</div>
                      <div>2. Run <code className="bg-black/30 px-1 rounded">module_reflection</code> → AI module patterns</div>
                      <div>3. Run <code className="bg-black/30 px-1 rounded">meta_analysis</code> → compare groups</div>
                      <div>4. Run <code className="bg-black/30 px-1 rounded">meta_improvement_plan</code> → generate plan</div>
                      <div className="text-cyan-300">5. Review plan → implement top improvements</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Examples Tab */}
        {activeTab === "examples" && (
          <Card className="border-cyan-500/30 bg-[#0b0816]">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Code2 className="w-6 h-6 text-cyan-400" />
                <h3 className="text-xl font-bold text-white">Teljes Server Pelda</h3>
              </div>

              <IntegrationExample
                title="Full Express Server with All Methods"
                description="Production-ready MDC + AlmightyCore + Meta Overseer"
                code={`const express = require("express");
const crypto = require("crypto");
const { safeObserveCodeEvent, callAlmighty } = require("./core/almighty/bridge");

const app = express();
app.use(express.json({ limit: "1mb" }));

function getUserContext(req) {
  const userId = req.headers["x-mdc-user"] || "anon";
  const rank = req.headers["x-mdc-rank"] || "regular";
  return { userId, rank };
}

// ========== PUBLIC ENDPOINTS ==========

app.post("/api/snippets/new", (req, res) => {
  const { userId, rank } = getUserContext(req);
  const { language, code, title } = req.body;
  
  const snippetId = "sn_" + crypto.randomBytes(4).toString("hex");
  // DB save...
  
  safeObserveCodeEvent({
    userId, rank, language, code,
    sourceType: "snippet_upload",
    meta: { title, snippetId }
  });
  
  res.json({ ok: true, snippetId });
});

app.post("/api/projects/save", (req, res) => {
  const { userId, rank } = getUserContext(req);
  const { projectId, files } = req.body;
  
  if (Array.isArray(files)) {
    files.forEach(file => {
      if (file.code) {
        safeObserveCodeEvent({
          userId, rank,
          language: file.language,
          code: file.code,
          sourceType: "project_file",
          meta: { projectId, filePath: file.path }
        });
      }
    });
  }
  
  res.json({ ok: true, projectId });
});

// ========== PRIVATE ROOT ENDPOINTS ==========

app.post("/_root/almighty/:method", (req, res) => {
  const providedKey = req.headers["x-ac-root-key"];
  const method = req.params.method;
  const args = req.body;
  
  try {
    const result = callAlmighty(method, args, providedKey);
    res.json({ ok: true, result });
  } catch (err) {
    if (err.message.includes("Unauthorized")) {
      return res.status(403).json({ ok: false });
    }
    res.status(500).json({ ok: false });
  }
});

const PORT = process.env.PORT || 9400;
app.listen(PORT, () => {
  console.log("🔥 MDC + AlmightyCore + Meta Overseer running on", PORT);
});`}
              />

              <div className="mt-6 p-4 rounded-lg bg-purple-900/20 border border-purple-500/30">
                <h4 className="font-semibold text-purple-300 mb-3">Environment Variables</h4>
                <div className="space-y-2 text-sm font-mono">
                  <div className="flex items-center gap-3">
                    <code className="text-purple-200">PORT</code>
                    <span className="text-gray-400">=</span>
                    <code className="text-cyan-300">9400</code>
                  </div>
                  <div className="flex items-center gap-3">
                    <code className="text-purple-200">AC_ROOT_KEY</code>
                    <span className="text-gray-400">=</span>
                    <code className="text-red-300">your_secret_master_key_here</code>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        )}
      </div>

      {/* Footer */}
      <Card className="border-purple-500/30 bg-gradient-to-br from-purple-900/20 to-pink-900/20">
        <div className="p-6">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-purple-400 mt-0.5" />
            <div>
              <h4 className="font-semibold text-purple-300 mb-2">Complete Module List</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
                <code className="text-xs bg-black/30 px-2 py-1 rounded text-cyan-200">engine.js</code>
                <code className="text-xs bg-black/30 px-2 py-1 rounded text-purple-200">bridge.js</code>
                <code className="text-xs bg-black/30 px-2 py-1 rounded text-pink-200">self_reflect.js</code>
                <code className="text-xs bg-black/30 px-2 py-1 rounded text-blue-200">module_reflection.js</code>
                <code className="text-xs bg-black/30 px-2 py-1 rounded text-yellow-200">hybrid_superpatterns.js</code>
                <code className="text-xs bg-black/30 px-2 py-1 rounded text-green-200">meta_overseer.js</code>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-green-600/20 text-green-300 border-green-600/30">Zero-dependency</Badge>
                <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30">HTTP-agnostic</Badge>
                <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30">White-label ready</Badge>
                <Badge className="bg-pink-600/20 text-pink-300 border-pink-600/30">Self-learning</Badge>
                <Badge className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30">Hybrid intelligence</Badge>
                <Badge className="bg-blue-600/20 text-blue-300 border-blue-600/30">Meta orchestration</Badge>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}