import React, { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  Pause, 
  Clock, 
  Activity, 
  CheckCircle2, 
  AlertTriangle,
  Settings,
  Zap
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function APCAutoIngest() {
  const [isRunning, setIsRunning] = useState(false);
  const [interval, setInterval] = useState(10); // minutes
  const [nextRun, setNextRun] = useState(null);
  const [lastRun, setLastRun] = useState(null);
  const [lastResult, setLastResult] = useState(null);
  const [currentRun, setCurrentRun] = useState(null);
  
  const intervalRef = useRef(null);
  const countdownRef = useRef(null);

  // Load saved settings
  useEffect(() => {
    const savedSettings = localStorage.getItem('apc_auto_ingest_settings');
    if (savedSettings) {
      try {
        const { isRunning: wasRunning, interval: savedInterval } = JSON.parse(savedSettings);
        setInterval(savedInterval || 10);
        if (wasRunning) {
          // Don't auto-start on page load, but show it was running
          toast.info('Auto-ingest was running. Click Start to resume.');
        }
      } catch (e) {
        console.error('Failed to load auto-ingest settings:', e);
      }
    }
  }, []);

  // Save settings
  useEffect(() => {
    localStorage.setItem('apc_auto_ingest_settings', JSON.stringify({
      isRunning,
      interval
    }));
  }, [isRunning, interval]);

  // Countdown timer
  useEffect(() => {
    if (isRunning && nextRun) {
      countdownRef.current = setInterval(() => {
        const now = Date.now();
        if (now >= nextRun) {
          setNextRun(null);
        }
      }, 1000);
    }

    return () => {
      if (countdownRef.current) {
        clearInterval(countdownRef.current);
      }
    };
  }, [isRunning, nextRun]);

  const runIngest = async () => {
    const startTime = Date.now();
    setCurrentRun({ status: 'running', startTime });

    try {
      // Log activity start
      const activity = await base44.entities.APCActivity.create({
        activityType: 'auto_ingest',
        status: 'in_progress',
        details: {
          intervalMinutes: interval,
          triggeredAt: new Date().toISOString()
        }
      });

      // 1. Fetch trending snippets
      const snippets = await base44.entities.TrendingSnippet.list('-created_date', 50);

      if (snippets.length === 0) {
        const duration = Date.now() - startTime;
        await base44.entities.APCActivity.update(activity.id, {
          status: 'error',
          errorMessage: 'No trending snippets available',
          duration
        });

        setLastResult({
          success: false,
          error: 'No snippets available',
          timestamp: Date.now()
        });
        setCurrentRun(null);
        toast.warning('Auto-ingest: No snippets available');
        return;
      }

      // 2. Prepare data for AI
      const limited = snippets.slice(0, 12).map((s, i) => ({
        idx: i,
        title: s.title,
        source: s.source,
        code: s.code,
        language: s.language
      }));

      // 3. AI Pattern Extraction
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are APC (Almighty Pattern Collector). Extract reusable code patterns from these trending snippets.

Analyze the code and identify:
- Common patterns (async handling, state management, UI patterns, etc.)
- Reusable concepts
- Innovation level (0-100)
- Usage frequency estimate (0-100)

Merge similar patterns and provide distinct, valuable patterns only.

Snippets:
${JSON.stringify(limited, null, 2)}`,
        response_json_schema: {
          type: "object",
          properties: {
            patterns: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  description: { type: "string" },
                  category: { type: "string" },
                  language: { type: "string" },
                  example_code: { type: "string" },
                  innovationScore: { type: "number" },
                  usageScore: { type: "number" },
                  tags: {
                    type: "array",
                    items: { type: "string" }
                  }
                }
              }
            }
          }
        }
      });

      const aiPatterns = response.patterns || [];

      // 4. Load existing patterns
      const existingPatterns = await base44.entities.APCPattern.list('-created_date', 1000);
      const existingIndex = {};
      existingPatterns.forEach(p => {
        existingIndex[p.patternId] = p;
      });

      const now = new Date().toISOString();
      let newCount = 0;
      let updatedCount = 0;

      // 5. Merge/Update patterns
      for (const p of aiPatterns) {
        const patternId = `${p.language || 'generic'}-${p.name}`
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-');

        const existing = existingIndex[patternId];

        if (existing) {
          const newInnovation = Math.round(
            ((existing.innovationScore || 0) + (p.innovationScore || 0)) / 2
          );
          const newUsage = Math.min(
            100,
            (existing.usageScore || 0) + (p.usageScore || 10) / 10
          );

          await base44.entities.APCPattern.update(existing.id, {
            description: p.description || existing.description,
            category: p.category || existing.category,
            exampleCode: p.example_code || existing.exampleCode,
            innovationScore: newInnovation,
            usageScore: newUsage,
            tags: Array.from(new Set([...(existing.tags || []), ...(p.tags || [])])),
            lastSeen: now,
            seenCount: (existing.seenCount || 1) + 1
          });

          updatedCount++;
        } else {
          await base44.entities.APCPattern.create({
            patternId,
            name: p.name,
            description: p.description,
            category: p.category,
            language: p.language,
            exampleCode: p.example_code || "",
            innovationScore: p.innovationScore || 0,
            usageScore: p.usageScore || 0,
            tags: p.tags || [],
            firstSeen: now,
            lastSeen: now,
            seenCount: 1
          });

          newCount++;
        }
      }

      const duration = Date.now() - startTime;

      // Update activity log
      await base44.entities.APCActivity.update(activity.id, {
        status: 'success',
        patternsAnalyzed: aiPatterns.length,
        patternsCreated: newCount,
        patternsUpdated: updatedCount,
        duration,
        details: {
          intervalMinutes: interval,
          triggeredAt: new Date(startTime).toISOString(),
          completedAt: new Date().toISOString(),
          snippetsAnalyzed: limited.length,
          newPatterns: newCount,
          updatedPatterns: updatedCount
        }
      });

      setLastResult({
        success: true,
        analyzed: aiPatterns.length,
        newPatterns: newCount,
        updatedPatterns: updatedCount,
        timestamp: Date.now(),
        duration
      });

      setLastRun(Date.now());
      setCurrentRun(null);

      toast.success(`🧠 Auto-ingest: ${aiPatterns.length} patterns (${newCount} new, ${updatedCount} updated)`);
    } catch (error) {
      const duration = Date.now() - startTime;
      
      console.error('APC Auto-ingest failed:', error);

      setLastResult({
        success: false,
        error: error.message,
        timestamp: Date.now(),
        duration
      });

      setCurrentRun(null);

      toast.error('Auto-ingest failed: ' + error.message);
    }
  };

  const handleStart = () => {
    setIsRunning(true);
    
    // Run immediately
    runIngest();
    
    // Schedule next runs
    const nextTime = Date.now() + (interval * 60 * 1000);
    setNextRun(nextTime);

    intervalRef.current = setInterval(() => {
      runIngest();
      setNextRun(Date.now() + (interval * 60 * 1000));
    }, interval * 60 * 1000);

    toast.success(`Auto-ingest started (every ${interval} minutes)`);
  };

  const handleStop = () => {
    setIsRunning(false);
    setNextRun(null);
    
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    toast.info('Auto-ingest stopped');
  };

  const handleIntervalChange = (value) => {
    const newInterval = parseInt(value);
    setInterval(newInterval);

    if (isRunning) {
      // Restart with new interval
      handleStop();
      setTimeout(() => {
        setInterval(newInterval);
        handleStart();
      }, 100);
    }
  };

  const getTimeUntilNext = () => {
    if (!nextRun) return null;
    const diff = Math.max(0, nextRun - Date.now());
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${minutes}m ${seconds}s`;
  };

  const getTimeSinceLast = () => {
    if (!lastRun) return 'Never';
    const diff = Date.now() - lastRun;
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h ago`;
  };

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
            isRunning ? 'animate-pulse-glow' : ''
          }`} style={{
            background: isRunning 
              ? 'linear-gradient(135deg, #10b981, #14b8a6)'
              : 'linear-gradient(135deg, #6b7280, #4b5563)'
          }}>
            <Zap className="w-5 h-5 text-white" />
          </div>
          
          <div>
            <h3 className="font-bold text-white text-lg flex items-center gap-2">
              Auto-Ingest
              {isRunning && (
                <Badge className="bg-green-600/20 text-green-300 border-green-600/30 text-xs">
                  Running
                </Badge>
              )}
            </h3>
            <p className="text-xs text-gray-400">
              Automatic pattern extraction every {interval} minutes
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Select value={interval.toString()} onValueChange={handleIntervalChange}>
            <SelectTrigger className="w-32 bg-[#141923] border-[#1a1f2e] text-white text-sm">
              <Clock className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="5">5 min</SelectItem>
              <SelectItem value="10">10 min</SelectItem>
              <SelectItem value="15">15 min</SelectItem>
              <SelectItem value="30">30 min</SelectItem>
              <SelectItem value="60">1 hour</SelectItem>
            </SelectContent>
          </Select>

          {isRunning ? (
            <Button
              onClick={handleStop}
              variant="outline"
              className="border-red-600/30 text-red-300 hover:bg-red-600/10"
            >
              <Pause className="w-4 h-4 mr-2" />
              Stop
            </Button>
          ) : (
            <Button
              onClick={handleStart}
              className="bg-gradient-to-r from-green-600 to-emerald-600 text-white"
            >
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
          )}
        </div>
      </div>

      {/* Status Grid */}
      <div className="grid md:grid-cols-3 gap-4 mb-4">
        {/* Current Status */}
        <div className="p-4 rounded-lg border" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-semibold text-gray-400">Status</span>
          </div>
          {currentRun ? (
            <div className="text-yellow-400 text-sm font-medium flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
              Running...
            </div>
          ) : isRunning ? (
            <div className="text-green-400 text-sm font-medium">Active</div>
          ) : (
            <div className="text-gray-500 text-sm font-medium">Stopped</div>
          )}
        </div>

        {/* Next Run */}
        <div className="p-4 rounded-lg border" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-semibold text-gray-400">Next Run</span>
          </div>
          <div className="text-white text-sm font-medium">
            {isRunning && nextRun ? getTimeUntilNext() : 'N/A'}
          </div>
        </div>

        {/* Last Run */}
        <div className="p-4 rounded-lg border" style={{
          background: 'rgba(5, 8, 22, 0.9)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-orange-400" />
            <span className="text-sm font-semibold text-gray-400">Last Run</span>
          </div>
          <div className="text-white text-sm font-medium">
            {getTimeSinceLast()}
          </div>
        </div>
      </div>

      {/* Last Result */}
      {lastResult && (
        <div className={`p-4 rounded-lg border ${
          lastResult.success 
            ? 'bg-green-600/10 border-green-600/30' 
            : 'bg-red-600/10 border-red-600/30'
        }`}>
          {lastResult.success ? (
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-green-300 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                Last Ingest Successful
              </div>
              <div className="text-gray-300">
                <div>• Analyzed: {lastResult.analyzed} patterns</div>
                <div>• New: {lastResult.newPatterns}</div>
                <div>• Updated: {lastResult.updatedPatterns}</div>
                <div>• Duration: {(lastResult.duration / 1000).toFixed(1)}s</div>
              </div>
            </div>
          ) : (
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-red-300 font-bold">
                <AlertTriangle className="w-4 h-4" />
                Last Ingest Failed
              </div>
              <div className="text-gray-300">{lastResult.error}</div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}