/**
 * MDC Company API Client
 * Type-safe wrapper for Company/Enterprise Portal API endpoints
 */

class CompanyAPIClient {
  constructor(baseURL = '/api/companies') {
    this.baseURL = baseURL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    if (options.body && typeof options.body === 'object') {
      config.body = JSON.stringify(options.body);
    }

    const response = await fetch(url, config);
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: response.statusText }));
      throw new Error(error.error || error.message || 'API request failed');
    }

    return response.json();
  }

  // ============================================
  // COMPANY PROFILE
  // ============================================

  /**
   * Get company profile
   * @param {string} companyId - Company identifier
   * @returns {Promise<Object>} Company profile
   */
  async getCompany(companyId) {
    return this.request(`/${companyId}`, {
      method: 'GET',
    });
  }

  /**
   * Update company profile
   * @param {string} companyId - Company identifier
   * @param {Object} updates - Profile updates
   * @returns {Promise<Object>} Updated profile
   */
  async updateCompany(companyId, updates) {
    return this.request(`/${companyId}`, {
      method: 'PUT',
      body: updates,
    });
  }

  /**
   * Get company dashboard data
   * @param {string} companyId - Company identifier
   * @returns {Promise<Object>} Dashboard data with AI insights
   */
  async getCompanyDashboard(companyId) {
    return this.request(`/${companyId}/dashboard`, {
      method: 'GET',
    });
  }

  // ============================================
  // COMPANY MISSIONS
  // ============================================

  /**
   * Get company missions
   * @param {string} companyId - Company identifier
   * @returns {Promise<Array>} Mission list
   */
  async getCompanyMissions(companyId) {
    return this.request(`/${companyId}/missions`, {
      method: 'GET',
    });
  }

  /**
   * Get single mission
   * @param {string} companyId - Company identifier
   * @param {string} missionId - Mission identifier
   * @returns {Promise<Object>} Mission details
   */
  async getCompanyMission(companyId, missionId) {
    return this.request(`/${companyId}/missions/${missionId}`, {
      method: 'GET',
    });
  }

  /**
   * Create new company mission
   * @param {string} companyId - Company identifier
   * @param {Object} mission - Mission data
   * @param {string} mission.title - Mission title
   * @param {string} mission.description - Mission description
   * @param {number} mission.bounty - Bounty amount
   * @param {string} mission.complexity - Complexity level
   * @param {string} mission.aiMode - AI mode (ai-only/ai+talent)
   * @returns {Promise<Object>} Created mission
   */
  async createCompanyMission(companyId, mission) {
    return this.request(`/${companyId}/missions`, {
      method: 'POST',
      body: mission,
    });
  }

  /**
   * Update company mission
   * @param {string} companyId - Company identifier
   * @param {string} missionId - Mission identifier
   * @param {Object} updates - Mission updates
   * @returns {Promise<Object>} Updated mission
   */
  async updateCompanyMission(companyId, missionId, updates) {
    return this.request(`/${companyId}/missions/${missionId}`, {
      method: 'PUT',
      body: updates,
    });
  }

  // ============================================
  // AI SHORTLIST
  // ============================================

  /**
   * Get AI-powered candidate shortlist
   * @param {string} companyId - Company identifier
   * @param {string} missionId - Mission identifier
   * @param {Array} candidates - Candidate list
   * @returns {Promise<Object>} AI-ranked shortlist
   */
  async getAIShortlist(companyId, missionId, candidates) {
    return this.request(`/${companyId}/missions/${missionId}/ai-shortlist`, {
      method: 'POST',
      body: { candidates },
    });
  }

  // ============================================
  // AI INSIGHTS
  // ============================================

  /**
   * Get AI strategic insights
   * @param {string} companyId - Company identifier
   * @param {string} context - Additional context
   * @returns {Promise<Object>} AI insights
   */
  async getAIInsights(companyId, context = "") {
    return this.request(`/${companyId}/ai-insights`, {
      method: 'POST',
      body: { context },
    });
  }

  // ============================================
  // RECRUITER / HIRING
  // ============================================

  /**
   * Search developers
   * @param {string} companyId - Company identifier
   * @param {Object} filters - Search filters
   * @returns {Promise<Array>} Developer matches
   */
  async searchDevelopers(companyId, filters = {}) {
    const query = new URLSearchParams(filters).toString();
    return this.request(`/${companyId}/search${query ? '?' + query : ''}`, {
      method: 'GET',
    });
  }
}

// Export singleton instance
export const companyAPI = new CompanyAPIClient();

// Also export class for custom instances
export default CompanyAPIClient;