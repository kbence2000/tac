import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Zap, Info, AlertTriangle, CheckCircle2 } from "lucide-react";
import { coreAPI } from "./CoreAPIClient";
import { formatDistanceToNow } from "date-fns";

export default function CoreSwarmEvents() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEvents();
    const interval = setInterval(fetchEvents, 3000); // Poll every 3s
    return () => clearInterval(interval);
  }, []);

  const fetchEvents = async () => {
    try {
      const data = await coreAPI.getSwarmEvents({ limit: 50 });
      setEvents(data.events || []);
    } catch (error) {
      console.error("Failed to fetch swarm events:", error);
    } finally {
      setLoading(false);
    }
  };

  const getEventIcon = (type) => {
    switch (type) {
      case "module_start": return <Zap className="w-4 h-4 text-blue-400" />;
      case "module_complete": return <CheckCircle2 className="w-4 h-4 text-green-400" />;
      case "module_error": return <AlertTriangle className="w-4 h-4 text-red-400" />;
      case "orchestrator_run": return <Activity className="w-4 h-4 text-purple-400" />;
      default: return <Info className="w-4 h-4 text-gray-400" />;
    }
  };

  const getEventColor = (type) => {
    switch (type) {
      case "module_start": return "bg-blue-600/20 text-blue-300 border-blue-600/30";
      case "module_complete": return "bg-green-600/20 text-green-300 border-green-600/30";
      case "module_error": return "bg-red-600/20 text-red-300 border-red-600/30";
      case "orchestrator_run": return "bg-purple-600/20 text-purple-300 border-purple-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Activity className="w-5 h-5 text-purple-400" />
        Swarm Events
        <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs ml-auto">
          {events.length} events
        </Badge>
      </h3>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {loading && events.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <Activity className="w-8 h-8 mx-auto mb-2 animate-pulse" />
            <p className="text-sm">Loading events...</p>
          </div>
        ) : events.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No events yet</p>
          </div>
        ) : (
          events.map((event, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-3 rounded-lg border hover:bg-white/5 transition-colors animate-fade-in"
              style={{
                background: 'rgba(5, 8, 22, 0.5)',
                borderColor: 'rgba(148, 163, 184, 0.2)',
                animationDelay: `${idx * 0.03}s`
              }}
            >
              <div className="mt-0.5">
                {getEventIcon(event.type)}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Badge className={`${getEventColor(event.type)} text-xs`}>
                    {event.type}
                  </Badge>
                  {event.moduleId && (
                    <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30 text-xs">
                      {event.moduleId}
                    </Badge>
                  )}
                  <span className="text-xs text-gray-500 ml-auto">
                    {event.timestamp 
                      ? formatDistanceToNow(new Date(event.timestamp), { addSuffix: true })
                      : 'now'
                    }
                  </span>
                </div>

                <p className="text-sm text-gray-300">
                  {event.message || event.description || 'No description'}
                </p>

                {event.metadata && Object.keys(event.metadata).length > 0 && (
                  <pre className="mt-2 text-xs text-gray-400 overflow-x-auto">
                    {JSON.stringify(event.metadata, null, 2)}
                  </pre>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
}