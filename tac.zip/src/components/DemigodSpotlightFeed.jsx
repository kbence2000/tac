import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, Code2, Zap, Heart, MessageSquare, ExternalLink, Loader2 } from "lucide-react";
import { demigodAPI } from "./DemigodAPIClient";
import { formatDistanceToNow } from "date-fns";

export default function DemigodSpotlightFeed({ limit = 10 }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    fetchSpotlight();
  }, [filter]);

  const fetchSpotlight = async () => {
    try {
      const data = await demigodAPI.getSpotlight({
        limit,
        type: filter !== "all" ? filter : undefined,
      });
      
      setItems(data.items || []);
    } catch (error) {
      console.error("Failed to fetch spotlight:", error);
    } finally {
      setLoading(false);
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case "code": return <Code2 className="w-4 h-4" />;
      case "project": return <Zap className="w-4 h-4" />;
      case "achievement": return <Star className="w-4 h-4" />;
      default: return <Star className="w-4 h-4" />;
    }
  };

  const getTypeBadge = (type) => {
    switch (type) {
      case "code": return "bg-green-600/20 text-green-300 border-green-600/30";
      case "project": return "bg-purple-600/20 text-purple-300 border-purple-600/30";
      case "achievement": return "bg-yellow-600/20 text-yellow-300 border-yellow-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  return (
    <div className="space-y-6">
      {/* Filter Tabs */}
      <div className="flex gap-2 flex-wrap">
        {["all", "code", "project", "achievement"].map((type) => (
          <Button
            key={type}
            onClick={() => setFilter(type)}
            variant={filter === type ? "default" : "outline"}
            size="sm"
            className={filter === type 
              ? "bg-purple-600 hover:bg-purple-700" 
              : "border-[#1a1f2e] text-gray-400 hover:text-white"
            }
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </Button>
        ))}
      </div>

      {/* Spotlight Items */}
      {loading ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-purple-400" />
          <p className="text-gray-400">Loading spotlight...</p>
        </Card>
      ) : items.length === 0 ? (
        <Card className="border p-12 text-center" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Star className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">No spotlight items yet</p>
        </Card>
      ) : (
        <div className="grid gap-4">
          {items.map((item, idx) => (
            <Card
              key={idx}
              className="border p-5 hover:shadow-lg transition-all"
              style={{
                background: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(148, 163, 184, 0.35)'
              }}
            >
              <div className="flex items-start gap-4">
                {/* Author Avatar */}
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-lg">
                    {item.author?.charAt(0).toUpperCase()}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-semibold text-white">{item.author}</span>
                    <Badge className={getTypeBadge(item.type)}>
                      {getTypeIcon(item.type)}
                      <span className="ml-1">{item.type}</span>
                    </Badge>
                    <span className="text-xs text-gray-500 ml-auto">
                      {item.timestamp 
                        ? formatDistanceToNow(new Date(item.timestamp), { addSuffix: true })
                        : 'now'
                      }
                    </span>
                  </div>

                  <h4 className="text-lg font-bold text-white mb-2">
                    {item.title}
                  </h4>

                  <p className="text-gray-300 text-sm leading-relaxed mb-3">
                    {item.description}
                  </p>

                  {item.code && (
                    <pre className="bg-[#0f0a1f] border border-[#1a1f2e] rounded-lg p-3 text-xs overflow-x-auto mb-3 font-mono text-gray-300">
                      {item.code}
                    </pre>
                  )}

                  {/* Actions */}
                  <div className="flex items-center gap-4 text-sm">
                    <button className="flex items-center gap-1 text-gray-400 hover:text-red-400 transition-colors">
                      <Heart className="w-4 h-4" />
                      <span>{item.likes || 0}</span>
                    </button>
                    <button className="flex items-center gap-1 text-gray-400 hover:text-cyan-400 transition-colors">
                      <MessageSquare className="w-4 h-4" />
                      <span>{item.comments || 0}</span>
                    </button>
                    {item.url && (
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-gray-400 hover:text-purple-400 transition-colors ml-auto"
                      >
                        <ExternalLink className="w-4 h-4" />
                        <span>View</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}