import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, Trophy, Target, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

/**
 * TalentDetectionBanner - Shows on PvP pages to promote talent program
 */
export default function TalentDetectionBanner() {
  return (
    <Card className="border-purple-500/50 bg-gradient-to-br from-purple-600/10 to-pink-600/10 p-6 mb-8">
      <div className="flex items-start gap-4">
        <div className="p-3 rounded-lg bg-purple-600/20">
          <Sparkles className="w-8 h-8 text-purple-400" />
        </div>
        
        <div className="flex-1">
          <h3 className="text-xl font-bold text-white mb-2">
            Get Discovered by Our AI
          </h3>
          <p className="text-sm text-gray-300 mb-4">
            Top performers in Innovation PvP get selected for our <strong className="text-purple-400">Talent Mentoring Program</strong>. 
            Win matches, rank high, and unlock 1-on-1 mentoring from R6+ Demigods.
          </p>

          <div className="grid md:grid-cols-3 gap-3 mb-4">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-6 h-6 rounded-full bg-yellow-600/20 flex items-center justify-center">
                <Trophy className="w-3 h-3 text-yellow-400" />
              </div>
              <span className="text-gray-300">2+ PvP wins</span>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center">
                <Target className="w-3 h-3 text-purple-400" />
              </div>
              <span className="text-gray-300">80+ Innovation</span>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <div className="w-6 h-6 rounded-full bg-cyan-600/20 flex items-center justify-center">
                <TrendingUp className="w-3 h-3 text-cyan-400" />
              </div>
              <span className="text-gray-300">Top 3 finish</span>
            </div>
          </div>

          <Link to={createPageUrl("TalentDashboard")}>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold">
              Check My Talent Status
            </Button>
          </Link>
        </div>
      </div>
    </Card>
  );
}