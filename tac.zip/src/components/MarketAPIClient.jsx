/**
 * MDC Market API Client
 * Type-safe wrapper for Community & Marketplace API endpoints
 */

class MarketAPIClient {
  constructor(baseURL = '/api/market') {
    this.baseURL = baseURL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    if (options.body && typeof options.body === 'object') {
      config.body = JSON.stringify(options.body);
    }

    const response = await fetch(url, config);
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: response.statusText }));
      throw new Error(error.error || error.message || 'API request failed');
    }

    return response.json();
  }

  // ============================================
  // ASSETS
  // ============================================

  /**
   * Get asset listings
   * @param {Object} params - Query parameters
   * @param {string} params.type - Asset type filter
   * @param {string} params.search - Search query
   * @param {string} params.sort - Sort order
   * @returns {Promise<Array>} Asset list
   */
  async getAssets(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/assets${query ? '?' + query : ''}`, {
      method: 'GET',
    });
  }

  /**
   * Get single asset details
   * @param {string} assetId - Asset identifier
   * @returns {Promise<Object>} Asset details
   */
  async getAsset(assetId) {
    return this.request(`/assets/${assetId}`, {
      method: 'GET',
    });
  }

  /**
   * Upload new asset
   * @param {Object} asset - Asset data
   * @param {string} asset.title - Asset title
   * @param {string} asset.type - Asset type
   * @param {number} asset.price - Price
   * @param {string} asset.currency - Currency code
   * @returns {Promise<Object>} Created asset
   */
  async uploadAsset(asset) {
    return this.request('/assets', {
      method: 'POST',
      body: asset,
    });
  }

  /**
   * Update existing asset
   * @param {string} assetId - Asset identifier
   * @param {Object} updates - Asset updates
   * @returns {Promise<Object>} Updated asset
   */
  async updateAsset(assetId, updates) {
    return this.request(`/assets/${assetId}`, {
      method: 'PUT',
      body: updates,
    });
  }

  /**
   * Delete asset
   * @param {string} assetId - Asset identifier
   * @returns {Promise<Object>} Deletion result
   */
  async deleteAsset(assetId) {
    return this.request(`/assets/${assetId}`, {
      method: 'DELETE',
    });
  }
}

// Export singleton instance
export const marketAPI = new MarketAPIClient();

// Also export class for custom instances
export default MarketAPIClient;