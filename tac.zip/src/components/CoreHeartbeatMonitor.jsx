import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Server, Zap, AlertTriangle, CheckCircle2 } from "lucide-react";
import { coreAPI } from "./CoreAPIClient";

export default function CoreHeartbeatMonitor() {
  const [heartbeat, setHeartbeat] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchHeartbeat = async () => {
      try {
        const data = await coreAPI.getHeartbeat();
        setHeartbeat(data);
        setError(null);
      } catch (err) {
        console.error("Heartbeat fetch failed:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchHeartbeat();
    const interval = setInterval(fetchHeartbeat, 5000); // Poll every 5s

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case "healthy": return "text-green-400";
      case "degraded": return "text-yellow-400";
      case "down": return "text-red-400";
      default: return "text-gray-400";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "healthy": return <CheckCircle2 className="w-4 h-4 text-green-400" />;
      case "degraded": return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case "down": return <AlertTriangle className="w-4 h-4 text-red-400" />;
      default: return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  if (loading) {
    return (
      <Card className="border p-4" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-gray-400 animate-pulse" />
          <span className="text-sm text-gray-400">Checking system health...</span>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border p-4" style={{
        background: 'rgba(239, 68, 68, 0.1)',
        borderColor: 'rgba(239, 68, 68, 0.3)'
      }}>
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <span className="text-sm text-red-300">Heartbeat failed: {error}</span>
        </div>
      </Card>
    );
  }

  return (
    <Card className="border p-4" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            {getStatusIcon(heartbeat?.status)}
            {heartbeat?.status === "healthy" && (
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white">System Health</span>
              <Badge className={`${getStatusColor(heartbeat?.status)} border-current text-xs`}>
                {heartbeat?.status || "unknown"}
              </Badge>
            </div>
            <div className="text-xs text-gray-400 mt-0.5">
              Uptime: {heartbeat?.uptime || "N/A"} • CPU: {heartbeat?.cpu || "N/A"}% • Memory: {heartbeat?.memory || "N/A"}%
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs text-gray-400">
          <div className="flex items-center gap-1">
            <Server className="w-3 h-3" />
            <span>{heartbeat?.activeModules || 0} modules</span>
          </div>
          <div className="flex items-center gap-1">
            <Zap className="w-3 h-3" />
            <span>{heartbeat?.activeMissions || 0} missions</span>
          </div>
        </div>
      </div>
    </Card>
  );
}