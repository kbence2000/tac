import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Shield, 
  CheckCircle2, 
  XCircle, 
  Copy,
  Check,
  AlertTriangle,
  TrendingUp,
  Code2,
  ArrowLeft
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import ReactMarkdown from "react-markdown";

export default function DevGuardianTaskDetail({ task, onBack }) {
  const [approving, setApproving] = useState(false);
  const [rejecting, setRejecting] = useState(false);
  const [copiedPatch, setCopiedPatch] = useState(null);
  const queryClient = useQueryClient();

  const handleApprove = async () => {
    setApproving(true);
    try {
      const user = await base44.auth.me();
      
      await base44.entities.DevGuardianTask.update(task.id, {
        status: 'approved',
        approvedAt: new Date().toISOString(),
        approvedBy: user.email
      });

      queryClient.invalidateQueries({ queryKey: ['devGuardianTasks'] });
      toast.success('✅ Task approved!');
      
      if (onBack) onBack();
    } catch (error) {
      console.error('Approval failed:', error);
      toast.error('Failed to approve task');
    } finally {
      setApproving(false);
    }
  };

  const handleReject = async () => {
    setRejecting(true);
    try {
      const user = await base44.auth.me();
      
      await base44.entities.DevGuardianTask.update(task.id, {
        status: 'rejected',
        rejectedAt: new Date().toISOString(),
        rejectedBy: user.email
      });

      queryClient.invalidateQueries({ queryKey: ['devGuardianTasks'] });
      toast.info('Task rejected');
      
      if (onBack) onBack();
    } catch (error) {
      console.error('Rejection failed:', error);
      toast.error('Failed to reject task');
    } finally {
      setRejecting(false);
    }
  };

  const handleCopyPatch = (patch, index) => {
    navigator.clipboard.writeText(patch.codeBlock);
    setCopiedPatch(index);
    toast.success('Patch copied to clipboard!');
    setTimeout(() => setCopiedPatch(null), 2000);
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-red-400';
      case 'high': return 'text-orange-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button
        onClick={onBack}
        variant="ghost"
        className="text-gray-400 hover:text-white"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Tasks
      </Button>

      {/* Header */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start gap-3 flex-1">
            <Shield className="w-8 h-8 text-purple-400" />
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-white mb-2">{task.title}</h2>
              <div className="flex flex-wrap gap-2">
                <Badge className={`${getSeverityColor(task.severity)} bg-opacity-20`}>
                  {task.severity} severity
                </Badge>
                <Badge className="bg-cyan-600/20 text-cyan-300">
                  {task.type}
                </Badge>
                <Badge className={
                  task.status === 'approved' ? 'bg-green-600/20 text-green-300' :
                  task.status === 'rejected' ? 'bg-red-600/20 text-red-300' :
                  'bg-yellow-600/20 text-yellow-300'
                }>
                  {task.status}
                </Badge>
              </div>
            </div>
          </div>

          {task.status === 'pending' && (
            <div className="flex gap-2">
              <Button
                onClick={handleReject}
                disabled={rejecting}
                variant="outline"
                className="border-red-600/30 text-red-300 hover:bg-red-600/10"
              >
                <XCircle className="w-4 h-4 mr-2" />
                Reject
              </Button>
              <Button
                onClick={handleApprove}
                disabled={approving}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Approve
              </Button>
            </div>
          )}
        </div>

        <div className="text-sm text-gray-400">
          Created: {new Date(task.created_date).toLocaleString()}
        </div>
      </Card>

      {/* Summary */}
      <Card className="border p-6" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-yellow-400" />
          Summary
        </h3>
        <div className="text-gray-300 leading-relaxed">
          <ReactMarkdown>{task.summary}</ReactMarkdown>
        </div>
      </Card>

      {/* Improvement Plan */}
      {task.improvementPlan && task.improvementPlan.length > 0 && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-cyan-400" />
            Improvement Plan
          </h3>
          <ol className="list-decimal ml-6 space-y-2 text-gray-300">
            {task.improvementPlan.map((step, idx) => (
              <li key={idx} className="leading-relaxed">{step}</li>
            ))}
          </ol>
        </Card>
      )}

      {/* Code Patches */}
      {task.patches && task.patches.length > 0 && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Code2 className="w-5 h-5 text-purple-400" />
            Code Patches ({task.patches.length})
          </h3>
          
          <div className="space-y-4">
            {task.patches.map((patch, idx) => (
              <div key={idx} className="p-4 rounded-lg border" style={{
                background: 'rgba(5, 8, 22, 0.9)',
                borderColor: 'rgba(148, 163, 184, 0.2)'
              }}>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-bold text-white mb-1">{patch.area}</h4>
                    <p className="text-sm text-gray-400">{patch.rationale}</p>
                  </div>
                  <Button
                    onClick={() => handleCopyPatch(patch, idx)}
                    variant="ghost"
                    size="sm"
                    className="text-cyan-400 hover:text-cyan-300"
                  >
                    {copiedPatch === idx ? (
                      <>
                        <Check className="w-4 h-4 mr-1" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-1" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>

                <pre className="mt-3 p-3 rounded border overflow-x-auto text-sm" style={{
                  background: 'rgba(0, 0, 0, 0.5)',
                  borderColor: 'rgba(148, 163, 184, 0.2)'
                }}>
                  <code className="text-gray-300">{patch.codeBlock}</code>
                </pre>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Why Better */}
      {task.whyBetter && (
        <Card className="border p-6" style={{
          background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.05), rgba(14, 165, 233, 0.05))',
          borderColor: 'rgba(34, 197, 94, 0.3)'
        }}>
          <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-400" />
            Why This Is Better
          </h3>
          <div className="text-gray-300 leading-relaxed">
            <ReactMarkdown>{task.whyBetter}</ReactMarkdown>
          </div>
        </Card>
      )}

      {/* Risks */}
      {task.risks && (
        <Card className="border p-6" style={{
          background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.05), rgba(251, 146, 60, 0.05))',
          borderColor: 'rgba(239, 68, 68, 0.3)'
        }}>
          <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-400" />
            Potential Risks
          </h3>
          <div className="text-gray-300 leading-relaxed">
            <ReactMarkdown>{task.risks}</ReactMarkdown>
          </div>
        </Card>
      )}

      {/* Snapshots */}
      {(task.healthSnapshot || task.patternSnapshot) && (
        <Card className="border p-6" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <h3 className="text-lg font-bold text-white mb-4">System State at Audit Time</h3>
          
          <div className="grid md:grid-cols-2 gap-4">
            {task.healthSnapshot && (
              <div className="p-4 rounded-lg border" style={{
                background: 'rgba(5, 8, 22, 0.9)',
                borderColor: 'rgba(148, 163, 184, 0.2)'
              }}>
                <h4 className="font-bold text-cyan-400 mb-2">Health Snapshot</h4>
                <pre className="text-xs text-gray-300 overflow-x-auto">
                  {JSON.stringify(task.healthSnapshot, null, 2)}
                </pre>
              </div>
            )}

            {task.patternSnapshot && (
              <div className="p-4 rounded-lg border" style={{
                background: 'rgba(5, 8, 22, 0.9)',
                borderColor: 'rgba(148, 163, 184, 0.2)'
              }}>
                <h4 className="font-bold text-purple-400 mb-2">Pattern Snapshot</h4>
                <pre className="text-xs text-gray-300 overflow-x-auto">
                  {JSON.stringify(task.patternSnapshot, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}