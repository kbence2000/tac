import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, Trophy, Clock, Users, 
  Code2, Lightbulb, DollarSign, Briefcase
} from "lucide-react";
import InnovationScoreboard from "./InnovationScoreboard";

const DIFFICULTY_CONFIG = {
  easy: { color: "text-green-400", icon: Lightbulb },
  medium: { color: "text-yellow-400", icon: Sparkles },
  hard: { color: "text-red-400", icon: Trophy },
  demigod: { color: "text-purple-400", icon: Trophy }
};

export default function InnovationArenaView({
  currentChallenge,
  currentMatch,
  latestScores,
  remainingMs,
  matchFinishedData,
  codeInput,
  setCodeInput,
  onSubmitCode,
  isRunning,
  isFinished
}) {
  if (!currentChallenge || !currentMatch) {
    return (
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="text-center py-20">
          <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">No Active Arena</h3>
          <p className="text-gray-400 mb-4">
            Join an innovation challenge during its time window
          </p>
          <div className="text-xs text-gray-500 max-w-md mx-auto">
            Innovation battles are scheduled with specific join windows. Check the left panel for upcoming challenges.
          </div>
        </div>
      </Card>
    );
  }

  const diffCfg = DIFFICULTY_CONFIG[currentChallenge.difficulty] || DIFFICULTY_CONFIG.medium;
  const DiffIcon = diffCfg.icon;

  // Timer display
  let timerText = "Waiting for match start...";
  let timerColor = "text-gray-400";
  if (remainingMs !== null && !isFinished) {
    const secs = Math.max(0, Math.round(remainingMs / 1000));
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    timerText = `${mins}:${s.toString().padStart(2, '0')}`;
    
    if (secs < 60) {
      timerColor = "text-red-400";
    } else if (secs < 180) {
      timerColor = "text-yellow-400";
    } else {
      timerColor = "text-green-400";
    }
  }
  if (isFinished) {
    timerText = "Innovation Battle Finished";
    timerColor = "text-gray-400";
  }

  const startDate = new Date(currentChallenge.startTime);
  const endDate = new Date(currentChallenge.endTime);

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="space-y-6">
        {/* Arena Header */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-purple-500" />
            <h2 className="text-2xl font-black text-white">{currentChallenge.title}</h2>
          </div>
          
          <div className="flex items-center gap-3 flex-wrap mb-3">
            <Badge className={`${diffCfg.color} bg-[#141923] border-[#1a1f2e]`}>
              <DiffIcon className="w-3 h-3 mr-1" />
              {currentChallenge.difficulty}
            </Badge>
            <Badge className="bg-blue-600/20 text-blue-400 border-blue-600/30">
              <Code2 className="w-3 h-3 mr-1" />
              {currentChallenge.language}
            </Badge>
            {currentChallenge.rewardType === "money" ? (
              <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                <DollarSign className="w-3 h-3 mr-1" />
                €{currentChallenge.rewardValue} reward
              </Badge>
            ) : (
              <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30">
                <Briefcase className="w-3 h-3 mr-1" />
                {currentChallenge.rewardValue}
              </Badge>
            )}
          </div>

          {currentChallenge.description && (
            <p className="text-sm text-gray-300 mb-3">
              {currentChallenge.description}
            </p>
          )}

          {/* Time Window Info */}
          <div className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e] mb-3">
            <div className="flex items-center justify-between text-xs">
              <div>
                <span className="text-gray-400">Join Window:</span>
                <div className="text-white font-mono mt-1">
                  {startDate.toLocaleTimeString()} – {endDate.toLocaleTimeString()}
                </div>
              </div>
            </div>
          </div>

          {/* Status Bar */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-400" />
                <span className="text-sm text-white font-semibold">
                  {currentMatch.players?.length || 0} Innovators
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <Clock className={`w-4 h-4 ${timerColor}`} />
                <span className={`text-sm font-bold ${timerColor}`}>
                  {timerText}
                </span>
              </div>
            </div>

            <Badge className={
              currentMatch.status === "waiting" 
                ? "bg-yellow-600/20 text-yellow-400 border-yellow-600/30"
                : currentMatch.status === "running"
                ? "bg-green-600/20 text-green-400 border-green-600/30"
                : "bg-gray-600/20 text-gray-400 border-gray-600/30"
            }>
              {currentMatch.status === "waiting" ? "Waiting" : 
               currentMatch.status === "running" ? "LIVE" : "Finished"}
            </Badge>
          </div>
        </div>

        {/* Innovation Hint */}
        {!isFinished && (
          <div className="p-4 rounded-lg bg-gradient-to-br from-purple-600/10 to-pink-600/10 border border-purple-600/30">
            <div className="flex items-start gap-2">
              <Lightbulb className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-purple-200">
                <strong>Innovation Tip:</strong> Focus on unique approaches, elegant code structure, performance optimizations, error handling, and creative problem-solving. AI evaluates 5 dimensions!
              </div>
            </div>
          </div>
        )}

        {/* Code Editor */}
        {!isFinished && (
          <div>
            <label className="text-sm font-bold text-white block mb-2">
              Your Innovative Solution:
            </label>
            <Textarea
              value={codeInput}
              onChange={(e) => setCodeInput(e.target.value)}
              placeholder="// Write your most innovative, elegant, and performant solution here...&#10;// AI scores: Quality (30%), Performance (20%), Safety (20%), Elegance (10%), Innovation (20%)"
              className="bg-[#141923] border-[#1a1f2e] text-white font-mono text-sm h-72 resize-none"
              disabled={!isRunning}
            />
            <Button
              onClick={onSubmitCode}
              disabled={!isRunning || !codeInput}
              className="w-full mt-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-lg py-6"
            >
              {!isRunning ? "Wait for match start..." : "Submit Innovation"}
            </Button>
          </div>
        )}

        {/* Innovation Scoreboard */}
        <InnovationScoreboard
          scores={latestScores}
          matchFinishedData={matchFinishedData}
          isFinished={isFinished}
        />

        {/* Winner Announcement */}
        {isFinished && matchFinishedData && (
          <div className="p-6 rounded-lg border-2 border-purple-500/50 bg-gradient-to-br from-purple-600/10 to-pink-600/10">
            <div className="text-center">
              <Trophy className="w-12 h-12 text-yellow-400 mx-auto mb-3" />
              <h3 className="text-2xl font-black text-white mb-2">
                Most Innovative: {matchFinishedData.winnerName}
              </h3>
              <div className="text-3xl font-bold text-purple-400 mb-2">
                {matchFinishedData.reward.type === "money" 
                  ? `€${matchFinishedData.reward.value}`
                  : matchFinishedData.reward.value}
              </div>
              <p className="text-sm text-gray-400">
                {matchFinishedData.reward.type === "money"
                  ? "Reward will be credited to your account"
                  : "Company will contact you for the interview"}
              </p>
            </div>
          </div>
        )}

        {/* Info Box */}
        {currentMatch.status === "waiting" && (
          <div className="p-4 rounded-lg bg-blue-600/10 border border-blue-600/30">
            <div className="flex items-start gap-2">
              <Clock className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-blue-300">
                <strong>Waiting for match start...</strong> The innovation battle will begin automatically when the time window opens. Get ready to show your most creative solution!
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}