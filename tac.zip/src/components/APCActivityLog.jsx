import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  Loader2,
  Sparkles,
  Brain,
  TrendingUp,
  Zap
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function APCActivityLog({ limit = 20 }) {
  const { data: activities, isLoading } = useQuery({
    queryKey: ['apcActivities', limit],
    queryFn: () => base44.entities.APCActivity.list('-created_date', limit),
    initialData: [],
    refetchInterval: 30000, // Refresh every 30s
  });

  const getActivityIcon = (type) => {
    switch (type) {
      case 'ingest': return <Sparkles className="w-4 h-4" />;
      case 'auto_ingest': return <Zap className="w-4 h-4" />;
      case 'insight': return <Brain className="w-4 h-4" />;
      case 'pattern_update': return <TrendingUp className="w-4 h-4" />;
      default: return <Activity className="w-4 h-4" />;
    }
  };

  const getActivityLabel = (type) => {
    switch (type) {
      case 'ingest': return 'Manual Ingest';
      case 'auto_ingest': return 'Auto Ingest';
      case 'insight': return 'Insight Generation';
      case 'pattern_update': return 'Pattern Update';
      default: return 'Activity';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success': return <CheckCircle2 className="w-4 h-4 text-green-400" />;
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-400" />;
      case 'in_progress': return <Loader2 className="w-4 h-4 text-yellow-400 animate-spin" />;
      default: return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-600/20 text-green-300 border-green-600/30 text-xs">Success</Badge>;
      case 'error':
        return <Badge className="bg-red-600/20 text-red-300 border-red-600/30 text-xs">Error</Badge>;
      case 'in_progress':
        return <Badge className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30 text-xs">Running</Badge>;
      default:
        return <Badge className="bg-gray-600/20 text-gray-300 border-gray-600/30 text-xs">Unknown</Badge>;
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <Card className="border p-6" style={{
      background: 'rgba(15, 23, 42, 0.95)',
      borderColor: 'rgba(148, 163, 184, 0.35)'
    }}>
      <div className="flex items-center gap-3 mb-4">
        <Activity className="w-6 h-6 text-cyan-400" />
        <div>
          <h3 className="font-bold text-white text-lg">Activity Log</h3>
          <p className="text-xs text-gray-400">Recent APC operations</p>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-gray-600 mx-auto mb-2" />
          <p className="text-gray-400 text-sm">Loading activities...</p>
        </div>
      ) : activities.length === 0 ? (
        <div className="text-center py-8">
          <Activity className="w-12 h-12 text-gray-600 mx-auto mb-2" />
          <p className="text-gray-400 text-sm">No activities yet</p>
        </div>
      ) : (
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {activities.map(activity => (
            <div 
              key={activity.id} 
              className="p-3 rounded-lg border hover:bg-white/5 transition-colors" 
              style={{
                background: 'rgba(5, 8, 22, 0.6)',
                borderColor: 'rgba(148, 163, 184, 0.2)'
              }}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{
                    background: activity.status === 'success' 
                      ? 'rgba(34, 197, 94, 0.1)' 
                      : activity.status === 'error'
                      ? 'rgba(239, 68, 68, 0.1)'
                      : 'rgba(234, 179, 8, 0.1)'
                  }}>
                    {getActivityIcon(activity.activityType)}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">
                      {getActivityLabel(activity.activityType)}
                    </div>
                    <div className="text-xs text-gray-500">
                      {formatTime(activity.created_date)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {getStatusIcon(activity.status)}
                  {getStatusBadge(activity.status)}
                </div>
              </div>

              {activity.status === 'success' && (
                <div className="flex items-center gap-4 text-xs text-gray-400 mt-2">
                  {activity.patternsAnalyzed > 0 && (
                    <span>📊 {activity.patternsAnalyzed} analyzed</span>
                  )}
                  {activity.patternsCreated > 0 && (
                    <span className="text-green-400">✨ {activity.patternsCreated} new</span>
                  )}
                  {activity.patternsUpdated > 0 && (
                    <span className="text-cyan-400">🔄 {activity.patternsUpdated} updated</span>
                  )}
                  {activity.duration && (
                    <span>⏱️ {(activity.duration / 1000).toFixed(1)}s</span>
                  )}
                </div>
              )}

              {activity.status === 'error' && activity.errorMessage && (
                <div className="text-xs text-red-400 mt-2">
                  {activity.errorMessage}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}