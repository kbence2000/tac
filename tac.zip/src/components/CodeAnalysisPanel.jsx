import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Terminal } from "lucide-react";
import DualDebugPanel from "./DualDebugPanel";
import CloudRuntimePanel from "./CloudRuntimePanel";

/**
 * Unified Code Analysis Panel
 * Combines Dual-Layer Debug + Cloud Runtime in tabs
 */
export default function CodeAnalysisPanel({ userId }) {
  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <Tabs defaultValue="debug" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="debug" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            Dual Debug
          </TabsTrigger>
          <TabsTrigger value="runtime" className="flex items-center gap-2">
            <Terminal className="w-4 h-4" />
            Runtime
          </TabsTrigger>
        </TabsList>

        <TabsContent value="debug">
          <DualDebugPanel userId={userId} />
        </TabsContent>

        <TabsContent value="runtime">
          <CloudRuntimePanel userId={userId} />
        </TabsContent>
      </Tabs>
    </Card>
  );
}