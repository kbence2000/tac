import React, { useState, useEffect } from "react";
import { Globe, Brain, Power, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function TrendSourcePanel() {
  const [sources, setSources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    label: "",
    mode: "ai-only",
    url: "",
    topic: "",
    maxSnippets: 3
  });

  useEffect(() => {
    loadSources();
  }, []);

  const loadSources = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.TrendSource.list('-created_date');
      setSources(data);
    } catch (error) {
      console.error('Failed to load sources:', error);
      toast.error('Failed to load sources');
    } finally {
      setLoading(false);
    }
  };

  const openAddSource = () => {
    setFormData({
      label: "",
      mode: "ai-only",
      url: "",
      topic: "",
      maxSnippets: 3
    });
    setShowModal(true);
  };

  const closeAddSource = () => {
    setShowModal(false);
  };

  const addSource = async () => {
    if (!formData.label || !formData.mode) {
      toast.error('Label and mode are required!');
      return;
    }

    if (formData.mode === 'html' && !formData.url) {
      toast.error('URL is required for HTML mode!');
      return;
    }

    if (formData.mode === 'ai-only' && !formData.topic) {
      toast.error('Topic is required for AI-only mode!');
      return;
    }

    try {
      const sourceId = formData.label.toLowerCase().replace(/[^a-z0-9]+/g, "-");
      
      await base44.entities.TrendSource.create({
        sourceId,
        label: formData.label,
        mode: formData.mode,
        url: formData.url || null,
        topic: formData.topic || null,
        maxSnippets: formData.maxSnippets || 3,
        enabled: true
      });

      toast.success('Source added successfully!');
      closeAddSource();
      loadSources();
    } catch (error) {
      console.error('Failed to add source:', error);
      toast.error('Failed to add source');
    }
  };

  const toggleSource = async (source) => {
    try {
      await base44.entities.TrendSource.update(source.id, {
        enabled: !source.enabled
      });
      
      toast.success(`Source ${source.enabled ? 'disabled' : 'enabled'}!`);
      loadSources();
    } catch (error) {
      console.error('Failed to toggle source:', error);
      toast.error('Failed to toggle source');
    }
  };

  const deleteSource = async (sourceId) => {
    if (!confirm('Are you sure you want to delete this source?')) return;

    try {
      await base44.entities.TrendSource.delete(sourceId);
      toast.success('Source deleted!');
      loadSources();
    } catch (error) {
      console.error('Failed to delete source:', error);
      toast.error('Failed to delete source');
    }
  };

  return (
    <>
      <style>{`
        .tsp-container {
          padding: 18px;
          background: transparent;
          color: white;
        }

        .tsp-title {
          font-size: 20px;
          text-align: center;
          font-weight: 800;
          color: #c8a4ff;
        }
        .tsp-sub {
          text-align: center;
          opacity: 0.6;
          margin-bottom: 15px;
        }

        .tsp-actions {
          display: flex;
          justify-content: center;
          gap: 10px;
          margin-bottom: 15px;
        }

        .tsp-btn,
        .tsp-btn2 {
          padding: 8px 16px;
          border-radius: 10px;
          border: none;
          font-size: 12px;
          cursor: pointer;
          color: white;
        }
        .tsp-btn { background: #4d0d6f; }
        .tsp-btn:hover { background: #5f1785; }
        .tsp-btn2 { background: #886E9D; }
        .tsp-btn2:hover { background: #9d7fb3; }

        /* source cards */
        .tsp-card {
          background: rgba(0,0,0,0.55);
          border: 1px solid #ffffff1a;
          border-radius: 12px;
          padding: 14px;
          margin-bottom: 12px;
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .tsp-card:hover {
          border-color: #ffffff33;
        }

        .tsp-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .tsp-icon-html { background: #4d0d6f; }
        .tsp-icon-ai { background: #886E9D; }

        .tsp-info {
          flex: 1;
        }

        .tsp-row {
          font-size: 12px;
          opacity: 0.85;
          margin-top: 2px;
        }

        .tsp-card-title {
          font-size: 15px;
          font-weight: 700;
          color: #c99fff;
        }

        .tsp-badge-html { color:#7effdf; font-size:11px; margin-left: 8px; }
        .tsp-badge-ai   { color:#ffc7ff; font-size:11px; margin-left: 8px; }

        .tsp-actions-btn {
          display: flex;
          gap: 6px;
          flex-shrink: 0;
        }

        .tsp-icon-btn {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.2s;
        }

        .tsp-icon-btn:hover {
          background: rgba(255,255,255,0.1);
        }

        /* modal */
        .tsp-modal {
          position:fixed;
          inset:0;
          background:rgba(0,0,0,0.7);
          backdrop-filter:blur(8px);
          align-items:center;
          justify-content:center;
          z-index: 1000;
        }
        
        .tsp-modal-box {
          background:#12001e;
          border:1px solid #4d0d6f;
          border-radius:14px;
          padding:18px;
          width:90%;
          max-width:320px;
        }

        .tsp-modal-title {
          color:#c99fff;
          font-size:16px;
          font-weight:700;
          margin-bottom:12px;
          text-align: center;
        }

        .tsp-input {
          width:100%;
          margin-bottom:10px;
          padding:8px;
          border-radius:8px;
          background:#1a0a26;
          border:1px solid #4d0d6f77;
          color:white;
          font-size:12px;
          box-sizing: border-box;
        }

        .tsp-input:focus {
          outline: none;
          border-color: #7effdf;
        }

        .tsp-modal-actions {
          display:flex;
          justify-content:space-between;
          gap: 10px;
        }

        .tsp-modal-actions button {
          flex: 1;
        }

        .tsp-empty {
          text-align: center;
          padding: 40px 20px;
          opacity: 0.5;
          font-size: 13px;
        }
      `}</style>

      <div className="tsp-container">
        <div className="tsp-title">TREND SOURCE CONTROL</div>
        <div className="tsp-sub">Manage scraping + AI trend sources</div>

        <div className="tsp-actions">
          <button onClick={openAddSource} className="tsp-btn">
            Add New Source
          </button>
          <button onClick={loadSources} className="tsp-btn2">
            Refresh
          </button>
        </div>

        <div id="sourceList">
          {loading ? (
            <div className="tsp-empty">Loading sources...</div>
          ) : sources.length === 0 ? (
            <div className="tsp-empty">
              No sources configured yet. Click "Add New Source" to get started.
            </div>
          ) : (
            sources.map(source => (
              <div key={source.id} className="tsp-card">
                <div className={`tsp-icon ${source.mode === 'html' ? 'tsp-icon-html' : 'tsp-icon-ai'}`}>
                  {source.mode === 'html' ? (
                    <Globe className="w-4 h-4 text-white" />
                  ) : (
                    <Brain className="w-4 h-4 text-white" />
                  )}
                </div>

                <div className="tsp-info">
                  <div className="tsp-card-title">
                    {source.label}
                    <span className={source.mode === 'html' ? 'tsp-badge-html' : 'tsp-badge-ai'}>
                      {source.mode}
                    </span>
                  </div>
                  <div className="tsp-row">
                    Max: {source.maxSnippets || 3} snippets
                    {source.enabled ? ' • ACTIVE' : ' • DISABLED'}
                  </div>
                  {source.url && <div className="tsp-row" style={{ fontSize: '10px', opacity: 0.6 }}>{source.url}</div>}
                  {source.topic && <div className="tsp-row" style={{ fontSize: '10px', opacity: 0.6 }}>{source.topic}</div>}
                </div>

                <div className="tsp-actions-btn">
                  <button 
                    onClick={() => toggleSource(source)}
                    className="tsp-icon-btn"
                    title={source.enabled ? 'Disable' : 'Enable'}
                  >
                    <Power className={`w-4 h-4 ${source.enabled ? 'text-green-400' : 'text-gray-500'}`} />
                  </button>

                  <button 
                    onClick={() => deleteSource(source.id)}
                    className="tsp-icon-btn"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add Source Modal */}
      {showModal && (
        <div className="tsp-modal" style={{ display: 'flex' }} onClick={closeAddSource}>
          <div className="tsp-modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="tsp-modal-title">Add Source</div>

            <input 
              id="srcLabel"
              value={formData.label}
              onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
              placeholder="Label (e.g. 'dev.to/javascript')"
              className="tsp-input"
            />

            <select 
              id="srcMode"
              value={formData.mode}
              onChange={(e) => setFormData(prev => ({ ...prev, mode: e.target.value }))}
              className="tsp-input"
            >
              <option value="html">HTML (real website scraping)</option>
              <option value="ai-only">AI-only (modeled trend)</option>
            </select>

            <input 
              id="srcUrl"
              value={formData.url}
              onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
              placeholder="URL (for HTML mode)"
              className="tsp-input"
            />

            <input 
              id="srcTopic"
              value={formData.topic}
              onChange={(e) => setFormData(prev => ({ ...prev, topic: e.target.value }))}
              placeholder="AI topic (for ai-only mode)"
              className="tsp-input"
            />

            <input 
              id="srcMax"
              type="number"
              value={formData.maxSnippets}
              onChange={(e) => setFormData(prev => ({ ...prev, maxSnippets: parseInt(e.target.value) || 3 }))}
              placeholder="Max snippets (default 3)"
              className="tsp-input"
            />

            <div className="tsp-modal-actions">
              <button onClick={addSource} className="tsp-btn">
                Add
              </button>
              <button onClick={closeAddSource} className="tsp-btn2">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}