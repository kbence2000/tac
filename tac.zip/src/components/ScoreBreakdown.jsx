import React from "react";
import { Card } from "@/components/ui/card";
import { Code2, Target, TrendingUp, Users, Heart, Sparkles, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";

const SCORE_METRICS = {
  hardSkill: {
    label: "Hard Skills",
    icon: Code2,
    color: "#8B5CF6",
    description: "GitHub contributions, repos, complexity",
    weight: 30,
  },
  aiQuality: {
    label: "AI Quality",
    icon: Sparkles,
    color: "#24E4FF",
    description: "Code quality analysis score",
    weight: 25,
  },
  community: {
    label: "Community",
    icon: Users,
    color: "#10B981",
    description: "Reddit karma, engagement",
    weight: 15,
  },
  impact: {
    label: "Impact",
    icon: Target,
    color: "#F59E0B",
    description: "GitHub stars, influence",
    weight: 10,
  },
  consistency: {
    label: "Consistency",
    icon: TrendingUp,
    color: "#06B6D4",
    description: "Regular contributions",
    weight: 10,
  },
  peerFeedbackScore: {
    label: "Peer Feedback",
    icon: MessageSquare,
    color: "#EC4899",
    description: "Weighted feedback from R4+ demigods",
    weight: 10,
  },
};

export default function ScoreBreakdown({ scores, compact = false, className = "" }) {
  const {
    hardSkill = 0,
    aiQuality = 0,
    community = 0,
    impact = 0,
    consistency = 0,
    peerFeedbackScore = 0,
    totalScore = 0,
  } = scores || {};

  const metrics = [
    { key: "hardSkill", value: hardSkill },
    { key: "aiQuality", value: aiQuality },
    { key: "community", value: community },
    { key: "impact", value: impact },
    { key: "consistency", value: consistency },
    { key: "peerFeedbackScore", value: peerFeedbackScore },
  ];

  return (
    <Card className={cn("border-[#1a1f2e] bg-[#0f1419] p-6", className)}>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Score Breakdown</h3>
        <div className="text-right">
          <div className="text-3xl font-black" style={{
            background: "linear-gradient(135deg, #8B5CF6, #24E4FF)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            {totalScore}
          </div>
          <div className="text-xs text-gray-500 uppercase tracking-wider">Total Score</div>
        </div>
      </div>

      <div className="space-y-4">
        {metrics.map(({ key, value }) => {
          const config = SCORE_METRICS[key];
          const Icon = config.icon;
          const percentage = (value / 100) * 100;

          return (
            <div key={key} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4" style={{ color: config.color }} />
                  <span className="text-sm font-semibold text-white">
                    {config.label}
                  </span>
                  {!compact && (
                    <span className="text-xs text-gray-500">
                      ({config.weight}%)
                    </span>
                  )}
                </div>
                <span 
                  className="text-sm font-bold font-mono"
                  style={{ color: config.color }}
                >
                  {value}
                </span>
              </div>

              {/* Progress bar */}
              <div className="relative h-2 bg-[#1a1f2e] rounded-full overflow-hidden">
                <div
                  className="absolute inset-y-0 left-0 rounded-full transition-all duration-500 ease-out"
                  style={{
                    width: `${percentage}%`,
                    background: `linear-gradient(90deg, ${config.color}, ${config.color}CC)`,
                    boxShadow: `0 0 10px ${config.color}88`,
                  }}
                />
              </div>

              {!compact && (
                <p className="text-xs text-gray-500">{config.description}</p>
              )}
            </div>
          );
        })}
      </div>

      {!compact && (
        <div className="mt-6 pt-6 border-t border-[#1a1f2e]">
          <div className="text-xs text-gray-400 leading-relaxed">
            <strong className="text-gray-300">Algorithm:</strong> HardSkill (30%) + AI Quality (25%) + Community (15%) + Impact (10%) + Consistency (10%) + Peer Feedback (10%)
          </div>
        </div>
      )}
    </Card>
  );
}