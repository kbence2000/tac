import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, AlertTriangle, RefreshCw, Lightbulb, Target } from "lucide-react";

export default function MissionFailureAnalysis({ analysis, mission }) {
  if (!analysis) return null;

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.05), rgba(234, 88, 12, 0.05))',
      borderColor: 'rgba(239, 68, 68, 0.3)'
    }}>
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Brain className="w-5 h-5 text-orange-400" />
        AI Failure Analysis
        {mission?.freeRetry && (
          <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs ml-auto">
            Free Retry
          </Badge>
        )}
      </h3>

      <div className="space-y-4">
        {/* Root Cause */}
        {analysis.rootCause && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <h4 className="font-semibold text-red-300 text-sm">Root Cause</h4>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed pl-6">
              {analysis.rootCause}
            </p>
          </div>
        )}

        {/* Improvement Hint */}
        {analysis.improvementHint && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="w-4 h-4 text-yellow-400" />
              <h4 className="font-semibold text-yellow-300 text-sm">Improvement Suggestion</h4>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed pl-6">
              {analysis.improvementHint}
            </p>
          </div>
        )}

        {/* Retry Recommendation */}
        {analysis.retryRecommended !== undefined && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <RefreshCw className="w-4 h-4 text-cyan-400" />
              <h4 className="font-semibold text-cyan-300 text-sm">Retry Recommended</h4>
            </div>
            <div className="pl-6">
              <Badge className={analysis.retryRecommended 
                ? "bg-green-600/20 text-green-300 border-green-600/30" 
                : "bg-gray-600/20 text-gray-300 border-gray-600/30"
              }>
                {analysis.retryRecommended ? "YES" : "NO"}
              </Badge>
            </div>
          </div>
        )}

        {/* Retry Adjustment */}
        {analysis.retryAdjustment && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-purple-400" />
              <h4 className="font-semibold text-purple-300 text-sm">Retry Adjustment</h4>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed pl-6">
              {analysis.retryAdjustment}
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}