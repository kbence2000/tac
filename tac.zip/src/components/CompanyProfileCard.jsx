import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building, MapPin, Zap, Briefcase } from "lucide-react";
import { companyAPI } from "./CompanyAPIClient";

export default function CompanyProfileCard({ companyId }) {
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (companyId) {
      fetchCompany();
    }
  }, [companyId]);

  const fetchCompany = async () => {
    try {
      const data = await companyAPI.getCompany(companyId);
      setCompany(data);
    } catch (error) {
      console.error("Failed to fetch company:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="border p-6 text-center" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <p className="text-gray-400">Loading company...</p>
      </Card>
    );
  }

  if (!company) {
    return null;
  }

  const getTierBadge = (tier) => {
    switch (tier) {
      case "startup": return "bg-green-600/20 text-green-300 border-green-600/30";
      case "scaleup": return "bg-blue-600/20 text-blue-300 border-blue-600/30";
      case "enterprise": return "bg-purple-600/20 text-purple-300 border-purple-600/30";
      default: return "bg-gray-600/20 text-gray-300 border-gray-600/30";
    }
  };

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      <div className="flex items-start gap-4">
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
          <Building className="w-8 h-8 text-white" />
        </div>

        <div className="flex-1">
          <h3 className="text-2xl font-bold text-white mb-2">
            {company.name}
          </h3>

          <div className="flex flex-wrap items-center gap-2 mb-3">
            <Badge className={getTierBadge(company.tier)}>
              {company.tier}
            </Badge>
            {company.location && (
              <Badge className="bg-gray-600/20 text-gray-300 border-gray-600/30">
                <MapPin className="w-3 h-3 mr-1" />
                {company.location}
              </Badge>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-lg" style={{
              background: 'rgba(5, 8, 22, 0.5)',
              border: '1px solid rgba(148, 163, 184, 0.2)'
            }}>
              <div className="flex items-center gap-2 mb-1">
                <Zap className="w-4 h-4 text-cyan-400" />
                <span className="text-xs text-gray-400">Credits</span>
              </div>
              <div className="text-xl font-bold text-white">
                {company.missionCredits || 0}
              </div>
            </div>

            <div className="p-3 rounded-lg" style={{
              background: 'rgba(5, 8, 22, 0.5)',
              border: '1px solid rgba(148, 163, 184, 0.2)'
            }}>
              <div className="flex items-center gap-2 mb-1">
                <Briefcase className="w-4 h-4 text-purple-400" />
                <span className="text-xs text-gray-400">Open</span>
              </div>
              <div className="text-xl font-bold text-white">
                {company.openMissions || 0}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}