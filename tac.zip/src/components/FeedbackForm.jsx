import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import RankBadge from "./RankBadge";
import { Shield, AlertCircle, Send, Lock } from "lucide-react";
import { toast } from "sonner";

export default function FeedbackForm({ 
  currentUserRank = "R1", 
  currentUserId,
  targetUserId,
  targetUserName,
  onSubmit 
}) {
  const [text, setText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const allowedTiers = ["R4", "R5", "R6", "R7"];
  const canSubmit = allowedTiers.includes(currentUserRank);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!canSubmit) {
      toast.error("Only R4+ demigods can submit feedback");
      return;
    }

    if (text.trim().length < 20) {
      toast.error("Feedback must be at least 20 characters");
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({ 
        fromUserId: currentUserId, 
        targetUserId, 
        text: text.trim() 
      });
      setText("");
      toast.success("Feedback submitted successfully!");
    } catch (err) {
      console.error("Feedback submit error:", err);
      toast.error(err.message || "Failed to submit feedback");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!canSubmit) {
    return (
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-full bg-amber-600/20 border border-amber-600/40">
            <Lock className="w-6 h-6 text-amber-500" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-white mb-2">
              Feedback System Locked
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              You need to reach <strong className="text-white">R4 (Shadow Elite)</strong> or higher to provide peer feedback. 
              This ensures quality and prevents spam.
            </p>
            <div className="flex items-center gap-3 text-xs text-gray-500">
              <span>Your current rank:</span>
              <RankBadge rank={currentUserRank} size="sm" showName />
            </div>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Shield className="w-5 h-5 text-purple-400" />
          <h3 className="text-lg font-bold text-white">
            Write Feedback for {targetUserName}
          </h3>
        </div>
        <RankBadge rank={currentUserRank} size="sm" showName />
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Share your detailed feedback... (min 20 characters)"
            className="bg-[#141923] border-[#1a1f2e] text-white min-h-[120px] resize-none"
            disabled={isSubmitting}
          />
          <div className="flex items-center justify-between mt-2">
            <span className={`text-xs ${text.length < 20 ? 'text-gray-500' : 'text-green-500'}`}>
              {text.length} / 20 minimum
            </span>
          </div>
        </div>

        <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-600/10 border border-blue-600/30">
          <AlertCircle className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
          <div className="text-xs text-blue-300 leading-relaxed">
            Your feedback will be weighted based on your rank ({currentUserRank}) and analyzed by AI for quality. 
            Be constructive and specific.
          </div>
        </div>

        <Button
          type="submit"
          disabled={isSubmitting || text.trim().length < 20}
          className="w-full bg-gradient-to-r from-purple-600 to-indigo-700 hover:from-purple-700 hover:to-indigo-800 text-white font-bold"
        >
          {isSubmitting ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              Submitting...
            </>
          ) : (
            <>
              <Send className="w-4 h-4 mr-2" />
              Submit Feedback
            </>
          )}
        </Button>
      </form>
    </Card>
  );
}