import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cpu, Zap, Activity, CheckCircle2, Clock } from "lucide-react";

export default function CoreStatusOverview() {
  const [coreStatus, setCoreStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCoreStatus();
    const interval = setInterval(fetchCoreStatus, 8000); // Poll every 8s
    return () => clearInterval(interval);
  }, []);

  const fetchCoreStatus = async () => {
    try {
      const response = await fetch('/api/core/status');
      const data = await response.json();
      setCoreStatus(data);
    } catch (error) {
      console.error("Failed to fetch core status:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="border p-4" style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(148, 163, 184, 0.35)'
      }}>
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-gray-400 animate-pulse" />
          <span className="text-sm text-gray-400">Checking core status...</span>
        </div>
      </Card>
    );
  }

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">{coreStatus?.core || "Core"}</h3>
            <p className="text-xs text-gray-400">AI Intelligence Layer</p>
          </div>
        </div>

        <Badge className={`${
          coreStatus?.status === 'online' 
            ? 'bg-green-600/20 text-green-300 border-green-600/30'
            : 'bg-red-600/20 text-red-300 border-red-600/30'
        }`}>
          {coreStatus?.status?.toUpperCase() || "UNKNOWN"}
        </Badge>
      </div>

      {/* Modules */}
      {coreStatus?.modules && (
        <div className="mb-4">
          <h4 className="text-sm font-semibold text-gray-300 mb-2">Active Modules:</h4>
          <div className="flex flex-wrap gap-2">
            {coreStatus.modules.map((module, idx) => (
              <Badge key={idx} className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                {module}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Metrics */}
      {coreStatus?.metrics && (
        <div className="grid grid-cols-2 gap-3 pt-4 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
          <div className="text-center p-3 rounded-lg" style={{
            background: 'rgba(5, 8, 22, 0.5)',
            border: '1px solid rgba(148, 163, 184, 0.2)'
          }}>
            <Zap className="w-4 h-4 text-cyan-400 mx-auto mb-1" />
            <div className="text-xl font-bold text-white">
              {coreStatus.metrics.activeMissions || 0}
            </div>
            <div className="text-xs text-gray-400">Active Missions</div>
          </div>

          <div className="text-center p-3 rounded-lg" style={{
            background: 'rgba(5, 8, 22, 0.5)',
            border: '1px solid rgba(148, 163, 184, 0.2)'
          }}>
            <Clock className="w-4 h-4 text-purple-400 mx-auto mb-1" />
            <div className="text-xl font-bold text-white">
              {coreStatus.metrics.avgLatencyMs || "N/A"}
            </div>
            <div className="text-xs text-gray-400">Avg Latency</div>
          </div>
        </div>
      )}

      {coreStatus?.metrics?.lastUpdate && (
        <div className="text-xs text-gray-500 text-center mt-3">
          Last update: {new Date(coreStatus.metrics.lastUpdate).toLocaleTimeString()}
        </div>
      )}
    </Card>
  );
}