import React, { useState } from 'react';
import { X, GitBranch, Repeat } from 'lucide-react';
import { useTriMind } from './TriMindContext';

export default function FractalEngineerPanel({ isOpen, onClose }) {
  const triMind = useTriMind();
  const [fractalMap, setFractalMap] = useState('No fractal map generated.');

  const generateFractal = () => {
    const depths = [3, 4, 5];
    const depth = depths[Math.floor(Math.random() * depths.length)];
    const nodes = depth * depth * 2 + Math.floor(Math.random() * 10);

    let map = "";
    for (let level = 1; level <= depth; level++) {
      map += `Level ${level}:\n`;
      map += "  ".repeat(level - 1) + "↳ Section-" + level + "-A\n";
      map += "  ".repeat(level - 1) + "↳ Section-" + level + "-B\n\n";
    }
    map += `Total estimated nodes: ~${nodes}\n\n`;
    map += `Pattern: Each level duplicates and simplifies the previous structure.\n`;
    map += `Use case: Infinite-depth navigation menus, recursive dashboards, or nested task hierarchies.`;

    setFractalMap(map);

    // Update Tri-Mind state
    if (triMind) {
      triMind.setFractalState({
        depth,
        nodes,
        map
      });
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
        onClick={onClose}
      />

      {/* Panel */}
      <div 
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[460px] max-w-[90vw] h-[540px] max-h-[85vh] z-[201] overflow-y-auto"
        style={{
          background: 'rgba(5, 18, 8, 0.96)',
          borderRadius: '18px',
          border: '1px solid rgba(78, 255, 139, 0.3)',
          backdropFilter: 'blur(16px)',
          boxShadow: '0 0 80px rgba(78, 255, 139, 0.4)',
          padding: '20px',
          animation: 'panelSlideIn 0.35s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <style>{`
          @keyframes panelSlideIn {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }
        `}</style>

        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-[0.9rem] tracking-[0.2em] uppercase" style={{ color: '#4eff8b' }}>
            FRACTAL ENGINEER
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Recursive Layout Map */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#a4ffc4' }}>
            RECURSIVE LAYOUT MAP
          </h3>
          <pre 
            className="p-3 rounded-lg text-xs whitespace-pre-wrap"
            style={{
              background: 'rgba(0, 0, 0, 0.5)',
              border: '1px solid rgba(78, 255, 139, 0.3)',
              color: '#d5ffe5',
              fontFamily: 'monospace'
            }}
          >
            {fractalMap}
          </pre>
        </div>

        {/* Info */}
        <div 
          className="p-3 rounded-lg mb-6"
          style={{
            background: 'rgba(78, 255, 139, 0.1)',
            border: '1px solid rgba(78, 255, 139, 0.3)'
          }}
        >
          <div className="flex items-start gap-2">
            <Repeat className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-semibold text-white">Fractal Engineer:</span> Designs recursive, self-similar UI structures that nest infinitely. Each level duplicates and simplifies the pattern above it - perfect for complex navigation hierarchies.
            </div>
          </div>
        </div>

        {/* Action Button */}
        <button 
          onClick={generateFractal}
          className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02]"
          style={{
            background: 'linear-gradient(135deg, rgba(78, 255, 139, 0.6), rgba(71, 255, 176, 0.4))',
            border: '1px solid rgba(78, 255, 139, 0.6)',
            boxShadow: '0 0 20px rgba(78, 255, 139, 0.5)',
            color: '#000'
          }}
        >
          <GitBranch className="w-4 h-4 inline mr-2" />
          Generate Fractal Layout
        </button>
      </div>
    </>
  );
}