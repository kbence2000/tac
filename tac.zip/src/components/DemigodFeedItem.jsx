import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, Code2, Lightbulb, Trophy,
  ChevronDown, ChevronUp, Copy, Check
} from "lucide-react";
import { toast } from "sonner";

const TYPE_CONFIG = {
  showcase: {
    icon: Sparkles,
    color: "text-purple-400",
    bg: "bg-purple-600/20",
    border: "border-purple-600/30",
    label: "SHOWCASE"
  },
  snippet: {
    icon: Code2,
    color: "text-cyan-400",
    bg: "bg-cyan-600/20",
    border: "border-cyan-600/30",
    label: "SNIPPET"
  },
  helpdrop: {
    icon: Lightbulb,
    color: "text-yellow-400",
    bg: "bg-yellow-600/20",
    border: "border-yellow-600/30",
    label: "HELP DROP"
  }
};

export default function DemigodFeedItem({ item }) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const typeCfg = TYPE_CONFIG[item.type] || TYPE_CONFIG.helpdrop;
  const Icon = typeCfg.icon;

  const handleCopyCode = () => {
    if (item.code) {
      navigator.clipboard.writeText(item.code);
      setCopied(true);
      toast.success("Code copied!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const timeAgo = () => {
    const diff = Date.now() - item.time;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'just now';
  };

  return (
    <Card className="border-[#1a1f2e] bg-[#141923] p-4">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center text-xl">
            {item.demigodName.charAt(0)}
          </div>
          <div>
            <div className="font-bold text-white flex items-center gap-2">
              {item.demigodName}
              <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30 text-xs">
                <Trophy className="w-3 h-3 mr-1" />
                Demigod
              </Badge>
            </div>
            <div className="text-xs text-gray-500">{timeAgo()}</div>
          </div>
        </div>

        <Badge className={`${typeCfg.bg} ${typeCfg.color} border ${typeCfg.border}`}>
          <Icon className="w-3 h-3 mr-1" />
          {typeCfg.label}
        </Badge>
      </div>

      {/* Content based on type */}
      {item.type === "showcase" && (
        <div>
          <h3 className="text-lg font-bold text-white mb-2">{item.title}</h3>
          <p className="text-sm text-gray-300 whitespace-pre-line leading-relaxed">
            {item.description}
          </p>
        </div>
      )}

      {item.type === "snippet" && (
        <div>
          <div className="relative group mb-3">
            <pre className="bg-[#0a0a0f] border border-[#1a1f2e] rounded-lg p-4 overflow-x-auto text-sm text-gray-200 font-mono">
              <code>{item.code}</code>
            </pre>
            <Button
              size="sm"
              onClick={handleCopyCode}
              className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-purple-600 hover:bg-purple-700"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 mr-1" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3 mr-1" />
                  Copy
                </>
              )}
            </Button>
          </div>

          {/* AI Analysis */}
          {item.aiScore !== undefined && (
            <div className="p-3 rounded-lg bg-gradient-to-br from-purple-600/10 to-pink-600/10 border border-purple-600/30">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-purple-300 font-semibold">AI Analysis</span>
                <Badge className="bg-purple-600/30 text-purple-300 border-purple-600/50">
                  {item.aiScore}/100
                </Badge>
              </div>
              <p className="text-xs text-purple-200">{item.insight}</p>
            </div>
          )}
        </div>
      )}

      {item.type === "helpdrop" && (
        <div className="p-4 rounded-lg bg-gradient-to-br from-yellow-600/10 to-orange-600/10 border border-yellow-600/30">
          <div className="flex items-start gap-2">
            <Lightbulb className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-yellow-100 leading-relaxed">
              {item.message}
            </p>
          </div>
        </div>
      )}
    </Card>
  );
}