import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Inbox, Clock, DollarSign, CheckCircle2,
  Send, Code2, MessageSquare
} from "lucide-react";
import { toast } from "sonner";

const TIP_API = import.meta.env.VITE_TIP_BACKEND_URL || "http://localhost:3004";

export default function DemigodTipQueue({ demigodId }) {
  const [answerText, setAnswerText] = useState("");
  const [selectedTip, setSelectedTip] = useState(null);
  const queryClient = useQueryClient();

  const { data: tips = [], isLoading } = useQuery({
    queryKey: ['demigodTips', demigodId],
    queryFn: async () => {
      if (!demigodId) return [];
      const res = await fetch(`${TIP_API}/api/tip/user/${demigodId}`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!demigodId,
    refetchInterval: 10000, // Refresh every 10s
  });

  const answerMutation = useMutation({
    mutationFn: async ({ tipId, answer }) => {
      const res = await fetch(`${TIP_API}/api/tip/answer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tipId,
          demigodId,
          answerText: answer
        })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to answer tip');
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['demigodTips'] });
      setAnswerText("");
      setSelectedTip(null);
      toast.success(`Answer submitted! Earned €${data.demigodEarnings.totalEarnedEUR.toFixed(2)}`);
    },
    onError: (error) => {
      toast.error(error.message);
    }
  });

  const handleAnswer = () => {
    if (!selectedTip || !answerText.trim()) {
      toast.error("Please write an answer");
      return;
    }
    answerMutation.mutate({ 
      tipId: selectedTip.id, 
      answer: answerText.trim() 
    });
  };

  const pendingTips = tips.filter(t => t.status === "pending-answer");
  const answeredTips = tips.filter(t => t.status === "answered");

  return (
    <div className="space-y-6">
      {/* Pending Queue */}
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-gradient-to-br from-yellow-500/20 to-orange-500/20">
            <Inbox className="w-6 h-6 text-yellow-400" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-black text-white">Pending Requests</h3>
            <p className="text-sm text-gray-400">{pendingTips.length} tips waiting for your answer</p>
          </div>
        </div>

        {isLoading ? (
          <div className="text-center py-8">
            <div className="w-8 h-8 border-2 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : pendingTips.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Inbox className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <div className="text-sm">No pending tip requests</div>
          </div>
        ) : (
          <div className="space-y-3">
            {pendingTips.map((tip) => (
              <div
                key={tip.id}
                className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                  selectedTip?.id === tip.id
                    ? 'border-yellow-500 bg-yellow-500/10'
                    : 'border-[#1a1f2e] hover:border-gray-600'
                }`}
                onClick={() => setSelectedTip(tip)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Code2 className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-semibold text-white">
                      {tip.requesterName}
                    </span>
                  </div>
                  <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                    €{tip.priceEUR} • 80% = €{tip.demigodShareEUR}
                  </Badge>
                </div>

                {tip.question && (
                  <div className="text-sm text-gray-300 mb-2 italic">
                    "{tip.question}"
                  </div>
                )}

                <pre className="text-xs text-gray-400 font-mono bg-[#0a0a0f] p-2 rounded border border-[#1a1f2e] overflow-x-auto mb-2">
                  {tip.codeSnippet.length > 200 
                    ? tip.codeSnippet.slice(0, 200) + "..." 
                    : tip.codeSnippet}
                </pre>

                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>
                    {new Date(tip.createdAt).toLocaleString('en-US', { 
                      month: 'short', 
                      day: 'numeric', 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </span>
                  {tip.expiresAt && (
                    <>
                      <span>•</span>
                      <span>Expires in {Math.floor((tip.expiresAt - Date.now()) / 60000)}m</span>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Answer Form */}
      {selectedTip && selectedTip.status === "pending-answer" && (
        <Card className="border-yellow-500/50 bg-gradient-to-br from-yellow-600/10 to-orange-600/10 p-6">
          <div className="flex items-center gap-2 mb-4">
            <MessageSquare className="w-5 h-5 text-yellow-400" />
            <h4 className="text-lg font-bold text-white">Answer Tip Request</h4>
          </div>

          <div className="mb-4 p-3 rounded-lg bg-[#0a0a0f] border border-[#1a1f2e]">
            <div className="text-xs text-gray-500 mb-1">Request from {selectedTip.requesterName}</div>
            {selectedTip.question && (
              <div className="text-sm text-gray-300 italic mb-2">"{selectedTip.question}"</div>
            )}
            <pre className="text-xs text-gray-400 font-mono overflow-x-auto">
              {selectedTip.codeSnippet}
            </pre>
          </div>

          <Textarea
            value={answerText}
            onChange={(e) => setAnswerText(e.target.value)}
            className="bg-[#141923] border-[#1a1f2e] text-white h-32 mb-4"
            placeholder="Write your expert advice here..."
            disabled={answerMutation.isPending}
          />

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setSelectedTip(null);
                setAnswerText("");
              }}
              className="flex-1 border-[#1a1f2e] text-white"
              disabled={answerMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAnswer}
              disabled={answerMutation.isPending || !answerText.trim()}
              className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold"
            >
              {answerMutation.isPending ? (
                <>Submitting...</>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send Answer
                </>
              )}
            </Button>
          </div>
        </Card>
      )}

      {/* Answered Tips */}
      {answeredTips.length > 0 && (
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
          <div className="flex items-center gap-3 mb-4">
            <CheckCircle2 className="w-5 h-5 text-green-400" />
            <h3 className="text-lg font-bold text-white">Answered Tips</h3>
          </div>
          <div className="space-y-2">
            {answeredTips.slice(0, 5).map((tip) => (
              <div key={tip.id} className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-400">{tip.requesterName}</span>
                  <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                    +€{tip.demigodShareEUR}
                  </Badge>
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {new Date(tip.answeredAt).toLocaleDateString('en-US')}
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}