import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  ExternalLink, Copy, Check, Package, 
  AlertCircle, RefreshCw, ShoppingBag 
} from "lucide-react";
import { toast } from "sonner";

/**
 * Shopify Product Manager Component
 * Generates Shopify Product JSON for manual import
 * Provides checkout link generation with affiliate tracking
 */
export default function ShopifyProductManager({ app, onSync }) {
  const [shopifyStore, setShopifyStore] = useState(app.shopify_store_url || '');
  const [shopifyHandle, setShopifyHandle] = useState(app.shopify_handle || '');
  const [shopifyProductId, setShopifyProductId] = useState(app.shopify_product_id || '');
  const [showJson, setShowJson] = useState(false);
  const [copied, setCopied] = useState(false);
  const [syncing, setSyncing] = useState(false);

  // Generate Shopify Product JSON
  const generateProductJson = () => {
    const priceUSD = Math.round(app.price / 380); // Convert HUF to USD (approximate)
    const compareAtUSD = app.ceiling_price ? Math.round(app.ceiling_price / 380) : null;

    return {
      product: {
        title: app.name,
        body_html: `<div class="product-description">
          <h2>Leírás</h2>
          <p>${app.description || ''}</p>
          
          ${app.tech_stack && app.tech_stack.length > 0 ? `
          <h3>Technológiai Stack</h3>
          <ul>
            ${app.tech_stack.map(tech => `<li>${tech}</li>`).join('')}
          </ul>` : ''}
          
          <h3>Licenc</h3>
          <p>${app.license_type || 'BASIC'} License</p>
          
          <h3>Verzió</h3>
          <p>v${app.version || '1.0.0'}</p>
          
          ${app.changelog ? `
          <h3>Változásnapló</h3>
          <p>${app.changelog}</p>` : ''}
        </div>`,
        vendor: app.developer || 'CodeMarket',
        product_type: 'Digital Product',
        tags: ['CodeMarket', 'Software', app.category, ...(app.tags || [])].join(', '),
        variants: [
          {
            price: priceUSD.toFixed(2),
            compare_at_price: compareAtUSD ? compareAtUSD.toFixed(2) : null,
            sku: `CM-${app.id}`,
            inventory_management: null,
            fulfillment_service: 'manual',
            requires_shipping: false,
            taxable: true
          }
        ],
        images: app.screenshots && app.screenshots.length > 0 
          ? app.screenshots.map(url => ({ src: url }))
          : app.icon_url 
          ? [{ src: app.icon_url }]
          : [],
        metafields: [
          {
            namespace: 'codemarket',
            key: 'app_id',
            value: app.id,
            type: 'single_line_text_field'
          },
          {
            namespace: 'codemarket',
            key: 'download_url',
            value: app.download_url || '',
            type: 'single_line_text_field'
          },
          {
            namespace: 'codemarket',
            key: 'category',
            value: app.category,
            type: 'single_line_text_field'
          }
        ]
      }
    };
  };

  const handleCopyJson = () => {
    const json = JSON.stringify(generateProductJson(), null, 2);
    navigator.clipboard.writeText(json);
    setCopied(true);
    toast.success('Shopify Product JSON másolva!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSyncShopify = async () => {
    if (!shopifyStore || !shopifyHandle) {
      toast.error('Add meg a Shopify store URL-t és a product handle-t!');
      return;
    }

    setSyncing(true);
    try {
      // Update app with Shopify info
      await onSync({
        shopify_store_url: shopifyStore,
        shopify_handle: shopifyHandle,
        shopify_product_id: shopifyProductId,
        shopify_synced_at: new Date().toISOString()
      });
      
      toast.success('Shopify adatok mentve!');
    } catch (error) {
      console.error('Sync error:', error);
      toast.error('Hiba a mentés során');
    } finally {
      setSyncing(false);
    }
  };

  const checkoutUrl = shopifyStore && shopifyHandle 
    ? `https://${shopifyStore}/products/${shopifyHandle}`
    : null;

  return (
    <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-gradient-to-br from-green-500/20 to-emerald-500/20">
          <ShoppingBag className="w-6 h-6 text-green-400" />
        </div>
        <div>
          <h3 className="text-xl font-black text-white">Shopify Integráció</h3>
          <p className="text-sm text-gray-400">Termék szinkronizálás és checkout linkek</p>
        </div>
      </div>

      {/* Step 1: Generate Product JSON */}
      <div className="space-y-4 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-bold text-white mb-1">1. Termék JSON Generálás</h4>
            <p className="text-xs text-gray-400">
              Exportáld a termék JSON-t Shopify Admin API-hoz
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowJson(!showJson)}
            className="border-[#1a1f2e] text-gray-300"
          >
            {showJson ? 'JSON Elrejtése' : 'JSON Mutatása'}
          </Button>
        </div>

        {showJson && (
          <div className="relative">
            <Textarea
              readOnly
              value={JSON.stringify(generateProductJson(), null, 2)}
              className="bg-[#141923] border-[#1a1f2e] text-white font-mono text-xs h-64"
            />
            <Button
              size="sm"
              onClick={handleCopyJson}
              className="absolute top-2 right-2 bg-[#00E599] text-black hover:bg-[#00E599]/90"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Másolva
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Másolás
                </>
              )}
            </Button>
          </div>
        )}

        <div className="p-3 rounded-lg bg-blue-600/10 border border-blue-600/30">
          <p className="text-xs text-blue-200">
            <AlertCircle className="w-4 h-4 inline mr-2" />
            <strong>Importálás:</strong> Shopify Admin → Products → Add product → Import → 
            Illeszd be a JSON-t vagy használd a Shopify Admin API-t
          </p>
        </div>
      </div>

      {/* Step 2: Configure Shopify Details */}
      <div className="space-y-4 mb-6 pt-6 border-t border-[#1a1f2e]">
        <div>
          <h4 className="text-sm font-bold text-white mb-3">2. Shopify Termék Konfiguráció</h4>
          
          <div className="space-y-3">
            <div>
              <label className="text-xs text-gray-400 block mb-1">
                Shopify Store URL
              </label>
              <Input
                placeholder="mystore.myshopify.com"
                value={shopifyStore}
                onChange={(e) => setShopifyStore(e.target.value)}
                className="bg-[#141923] border-[#1a1f2e] text-white text-sm"
              />
            </div>

            <div>
              <label className="text-xs text-gray-400 block mb-1">
                Product Handle (URL slug)
              </label>
              <Input
                placeholder="my-awesome-app"
                value={shopifyHandle}
                onChange={(e) => setShopifyHandle(e.target.value)}
                className="bg-[#141923] border-[#1a1f2e] text-white text-sm"
              />
            </div>

            <div>
              <label className="text-xs text-gray-400 block mb-1">
                Product ID (opcionális)
              </label>
              <Input
                placeholder="gid://shopify/Product/1234567890"
                value={shopifyProductId}
                onChange={(e) => setShopifyProductId(e.target.value)}
                className="bg-[#141923] border-[#1a1f2e] text-white text-sm"
              />
            </div>
          </div>

          <Button
            onClick={handleSyncShopify}
            disabled={syncing || !shopifyStore || !shopifyHandle}
            className="w-full mt-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white"
          >
            {syncing ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Mentés...
              </>
            ) : (
              <>
                <Package className="w-4 h-4 mr-2" />
                Shopify Adatok Mentése
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Step 3: Checkout Link */}
      {checkoutUrl && (
        <div className="space-y-3 pt-6 border-t border-[#1a1f2e]">
          <div>
            <h4 className="text-sm font-bold text-white mb-2">3. Checkout Link</h4>
            <div className="flex gap-2">
              <Input
                readOnly
                value={checkoutUrl}
                className="bg-[#141923] border-[#1a1f2e] text-white text-sm font-mono"
              />
              <Button
                onClick={() => {
                  navigator.clipboard.writeText(checkoutUrl);
                  toast.success('Checkout link másolva!');
                }}
                variant="outline"
                className="border-[#1a1f2e]"
              >
                <Copy className="w-4 h-4" />
              </Button>
              <Button
                onClick={() => window.open(checkoutUrl, '_blank')}
                className="bg-green-600 hover:bg-green-700"
              >
                <ExternalLink className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {app.shopify_synced_at && (
            <Badge className="bg-green-600/20 text-green-400 border border-green-600/30">
              <Check className="w-3 h-3 mr-1" />
              Szinkronizálva: {new Date(app.shopify_synced_at).toLocaleString('hu-HU')}
            </Badge>
          )}
        </div>
      )}
    </Card>
  );
}