import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Inbox, Check, X, Clock, 
  DollarSign, Briefcase, Building
} from "lucide-react";
import { toast } from "sonner";

const STAKE_API = import.meta.env.VITE_STAKE_BACKEND_URL || "http://localhost:3005";

const STATUS_CONFIG = {
  requested: {
    label: "Pending",
    color: "text-yellow-400",
    bg: "bg-yellow-600/20",
    border: "border-yellow-600/30"
  },
  accepted: {
    label: "Accepted",
    color: "text-green-400",
    bg: "bg-green-600/20",
    border: "border-green-600/30"
  },
  rejected: {
    label: "Rejected",
    color: "text-red-400",
    bg: "bg-red-600/20",
    border: "border-red-600/30"
  }
};

export default function EngagementInbox({ devId }) {
  const queryClient = useQueryClient();

  const { data: engagements = [], isLoading } = useQuery({
    queryKey: ['devEngagements', devId],
    queryFn: async () => {
      if (!devId) return [];
      const res = await fetch(`${STAKE_API}/api/stake/engagement/dev/${devId}`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!devId,
    refetchInterval: 15000,
  });

  const decisionMutation = useMutation({
    mutationFn: async ({ engagementId, decision }) => {
      const res = await fetch(`${STAKE_API}/api/stake/engagement/dev/decision`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ engagementId, devId, decision })
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Decision failed');
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['devEngagements'] });
      toast.success(`Engagement ${data.status}!`);
    },
    onError: (error) => {
      toast.error(error.message);
    }
  });

  const handleDecision = (engagementId, decision) => {
    decisionMutation.mutate({ engagementId, decision });
  };

  const pendingEngagements = engagements.filter(e => e.status === "requested");
  const otherEngagements = engagements.filter(e => e.status !== "requested");

  if (isLoading) {
    return (
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="text-center py-8">
          <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Pending Requests */}
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
        <div className="flex items-center gap-3 mb-4">
          <Inbox className="w-6 h-6 text-yellow-400" />
          <div className="flex-1">
            <h3 className="text-xl font-black text-white">Engagement Requests</h3>
            <p className="text-sm text-gray-400">{pendingEngagements.length} pending review</p>
          </div>
        </div>

        {pendingEngagements.length === 0 ? (
          <div className="text-center py-8 text-gray-500 text-sm">
            No pending engagement requests
          </div>
        ) : (
          <div className="space-y-3">
            {pendingEngagements.map((eng) => (
              <div key={eng.id} className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Building className="w-4 h-4 text-gray-400" />
                      <span className="font-semibold text-white">{eng.companyName}</span>
                    </div>
                    <div className="text-sm text-gray-400">
                      Project: <span className="text-white font-medium">{eng.projectTitle}</span>
                    </div>
                  </div>
                  <Badge className={`${STATUS_CONFIG[eng.status].bg} ${STATUS_CONFIG[eng.status].color} border ${STATUS_CONFIG[eng.status].border}`}>
                    {STATUS_CONFIG[eng.status].label}
                  </Badge>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
                  <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e] text-center">
                    <div className="text-gray-500 mb-1">Total Budget</div>
                    <div className="font-bold text-white">€{eng.budgetEUR?.toLocaleString()}</div>
                  </div>
                  <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e] text-center">
                    <div className="text-gray-500 mb-1">Platform Fee</div>
                    <div className="font-bold text-red-400">-€{eng.platformFeeEUR?.toLocaleString()}</div>
                  </div>
                  <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e] text-center">
                    <div className="text-gray-500 mb-1">You Receive</div>
                    <div className="font-bold text-green-400">€{eng.devShareEUR?.toLocaleString()}</div>
                  </div>
                </div>

                {eng.notes && (
                  <div className="p-3 rounded bg-[#0a0a0f] border border-[#1a1f2e] mb-3">
                    <div className="text-xs text-gray-500 mb-1">Company Notes:</div>
                    <p className="text-sm text-gray-300">{eng.notes}</p>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    onClick={() => handleDecision(eng.id, "reject")}
                    disabled={decisionMutation.isPending}
                    variant="outline"
                    className="flex-1 border-red-600/30 text-red-400 hover:bg-red-600/10"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Reject
                  </Button>
                  <Button
                    onClick={() => handleDecision(eng.id, "accept")}
                    disabled={decisionMutation.isPending}
                    className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Accept Offer
                  </Button>
                </div>

                <div className="mt-2 text-xs text-gray-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {new Date(eng.createdAt).toLocaleString('en-US')}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Engagement History */}
      {otherEngagements.length > 0 && (
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
          <h3 className="text-lg font-bold text-white mb-4">Engagement History</h3>
          <div className="space-y-2">
            {otherEngagements.slice(0, 5).map((eng) => {
              const statusCfg = STATUS_CONFIG[eng.status];
              
              return (
                <div key={eng.id} className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-white">{eng.projectTitle}</div>
                      <div className="text-xs text-gray-400">
                        {eng.companyName} • €{eng.budgetEUR?.toLocaleString()}
                      </div>
                    </div>
                    <Badge className={`${statusCfg.bg} ${statusCfg.color} border ${statusCfg.border}`}>
                      {statusCfg.label}
                    </Badge>
                  </div>
                  {eng.status === "accepted" && (
                    <div className="mt-2 text-xs text-green-400 font-medium">
                      +€{eng.devShareEUR?.toLocaleString()} earned
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}