import React, { useState, useEffect } from 'react';
import { X, Eye, Sparkles, Loader2, Image as ImageIcon } from 'lucide-react';
import { useTriMind } from './TriMindContext';

export default function DreamRendererPanel({ isOpen, onClose }) {
  const triMind = useTriMind();
  const [loading, setLoading] = useState(false);
  const [blueprints, setBlueprints] = useState([]);
  const [promptPreview, setPromptPreview] = useState('');

  const chaosSubjects = [
    "Mission Control UI",
    "Marketplace grid",
    "Neural Core orb",
    "Demigod profile page",
    "For You feed",
    "Agent swarm visualizer",
    "Debug timeline",
    "Talent discovery map",
    "Company portal dashboard",
    "Code snippet detail view"
  ];

  const chaosStyles = [
    "cyberpunk OS aesthetic",
    "minimal Apple-like chrome with hidden depth",
    "NVIDIA tech-demo level neon lighting",
    "clean Neuralink-lab style",
    "holographic command center look",
    "retro-futuristic terminal vibes in 3D",
    "elegant financial-trading interface energy",
    "AI cathedral interior feel",
    "blade-runner city-light reflection theme",
    "dark glass with quantum particles drifting behind"
  ];

  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  const generateInitialBlueprints = () => {
    const initial = [
      {
        title: "Neural Mission Room",
        description: "A dark glass control room where agents are glowing nodes, connected by animated neural lines."
      },
      {
        title: "Living Marketplace",
        description: "Code assets float in 3D clusters, rearranging themselves based on demand and relevance."
      },
      {
        title: "Swarm Vision HUD",
        description: "A tactical overlay showing agent swarms as colored waves moving across mission phases."
      },
      {
        title: "Demigod Profiles",
        description: "Legendary devs visualized as constellations, each star a shipped solution or breakthrough."
      }
    ];
    setBlueprints(initial);
  };

  const generateBlueprint = () => {
    setLoading(true);

    setTimeout(() => {
      const target = triMind?.chaosIdeas?.length 
        ? pick(chaosSubjects) 
        : "Neural Core OS screen";
      
      const style = triMind?.chaosIdeas?.length 
        ? pick(chaosStyles) 
        : "dark glass with quantum particles drifting behind";
      
      const efficiency = triMind?.neuroState?.efficiency || 82;

      const newBlueprint = {
        name: "Q-Blueprint " + Math.floor(Math.random() * 999),
        target,
        style,
        efficiencyHint: efficiency,
        title: `${target} Blueprint`,
        description: `Target: ${target}. Style: ${style}. Optimized for ~${efficiency}% workflow efficiency.`
      };

      const imgPrompt = `Ultra-detailed futuristic UI concept for ${target}, in a ${style}.
Show a dark, premium AI operating system interface with glowing neural lines,
radial modules around a central core, subtle particle effects, and a cinematic contrast.
It should feel like the inside of an advanced AI mind, but remain readable and functional.`;

      setPromptPreview(imgPrompt);
      setBlueprints([newBlueprint, ...blueprints]);

      // Update Tri-Mind state
      if (triMind) {
        triMind.setBlueprint(newBlueprint);
      }

      setLoading(false);
    }, 1500);
  };

  useEffect(() => {
    if (isOpen && blueprints.length === 0) {
      generateInitialBlueprints();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200]"
        onClick={onClose}
      />

      {/* Panel */}
      <div 
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[460px] max-w-[90vw] h-[540px] max-h-[85vh] z-[201] overflow-y-auto"
        style={{
          background: 'rgba(7, 7, 18, 0.92)',
          borderRadius: '18px',
          border: '1px solid rgba(59, 211, 255, 0.26)',
          backdropFilter: 'blur(16px)',
          boxShadow: '0 0 80px rgba(59, 211, 255, 0.4)',
          padding: '20px',
          animation: 'panelSlideIn 0.35s ease-out'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <style>{`
          @keyframes panelSlideIn {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.9);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }
        `}</style>

        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="text-[0.9rem] tracking-[0.2em] uppercase" style={{ color: '#3bd3ff' }}>
            DREAM RENDERING ENGINE
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Blueprint Snapshots */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#9fa8ff' }}>
            BLUEPRINT SNAPSHOTS
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {blueprints.map((bp, idx) => (
              <div
                key={idx}
                className="relative overflow-hidden rounded-xl p-3 border"
                style={{
                  background: 'rgba(3, 14, 22, 0.95)',
                  borderColor: 'rgba(59, 211, 255, 0.26)'
                }}
              >
                <div 
                  className="absolute inset-0 opacity-40 pointer-events-none"
                  style={{
                    background: 'radial-gradient(circle at 0 0, rgba(59, 211, 255, 0.35), transparent 60%)'
                  }}
                />
                <h4 className="text-xs font-semibold uppercase tracking-wide mb-2 relative z-10" style={{ color: '#9ce7ff' }}>
                  {bp.title}
                </h4>
                <p className="text-[0.68rem] relative z-10" style={{ color: '#d9f8ff' }}>
                  {bp.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* New Blueprint Generation */}
        <div className="mb-6">
          <h3 className="text-[0.8rem] tracking-[0.16em] mb-3 font-semibold" style={{ color: '#9fa8ff' }}>
            NEW VISUAL BLUEPRINT
          </h3>
          <button
            onClick={generateBlueprint}
            disabled={loading}
            className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            style={{
              background: 'linear-gradient(135deg, rgba(59, 211, 255, 0.9), rgba(123, 63, 246, 0.95))',
              border: 'none',
              color: '#fff',
              boxShadow: '0 0 18px rgba(59, 211, 255, 0.65)'
            }}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Rendering Dream...
              </>
            ) : (
              <>
                <Eye className="w-4 h-4" />
                Generate Blueprint from Neuro + Chaos
              </>
            )}
          </button>
        </div>

        {/* Prompt Preview */}
        {promptPreview && (
          <div className="mb-4">
            <h3 className="text-[0.8rem] tracking-[0.16em] mb-2 font-semibold" style={{ color: '#9fa8ff' }}>
              IMAGE PROMPT (FOR AI GENERATION)
            </h3>
            <div 
              className="p-3 rounded-lg text-[0.65rem] leading-relaxed max-h-32 overflow-y-auto"
              style={{
                background: 'rgba(59, 211, 255, 0.05)',
                border: '1px solid rgba(59, 211, 255, 0.15)',
                color: '#ccf7ff',
                fontFamily: 'monospace',
                whiteSpace: 'pre-wrap'
              }}
            >
              {promptPreview}
            </div>
          </div>
        )}

        {/* Info */}
        <div className="p-3 rounded-lg" style={{ background: 'rgba(59, 211, 255, 0.1)', border: '1px solid rgba(59, 211, 255, 0.3)' }}>
          <div className="flex items-start gap-2">
            <ImageIcon className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-semibold text-white">Dream Renderer:</span> Synthesizes visual blueprints by combining Neuro Evolution metrics with Chaos Architect concepts. Use the prompt with AI image generators like Midjourney or DALL-E.
            </div>
          </div>
        </div>
      </div>
    </>
  );
}