/**
 * MDC Core API Client
 * Type-safe wrapper for all Core API endpoints
 */

class CoreAPIClient {
  constructor(baseURL = '/api/core') {
    this.baseURL = baseURL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    if (options.body && typeof options.body === 'object') {
      config.body = JSON.stringify(options.body);
    }

    const response = await fetch(url, config);
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: response.statusText }));
      throw new Error(error.error || error.message || 'API request failed');
    }

    return response.json();
  }

  // ============================================
  // ORCHESTRATOR
  // ============================================

  /**
   * Execute orchestrator workflow
   * @param {Object} params
   * @param {string} params.task - Task description
   * @param {Object} params.context - Additional context
   * @returns {Promise<Object>} Workflow result
   */
  async runOrchestrator(params) {
    return this.request('/orchestrator/run', {
      method: 'POST',
      body: params,
    });
  }

  // ============================================
  // MODULES
  // ============================================

  /**
   * List all available modules
   * @returns {Promise<Array>} Module list
   */
  async listModules() {
    return this.request('/modules/list', {
      method: 'GET',
    });
  }

  /**
   * Run a specific module
   * @param {Object} params
   * @param {string} params.moduleId - Module identifier
   * @param {Object} params.input - Module input
   * @returns {Promise<Object>} Module result
   */
  async runModule(params) {
    return this.request('/modules/run', {
      method: 'POST',
      body: params,
    });
  }

  // ============================================
  // SECURITY
  // ============================================

  /**
   * Get security status
   * @returns {Promise<Object>} Security status
   */
  async getSecurityStatus() {
    return this.request('/security/status', {
      method: 'GET',
    });
  }

  /**
   * Quarantine a threat
   * @param {Object} params
   * @param {string} params.threatId - Threat identifier
   * @param {string} params.reason - Quarantine reason
   * @returns {Promise<Object>} Quarantine result
   */
  async quarantineThreat(params) {
    return this.request('/security/quarantine', {
      method: 'POST',
      body: params,
    });
  }

  // ============================================
  // MISSION ENGINE
  // ============================================

  /**
   * Deploy a mission
   * @param {Object} params
   * @param {string} params.missionId - Mission identifier
   * @param {Object} params.config - Deployment config
   * @returns {Promise<Object>} Deployment result
   */
  async deployMission(params) {
    return this.request('/mission-engine/deploy', {
      method: 'POST',
      body: params,
    });
  }

  /**
   * Retry a failed mission
   * @param {Object} params
   * @param {string} params.missionId - Mission identifier
   * @returns {Promise<Object>} Retry result
   */
  async retryMission(params) {
    return this.request('/mission-engine/retry', {
      method: 'POST',
      body: params,
    });
  }

  /**
   * Get mission logs
   * @param {string} missionId - Mission identifier
   * @returns {Promise<Array>} Mission logs
   */
  async getMissionLogs(missionId) {
    return this.request(`/mission-engine/logs?missionId=${missionId}`, {
      method: 'GET',
    });
  }

  // ============================================
  // SWARM
  // ============================================

  /**
   * Get swarm events
   * @param {Object} params
   * @param {number} params.limit - Max events to return
   * @param {string} params.since - Timestamp filter
   * @returns {Promise<Array>} Swarm events
   */
  async getSwarmEvents(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/swarm/events${query ? '?' + query : ''}`, {
      method: 'GET',
    });
  }

  // ============================================
  // SYSTEM
  // ============================================

  /**
   * Get system heartbeat
   * @returns {Promise<Object>} System health
   */
  async getHeartbeat() {
    return this.request('/heartbeat', {
      method: 'GET',
    });
  }

  /**
   * Trigger system reflection
   * @param {Object} params
   * @param {string} params.scope - Reflection scope
   * @returns {Promise<Object>} Reflection result
   */
  async triggerReflection(params) {
    return this.request('/reflection', {
      method: 'POST',
      body: params,
    });
  }
}

// Export singleton instance
export const coreAPI = new CoreAPIClient();

// Also export class for custom instances
export default CoreAPIClient;