/**
 * AlmightyObserver - Universal code observation hooks
 * Automatically feeds AlmightyCollective Core from all code flows
 * 
 * Usage:
 *   import { observeCode } from "@/components/AlmightyObserver";
 *   observeCode({ userId, rank, language, code, sourceType });
 */

import { base44 } from "@/api/base44Client";

/**
 * Source types for different code flows in MDC
 */
export const SOURCE_TYPES = {
  CODING_PVP: "coding_pvp",
  INNOVATION_PVP: "innovation_pvp",
  APP_UPLOAD: "app_upload",
  PROJECT_STAKE: "project_stake",
  DEMIGOD_TIP: "demigod_tip",
  CLOUD_RUNTIME: "cloud_runtime",
  GENERIC: "generic"
};

/**
 * Observe code event - feeds AlmightyCollective Core
 * This is a "fire and forget" call - never blocks UI
 */
export async function observeCode({
  userId,
  rank = "regular",
  language = "unknown",
  code,
  sourceType = SOURCE_TYPES.GENERIC,
  meta = {}
}) {
  if (!code || !userId) {
    console.warn("AlmightyObserver: Missing userId or code");
    return;
  }

  try {
    // In production: call your backend bridge
    // await fetch("/api/almighty/observe", {
    //   method: "POST",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify({ userId, rank, language, code, sourceType, meta })
    // });

    // For now: log for integration testing
    console.log("🧠 AlmightyCore observation:", {
      userId,
      rank,
      language,
      sourceType,
      codeLength: code.length,
      meta
    });

    return true;
  } catch (err) {
    // Silent fail - never break the user flow
    console.error("AlmightyObserver error:", err.message);
    return false;
  }
}

/**
 * Privileged call to AlmightyCollective Core
 * Requires ROOT_MASTER_KEY - only for admin/backend use
 */
export async function callAlmightyPrivileged(method, args, masterKey) {
  if (!masterKey) {
    throw new Error("Missing master key for privileged AlmightyCollective call");
  }

  try {
    const response = await fetch("/api/almighty/privileged", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-AC-Master-Key": masterKey
      },
      body: JSON.stringify({ method, args })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${await response.text()}`);
    }

    return await response.json();
  } catch (err) {
    console.error("AlmightyPrivileged error:", err.message);
    throw err;
  }
}

/**
 * Get mastery snapshot (privileged)
 */
export async function getMasterySnapshot(limit = 30, masterKey) {
  return callAlmightyPrivileged("snapshot", { limit }, masterKey);
}

/**
 * Generate innovation suggestions (privileged)
 */
export async function generateSuggestions(goal, language, masterKey) {
  return callAlmightyPrivileged("suggest", { goal, language }, masterKey);
}

/**
 * Export AlmightyCore state (privileged)
 */
export async function exportCoreState(masterKey) {
  return callAlmightyPrivileged("export", {}, masterKey);
}

/**
 * Import AlmightyCore state (privileged)
 */
export async function importCoreState(snapshot, masterKey) {
  return callAlmightyPrivileged("import", { snapshot }, masterKey);
}

/**
 * React hook for easy observation in components
 */
export function useAlmightyObserver() {
  return {
    observeCode,
    SOURCE_TYPES
  };
}