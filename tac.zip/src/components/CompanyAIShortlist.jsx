import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Brain, Users, Loader2, TrendingUp, Github, Star, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { companyAPI } from "./CompanyAPIClient";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function CompanyAIShortlist({ companyId, missionId, missionData }) {
  const [generating, setGenerating] = useState(false);
  const [shortlist, setShortlist] = useState(null);

  const { data: expertProfiles } = useQuery({
    queryKey: ['expertProfiles'],
    queryFn: () => base44.entities.ExpertProfile.list('-created_date', 50),
    initialData: [],
  });

  const handleGenerateShortlist = async () => {
    if (expertProfiles.length === 0) {
      toast.error("No expert profiles available");
      return;
    }

    setGenerating(true);

    try {
      // Prepare candidates from expert profiles
      const candidates = expertProfiles.slice(0, 10).map(profile => ({
        id: profile.user_email,
        handle: profile.user_email.split('@')[0],
        skills: profile.skills || [],
        experienceLevel: profile.experience_level,
        rating: profile.rating || 0,
        completedTasks: profile.completed_tasks || 0,
        bio: profile.bio || "",
      }));

      const result = await companyAPI.getAIShortlist(companyId, missionId, candidates);
      
      setShortlist(result.shortlist || []);
      toast.success("AI Shortlist generated!");
    } catch (error) {
      console.error("Failed to generate shortlist:", error);
      toast.error("Failed to generate shortlist: " + error.message);
    } finally {
      setGenerating(false);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-400";
    if (score >= 60) return "text-cyan-400";
    if (score >= 40) return "text-yellow-400";
    return "text-orange-400";
  };

  return (
    <Card className="border p-6" style={{
      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
      borderColor: 'rgba(139, 92, 255, 0.3)'
    }}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">AI Shortlist</h3>
            <p className="text-sm text-gray-400">AI-powered talent matching</p>
          </div>
        </div>

        <Button
          onClick={handleGenerateShortlist}
          disabled={generating}
          size="sm"
          style={{
            background: generating ? '#4a5568' : 'linear-gradient(135deg, #8b5cff, #24e4ff)',
            color: 'white'
          }}
        >
          {generating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Brain className="w-4 h-4 mr-2" />
              Generate Shortlist
            </>
          )}
        </Button>
      </div>

      {missionData && (
        <div className="mb-6 p-4 rounded-lg border" style={{
          background: 'rgba(5, 8, 22, 0.5)',
          borderColor: 'rgba(148, 163, 184, 0.2)'
        }}>
          <h4 className="font-semibold text-white mb-2">{missionData.title}</h4>
          <div className="flex items-center gap-2">
            <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30">
              {missionData.complexity}
            </Badge>
            <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30">
              €{missionData.bounty}
            </Badge>
          </div>
        </div>
      )}

      {/* Shortlist Results */}
      {shortlist && shortlist.length > 0 && (
        <div className="space-y-4">
          <h4 className="font-semibold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-cyan-400" />
            Top Candidates ({shortlist.length})
          </h4>

          <div className="space-y-3">
            {shortlist
              .sort((a, b) => (b.score || 0) - (a.score || 0))
              .map((candidate, idx) => (
                <Card
                  key={candidate.id}
                  className="border p-4 hover:shadow-lg transition-all"
                  style={{
                    background: candidate.recommended 
                      ? 'linear-gradient(135deg, rgba(34, 197, 94, 0.05), rgba(16, 185, 129, 0.05))'
                      : 'rgba(15, 23, 42, 0.95)',
                    borderColor: candidate.recommended 
                      ? 'rgba(34, 197, 94, 0.4)'
                      : 'rgba(148, 163, 184, 0.35)'
                  }}
                >
                  <div className="flex items-start gap-4">
                    {/* Rank Badge */}
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                      idx === 0 ? 'bg-yellow-500 text-black' :
                      idx === 1 ? 'bg-gray-400 text-black' :
                      idx === 2 ? 'bg-orange-500 text-black' :
                      'bg-gray-700 text-white'
                    }`}>
                      #{idx + 1}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-white">{candidate.handle}</h4>
                          {candidate.recommended && (
                            <Badge className="bg-green-600/20 text-green-300 border-green-600/30">
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              Recommended
                            </Badge>
                          )}
                        </div>
                        <div className={`text-2xl font-bold ${getScoreColor(candidate.score || 0)}`}>
                          {candidate.score || 0}
                        </div>
                      </div>

                      <p className="text-sm text-gray-300 mb-3 leading-relaxed">
                        {candidate.reason || "AI match analysis"}
                      </p>

                      {candidate.skills && candidate.skills.length > 0 && (
                        <div className="flex flex-wrap gap-1.5">
                          {candidate.skills.slice(0, 5).map((skill, idx) => (
                            <Badge key={idx} className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30 text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
          </div>
        </div>
      )}

      {!shortlist && !generating && (
        <div className="text-center py-12 text-gray-400">
          <Brain className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Click "Generate Shortlist" to get AI-powered candidate matches</p>
        </div>
      )}
    </Card>
  );
}