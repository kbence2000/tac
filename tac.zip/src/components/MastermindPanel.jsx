import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Brain, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  Zap, 
  TrendingUp,
  Loader2,
  RefreshCw,
  Sparkles,
  Target,
  Lightbulb
} from "lucide-react";

export default function MastermindPanel() {
  const [modules, setModules] = useState([]);
  const [selfEval, setSelfEval] = useState(null);
  const [recommendations, setRecommendations] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadData();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    if (modules.length > 0) setRefreshing(true);
    else setLoading(true);

    try {
      await Promise.all([
        loadModuleStatus(),
        loadSelfEval(),
        loadRecommendations()
      ]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const loadModuleStatus = async () => {
    try {
      const response = await fetch('/api/mastermind/status');
      if (response.ok) {
        const data = await response.json();
        setModules(data.modules || []);
      }
    } catch (error) {
      console.error('Failed to load module status:', error);
    }
  };

  const loadSelfEval = async () => {
    try {
      const response = await fetch('/api/mastermind/self-eval', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      if (response.ok) {
        const data = await response.json();
        setSelfEval(data);
      }
    } catch (error) {
      console.error('Failed to load self-eval:', error);
    }
  };

  const loadRecommendations = async () => {
    try {
      const response = await fetch('/api/mastermind/suggest-optimizations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ goals: ['stability', 'scale', 'performance'] })
      });
      if (response.ok) {
        const data = await response.json();
        setRecommendations(data);
      }
    } catch (error) {
      console.error('Failed to load recommendations:', error);
    }
  };

  const getHealthColor = (health) => {
    switch (health) {
      case 'good': return 'bg-green-600/20 text-green-300 border-green-600/30';
      case 'mid': return 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30';
      case 'poor': return 'bg-red-600/20 text-red-300 border-red-600/30';
      default: return 'bg-gray-600/20 text-gray-300 border-gray-600/30';
    }
  };

  const getHealthIcon = (health) => {
    switch (health) {
      case 'good': return <CheckCircle2 className="w-5 h-5 text-green-400" />;
      case 'mid': return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case 'poor': return <AlertTriangle className="w-5 h-5 text-red-400" />;
      default: return <Activity className="w-5 h-5 text-gray-400" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-purple-400" />
          <p className="text-gray-400">Loading Mastermind diagnostics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center animate-pulse-glow" style={{
                background: 'linear-gradient(135deg, #8b5cff, #24e4ff)'
              }}>
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-black gradient-text">ALMIGHTY COLLECTIVE</h1>
                <p className="text-sm text-gray-400">Real-time AI Meta Diagnostic</p>
              </div>
            </div>
          </div>
          
          <Button
            onClick={loadData}
            disabled={refreshing}
            variant="outline"
            className="border-purple-600/50 text-purple-400 hover:bg-purple-600/20"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </Button>
        </div>

        {/* Module Health Cards */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5 text-cyan-400" />
            <h2 className="text-xl font-bold text-white">Module Health Status</h2>
          </div>

          {modules.length === 0 ? (
            <Card className="border p-8 text-center" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(148, 163, 184, 0.35)'
            }}>
              <Sparkles className="w-12 h-12 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No module metrics yet. Modules will appear here once they start reporting.</p>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {modules.map((module, idx) => (
                <Card key={idx} className="border p-4 hover:shadow-lg transition-all" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {getHealthIcon(module.health)}
                      <div>
                        <h3 className="font-bold text-white">{module.moduleName}</h3>
                        <p className="text-xs text-gray-500">{module.role}</p>
                      </div>
                    </div>
                    <Badge className={getHealthColor(module.health)}>
                      {module.health?.toUpperCase()}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <div className="text-gray-500 text-xs">Calls</div>
                      <div className="text-white font-semibold">{module.calls}</div>
                    </div>
                    <div>
                      <div className="text-gray-500 text-xs">Success Rate</div>
                      <div className="text-white font-semibold">{(module.successRate * 100).toFixed(0)}%</div>
                    </div>
                    {module.avgLatencyMs && (
                      <div>
                        <div className="text-gray-500 text-xs">Avg Latency</div>
                        <div className="text-white font-semibold">{module.avgLatencyMs}ms</div>
                      </div>
                    )}
                    <div>
                      <div className="text-gray-500 text-xs">Errors</div>
                      <div className="text-white font-semibold">{module.errorCount}</div>
                    </div>
                  </div>

                  {module.lastErrorCode && (
                    <div className="mt-3 pt-3 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
                      <div className="text-xs text-red-400">Last Error: {module.lastErrorCode}</div>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </section>

        {/* Self Evaluation */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-5 h-5 text-purple-400" />
            <h2 className="text-xl font-bold text-white">System Self-Evaluation</h2>
          </div>

          <Card className="border p-6" style={{
            background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
            borderColor: 'rgba(139, 92, 255, 0.3)'
          }}>
            {!selfEval ? (
              <div className="text-center py-8">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-400" />
                <p className="text-gray-400">Running self-evaluation...</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Global Summary */}
                {selfEval.globalSummary && (
                  <div>
                    <h3 className="font-bold text-white mb-2 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      Global Summary
                    </h3>
                    <p className="text-gray-300 leading-relaxed">{selfEval.globalSummary}</p>
                  </div>
                )}

                {/* Per-Module Assessment */}
                {selfEval.perModule && selfEval.perModule.length > 0 && (
                  <div>
                    <h3 className="font-bold text-white mb-3">Per-Module Assessment</h3>
                    <div className="space-y-2">
                      {selfEval.perModule.map((mod, idx) => (
                        <div key={idx} className="p-3 rounded-lg border" style={{
                          background: 'rgba(15, 23, 42, 0.9)',
                          borderColor: 'rgba(148, 163, 184, 0.2)'
                        }}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-white">{mod.moduleName}</span>
                            <Badge className={getHealthColor(mod.health)}>
                              {mod.health}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-400">{mod.notes}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Risks */}
                {selfEval.risks && selfEval.risks.length > 0 && (
                  <div>
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-400" />
                      Identified Risks
                    </h3>
                    <ul className="space-y-2">
                      {selfEval.risks.map((risk, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-gray-300">
                          <span className="text-yellow-400 mt-0.5">⚠</span>
                          <span>{risk}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Recommendations */}
                {selfEval.recommendations && selfEval.recommendations.length > 0 && (
                  <div>
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-400" />
                      Recommendations
                    </h3>
                    <ul className="space-y-2">
                      {selfEval.recommendations.map((rec, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-gray-300">
                          <span className="text-green-400 mt-0.5">✓</span>
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </Card>
        </section>

        {/* Mastermind Recommendations */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Target className="w-5 h-5 text-cyan-400" />
            <h2 className="text-xl font-bold text-white">Mastermind Recommendations</h2>
          </div>

          <Card className="border p-6" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(36, 228, 255, 0.3)'
          }}>
            {!recommendations ? (
              <div className="text-center py-8">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-cyan-400" />
                <p className="text-gray-400">Generating optimization plan...</p>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Strategy */}
                {recommendations.strategy && recommendations.strategy.length > 0 && (
                  <div>
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <Brain className="w-4 h-4 text-purple-400" />
                      Strategic Approach
                    </h3>
                    <ul className="space-y-2">
                      {recommendations.strategy.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-gray-300">
                          <span className="text-purple-400 mt-0.5">→</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Prioritized Tasks */}
                {recommendations.prioritizedTasks && recommendations.prioritizedTasks.length > 0 && (
                  <div>
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <Target className="w-4 h-4 text-cyan-400" />
                      Prioritized Tasks
                    </h3>
                    <div className="space-y-3">
                      {recommendations.prioritizedTasks.map((task, idx) => (
                        <div key={idx} className="p-4 rounded-lg border" style={{
                          background: 'rgba(5, 8, 22, 0.9)',
                          borderColor: 'rgba(148, 163, 184, 0.2)'
                        }}>
                          <div className="flex items-start justify-between mb-2">
                            <span className="font-semibold text-white">{task.moduleName}</span>
                            <div className="flex gap-2">
                              <Badge className={
                                task.impact === 'high' ? 'bg-red-600/20 text-red-300 border-red-600/30' :
                                task.impact === 'medium' ? 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30' :
                                'bg-green-600/20 text-green-300 border-green-600/30'
                              }>
                                {task.impact} impact
                              </Badge>
                              <Badge className={
                                task.effort === 'high' ? 'bg-red-600/20 text-red-300 border-red-600/30' :
                                task.effort === 'medium' ? 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30' :
                                'bg-green-600/20 text-green-300 border-green-600/30'
                              }>
                                {task.effort} effort
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm text-gray-300">{task.action}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quick Wins */}
                {recommendations.quickWins && recommendations.quickWins.length > 0 && (
                  <div>
                    <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-yellow-400" />
                      Quick Wins
                    </h3>
                    <div className="grid md:grid-cols-2 gap-3">
                      {recommendations.quickWins.map((win, idx) => (
                        <div key={idx} className="p-3 rounded-lg border" style={{
                          background: 'rgba(234, 179, 8, 0.05)',
                          borderColor: 'rgba(234, 179, 8, 0.3)'
                        }}>
                          <div className="flex items-start gap-2">
                            <Zap className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-300">{win}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </Card>
        </section>
      </div>
    </div>
  );
}