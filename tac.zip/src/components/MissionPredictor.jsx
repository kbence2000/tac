import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, Zap, Clock, DollarSign, Users, AlertCircle, 
  CheckCircle, TrendingUp, Target, Sparkles, Loader2
} from "lucide-react";
import { 
  predictMission, 
  getComplexityColor, 
  getRiskColor, 
  getDeadlineFitBadge,
  formatPriceBand
} from ".@/api/functions/missionPredictor";
import { toast } from "sonner";

export default function MissionPredictor({ onPredictionComplete = null }) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    budget: "",
    deadlineHours: "",
    complexityHint: "auto"
  });
  
  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(false);
  const [useAI, setUseAI] = useState(false);

  const handlePredict = async () => {
    if (!formData.title && !formData.description) {
      toast.error("Please provide at least a title or description");
      return;
    }
    
    setLoading(true);
    try {
      const result = await predictMission({
        title: formData.title,
        description: formData.description,
        budget: parseFloat(formData.budget) || 0,
        deadlineHours: formData.deadlineHours ? parseInt(formData.deadlineHours) : null,
        complexityHint: formData.complexityHint,
        useAI
      });
      
      setPrediction(result);
      if (onPredictionComplete) {
        onPredictionComplete(result);
      }
      toast.success("Mission analysis complete!");
    } catch (error) {
      console.error('Prediction error:', error);
      toast.error("Analysis failed: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setFormData({
      title: "",
      description: "",
      budget: "",
      deadlineHours: "",
      complexityHint: "auto"
    });
    setPrediction(null);
  };

  return (
    <div className="space-y-6">
      {/* Input Form */}
      <Card style={{
        background: 'rgba(15, 23, 42, 0.95)',
        borderColor: 'rgba(139, 92, 255, 0.3)'
      }}>
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-white">
            <Brain className="w-6 h-6 text-purple-400" />
            Mission Prediction Engine
          </CardTitle>
          <p className="text-sm text-gray-400 mt-2">
            AI-powered analysis for complexity, risk, and resource estimation
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-gray-300 mb-2 block">Mission Title</label>
            <Input
              placeholder="e.g., Build real-time chat dashboard"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              className="bg-gray-800/50 border-gray-700 text-white"
            />
          </div>

          <div>
            <label className="text-sm text-gray-300 mb-2 block">Description</label>
            <Textarea
              placeholder="Detailed mission requirements, technologies, constraints..."
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="bg-gray-800/50 border-gray-700 text-white min-h-[120px]"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Budget (EUR)</label>
              <Input
                type="number"
                placeholder="1000"
                value={formData.budget}
                onChange={(e) => setFormData({...formData, budget: e.target.value})}
                className="bg-gray-800/50 border-gray-700 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Deadline (hours)</label>
              <Input
                type="number"
                placeholder="48"
                value={formData.deadlineHours}
                onChange={(e) => setFormData({...formData, deadlineHours: e.target.value})}
                className="bg-gray-800/50 border-gray-700 text-white"
              />
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Complexity Hint</label>
              <select
                value={formData.complexityHint}
                onChange={(e) => setFormData({...formData, complexityHint: e.target.value})}
                className="w-full px-3 py-2 rounded-lg bg-gray-800/50 border border-gray-700 text-white"
              >
                <option value="auto">Auto Detect</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="useAI"
              checked={useAI}
              onChange={(e) => setUseAI(e.target.checked)}
              className="w-4 h-4"
            />
            <label htmlFor="useAI" className="text-sm text-gray-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              Enhanced AI Analysis (slower but more detailed)
            </label>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handlePredict}
              disabled={loading}
              className="flex-1 bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4 mr-2" />
                  Analyze Mission
                </>
              )}
            </Button>
            
            {prediction && (
              <Button
                onClick={handleReset}
                variant="outline"
                className="border-gray-700 text-gray-300 hover:bg-gray-800"
              >
                Reset
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Prediction Results */}
      {prediction && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
          {/* Core Metrics */}
          <Card style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(139, 92, 255, 0.3)'
          }}>
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-purple-400" />
                Core Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Complexity</span>
                <Badge className={`${getComplexityColor(prediction.complexity)} bg-gray-800 font-bold uppercase`}>
                  {prediction.complexity}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-gray-400">Risk Level</span>
                <Badge className={`${getRiskColor(prediction.risk)} bg-gray-800 font-bold uppercase`}>
                  {prediction.risk}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-gray-400">Recommended Mode</span>
                <Badge className="bg-cyan-600 text-white font-semibold">
                  {prediction.mode === "AI_ONLY" ? "AI Only" : "AI + Demigods"}
                </Badge>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-gray-400 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Est. Duration
                </span>
                <span className="text-white font-bold">{prediction.etaHours}h</span>
              </div>

              {prediction.deadline.provided && (
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Deadline Fit</span>
                  <Badge className={getDeadlineFitBadge(prediction.deadline.fit).color}>
                    {getDeadlineFitBadge(prediction.deadline.fit).text}
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Resources & Budget */}
          <Card style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(139, 92, 255, 0.3)'
          }}>
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-cyan-400" />
                Resources & Budget
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">AI Agents</span>
                <span className="text-white font-bold">{prediction.resources.aiAgents}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-gray-400">Demigods Needed</span>
                <span className="text-white font-bold">{prediction.resources.demigodsNeeded}</span>
              </div>

              <div className="pt-3 border-t border-gray-700">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-400 flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Price Range
                  </span>
                  <span className="text-white font-bold">
                    {formatPriceBand(prediction.priceBand)}
                  </span>
                </div>

                {prediction.budget.provided > 0 && (
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Your Budget</span>
                    <div className="flex items-center gap-2">
                      <span className="text-white">€{prediction.budget.provided}</span>
                      {prediction.budget.adequacy === "critically_low" && (
                        <AlertCircle className="w-4 h-4 text-red-400" />
                      )}
                      {prediction.budget.adequacy === "very_high" && (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      )}
                    </div>
                  </div>
                )}
              </div>

              {prediction.techHints.length > 0 && (
                <div className="pt-3 border-t border-gray-700">
                  <span className="text-gray-400 text-sm block mb-2">Detected Technologies</span>
                  <div className="flex flex-wrap gap-2">
                    {prediction.techHints.map((tech, idx) => (
                      <Badge key={idx} className="bg-purple-900/50 text-purple-300">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Explanation */}
          <Card className="md:col-span-2" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(139, 92, 255, 0.3)'
          }}>
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-400" />
                Analysis Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {prediction.explanation.map((line, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-300 text-sm">{line}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* AI Insights (if available) */}
          {prediction.aiInsights && (
            <Card className="md:col-span-2" style={{
              background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.1), rgba(36, 228, 255, 0.1))',
              borderColor: 'rgba(36, 228, 255, 0.4)'
            }}>
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-cyan-400" />
                  AI Deep Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {prediction.aiInsights.challenges && (
                  <div>
                    <h4 className="text-yellow-400 font-semibold mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4" />
                      Key Challenges
                    </h4>
                    <ul className="space-y-1 ml-6">
                      {prediction.aiInsights.challenges.map((challenge, idx) => (
                        <li key={idx} className="text-gray-300 text-sm">• {challenge}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {prediction.aiInsights.approach && (
                  <div>
                    <h4 className="text-green-400 font-semibold mb-2 flex items-center gap-2">
                      <Zap className="w-4 h-4" />
                      Recommended Approach
                    </h4>
                    <p className="text-gray-300 text-sm">{prediction.aiInsights.approach}</p>
                  </div>
                )}

                {prediction.aiInsights.successProbability && (
                  <div>
                    <h4 className="text-cyan-400 font-semibold mb-2">Success Probability</h4>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-3 bg-gray-800 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full transition-all"
                          style={{ width: `${prediction.aiInsights.successProbability}%` }}
                        />
                      </div>
                      <span className="text-white font-bold">{prediction.aiInsights.successProbability}%</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}