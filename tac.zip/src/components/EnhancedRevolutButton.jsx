import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { ExternalLink, Loader2 } from "lucide-react";
import { toast } from "sonner";
import backendClient from "./BackendClient";
import { getAffiliateCookie } from "./ShopifyBuyButton";

/**
 * Enhanced Revolut Pay Button with Backend Integration
 * Generates payment link via backend and tracks transactions
 */
export default function EnhancedRevolutButton({ 
  app,
  user,
  licenseType = "BASIC",
  amount,
  currency = "USD",
  className = "",
  disabled = false 
}) {
  const [loading, setLoading] = useState(false);

  const handleClick = async () => {
    if (!user) {
      toast.error("Jelentkezz be a fizetéshez!");
      return;
    }

    setLoading(true);
    
    try {
      const affiliateCode = getAffiliateCookie();
      
      const response = await backendClient.generateRevolutLink({
        appId: app.id,
        amount: amount,
        currency: currency,
        buyerEmail: user.email,
        sellerEmail: app.created_by,
        licenseType: licenseType,
        affiliateCode: affiliateCode
      });

      if (response.ok && response.link) {
        // Redirect to Revolut payment page
        window.location.href = response.link;
      } else {
        throw new Error(response.error || 'Failed to generate payment link');
      }
    } catch (error) {
      console.error('Revolut payment error:', error);
      toast.error('Hiba a fizetési link generálásakor');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      type="button"
      onClick={handleClick}
      disabled={disabled || loading}
      className={`bg-black hover:bg-gray-800 text-white flex items-center gap-2 ${className}`}
    >
      {loading ? (
        <>
          <Loader2 className="w-5 h-5 animate-spin" />
          Generálás...
        </>
      ) : (
        <>
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
            <path d="M12.5 7H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
          </svg>
          Fizetés Revolut-tal
          <ExternalLink className="w-4 h-4" />
        </>
      )}
    </Button>
  );
}