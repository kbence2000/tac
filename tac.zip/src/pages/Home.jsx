import React, { useState } from 'react';
import { ArrowLeft, Play, Square, Activity, Clock, CheckCircle2, Zap, TrendingUp, Settings, Database } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import GlobalHealthWidget from '../components/GlobalHealthWidget';

export default function Home() {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState(`{
  "pattern": "non-linear loop",
  "confidence": 0.93,
  "improvement": "suggested"
}`);

  const moduleStats = {
    mode: 'Recursive',
    lastUpdate: '3 hours ago',
    status: 'Operational',
    statusColor: '#22c55e'
  };

  const upgradeHistory = [
    { version: 'v1.7', description: 'Enhanced recursion control + 32% faster solving', color: '#22c55e' },
    { version: 'v1.6', description: 'Added paradox-splitting function', color: '#a855f7' },
    { version: 'v1.5', description: 'Multi-agent compatibility', color: '#c026d3' }
  ];

  return (
    <div className="min-h-screen" style={{
      background: 'linear-gradient(to bottom right, #000000, #0f0a1f, #150016)'
    }}>
      <style>{`
        .glow-outline {
          box-shadow: 0 0 14px rgba(168, 85, 247, 0.6);
          border-color: rgba(168, 85, 247, 0.7);
        }
        
        .glow-green {
          box-shadow: 0 0 14px rgba(34, 197, 94, 0.7);
        }
        
        .glow-red {
          box-shadow: 0 0 14px rgba(255, 68, 119, 0.65);
        }
        
        .inner-glow {
          box-shadow: inset 0 0 12px rgba(90, 0, 110, 0.8);
        }
      `}</style>

      <div className="max-w-7xl mx-auto px-4 py-6 flex gap-6">
        {/* LEFT SIDEBAR - GLOBAL HEALTH WIDGET */}
        <aside className="w-80 flex-shrink-0 hidden lg:block">
          <div className="sticky top-6">
            <GlobalHealthWidget />
          </div>
        </aside>

        {/* MAIN CONTENT */}
        <div className="flex-1">
          {/* HEADER */}
          <div className="flex items-center justify-between mb-6">
            <div className="inline-flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{
                background: 'linear-gradient(to bottom right, #a855f7, #c026d3)',
                boxShadow: '0 0 14px rgba(168, 85, 247, 0.6)'
              }}>
                <div className="w-4 h-4 rounded-full border border-purple-100 glow-green"></div>
              </div>
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-purple-400/70 glow-outline">
                  <span className="text-[11px] uppercase tracking-[0.18em] text-purple-200">TAC</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 glow-green"></span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">AI Module Engine</p>
              </div>
            </div>

            <Link to={createPageUrl('NeuralCore')}>
              <button className="text-[12px] px-3 py-1.5 rounded-full border border-slate-600 hover:glow-outline transition flex items-center gap-2">
                <ArrowLeft className="w-3 h-3" />
                Neural Core
              </button>
            </Link>
          </div>

          {/* MODULE HEADER */}
          <div className="rounded-[1.15rem] border border-purple-900/70 inner-glow p-6" style={{
            background: 'rgba(12, 6, 20, 0.88)'
          }}>
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <h1 className="text-[26px] font-semibold flex items-center gap-2 text-white">
                  Paradox Engine
                  <span className="px-2 py-1 rounded-full border border-purple-500/70 glow-outline text-[11px] text-purple-200">
                    CORE
                  </span>
                </h1>
                <p className="text-[13px] text-slate-300 max-w-xl mt-2">
                  High-level reasoning system for complex problem solving, recursive pattern extraction and self-reconstructive AI flows.
                </p>
              </div>

              <div className="flex flex-col gap-2 text-right">
                <button className="px-4 py-1.5 rounded-full text-[12px] border border-green-400 glow-green flex items-center gap-2 hover:bg-green-900/20 transition">
                  <Play className="w-3 h-3" />
                  Start
                </button>
                <button className="px-4 py-1.5 rounded-full text-[12px] border border-red-400 glow-red flex items-center gap-2 hover:bg-red-900/20 transition">
                  <Square className="w-3 h-3" />
                  Stop
                </button>
              </div>
            </div>

            {/* STATS */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
              <div className="border border-purple-700/60 rounded-xl bg-black/40 p-4 inner-glow">
                <p className="text-[11px] text-slate-300 uppercase tracking-wider mb-1 flex items-center gap-2">
                  <Activity className="w-3 h-3" />
                  Mode
                </p>
                <p className="text-[14px] text-white font-semibold">{moduleStats.mode}</p>
              </div>
              <div className="border border-purple-700/60 rounded-xl bg-black/40 p-4 inner-glow">
                <p className="text-[11px] text-slate-300 uppercase tracking-wider mb-1 flex items-center gap-2">
                  <Clock className="w-3 h-3" />
                  Last update
                </p>
                <p className="text-[14px] text-white font-semibold">{moduleStats.lastUpdate}</p>
              </div>
              <div className="border border-purple-700/60 rounded-xl bg-black/40 p-4 inner-glow">
                <p className="text-[11px] text-slate-300 uppercase tracking-wider mb-1 flex items-center gap-2">
                  <CheckCircle2 className="w-3 h-3" />
                  Status
                </p>
                <p className="text-[14px] font-semibold" style={{ color: moduleStats.statusColor }}>
                  {moduleStats.status}
                </p>
              </div>
            </div>
          </div>

          {/* I/O SECTION */}
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Input */}
            <div className="rounded-[1.15rem] border border-slate-700/70 bg-black/40 p-5 inner-glow">
              <h2 className="text-[15px] font-semibold mb-3 text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-purple-400" />
                Input Preview
              </h2>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="w-full h-40 bg-black/50 border border-purple-600/70 rounded-xl p-3 text-[12px] focus:ring-2 focus:ring-purple-500 focus:outline-none inner-glow resize-none text-slate-100"
                placeholder="Enter input for Paradox Engine..."
              />
            </div>

            {/* Output */}
            <div className="rounded-[1.15rem] border border-slate-700/70 bg-black/40 p-5 inner-glow">
              <h2 className="text-[15px] font-semibold mb-3 text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-green-400" />
                Output Preview
              </h2>
              <pre className="w-full h-40 bg-black/50 border border-purple-600/70 rounded-xl p-3 text-[12px] overflow-y-auto inner-glow text-slate-100 font-mono">
{outputText}
              </pre>
            </div>
          </div>

          {/* UPGRADE HISTORY */}
          <div className="mt-6 rounded-[1.15rem] border border-purple-900/70 inner-glow p-5" style={{
            background: 'rgba(12, 6, 20, 0.88)'
          }}>
            <h2 className="text-[15px] font-semibold mb-4 text-white flex items-center gap-2">
              <Settings className="w-4 h-4 text-purple-400" />
              Upgrade History
            </h2>

            <ul className="space-y-3 text-[12px]">
              {upgradeHistory.map((upgrade, idx) => (
                <li key={idx} className="flex gap-3 text-slate-300">
                  <span 
                    className="w-1.5 h-1.5 rounded-full mt-1"
                    style={{ 
                      background: upgrade.color,
                      boxShadow: `0 0 12px ${upgrade.color}99`
                    }}
                  />
                  <div>
                    <span className="font-semibold text-white">{upgrade.version}</span>
                    <span className="text-slate-400"> · {upgrade.description}</span>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* QUICK ACTIONS */}
          <div className="mt-6 rounded-[1.15rem] border border-purple-900/70 inner-glow p-5" style={{
            background: 'rgba(12, 6, 20, 0.88)'
          }}>
            <h2 className="text-[15px] font-semibold mb-4 text-white">Quick Actions</h2>
            <div className="flex flex-wrap gap-3">
              <Link to={createPageUrl('ModuleVault')}>
                <button className="px-4 py-2 rounded-full text-[12px] border border-purple-500/70 glow-outline bg-black/60 hover:bg-purple-900/30 transition flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  Module Vault
                </button>
              </Link>
              <Link to={createPageUrl('ControlHub')}>
                <button className="px-4 py-2 rounded-full text-[12px] border border-cyan-500/70 hover:glow-outline bg-black/60 transition flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  Control Hub
                </button>
              </Link>
              <Link to={createPageUrl('SecurityOversight')}>
                <button className="px-4 py-2 rounded-full text-[12px] border border-red-500/70 glow-red bg-black/60 hover:bg-red-900/20 transition flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  Security
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}