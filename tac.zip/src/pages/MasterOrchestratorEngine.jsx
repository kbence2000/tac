import React, { useState, useRef, useEffect } from 'react';
import { Crown, Loader2, AlertTriangle, Sparkles, Zap, Activity, CheckCircle2, Database, TrendingUp, Shield, Flame, Target, Box, Orbit, Radio, Infinity as InfinityIcon, Rocket, Eye, Clock } from 'lucide-react';

const MODULES = [
  { id: "paradox", label: "Paradox Engine", icon: Flame, color: "#22c55e" },
  { id: "shadow-architect", label: "Shadow Architect", icon: Shield, color: "#8b5cf6" },
  { id: "hallucinator", label: "Hallucinator", icon: Sparkles, color: "#ec4899" },
  { id: "distorted-synergy", label: "Distorted Synergy", icon: TrendingUp, color: "#dc2626" },
  { id: "dark-energy", label: "Dark Energy", icon: Zap, color: "#4b0082" },
  { id: "anti-1998", label: "Anti-1998", icon: Radio, color: "#8b008b" },
  { id: "nq-fice", label: "NQ-FICE", icon: Box, color: "#24e4ff" },
  { id: "infinity-expansion", label: "Infinity", icon: InfinityIcon, color: "#ff8c00" },
  { id: "endless-mind-symphony", label: "Mind Symphony", icon: Eye, color: "#f59e0b" }
];

export default function MasterOrchestratorEngine() {
  const [isRunning, setIsRunning] = useState(false);
  const [completedModules, setCompletedModules] = useState(new Set());
  const [result, setResult] = useState(null);
  const [vault, setVault] = useState([]);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated orchestrator background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    let rotation = 0;

    const rings = [
      { radius: 100, speed: 0.002, color: '#ffd700', particles: 8 },
      { radius: 180, speed: -0.003, color: '#8b5cf6', particles: 12 },
      { radius: 260, speed: 0.004, color: '#24e4ff', particles: 16 },
    ];

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(2, 0, 12, 0.15)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      rotation += 0.001;

      // Draw orbiting particles
      rings.forEach(ring => {
        const angleStep = (Math.PI * 2) / ring.particles;
        for (let i = 0; i < ring.particles; i++) {
          const angle = rotation * ring.speed * 100 + (i * angleStep);
          const x = centerX + ring.radius * Math.cos(angle);
          const y = centerY + ring.radius * Math.sin(angle);

          ctx.beginPath();
          ctx.arc(x, y, 3, 0, Math.PI * 2);
          ctx.fillStyle = ring.color;
          ctx.fill();

          // Glow effect
          ctx.shadowBlur = 15;
          ctx.shadowColor = ring.color;
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      });

      // Draw center core
      const coreSize = 20 + Math.sin(rotation * 5) * 5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, coreSize, 0, Math.PI * 2);
      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, coreSize);
      gradient.addColorStop(0, '#ffffff');
      gradient.addColorStop(0.5, '#ffd700');
      gradient.addColorStop(1, 'transparent');
      ctx.fillStyle = gradient;
      ctx.fill();

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Load vault on mount
  useEffect(() => {
    loadVault();
  }, []);

  const loadVault = async () => {
    // Vault loading would happen here if there was a GET endpoint
    // For now, vault is updated after each run
  };

  const runOrchestrator = async () => {
    if (isRunning) return;

    setIsRunning(true);
    setError(null);
    setResult(null);
    setCompletedModules(new Set());

    // Simulate module completion for UI feedback
    const simulateProgress = () => {
      let completed = 0;
      const interval = setInterval(() => {
        if (completed < MODULES.length) {
          setCompletedModules(prev => new Set([...prev, MODULES[completed].id]));
          completed++;
        } else {
          clearInterval(interval);
        }
      }, 800);
      return interval;
    };

    const progressInterval = simulateProgress();

    try {
      const response = await fetch('http://localhost:9922/api/moe/run');

      clearInterval(progressInterval);

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error('Orchestrator execution failed');
      }

      setResult(data);
      setCompletedModules(new Set(MODULES.map(m => m.id)));

    } catch (err) {
      console.error('Master Orchestrator error:', err);
      setError(err.message);
      clearInterval(progressInterval);
    } finally {
      setIsRunning(false);
    }
  };

  const getTotalIdeas = () => {
    if (!result?.allResults) return 0;
    return result.allResults.reduce((sum, r) => sum + (r.output?.cycles?.top10?.length || 0), 0);
  };

  const getTopIdea = () => {
    if (!result?.allResults) return null;
    
    let bestIdea = null;
    let bestBreakthrough = 0;

    result.allResults.forEach(moduleResult => {
      const top = moduleResult.output?.cycles?.top10?.[0];
      if (top && top.breakthrough > bestBreakthrough) {
        bestBreakthrough = top.breakthrough;
        bestIdea = {
          ...top,
          module: moduleResult.module
        };
      }
    });

    return bestIdea;
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 50% 0%, #2a1f0a 0%, #0a0802 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes orchestratorPulse {
          0%, 100% { opacity: 0.8; transform: scale(1) rotate(0deg); }
          50% { opacity: 1; transform: scale(1.08) rotate(360deg); }
        }

        @keyframes shimmerGold {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }

        @keyframes masterFloat {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(3deg); }
        }

        .master-badge {
          animation: orchestratorPulse 4s ease-in-out infinite;
        }

        .master-card {
          animation: masterFloat 8s ease-in-out infinite;
        }

        .shimmer-master {
          background: linear-gradient(90deg, #ffd700, #ffed4e, #fff176, #ffed4e, #ffd700);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmerGold 3s linear infinite;
        }

        .master-border {
          position: relative;
        }

        .master-border::before {
          content: '';
          position: absolute;
          inset: -2px;
          border-radius: inherit;
          padding: 2px;
          background: linear-gradient(135deg, rgba(255, 215, 0, 0.6), rgba(139, 92, 255, 0.4), rgba(255, 215, 0, 0.6));
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
          animation: shimmerGold 3s linear infinite;
        }

        .module-progress {
          transition: all 0.3s ease-out;
        }

        .module-progress.completed {
          background: rgba(34, 197, 94, 0.2);
          border-color: rgba(34, 197, 94, 0.5);
        }

        .module-progress.running {
          background: rgba(255, 215, 0, 0.2);
          border-color: rgba(255, 215, 0, 0.6);
          animation: orchestratorPulse 1.5s ease-in-out infinite;
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.6 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1800px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Crown className="w-20 h-20 text-yellow-500 master-badge" />
            <h1 className="text-5xl md:text-7xl font-black tracking-wider uppercase shimmer-master">
              MASTER ORCHESTRATOR
            </h1>
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            Supreme Command Center :: 9-Module Parallel Evolution Engine
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(255, 215, 0, 0.15)',
              border: '1px solid rgba(255, 215, 0, 0.5)',
              boxShadow: '0 0 20px rgba(255, 215, 0, 0.4)'
            }}
          >
            <Crown className="w-3 h-3" />
            9 Modules · Parallel Execution · Unified Vault
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border master-border"
          style={{
            background: 'rgba(255, 215, 0, 0.08)',
            borderColor: 'rgba(255, 215, 0, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Crown className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-yellow-300">Master Orchestrator Engine:</span>
              <br />
              The supreme command center that runs <strong>all 9 TAC modules in parallel</strong>.
              Each module executes the full Chaos→Evolution→Approval pipeline simultaneously.
              <br />
              <span className="text-yellow-400 font-semibold">Process:</span> Single click triggers 9 parallel pipelines, 
              each generating 10 ideas, evolving 1000→100→5gen, selecting top 10, all results unified in Master Vault.
              <br />
              <span className="text-yellow-400 font-semibold">Output:</span> 90+ evolved ideas across all TAC modules, 
              ranked and compared for supreme architectural decision-making.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node master-orchestrator-engine.js</code> on port 9922
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Control + Progress */}
          <div className="xl:col-span-4 space-y-4">
            {/* Master Control */}
            <div className="master-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(255, 215, 0, 0.3)',
                background: 'rgba(42, 31, 10, 0.95)',
                boxShadow: '0 0 60px rgba(255, 215, 0, 0.3)'
              }}
            >
              <div className="text-xs tracking-widest uppercase text-yellow-400 mb-4 flex items-center gap-2">
                <Crown className="w-4 h-4" />
                MASTER CONTROL
              </div>

              <button
                onClick={runOrchestrator}
                disabled={isRunning}
                className="w-full py-4 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #ffd700, #ffed4e, #ffd700)',
                  color: '#1a0f05',
                  boxShadow: isRunning ? 'none' : '0 0 40px rgba(255, 215, 0, 0.8)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    ORCHESTRATING...
                  </>
                ) : (
                  <>
                    <Crown className="w-5 h-5" />
                    RUN ALL 9 MODULES
                  </>
                )}
              </button>

              {/* Stats */}
              <div className="mt-6 pt-4 border-t" style={{ borderColor: 'rgba(255, 215, 0, 0.2)' }}>
                <div className="text-xs text-gray-400 mb-3">Orchestrator Stats</div>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Total Modules:</span>
                    <span className="text-white font-semibold">{MODULES.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Ideas per Module:</span>
                    <span className="text-white font-semibold">10</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Total Ideas/Cycle:</span>
                    <span className="text-yellow-400 font-bold">~90</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Vault Records:</span>
                    <span className="text-white font-semibold">{vault.length}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Module Progress */}
            <div className="master-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(255, 215, 0, 0.3)',
                background: 'rgba(42, 31, 10, 0.95)'
              }}
            >
              <div className="text-xs tracking-widest uppercase text-yellow-400 mb-4">
                MODULE PROGRESS
              </div>

              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                {MODULES.map((module, idx) => {
                  const Icon = module.icon;
                  const isCompleted = completedModules.has(module.id);
                  const isRunning = !isCompleted && idx === completedModules.size;

                  return (
                    <div
                      key={module.id}
                      className={`module-progress flex items-center gap-3 p-3 rounded-lg border ${
                        isCompleted ? 'completed' : isRunning ? 'running' : ''
                      }`}
                      style={{
                        borderColor: isCompleted 
                          ? 'rgba(34, 197, 94, 0.5)' 
                          : isRunning 
                            ? 'rgba(255, 215, 0, 0.6)' 
                            : 'rgba(148, 163, 184, 0.2)',
                        background: isCompleted 
                          ? 'rgba(34, 197, 94, 0.1)' 
                          : isRunning 
                            ? 'rgba(255, 215, 0, 0.15)' 
                            : 'rgba(0, 0, 0, 0.3)'
                      }}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0" />
                      ) : isRunning ? (
                        <Loader2 className="w-5 h-5 animate-spin text-yellow-400 flex-shrink-0" />
                      ) : (
                        <Icon className="w-5 h-5 text-gray-600 flex-shrink-0" />
                      )}
                      <div className="flex-1">
                        <div className="text-xs font-semibold text-white">{module.label}</div>
                        <div className="text-[10px] text-gray-400">
                          {isCompleted ? 'Complete' : isRunning ? 'Running...' : 'Waiting'}
                        </div>
                      </div>
                      <div 
                        className="w-2 h-2 rounded-full"
                        style={{ 
                          background: module.color,
                          boxShadow: `0 0 8px ${module.color}`
                        }}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right: Results */}
          <div className="xl:col-span-8">
            {!result && !isRunning && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: 'rgba(255, 215, 0, 0.3)',
                  background: 'rgba(42, 31, 10, 0.95)'
                }}
              >
                <div>
                  <Crown className="w-24 h-24 mx-auto mb-4 text-yellow-500/30" />
                  <p className="text-sm text-gray-500">
                    No orchestration result yet.
                    <br />
                    Click "Run All 9 Modules" to start the master cycle.
                  </p>
                </div>
              </div>
            )}

            {isRunning && !result && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: 'rgba(255, 215, 0, 0.5)',
                  background: 'rgba(42, 31, 10, 0.95)'
                }}
              >
                <div>
                  <Loader2 className="w-24 h-24 mx-auto mb-4 text-yellow-500 animate-spin" />
                  <p className="text-sm text-gray-400">
                    Master Orchestrator running...
                    <br />
                    <span className="text-xs text-gray-600">
                      Executing 9 parallel evolution pipelines
                    </span>
                  </p>
                  <div className="mt-4 text-xs text-yellow-400">
                    {completedModules.size} / {MODULES.length} modules complete
                  </div>
                </div>
              </div>
            )}

            {result && result.allResults && (
              <div className="space-y-4">
                {/* Master Summary */}
                <div className="master-card rounded-2xl border p-6"
                  style={{
                    borderColor: 'rgba(255, 215, 0, 0.5)',
                    background: 'rgba(42, 31, 10, 0.95)',
                    boxShadow: '0 0 80px rgba(255, 215, 0, 0.4)',
                    animationDelay: '0s'
                  }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Crown className="w-8 h-8 text-yellow-400" />
                      <h3 className="text-xl font-black text-white">Master Cycle Complete</h3>
                    </div>
                    <div className="text-xs px-3 py-1 rounded-full"
                      style={{
                        background: 'rgba(34, 197, 94, 0.2)',
                        border: '1px solid rgba(34, 197, 94, 0.5)',
                        color: '#4ade80'
                      }}
                    >
                      Cycle #{result.cycleCount || 1}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl text-center"
                      style={{
                        background: 'rgba(255, 215, 0, 0.1)',
                        border: '1px solid rgba(255, 215, 0, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Modules Executed</div>
                      <div className="text-3xl font-black text-yellow-400">{MODULES.length}</div>
                    </div>
                    <div className="p-4 rounded-xl text-center"
                      style={{
                        background: 'rgba(255, 215, 0, 0.1)',
                        border: '1px solid rgba(255, 215, 0, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Total Ideas</div>
                      <div className="text-3xl font-black text-yellow-400">{getTotalIdeas()}</div>
                    </div>
                    <div className="p-4 rounded-xl text-center"
                      style={{
                        background: 'rgba(34, 197, 94, 0.15)',
                        border: '1px solid rgba(34, 197, 94, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Avg Breakthrough</div>
                      <div className="text-3xl font-black text-green-400">
                        {result.allResults.reduce((sum, r) => {
                          const top = r.output?.cycles?.top10?.[0];
                          return sum + (top?.breakthrough || 0);
                        }, 0) / MODULES.length * 100 || 0}%
                      </div>
                    </div>
                    <div className="p-4 rounded-xl text-center"
                      style={{
                        background: 'rgba(139, 92, 255, 0.15)',
                        border: '1px solid rgba(139, 92, 255, 0.3)'
                      }}
                    >
                      <div className="text-xs text-gray-400 mb-1">Vault Size</div>
                      <div className="text-3xl font-black text-purple-400">{result.cycleCount || 1}</div>
                    </div>
                  </div>

                  {/* Supreme Winner */}
                  {getTopIdea() && (
                    <div className="mt-6 p-4 rounded-xl"
                      style={{
                        background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(255, 215, 0, 0.15))',
                        border: '2px solid rgba(34, 197, 94, 0.5)',
                        boxShadow: '0 0 30px rgba(34, 197, 94, 0.4)'
                      }}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Crown className="w-5 h-5 text-yellow-400" />
                        <div className="text-xs font-bold text-yellow-300 uppercase tracking-wider">
                          Supreme Winner
                        </div>
                        <div className="text-xs px-2 py-0.5 rounded-full ml-auto"
                          style={{
                            background: MODULES.find(m => m.id === getTopIdea().module)?.color + '40',
                            border: `1px solid ${MODULES.find(m => m.id === getTopIdea().module)?.color}`,
                            color: MODULES.find(m => m.id === getTopIdea().module)?.color
                          }}
                        >
                          {MODULES.find(m => m.id === getTopIdea().module)?.label}
                        </div>
                      </div>
                      <div className="text-sm text-white font-semibold mb-3">
                        {getTopIdea().idea}
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex gap-4">
                          <span className="text-gray-400">Fitness: <strong className="text-white">{getTopIdea().best?.fitness?.toFixed(3)}</strong></span>
                          <span className="text-gray-400">Novelty: <strong className="text-white">{getTopIdea().best?.novelty?.toFixed(2)}</strong></span>
                        </div>
                        <span className="text-green-400 font-bold">
                          {(getTopIdea().breakthrough * 100).toFixed(1)}% Breakthrough
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Module Results */}
                <div className="space-y-3">
                  {result.allResults.map((moduleResult, idx) => {
                    const module = MODULES.find(m => m.id === moduleResult.module);
                    if (!module) return null;

                    const Icon = module.icon;
                    const topIdea = moduleResult.output?.cycles?.top10?.[0];

                    return (
                      <div
                        key={moduleResult.module}
                        className="master-card rounded-xl border p-5"
                        style={{
                          borderColor: `${module.color}60`,
                          background: 'rgba(42, 31, 10, 0.95)',
                          animationDelay: `${idx * 0.05}s`
                        }}
                      >
                        <div className="flex items-center gap-3 mb-3">
                          <Icon className="w-6 h-6" style={{ color: module.color }} />
                          <div className="flex-1">
                            <h4 className="text-sm font-bold text-white">{module.label}</h4>
                            <div className="text-xs text-gray-400">
                              {moduleResult.output?.cycles?.top10?.length || 0} top ideas evolved
                            </div>
                          </div>
                          <CheckCircle2 className="w-5 h-5 text-green-400" />
                        </div>

                        {topIdea && (
                          <div className="space-y-3">
                            <div className="p-3 rounded-lg"
                              style={{
                                background: `${module.color}15`,
                                border: `1px solid ${module.color}40`
                              }}
                            >
                              <div className="text-xs font-semibold text-white mb-2">
                                Top Idea:
                              </div>
                              <div className="text-xs text-gray-300">
                                {topIdea.idea}
                              </div>
                            </div>

                            <div className="grid grid-cols-4 gap-2 text-xs">
                              <div className="text-center">
                                <div className="text-gray-400 text-[10px] mb-1">Fitness</div>
                                <div className="text-white font-semibold">
                                  {topIdea.best?.fitness?.toFixed(2)}
                                </div>
                              </div>
                              <div className="text-center">
                                <div className="text-gray-400 text-[10px] mb-1">Improve</div>
                                <div className="text-white font-semibold">
                                  {topIdea.best?.impro?.toFixed(1)}
                                </div>
                              </div>
                              <div className="text-center">
                                <div className="text-gray-400 text-[10px] mb-1">Novelty</div>
                                <div className="text-white font-semibold">
                                  {topIdea.best?.novelty?.toFixed(2)}
                                </div>
                              </div>
                              <div className="text-center">
                                <div className="text-gray-400 text-[10px] mb-1">Risk</div>
                                <div className="text-red-400 font-semibold">
                                  {topIdea.best?.risk?.toFixed(2)}
                                </div>
                              </div>
                            </div>

                            <div className="pt-2">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-xs text-gray-400">Breakthrough Potential</span>
                                <span className="text-xs font-bold" style={{ color: module.color }}>
                                  {(topIdea.breakthrough * 100).toFixed(1)}%
                                </span>
                              </div>
                              <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
                                <div 
                                  className="h-full transition-all duration-500"
                                  style={{ 
                                    width: `${topIdea.breakthrough * 100}%`,
                                    background: `linear-gradient(90deg, ${module.color}, ${module.color}dd)`
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Master Orchestrator Engine :: Supreme 9-Module Parallel Evolution Command</p>
          <p className="mt-1">Backend: http://localhost:9922/api/moe/run</p>
          <p className="mt-1 text-yellow-500/60">Executes all TAC modules simultaneously for comprehensive innovation analysis.</p>
        </div>
      </div>
    </div>
  );
}