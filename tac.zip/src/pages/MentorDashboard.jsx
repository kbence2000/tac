import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Users, User, Award, FileText, 
  Send, Target, TrendingUp, Sparkles,
  Clock, CheckCircle2
} from "lucide-react";
import { toast } from "sonner";

const MENTORING_API = import.meta.env.VITE_MENTORING_BACKEND_URL || "http://localhost:4000";

export default function MentorDashboard() {
  const [selectedTalent, setSelectedTalent] = useState(null);
  const [newNote, setNewNote] = useState("");
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Register as mentor
  const registerMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${MENTORING_API}/mentoring/mentor/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mentorId: user.email,
          username: user.full_name || user.email.split('@')[0],
          specialty: "AI & Code Architecture"
        })
      });
      if (!res.ok) throw new Error('Registration failed');
      return res.json();
    },
    onSuccess: () => {
      toast.success("Registered as mentor!");
      queryClient.invalidateQueries({ queryKey: ['mentor'] });
    }
  });

  const { data: mentor } = useQuery({
    queryKey: ['mentor', user?.email],
    queryFn: async () => {
      // Try to get mentor info (would need GET endpoint in backend)
      return null; // For now, assume registered
    },
    enabled: !!user?.email,
  });

  const addNoteMutation = useMutation({
    mutationFn: async ({ talentId, note }) => {
      const res = await fetch(`${MENTORING_API}/mentoring/mentor/note`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mentorId: user.email,
          userId: talentId,
          note
        })
      });
      if (!res.ok) throw new Error('Add note failed');
      return res.json();
    },
    onSuccess: () => {
      toast.success("Note added!");
      setNewNote("");
      queryClient.invalidateQueries({ queryKey: ['talentQueue'] });
    }
  });

  const handleAddNote = () => {
    if (!selectedTalent || !newNote.trim()) return;
    addNoteMutation.mutate({ talentId: selectedTalent.userId, note: newNote });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-8 text-center">
          <User className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Login Required</h2>
          <Button onClick={() => base44.auth.redirectToLogin()}>
            Sign In
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="mb-8">
          <h1 className="text-4xl font-black text-white mb-2">Mentor Dashboard</h1>
          <p className="text-gray-400">Guide high-potential talents to Demigod certification</p>
        </div>

        {/* Register as Mentor CTA */}
        {!mentor && (
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-8 mb-8">
            <div className="text-center max-w-2xl mx-auto">
              <Award className="w-16 h-16 text-purple-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-3">Become a Mentor</h2>
              <p className="text-gray-400 mb-6">
                Share your expertise with AI-selected talents. Help the next generation of Code Demigods rise. Only R6+ developers can mentor.
              </p>
              <Button
                onClick={() => registerMutation.mutate()}
                disabled={registerMutation.isPending}
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold px-8 py-3"
              >
                {registerMutation.isPending ? "Registering..." : "Register as Mentor"}
              </Button>
            </div>
          </Card>
        )}

        <div className="grid lg:grid-cols-[1fr_1.2fr] gap-8">
          {/* Left: Talent Queue */}
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-cyan-400" />
              Talent Queue
            </h2>
            
            <div className="text-sm text-gray-400 mb-4">
              AI-detected talents waiting for mentor assignment
            </div>

            {/* Mock talent queue - in real app would fetch from backend */}
            <div className="space-y-3">
              <div className="text-center py-8 text-gray-500 text-sm">
                No pending talents. Check back later or contact admin to assign talents.
              </div>
            </div>
          </Card>

          {/* Right: Selected Talent Detail */}
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-400" />
              Talent Details
            </h2>

            {!selectedTalent ? (
              <div className="text-center py-12 text-gray-500 text-sm">
                Select a talent from the queue to view details and add notes
              </div>
            ) : (
              <div className="space-y-4">
                {/* Talent Header */}
                <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-bold text-white">{selectedTalent.username}</div>
                      <div className="text-xs text-gray-400">{selectedTalent.userId}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e] text-center">
                      <div className="font-bold text-purple-400">{selectedTalent.scoreTrend?.innovationIndex}</div>
                      <div className="text-gray-500">Innovation</div>
                    </div>
                    <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e] text-center">
                      <div className="font-bold text-yellow-400">{selectedTalent.scoreTrend?.pvpWins}</div>
                      <div className="text-gray-500">Wins</div>
                    </div>
                    <div className="p-2 rounded bg-[#0a0a0f] border border-[#1a1f2e] text-center">
                      <div className="font-bold text-cyan-400">#{selectedTalent.scoreTrend?.battleRank}</div>
                      <div className="text-gray-500">Rank</div>
                    </div>
                  </div>
                </div>

                {/* Add Note */}
                <div>
                  <label className="text-sm font-bold text-white block mb-2">Add Mentor Note</label>
                  <Textarea
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="Provide feedback, suggestions, or encouragement..."
                    className="bg-[#141923] border-[#1a1f2e] text-white h-24 mb-3"
                  />
                  <Button
                    onClick={handleAddNote}
                    disabled={addNoteMutation.isPending || !newNote.trim()}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {addNoteMutation.isPending ? "Sending..." : "Send Note to Talent"}
                  </Button>
                </div>

                {/* Growth Plan Preview */}
                {selectedTalent.growthPlan && (
                  <div className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                    <div className="text-xs text-gray-400 mb-1">AI Growth Plan:</div>
                    <pre className="text-xs text-gray-300 whitespace-pre-wrap font-mono leading-relaxed max-h-48 overflow-y-auto">
                      {selectedTalent.growthPlan}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}