import React, { useState, useEffect } from 'react';
import { Activity, Zap, Radio, Heart, Waves, Flame, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function GlobalHealthDashboard() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [healthData, setHealthData] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(false);

  const refreshDashboard = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await base44.functions.invoke('globalSystemHealth', {
        snapshot: {
          source: "TAC-Core",
          layers: [
            { name: "logic", baseValue: 0.8, drift: 0.2 },
            { name: "creative", baseValue: 1.1, drift: 0.3 },
            { name: "resonance", baseValue: 0.5, drift: 0.1 }
          ],
          paradoxCheck: {
            exprA: "2 + 2",
            exprB: "4"
          }
        }
      });

      setHealthData(response.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshDashboard();
  }, []);

  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      refreshDashboard();
    }, 3000);

    return () => clearInterval(interval);
  }, [autoRefresh]);

  const getHealthColor = (value) => {
    if (value >= 0.7) return 'var(--ok)';
    if (value >= 0.4) return 'var(--warn)';
    return 'var(--danger)';
  };

  const getHealthClass = (value) => {
    if (value >= 0.7) return 'health-high';
    if (value >= 0.4) return 'health-medium';
    return 'health-low';
  };

  return (
    <div style={{ 
      background: 'radial-gradient(circle at top, #101527, #05060a 65%)',
      minHeight: '100vh',
      color: '#f5f5ff'
    }}>
      <style>{`
        :root {
          --bg: #05060a;
          --panel: #0c0f18;
          --accent: #7cf7c9;
          --accent-soft: rgba(124, 247, 201, 0.18);
          --danger: #ff4b81;
          --warn: #ffc857;
          --ok: #5ee7ff;
          --text-main: #f5f5ff;
          --text-muted: #9da2c6;
          --border-subtle: rgba(255, 255, 255, 0.05);
        }

        .shell {
          max-width: 1180px;
          margin: 24px auto 40px;
          padding: 0 16px;
        }
        
        .brand {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        
        .brand-title {
          font-size: 20px;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          font-weight: 600;
        }
        
        .brand-sub {
          font-size: 12px;
          color: var(--text-muted);
        }
        
        .pill {
          padding: 4px 12px;
          border-radius: 999px;
          border: 1px solid var(--accent-soft);
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.09em;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .pill:hover {
          border-color: var(--accent);
          background: var(--accent-soft);
        }

        .pill.active {
          border-color: var(--accent);
          color: var(--accent);
        }

        .grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
          gap: 16px;
        }

        .grid-2 {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
          gap: 16px;
          margin-top: 16px;
        }
        
        .card {
          background: var(--panel);
          border-radius: 16px;
          padding: 14px 16px;
          border: 1px solid var(--border-subtle);
          box-shadow: 0 0 24px rgba(0,0,0,0.35);
        }
        
        .card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 12px;
        }
        
        .card-title {
          font-size: 13px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--text-muted);
        }

        .health-score {
          font-size: 32px;
          font-weight: 700;
          text-align: center;
          margin: 8px 0;
        }

        .health-label {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--text-muted);
          text-align: center;
        }

        .health-high { color: var(--ok); }
        .health-medium { color: var(--warn); }
        .health-low { color: var(--danger); }

        .progress-bar {
          height: 8px;
          border-radius: 4px;
          background: rgba(255, 255, 255, 0.05);
          overflow: hidden;
          margin-top: 8px;
        }

        .progress-fill {
          height: 100%;
          transition: width 0.5s ease-out;
        }

        .metric-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 6px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.03);
          font-size: 12px;
        }

        .metric-label {
          color: var(--text-muted);
        }

        .metric-value {
          font-weight: 500;
          font-family: 'Courier New', monospace;
        }

        .btn-refresh {
          padding: 6px 12px;
          border-radius: 8px;
          border: 1px solid var(--border-subtle);
          background: rgba(255,255,255,0.02);
          color: var(--text-main);
          font-size: 12px;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .btn-refresh:hover {
          background: var(--accent-soft);
          border-color: var(--accent);
        }

        .btn-refresh:disabled {
          opacity: 0.4;
          cursor: not-allowed;
        }

        .pulse-animate {
          animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }
      `}</style>

      <div className="shell">
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '16px', marginBottom: '18px', flexWrap: 'wrap' }}>
          <div className="brand">
            <div className="brand-title">Global System Health</div>
            <div className="brand-sub">Neural Stability • Coherence • Entropy • Vitality</div>
          </div>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <div 
              className={`pill ${autoRefresh ? 'active' : ''}`}
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              {autoRefresh ? 'AUTO: ON' : 'AUTO: OFF'}
            </div>
            <button
              onClick={refreshDashboard}
              disabled={isLoading}
              className="btn-refresh"
            >
              {isLoading ? <Activity className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
              Refresh
            </button>
          </div>
        </header>

        {error && (
          <div style={{ 
            padding: '12px', 
            borderRadius: '12px', 
            background: 'rgba(255, 75, 129, 0.1)', 
            border: '1px solid rgba(255, 75, 129, 0.3)',
            marginBottom: '16px',
            fontSize: '13px',
            color: '#ff4b81'
          }}>
            Error: {error}
          </div>
        )}

        {!healthData ? (
          <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
            <Activity className="w-8 h-8 mx-auto mb-2 opacity-50 animate-spin" style={{ display: 'inline-block' }} />
            <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Loading global health...</div>
          </div>
        ) : (
          <>
            {/* Global Health Scores */}
            <div className="grid">
              <div className="card">
                <div className="card-header">
                  <div className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Heart className="w-4 h-4" />
                    Neural Stability
                  </div>
                </div>
                <div className={`health-score ${getHealthClass(healthData.globalHealth?.neuralStability)}`}>
                  {(healthData.globalHealth?.neuralStability * 100).toFixed(1)}%
                </div>
                <div className="health-label">Cognitive Balance</div>
                <div className="progress-bar">
                  <div 
                    className="progress-fill"
                    style={{ 
                      width: `${healthData.globalHealth?.neuralStability * 100}%`,
                      background: `linear-gradient(90deg, ${getHealthColor(healthData.globalHealth?.neuralStability)}, ${getHealthColor(healthData.globalHealth?.neuralStability)}aa)`
                    }}
                  />
                </div>
              </div>

              <div className="card">
                <div className="card-header">
                  <div className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Waves className="w-4 h-4" />
                    Coherence Flow
                  </div>
                </div>
                <div className={`health-score ${getHealthClass(healthData.globalHealth?.coherenceFlow)}`}>
                  {(healthData.globalHealth?.coherenceFlow * 100).toFixed(1)}%
                </div>
                <div className="health-label">System Harmony</div>
                <div className="progress-bar">
                  <div 
                    className="progress-fill"
                    style={{ 
                      width: `${healthData.globalHealth?.coherenceFlow * 100}%`,
                      background: `linear-gradient(90deg, ${getHealthColor(healthData.globalHealth?.coherenceFlow)}, ${getHealthColor(healthData.globalHealth?.coherenceFlow)}aa)`
                    }}
                  />
                </div>
              </div>

              <div className="card">
                <div className="card-header">
                  <div className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Flame className="w-4 h-4" />
                    Entropy Pressure
                  </div>
                </div>
                <div className={`health-score ${getHealthClass(1 - healthData.globalHealth?.entropyPressure)}`}>
                  {(healthData.globalHealth?.entropyPressure * 100).toFixed(1)}%
                </div>
                <div className="health-label">System Disorder</div>
                <div className="progress-bar">
                  <div 
                    className="progress-fill"
                    style={{ 
                      width: `${healthData.globalHealth?.entropyPressure * 100}%`,
                      background: `linear-gradient(90deg, var(--danger), var(--warn))`
                    }}
                  />
                </div>
              </div>

              <div className="card">
                <div className="card-header">
                  <div className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Sparkles className="w-4 h-4" />
                    Vitality Pulse
                  </div>
                </div>
                <div className={`health-score pulse-animate ${getHealthClass(healthData.globalHealth?.vitalityPulse)}`}>
                  {(healthData.globalHealth?.vitalityPulse * 100).toFixed(1)}%
                </div>
                <div className="health-label">Living Signal</div>
                <div className="progress-bar">
                  <div 
                    className="progress-fill pulse-animate"
                    style={{ 
                      width: `${healthData.globalHealth?.vitalityPulse * 100}%`,
                      background: `linear-gradient(90deg, ${getHealthColor(healthData.globalHealth?.vitalityPulse)}, ${getHealthColor(healthData.globalHealth?.vitalityPulse)}aa)`
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Engine Components */}
            <div className="grid-2">
              <div className="card">
                <div className="card-header">
                  <div className="card-title">Rift Analysis</div>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Avg Rift Intensity</span>
                  <span className="metric-value">{healthData.components?.avgRift?.toFixed(3)}</span>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Max Rift</span>
                  <span className="metric-value">{healthData.components?.maxRift?.toFixed(3)}</span>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Risk Level</span>
                  <span className="metric-value">{healthData.engines?.riftData?.antiAnalysis?.riskLevel?.toUpperCase()}</span>
                </div>
              </div>

              <div className="card">
                <div className="card-header">
                  <div className="card-title">Resonance Engine</div>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Resonance</span>
                  <span className="metric-value">{healthData.components?.resonance?.toFixed(3)}</span>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Anti-Resonance</span>
                  <span className="metric-value">{healthData.components?.antiResonance?.toFixed(3)}</span>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Variance</span>
                  <span className="metric-value">{healthData.components?.variance?.toFixed(3)}</span>
                </div>
              </div>

              <div className="card">
                <div className="card-header">
                  <div className="card-title">Singularity Engine</div>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Singularity Vector</span>
                  <span className="metric-value">{healthData.components?.singularityField?.toFixed(3)}</span>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Collapse Risk</span>
                  <span className="metric-value">{healthData.components?.collapseRisk?.toFixed(3)}</span>
                </div>
                <div className="metric-row">
                  <span className="metric-label">Cohesion</span>
                  <span className="metric-value">{healthData.components?.cohesion?.toFixed(3)}</span>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}