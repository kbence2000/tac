import React, { useState, useRef, useEffect } from 'react';
import { Zap, Loader2, AlertTriangle, Sparkles, TrendingUp, Target, Shield, Flame, Activity, ArrowRight, CheckCircle2, Rocket } from 'lucide-react';

const MODULES = [
  { id: "paradox", label: "Paradox Engine", icon: Flame, color: "#22c55e" },
  { id: "shadow-architect", label: "Shadow Architect", icon: Shield, color: "#8b5cf6" },
  { id: "hallucinator", label: "Hallucinator", icon: Sparkles, color: "#ec4899" },
  { id: "infinity-expansion", label: "Infinity Expansion", icon: Target, color: "#ff8c00" },
  { id: "anti-1998", label: "Anti-1998 Field", icon: Activity, color: "#8b008b" },
  { id: "dark-energy", label: "Dark Energy Engine", icon: Zap, color: "#4b0082" },
  { id: "distorted-synergy", label: "Distorted Synergy", icon: TrendingUp, color: "#dc2626" },
  { id: "nq-fice", label: "NQ-FICE", icon: Target, color: "#24e4ff" },
  { id: "endless-mind-symphony", label: "Endless Mind Symphony", icon: Sparkles, color: "#f59e0b" }
];

export default function UniversalUpgradeEngine() {
  const [selectedModule, setSelectedModule] = useState("paradox");
  const [autoMode, setAutoMode] = useState(false);
  const [energy, setEnergy] = useState(1.0);
  const [curvature, setCurvature] = useState(0.1);
  const [entropy, setEntropy] = useState(1.0);
  const [radius, setRadius] = useState(1.0);
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated particle background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    for (let i = 0; i < 100; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.3
      });
    }

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(2, 0, 12, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(139, 92, 255, ${p.opacity})`;
        ctx.fill();
      });

      // Draw connections
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 150) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(139, 92, 255, ${0.1 * (1 - dist / 150)})`;
            ctx.lineWidth = 1;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const runUpgrade = async () => {
    if (isRunning) return;

    setIsRunning(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:9009/api/universal/upgrade', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          targetModule: selectedModule,
          autoMode: autoMode ? 'enabled' : 'manual',
          params: {
            energy,
            curvature,
            entropy,
            radius
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setResult(data);

    } catch (err) {
      console.error('Universal Upgrade error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const selectedModuleData = MODULES.find(m => m.id === selectedModule);
  const Icon = selectedModuleData?.icon || Zap;

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 50% 0%, #1a0f2e 0%, #0a0514 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes universalPulse {
          0%, 100% { opacity: 0.8; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }

        @keyframes shimmerUniversal {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }

        @keyframes upgradeFloat {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-8px); }
        }

        .universal-badge {
          animation: universalPulse 3s ease-in-out infinite;
        }

        .upgrade-card {
          animation: upgradeFloat 5s ease-in-out infinite;
        }

        .shimmer-universal {
          background: linear-gradient(90deg, #8b5cf6, #ec4899, #22c55e, #8b5cf6);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmerUniversal 4s linear infinite;
        }

        .universal-border {
          position: relative;
        }

        .universal-border::before {
          content: '';
          position: absolute;
          inset: -2px;
          border-radius: inherit;
          padding: 2px;
          background: linear-gradient(135deg, rgba(139, 92, 255, 0.6), transparent, rgba(139, 92, 255, 0.6));
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
        }

        .module-option {
          transition: all 0.2s ease-out;
        }

        .module-option:hover {
          transform: translateX(4px);
        }

        .module-option.selected {
          background: rgba(139, 92, 255, 0.2);
          border-color: rgba(139, 92, 255, 0.6);
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.4 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1800px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Rocket className="w-16 h-16 text-purple-500 universal-badge" />
            <h1 className="text-5xl md:text-6xl font-black tracking-wider uppercase shimmer-universal">
              UNIVERSAL UPGRADE ENGINE
            </h1>
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            Multi-Module Evolution Framework :: 1000→100→Evolution Loop
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(139, 92, 255, 0.15)',
              border: '1px solid rgba(139, 92, 255, 0.5)',
              boxShadow: '0 0 20px rgba(139, 92, 255, 0.3)'
            }}
          >
            <Zap className="w-3 h-3" />
            Infinity Math · Genetic Evolution · AI Narrative
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border universal-border"
          style={{
            background: 'rgba(139, 92, 255, 0.08)',
            borderColor: 'rgba(139, 92, 255, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-purple-300">Universal Upgrade Engine:</span>
              <br />
              Select any TAC module, configure base parameters (energy, curvature, entropy, radius), and run the evolution loop.
              <br />
              <span className="text-purple-400 font-semibold">Process:</span> (1) Infinity Math simulation with module-specific biases,
              (2) Generate 1000 upgrade candidates, (3) Evolve top 100 over 5 generations, (4) AI narrative synthesis.
              <br />
              <span className="text-purple-400 font-semibold">Output:</span> Mathematical metrics, breakthrough potential, top 10 upgrades, AI recommendations.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node universal-upgrade-engine.js</code> on port 9009
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Module Selection + Controls */}
          <div className="xl:col-span-4 space-y-4">
            {/* Module Selection */}
            <div className="universal-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(139, 92, 255, 0.3)',
                background: 'rgba(10, 5, 32, 0.95)',
                boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
              }}
            >
              <label className="block text-xs tracking-widest uppercase text-purple-400 mb-3">
                TARGET MODULE
              </label>
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                {MODULES.map(module => {
                  const ModuleIcon = module.icon;
                  return (
                    <div
                      key={module.id}
                      onClick={() => setSelectedModule(module.id)}
                      className={`module-option flex items-center gap-3 p-3 rounded-xl border cursor-pointer ${
                        selectedModule === module.id ? 'selected' : ''
                      }`}
                      style={{
                        borderColor: selectedModule === module.id 
                          ? `${module.color}80` 
                          : 'rgba(148, 163, 184, 0.2)',
                        background: selectedModule === module.id 
                          ? `${module.color}15` 
                          : 'rgba(0, 0, 0, 0.3)'
                      }}
                    >
                      <ModuleIcon className="w-5 h-5 flex-shrink-0" style={{ color: module.color }} />
                      <span className="text-sm font-semibold text-white">{module.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Base Parameters */}
            <div className="universal-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(139, 92, 255, 0.3)',
                background: 'rgba(10, 5, 32, 0.95)'
              }}
            >
              <div className="text-xs tracking-widest uppercase text-purple-400 mb-4">
                BASE PARAMETERS
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs text-gray-400">Energy Density</label>
                    <span className="text-xs text-white font-semibold">{energy.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="5.0"
                    step="0.1"
                    value={energy}
                    onChange={(e) => setEnergy(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full"
                    style={{ accentColor: '#8b5cf6' }}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs text-gray-400">Curvature</label>
                    <span className="text-xs text-white font-semibold">{curvature.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.01"
                    max="1.0"
                    step="0.01"
                    value={curvature}
                    onChange={(e) => setCurvature(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full"
                    style={{ accentColor: '#8b5cf6' }}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs text-gray-400">Entropy</label>
                    <span className="text-xs text-white font-semibold">{entropy.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="5.0"
                    step="0.1"
                    value={entropy}
                    onChange={(e) => setEntropy(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full"
                    style={{ accentColor: '#8b5cf6' }}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs text-gray-400">Radius</label>
                    <span className="text-xs text-white font-semibold">{radius.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="5.0"
                    step="0.1"
                    value={radius}
                    onChange={(e) => setRadius(parseFloat(e.target.value))}
                    disabled={isRunning}
                    className="w-full"
                    style={{ accentColor: '#8b5cf6' }}
                  />
                </div>
              </div>

              {/* Auto Mode Toggle */}
              <div className="mt-6 pt-4 border-t" style={{ borderColor: 'rgba(139, 92, 255, 0.2)' }}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-purple-300">Auto Mode</div>
                    <div className="text-[10px] text-gray-500">Continuous evolution loop</div>
                  </div>
                  <button
                    onClick={() => setAutoMode(!autoMode)}
                    disabled={isRunning}
                    className={`w-12 h-6 rounded-full transition-all ${
                      autoMode ? 'bg-purple-600' : 'bg-gray-600'
                    }`}
                    style={{ position: 'relative' }}
                  >
                    <div 
                      className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all"
                      style={{ 
                        left: autoMode ? 'calc(100% - 22px)' : '2px',
                        boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
                      }}
                    />
                  </button>
                </div>
              </div>

              {/* Run Button */}
              <button
                onClick={runUpgrade}
                disabled={isRunning}
                className="w-full mt-6 py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #8b5cf6, #ec4899)',
                  color: '#fff',
                  boxShadow: isRunning ? 'none' : '0 0 30px rgba(139, 92, 255, 0.6)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    EVOLVING...
                  </>
                ) : (
                  <>
                    <Rocket className="w-5 h-5" />
                    RUN UPGRADE EVOLUTION
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right: Output */}
          <div className="xl:col-span-8">
            <div className="rounded-2xl border p-6 h-full"
              style={{
                borderColor: 'rgba(139, 92, 255, 0.4)',
                background: 'rgba(10, 5, 32, 0.95)',
                boxShadow: '0 0 60px rgba(139, 92, 255, 0.2)'
              }}
            >
              <h3 className="text-xs tracking-widest uppercase text-purple-400 mb-4 flex items-center gap-2">
                <Icon className="w-4 h-4" style={{ color: selectedModuleData?.color }} />
                UPGRADE EVOLUTION RESULTS
              </h3>

              {!result && !isRunning && (
                <div className="text-center py-12">
                  <Rocket className="w-16 h-16 mx-auto mb-4 text-purple-500/30" />
                  <p className="text-sm text-gray-500">
                    No evolution analysis generated yet.
                    <br />
                    Select a module, configure parameters, and run upgrade evolution.
                  </p>
                </div>
              )}

              {isRunning && (
                <div className="text-center py-12">
                  <Loader2 className="w-16 h-16 mx-auto mb-4 text-purple-500 animate-spin" />
                  <p className="text-sm text-gray-400">
                    Running evolution loop...
                    <br />
                    <span className="text-xs text-gray-600">
                      Generating 1000 candidates → Top 100 → 5 generations
                    </span>
                  </p>
                </div>
              )}

              {result && (
                <div className="space-y-4 max-h-[800px] overflow-y-auto">
                  {/* Module Info */}
                  <div className="upgrade-card p-4 rounded-xl"
                    style={{
                      background: `${selectedModuleData?.color}15`,
                      border: `1px solid ${selectedModuleData?.color}40`,
                      animationDelay: '0s'
                    }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className="w-5 h-5" style={{ color: selectedModuleData?.color }} />
                        <span className="text-sm font-bold text-white">{result.module}</span>
                      </div>
                      <div className="text-xs px-3 py-1 rounded-full"
                        style={{
                          background: 'rgba(139, 92, 255, 0.2)',
                          border: '1px solid rgba(139, 92, 255, 0.4)',
                          color: '#a78bfa'
                        }}
                      >
                        {result.automation}
                      </div>
                    </div>
                  </div>

                  {/* Mathematical Metrics */}
                  {result.math && (
                    <div className="upgrade-card"
                      style={{ animationDelay: '0.1s' }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-3 flex items-center gap-2">
                        <Target className="w-4 h-4" />
                        INFINITY MATHEMATICS
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="p-3 rounded-xl text-center"
                          style={{
                            background: 'rgba(139, 92, 255, 0.1)',
                            border: '1px solid rgba(139, 92, 255, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Expansion</div>
                          <div className="text-xl font-bold text-purple-300">
                            {result.math.expansion.toFixed(2)}
                          </div>
                        </div>
                        <div className="p-3 rounded-xl text-center"
                          style={{
                            background: 'rgba(139, 92, 255, 0.1)',
                            border: '1px solid rgba(139, 92, 255, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Entropy Burst</div>
                          <div className="text-xl font-bold text-purple-300">
                            {result.math.entropyBurst.toFixed(2)}
                          </div>
                        </div>
                        <div className="p-3 rounded-xl text-center"
                          style={{
                            background: 'rgba(239, 68, 68, 0.15)',
                            border: '1px solid rgba(239, 68, 68, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Collapse Risk</div>
                          <div className="text-xl font-bold text-red-400">
                            {(result.math.collapseProbability * 100).toFixed(1)}%
                          </div>
                        </div>
                        <div className="p-3 rounded-xl text-center"
                          style={{
                            background: 'rgba(34, 197, 94, 0.15)',
                            border: '1px solid rgba(34, 197, 94, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Infinity Index</div>
                          <div className="text-xl font-bold text-green-400">
                            {result.math.infinityIndex.toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Evolution Results */}
                  {result.evo && (
                    <div className="upgrade-card"
                      style={{ animationDelay: '0.2s' }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-3 flex items-center gap-2">
                        <TrendingUp className="w-4 h-4" />
                        EVOLUTION BREAKTHROUGH
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="p-4 rounded-xl"
                          style={{
                            background: 'rgba(34, 197, 94, 0.1)',
                            border: '1px solid rgba(34, 197, 94, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Best Fitness Score</div>
                          <div className="text-2xl font-bold text-green-400">
                            {result.evo.best.fitness.toFixed(3)}
                          </div>
                          <div className="mt-2 text-xs text-gray-500 space-y-1">
                            <div>Improvement: {result.evo.best.improv.toFixed(2)}</div>
                            <div>Novelty: {result.evo.best.novelty.toFixed(2)}</div>
                            <div>Synergy: {result.evo.best.synergy.toFixed(2)}</div>
                            <div>Risk: {result.evo.best.risk.toFixed(2)}</div>
                          </div>
                        </div>
                        <div className="p-4 rounded-xl"
                          style={{
                            background: 'rgba(255, 140, 0, 0.1)',
                            border: '1px solid rgba(255, 140, 0, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Breakthrough Potential</div>
                          <div className="text-2xl font-bold text-orange-400">
                            {(result.evo.breakthroughPotential * 100).toFixed(1)}%
                          </div>
                          <div className="mt-3">
                            <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-gradient-to-r from-orange-500 to-yellow-400"
                                style={{ width: `${result.evo.breakthroughPotential * 100}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Top 10 Candidates */}
                      {result.evo.top10 && (
                        <div>
                          <div className="text-xs font-bold text-purple-300 mb-2">TOP 10 CANDIDATES</div>
                          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                            {result.evo.top10.map((candidate, idx) => (
                              <div 
                                key={idx}
                                className="p-2 rounded-lg text-center"
                                style={{
                                  background: idx === 0 
                                    ? 'rgba(34, 197, 94, 0.2)' 
                                    : 'rgba(139, 92, 255, 0.1)',
                                  border: `1px solid ${idx === 0 ? 'rgba(34, 197, 94, 0.5)' : 'rgba(139, 92, 255, 0.2)'}`
                                }}
                              >
                                <div className="text-[10px] text-gray-400 mb-1">
                                  {idx === 0 ? '👑 Best' : `#${idx + 1}`}
                                </div>
                                <div className="text-xs font-semibold text-white">
                                  {candidate.fitness.toFixed(3)}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* AI Narrative */}
                  {result.ai && !result.ai.raw && (
                    <div className="upgrade-card"
                      style={{ animationDelay: '0.3s' }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-3 flex items-center gap-2">
                        <Sparkles className="w-4 h-4" />
                        AI NARRATIVE
                      </div>
                      <div className="space-y-3">
                        {result.ai.overview && (
                          <div className="p-4 rounded-xl"
                            style={{
                              background: 'rgba(139, 92, 255, 0.12)',
                              border: '2px solid rgba(139, 92, 255, 0.4)',
                              boxShadow: '0 0 30px rgba(139, 92, 255, 0.3)'
                            }}
                          >
                            <div className="text-xs font-bold text-purple-300 mb-2">OVERVIEW</div>
                            <div className="text-sm text-white leading-relaxed">{result.ai.overview}</div>
                          </div>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {result.ai.risk && (
                            <div className="p-3 rounded-lg"
                              style={{
                                background: 'rgba(239, 68, 68, 0.1)',
                                border: '1px solid rgba(239, 68, 68, 0.3)'
                              }}
                            >
                              <div className="text-xs font-bold text-red-300 mb-1">RISKS</div>
                              <div className="text-xs text-gray-300">{result.ai.risk}</div>
                            </div>
                          )}

                          {result.ai.potential && (
                            <div className="p-3 rounded-lg"
                              style={{
                                background: 'rgba(34, 197, 94, 0.1)',
                                border: '1px solid rgba(34, 197, 94, 0.3)'
                              }}
                            >
                              <div className="text-xs font-bold text-green-300 mb-1">POTENTIAL</div>
                              <div className="text-xs text-gray-300">{result.ai.potential}</div>
                            </div>
                          )}
                        </div>

                        {result.ai.integration && (
                          <div className="p-3 rounded-lg"
                            style={{
                              background: 'rgba(36, 228, 255, 0.1)',
                              border: '1px solid rgba(36, 228, 255, 0.3)'
                            }}
                          >
                            <div className="text-xs font-bold text-cyan-300 mb-1">INTEGRATION PATH</div>
                            <div className="text-xs text-gray-300">{result.ai.integration}</div>
                          </div>
                        )}

                        {result.ai.recommendations && (
                          <div className="p-3 rounded-lg"
                            style={{
                              background: 'rgba(139, 92, 255, 0.08)',
                              border: '1px solid rgba(139, 92, 255, 0.3)'
                            }}
                          >
                            <div className="text-xs font-bold text-purple-300 mb-2">RECOMMENDATIONS</div>
                            <div className="text-xs text-gray-300">{result.ai.recommendations}</div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Next Steps */}
                  {result.next && (
                    <div className="upgrade-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(255, 140, 0, 0.1)',
                        border: '1px solid rgba(255, 140, 0, 0.3)',
                        animationDelay: '0.4s'
                      }}
                    >
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-orange-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <div className="text-xs font-bold text-orange-300 mb-1">NEXT STEP</div>
                          <div className="text-sm text-gray-300">{result.next}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Universal Upgrade Engine :: Multi-Module Evolution Framework</p>
          <p className="mt-1">Backend: http://localhost:9009/api/universal/upgrade</p>
          <p className="mt-1 text-purple-500/60">Supports 9 TAC modules with adaptive evolution algorithms.</p>
        </div>
      </div>
    </div>
  );
}