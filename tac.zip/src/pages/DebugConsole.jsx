import React, { useEffect, useState } from "react";

const API_BASE = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

const STYLE = `
.mdc-debug-root {
  min-height: 100vh;
  padding: 24px;
  background: radial-gradient(circle at top, #160943 0, #050510 45%, #020207 100%);
  color: #f3edff;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Inter", sans-serif;
}

.mdc-debug-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  margin-bottom: 24px;
}

.mdc-debug-title-area h1 {
  margin: 0;
  font-size: 30px;
  background: linear-gradient(90deg, #b87cff, #ff6cf8);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.mdc-debug-title-area p {
  margin: 4px 0 0;
  opacity: 0.8;
  font-size: 14px;
}

.mdc-debug-user-card {
  background: rgba(8,8,16,0.92);
  border-radius: 12px;
  border: 1px solid #30275b;
  padding: 12px 16px;
  min-width: 260px;
  backdrop-filter: blur(10px);
}

.mdc-debug-user-title {
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 1px;
  opacity: 0.7;
}

.mdc-debug-row {
  display: flex;
  gap: 8px;
  margin-top: 6px;
}
.mdc-debug-input {
  flex: 1;
  background: #0a0915;
  border-radius: 6px;
  border: 1px solid #292447;
  padding: 6px 8px;
  font-size: 13px;
  color: #f0ebff;
  outline: none;
}
.mdc-debug-input:focus {
  border-color: #8c63ff;
}

.mdc-debug-actions {
  margin-top: 8px;
  display: flex;
  gap: 8px;
}

.mdc-debug-btn {
  border-radius: 6px;
  border: 1px solid #36335a;
  background: #171429;
  padding: 6px 10px;
  font-size: 13px;
  font-weight: 600;
  color: #f3edff;
  cursor: pointer;
  transition: 0.2s;
}
.mdc-debug-btn.primary {
  background: linear-gradient(135deg, #825bff, #d64aff);
  border-color: transparent;
  box-shadow: 0 0 12px #825bff66;
}
.mdc-debug-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 0 12px #825bff33;
}
.mdc-debug-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.mdc-debug-tier {
  margin-top: 8px;
  font-size: 11px;
  border-radius: 999px;
  border: 1px solid #3a335c;
  background: linear-gradient(135deg, #191626, #241e3a);
  padding: 4px 8px;
  display: inline-flex;
  gap: 6px;
  align-items: center;
}

.mdc-debug-main {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) minmax(0, 1.3fr);
  gap: 18px;
}
@media(max-width: 900px) {
  .mdc-debug-main {
    grid-template-columns: 1fr;
  }
}

.mdc-debug-panel {
  background: rgba(5,5,15,0.96);
  border-radius: 12px;
  border: 1px solid #282345;
  padding: 16px;
  backdrop-filter: blur(10px);
}

.mdc-debug-panel h2 {
  margin: 0 0 8px;
  font-size: 18px;
}
.mdc-debug-panel p {
  margin: 0 0 10px;
  font-size: 13px;
  opacity: 0.82;
}

.mdc-debug-field {
  margin-bottom: 10px;
}
.mdc-debug-field label {
  display: block;
  font-size: 12px;
  opacity: 0.8;
  margin-bottom: 3px;
}
.mdc-debug-textarea {
  width: 100%;
  min-height: 110px;
  background: #060513;
  border-radius: 8px;
  border: 1px solid #292349;
  padding: 8px;
  font-size: 13px;
  color: #f0ebff;
  resize: vertical;
  outline: none;
  font-family: "JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}
.mdc-debug-textarea:focus {
  border-color: #8a62ff;
}

.mdc-debug-select {
  width: 100%;
}

.mdc-debug-status {
  margin-top: 6px;
  font-size: 12px;
}
.mdc-debug-status.error {
  color: #ff9393;
}
.mdc-debug-status.ok {
  color: #79ffd0;
}

/* Results */
.mdc-debug-results {
  display: grid;
  grid-template-rows: auto;
  gap: 10px;
  font-size: 13px;
}

.mdc-debug-block {
  padding: 10px;
  border-radius: 8px;
  border: 1px solid #332a57;
  background: radial-gradient(circle at top left, #24173f 0, #120f22 40%, #090616 100%);
}
.mdc-debug-block h3 {
  margin: 0 0 6px;
  font-size: 14px;
}
.mdc-debug-block pre {
  margin: 4px 0 0;
  white-space: pre-wrap;
  word-break: break-word;
  font-size: 12px;
  line-height: 1.4;
  background: #050410;
  border-radius: 6px;
  border: 1px solid #292446;
  padding: 6px;
}

.mdc-debug-tagline {
  margin-top: 4px;
  font-size: 11px;
  opacity: 0.7;
}

.mdc-debug-demigod-list {
  margin-top: 4px;
  font-size: 12px;
}
.mdc-debug-demigod-list ul {
  padding-left: 16px;
  margin: 4px 0;
}

.mdc-debug-chip {
  display: inline-block;
  font-size: 11px;
  border-radius: 999px;
  border: 1px solid #3f375f;
  padding: 2px 8px;
  margin-right: 6px;
  margin-top: 4px;
  background: #1a1330;
}
`;

// Inject style once
function Style() {
  useEffect(() => {
    const el = document.createElement("style");
    el.innerHTML = STYLE;
    document.head.appendChild(el);
    return () => {
      document.head.removeChild(el);
    };
  }, []);
  return null;
}

function DebugConsole() {
  // user state
  const [userId, setUserId] = useState("user_demo");
  const [username, setUsername] = useState("demo_user");
  const [score, setScore] = useState(75);
  const [user, setUser] = useState(null);
  const [userMsg, setUserMsg] = useState("");
  const [userLoading, setUserLoading] = useState(false);

  // debug form
  const [language, setLanguage] = useState("javascript");
  const [code, setCode] = useState("");
  const [errorDesc, setErrorDesc] = useState("");
  const [extraContext, setExtraContext] = useState("");

  // result
  const [loadingDebug, setLoadingDebug] = useState(false);
  const [debugResult, setDebugResult] = useState(null);
  const [debugError, setDebugError] = useState("");

  async function handleSetUser() {
    setUserLoading(true);
    setUserMsg("");
    try {
      const res = await fetch(`${API_BASE}/api/user/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: userId,
          username,
          score: Number(score)
        })
      });
      const data = await res.json();
      if (res.ok) {
        setUser(data);
        setUserMsg(
          `User set: ${data.username} (${data.tier.id} – ${data.tier.name})`
        );
      } else {
        setUserMsg(data.error || "User set error");
      }
    } catch (e) {
      console.error(e);
      setUserMsg("Network error while setting user");
    } finally {
      setUserLoading(false);
    }
  }

  async function handleAnalyze() {
    setDebugError("");
    setDebugResult(null);

    if (!user || !user.id) {
      setDebugError("Először állíts be egy usert.");
      return;
    }
    if (!code.trim()) {
      setDebugError("Kódrészlet szükséges a debughoz.");
      return;
    }

    setLoadingDebug(true);
    try {
      const res = await fetch(`${API_BASE}/api/debug/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          language,
          code,
          errorDescription: errorDesc,
          extraContext
        })
      });
      const data = await res.json();
      if (!res.ok) {
        setDebugError(data.error || "Debug hiba");
      } else {
        setDebugResult(data);
      }
    } catch (e) {
      console.error(e);
      setDebugError("Hálózati hiba a debug hívás közben.");
    } finally {
      setLoadingDebug(false);
    }
  }

  return (
    <>
      <Style />
      <div className="mdc-debug-root">
        <header className="mdc-debug-header">
          <div className="mdc-debug-title-area">
            <h1>MDC — Dual-Layer Debug Console</h1>
            <p>
              OpenAI Core Debug Engine + Demigod-enhanced Brain, egy panelen.
            </p>
          </div>

          <div className="mdc-debug-user-card">
            <div className="mdc-debug-user-title">Active Identity</div>
            <div className="mdc-debug-row">
              <input
                className="mdc-debug-input"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="userId"
              />
            </div>
            <div className="mdc-debug-row">
              <input
                className="mdc-debug-input"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="username"
              />
            </div>
            <div className="mdc-debug-row">
              <input
                className="mdc-debug-input"
                type="number"
                value={score}
                onChange={(e) => setScore(Number(e.target.value))}
                placeholder="score (0-100)"
              />
            </div>
            <div className="mdc-debug-actions">
              <button
                className="mdc-debug-btn primary"
                onClick={handleSetUser}
                disabled={userLoading}
              >
                {userLoading ? "Mentés..." : "Set / Update User"}
              </button>
            </div>
            {user && (
              <div className="mdc-debug-tier">
                <span>{user.tier.id}</span>
                <span>{user.tier.name}</span>
                <span>• score: {user.score}</span>
              </div>
            )}
            {userMsg && (
              <div className="mdc-debug-status ok">{userMsg}</div>
            )}
          </div>
        </header>

        <main className="mdc-debug-main">
          {/* LEFT: input form */}
          <section className="mdc-debug-panel">
            <h2>Debug Request</h2>
            <p>
              Add meg a kódot, a hibát és extra kontextust. A motor először OpenAI
              alapon analizál, majd beemeli a releváns demigod mintákat.
            </p>

            <div className="mdc-debug-field">
              <label>Nyelv</label>
              <select
                className="mdc-debug-input mdc-debug-select"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
              >
                <option>javascript</option>
                <option>typescript</option>
                <option>python</option>
                <option>rust</option>
                <option>go</option>
                <option>java</option>
                <option>c++</option>
                <option>other</option>
              </select>
            </div>

            <div className="mdc-debug-field">
              <label>Kódrészlet</label>
              <textarea
                className="mdc-debug-textarea"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Illeszd be a hibás / gyanús kódrészt ide..."
              />
            </div>

            <div className="mdc-debug-field">
              <label>Hibaleírás / viselkedés</label>
              <textarea
                className="mdc-debug-textarea"
                style={{ minHeight: 70 }}
                value={errorDesc}
                onChange={(e) => setErrorDesc(e.target.value)}
                placeholder="Mit látsz? Exception, rossz output, lassúság, memory leak gyanú, stb."
              />
            </div>

            <div className="mdc-debug-field">
              <label>Extra kontextus (opcionális)</label>
              <textarea
                className="mdc-debug-textarea"
                style={{ minHeight: 60 }}
                value={extraContext}
                onChange={(e) => setExtraContext(e.target.value)}
                placeholder="Hol fut, milyen környezetben, milyen dependency-kkel, stb."
              />
            </div>

            <button
              className="mdc-debug-btn primary"
              onClick={handleAnalyze}
              disabled={loadingDebug}
            >
              {loadingDebug ? "Analyzing..." : "Analyze with Dual-Layer Debug"}
            </button>

            {debugError && (
              <div className="mdc-debug-status error">{debugError}</div>
            )}
          </section>

          {/* RIGHT: results */}
          <section className="mdc-debug-panel">
            <h2>Debug Result</h2>
            {!debugResult && !loadingDebug && (
              <p className="mdc-debug-tagline">
                Itt fogod látni a Core AI analysis-t, a javasolt fixet, az
                improved code-ot és a Demigod Brain hozzájárulását.
              </p>
            )}

            {loadingDebug && (
              <p className="mdc-debug-tagline">AI gondolkodik... ⚡</p>
            )}

            {debugResult && (
              <div className="mdc-debug-results">
                <div className="mdc-debug-block">
                  <h3>Core Analysis (OpenAI)</h3>
                  <pre>{debugResult.coreAnalysis || "N/A"}</pre>
                </div>

                <div className="mdc-debug-block">
                  <h3>Suggested Fix</h3>
                  <pre>{debugResult.suggestedFix || "N/A"}</pre>
                </div>

                <div className="mdc-debug-block">
                  <h3>Improved Code</h3>
                  <pre>{debugResult.improvedCode || "N/A"}</pre>
                </div>

                <div className="mdc-debug-block">
                  <h3>Tests to Run</h3>
                  <pre>{debugResult.testsToRun || "N/A"}</pre>
                </div>

                <div className="mdc-debug-block">
                  <h3>Demigod Influence</h3>
                  <pre>{debugResult.demigodInfluence || "N/A"}</pre>
                  <div className="mdc-debug-demigod-list">
                    <strong>Felhasznált demigod context:</strong>
                    {debugResult.demigodContext &&
                    debugResult.demigodContext.length > 0 ? (
                      <ul>
                        {debugResult.demigodContext.map((d) => (
                          <li key={d.exampleId}>
                            {d.authorName} ({d.tierId}) • {d.language} • tags:{" "}
                            {d.tags.join(", ")}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <div>Nincs releváns demigod példa ehhez az esetre.</div>
                    )}
                  </div>
                </div>

                <div className="mdc-debug-block">
                  <h3>Royalty / Contributors</h3>
                  {debugResult.demigodRoyalty &&
                  debugResult.demigodRoyalty.contributors &&
                  debugResult.demigodRoyalty.contributors.length > 0 ? (
                    <>
                      <div>
                        Összes kiosztott credit:{" "}
                        {debugResult.demigodRoyalty.totalAllocated.toFixed(4)}
                      </div>
                      <div style={{ marginTop: 4 }}>
                        {debugResult.demigodRoyalty.contributors.map((c) => (
                          <span key={c.exampleId} className="mdc-debug-chip">
                            {c.authorName} ({c.tierId}) • +{" "}
                            {c.creditsAdded.toFixed(4)}
                          </span>
                        ))}
                      </div>
                    </>
                  ) : (
                    <div>Még nem lett demigod credit kiosztva ennél a hívásnál.</div>
                  )}
                </div>
              </div>
            )}
          </section>
        </main>
      </div>
    </>
  );
}

export default DebugConsole;