import React, { useState, useRef, useEffect } from 'react';
import { Zap, Brain, Sparkles, Loader2, TrendingUp, AlertTriangle, Eye, Target, Layers, GitBranch, Box } from 'lucide-react';

const MODE_OPTIONS = [
  { value: 'explore', label: 'EXPLORE', color: '#24e4ff', desc: 'Radical new ideas, less caution' },
  { value: 'debug', label: 'DEBUG', color: '#ff4b81', desc: 'Find bugs, traps, contradictions' },
  { value: 'hybrid', label: 'HYBRID', color: '#b788ff', desc: 'Balanced: exploration + debugging' }
];

const TARGET_AREAS = [
  'ai_architecture',
  'code_optimization',
  'creativity_engine',
  'security_system',
  'data_processing',
  'user_experience',
  'system_integration',
  'performance_tuning'
];

export default function NQFiceEngine() {
  const [context, setContext] = useState("TAC AI Platform with Paradox Architecture (Harmony 9, Distorted 9, Hallucinator, Stabilizer)");
  const [targetArea, setTargetArea] = useState("ai_architecture");
  const [intensity, setIntensity] = useState(7);
  const [mode, setMode] = useState("hybrid");
  const [seedIdea, setSeedIdea] = useState("AI agent system that optimizes code and fixes bugs autonomously");
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated background particles
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    const particleCount = 60;

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        radius: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.4 + 0.2,
        hue: Math.random() * 60 + 180 // blue-purple range
      });
    }

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(2, 6, 23, 0.08)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue}, 80%, 60%, ${p.opacity})`;
        ctx.fill();
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const runNQFice = async () => {
    if (isRunning || !seedIdea.trim()) return;

    setIsRunning(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:8099/api/nqfice/run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          context,
          targetArea,
          intensity,
          mode,
          seedIdea
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error(data.message || 'Unknown backend error');
      }

      setResult(data.result || null);

    } catch (err) {
      console.error('NQ-FICE error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const getIntensityLabel = (level) => {
    if (level <= 3) return "Shallow";
    if (level <= 5) return "Moderate";
    if (level <= 7) return "Deep";
    return "Insane";
  };

  const getIntensityColor = (level) => {
    if (level <= 3) return "#3b82f6";
    if (level <= 5) return "#22c55e";
    if (level <= 7) return "#a855f7";
    return "#ef4444";
  };

  const selectedMode = MODE_OPTIONS.find(m => m.value === mode);

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 20% 0%, #0f1729 0%, #050a14 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes pulseGlow {
          0%, 100% { opacity: 0.7; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }

        @keyframes shimmer {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-8px); }
        }

        .nqfice-badge {
          animation: pulseGlow 2.5s ease-in-out infinite;
        }

        .layer-card {
          animation: float 4s ease-in-out infinite;
        }

        .shimmer-text {
          background: linear-gradient(90deg, #24e4ff, #b788ff, #ff6ec7, #24e4ff);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmer 4s linear infinite;
        }

        .mode-option {
          transition: all 0.2s ease-out;
        }

        .mode-option.active {
          transform: scale(1.05);
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.5 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1600px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Box className="w-12 h-12 text-cyan-400 nqfice-badge" />
            <h1 className="text-4xl md:text-5xl font-black tracking-wider uppercase shimmer-text">
              NQ-FICE ENGINE
            </h1>
            <Sparkles className="w-12 h-12 text-purple-400 nqfice-badge" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            Negative Quantum Full-Inversion Causality Engine
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(36, 228, 255, 0.15)',
              border: '1px solid rgba(36, 228, 255, 0.5)',
              boxShadow: '0 0 20px rgba(36, 228, 255, 0.3)'
            }}
          >
            <Layers className="w-3 h-3" />
            3-Layer Abstract Reasoning System
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border"
          style={{
            background: 'rgba(36, 228, 255, 0.08)',
            borderColor: 'rgba(36, 228, 255, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Brain className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-cyan-300">How NQ-FICE Works:</span>
              <br />
              <strong>Layer 1:</strong> Negative Quantum Simulation (hidden contradictions, opportunity spikes)
              <br />
              <strong>Layer 2:</strong> Full Inversion Hallucinator (complete inverse architectures)
              <br />
              <strong>Layer 3:</strong> Inverted Causality Engine (reverse-engineer from success state)
              <br />
              <strong>Output:</strong> Fused design direction with concrete next steps.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node nqfice-engine.js</code> on port 8099
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Input Controls */}
          <div className="xl:col-span-5 space-y-4">
            <div className="rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(36, 228, 255, 0.3)',
                background: 'rgba(7, 7, 18, 0.95)',
                boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
              }}
            >
              <label className="block text-xs tracking-widest uppercase text-cyan-400 mb-3">
                SEED IDEA
              </label>
              <textarea
                value={seedIdea}
                onChange={(e) => setSeedIdea(e.target.value)}
                disabled={isRunning}
                rows={3}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(36, 228, 255, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="Enter your seed idea, module, feature, or problem..."
              />

              <label className="block text-xs tracking-widest uppercase text-cyan-400 mb-3">
                CONTEXT (Optional)
              </label>
              <textarea
                value={context}
                onChange={(e) => setContext(e.target.value)}
                disabled={isRunning}
                rows={2}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(36, 228, 255, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="Project/system context..."
              />

              <label className="block text-xs tracking-widest uppercase text-cyan-400 mb-3">
                TARGET AREA
              </label>
              <select
                value={targetArea}
                onChange={(e) => setTargetArea(e.target.value)}
                disabled={isRunning}
                className="w-full rounded-xl border px-4 py-3 text-sm mb-4"
                style={{
                  borderColor: 'rgba(36, 228, 255, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
              >
                {TARGET_AREAS.map(area => (
                  <option key={area} value={area}>{area}</option>
                ))}
              </select>

              <label className="block text-xs tracking-widest uppercase text-cyan-400 mb-3">
                MODE
              </label>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {MODE_OPTIONS.map(opt => (
                  <button
                    key={opt.value}
                    onClick={() => setMode(opt.value)}
                    disabled={isRunning}
                    className={`mode-option px-3 py-3 rounded-xl text-xs font-bold uppercase transition-all ${
                      mode === opt.value ? 'active' : ''
                    }`}
                    style={{
                      background: mode === opt.value 
                        ? `${opt.color}20` 
                        : 'rgba(255, 255, 255, 0.02)',
                      border: `1px solid ${mode === opt.value ? opt.color : 'rgba(255, 255, 255, 0.1)'}`,
                      color: mode === opt.value ? opt.color : '#9094b2',
                      boxShadow: mode === opt.value ? `0 0 15px ${opt.color}40` : 'none'
                    }}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              <div className="text-xs text-gray-500 mb-4">
                {selectedMode?.desc}
              </div>

              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs tracking-widest uppercase text-cyan-400">
                    INTENSITY LEVEL
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">{intensity}</span>
                    <span 
                      className="text-xs font-bold px-2 py-0.5 rounded-full"
                      style={{
                        color: getIntensityColor(intensity),
                        background: `${getIntensityColor(intensity)}20`,
                        border: `1px solid ${getIntensityColor(intensity)}40`
                      }}
                    >
                      {getIntensityLabel(intensity)}
                    </span>
                  </div>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={intensity}
                  onChange={(e) => setIntensity(parseInt(e.target.value))}
                  disabled={isRunning}
                  className="w-full"
                  style={{
                    accentColor: getIntensityColor(intensity)
                  }}
                />
                <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                  <span>Shallow</span>
                  <span>Moderate</span>
                  <span>Deep</span>
                  <span>Insane</span>
                </div>
              </div>

              <button
                onClick={runNQFice}
                disabled={isRunning}
                className="w-full py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #24e4ff, #b788ff)',
                  color: '#020206',
                  boxShadow: isRunning ? 'none' : '0 0 30px rgba(36, 228, 255, 0.6)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    PROCESSING...
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    RUN NQ-FICE
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right: Output */}
          <div className="xl:col-span-7">
            <div className="rounded-2xl border p-6 h-full"
              style={{
                borderColor: 'rgba(36, 228, 255, 0.4)',
                background: 'rgba(7, 7, 18, 0.95)',
                boxShadow: '0 0 60px rgba(36, 228, 255, 0.2)'
              }}
            >
              <h3 className="text-xs tracking-widest uppercase text-cyan-400 mb-4 flex items-center gap-2">
                <Target className="w-4 h-4" />
                NQ-FICE OUTPUT
              </h3>

              {!result && !isRunning && (
                <div className="text-center py-12">
                  <Box className="w-16 h-16 mx-auto mb-4 text-cyan-400/30" />
                  <p className="text-sm text-gray-500">
                    No analysis generated yet.
                    <br />
                    Configure parameters and click "Run NQ-FICE".
                  </p>
                </div>
              )}

              {isRunning && (
                <div className="text-center py-12">
                  <Loader2 className="w-16 h-16 mx-auto mb-4 text-cyan-400 animate-spin" />
                  <p className="text-sm text-gray-400">
                    NQ-FICE is processing through 3 conceptual layers...
                  </p>
                </div>
              )}

              {result && (
                <div className="space-y-4 max-h-[700px] overflow-y-auto">
                  {/* Seed Echo */}
                  {result.seed && (
                    <div className="layer-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(36, 228, 255, 0.08)',
                        border: '1px solid rgba(36, 228, 255, 0.3)',
                        animationDelay: '0s'
                      }}
                    >
                      <div className="text-xs font-bold text-cyan-300 mb-2 flex items-center gap-2">
                        <Eye className="w-3 h-3" />
                        SEED
                      </div>
                      <div className="text-sm text-white mb-1">{result.seed.raw}</div>
                      <div className="text-xs text-gray-400">Target: {result.seed.targetArea}</div>
                    </div>
                  )}

                  {/* Layer 1: Quantum */}
                  {result.quantumLayer && (
                    <div className="layer-card"
                      style={{ animationDelay: '0.2s' }}
                    >
                      <div className="text-xs font-bold text-blue-300 mb-2 flex items-center gap-2">
                        <Sparkles className="w-3 h-3" />
                        LAYER 1: NEGATIVE QUANTUM SIMULATION
                      </div>
                      {result.quantumLayer.negativePatterns && (
                        <div className="mb-3">
                          <div className="text-xs text-gray-400 mb-1">Negative Patterns:</div>
                          <ul className="space-y-1">
                            {result.quantumLayer.negativePatterns.map((p, i) => (
                              <li key={i} className="text-xs text-gray-300 p-2 rounded"
                                style={{
                                  background: 'rgba(59, 130, 246, 0.1)',
                                  border: '1px solid rgba(59, 130, 246, 0.2)'
                                }}
                              >
                                • {p}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {result.quantumLayer.opportunityNodes && (
                        <div className="mb-3">
                          <div className="text-xs text-gray-400 mb-1">Opportunity Nodes:</div>
                          <ul className="space-y-1">
                            {result.quantumLayer.opportunityNodes.map((p, i) => (
                              <li key={i} className="text-xs text-gray-300 p-2 rounded"
                                style={{
                                  background: 'rgba(34, 197, 94, 0.1)',
                                  border: '1px solid rgba(34, 197, 94, 0.2)'
                                }}
                              >
                                ✦ {p}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {result.quantumLayer.notes && (
                        <div className="text-xs text-gray-400 italic">{result.quantumLayer.notes}</div>
                      )}
                    </div>
                  )}

                  {/* Layer 2: Inversion */}
                  {result.inversionLayer && (
                    <div className="layer-card"
                      style={{ animationDelay: '0.4s' }}
                    >
                      <div className="text-xs font-bold text-purple-300 mb-2 flex items-center gap-2">
                        <GitBranch className="w-3 h-3" />
                        LAYER 2: FULL INVERSION HALLUCINATOR
                      </div>
                      {result.inversionLayer.invertedArchitectures && (
                        <div className="space-y-2 mb-3">
                          {result.inversionLayer.invertedArchitectures.map((arch, i) => (
                            <div key={i} className="p-3 rounded-lg"
                              style={{
                                background: 'rgba(168, 85, 247, 0.1)',
                                border: '1px solid rgba(168, 85, 247, 0.3)'
                              }}
                            >
                              <div className="text-sm font-semibold text-purple-200 mb-1">{arch.name}</div>
                              <div className="text-xs text-gray-300 mb-1">{arch.description}</div>
                              <div className="text-xs text-purple-400 italic">Why: {arch.whyInteresting}</div>
                            </div>
                          ))}
                        </div>
                      )}
                      {result.inversionLayer.dangerousPitfalls && (
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Pitfalls:</div>
                          <ul className="space-y-1">
                            {result.inversionLayer.dangerousPitfalls.map((p, i) => (
                              <li key={i} className="text-xs text-gray-300 p-2 rounded"
                                style={{
                                  background: 'rgba(239, 68, 68, 0.1)',
                                  border: '1px solid rgba(239, 68, 68, 0.2)'
                                }}
                              >
                                ⚠ {p}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Layer 3: Causality */}
                  {result.causalityLayer && (
                    <div className="layer-card"
                      style={{ animationDelay: '0.6s' }}
                    >
                      <div className="text-xs font-bold text-emerald-300 mb-2 flex items-center gap-2">
                        <TrendingUp className="w-3 h-3" />
                        LAYER 3: INVERTED CAUSALITY ENGINE
                      </div>
                      {result.causalityLayer.finalStateVision && (
                        <div className="mb-3 p-3 rounded-lg"
                          style={{
                            background: 'rgba(16, 185, 129, 0.1)',
                            border: '1px solid rgba(16, 185, 129, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Final State Vision:</div>
                          <div className="text-xs text-gray-200">{result.causalityLayer.finalStateVision}</div>
                        </div>
                      )}
                      {result.causalityLayer.causalChain && (
                        <div className="mb-3">
                          <div className="text-xs text-gray-400 mb-1">Causal Chain (Future → Present):</div>
                          <ol className="space-y-1">
                            {result.causalityLayer.causalChain.map((step, i) => (
                              <li key={i} className="text-xs text-gray-300 p-2 rounded"
                                style={{
                                  background: 'rgba(34, 197, 94, 0.1)',
                                  border: '1px solid rgba(34, 197, 94, 0.2)'
                                }}
                              >
                                {i + 1}. {step}
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}
                      {result.causalityLayer.requiredSubmodules && (
                        <div>
                          <div className="text-xs text-gray-400 mb-1">Required Submodules:</div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            {result.causalityLayer.requiredSubmodules.map((sub, i) => (
                              <div key={i} className="p-2 rounded"
                                style={{
                                  background: 'rgba(59, 130, 246, 0.1)',
                                  border: '1px solid rgba(59, 130, 246, 0.2)'
                                }}
                              >
                                <div className="text-xs font-semibold text-blue-200">{sub.name}</div>
                                <div className="text-[10px] text-gray-400">{sub.role}</div>
                                <div className={`text-[10px] font-bold ${
                                  sub.priority === 'high' ? 'text-red-400' :
                                  sub.priority === 'medium' ? 'text-yellow-400' :
                                  'text-green-400'
                                }`}>
                                  Priority: {sub.priority}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Fused Proposal */}
                  {result.fusedProposal && (
                    <div className="layer-card p-4 rounded-xl"
                      style={{
                        background: 'linear-gradient(135deg, rgba(36, 228, 255, 0.15), rgba(183, 136, 255, 0.15))',
                        border: '2px solid rgba(36, 228, 255, 0.5)',
                        animationDelay: '0.8s',
                        boxShadow: '0 0 30px rgba(36, 228, 255, 0.3)'
                      }}
                    >
                      <div className="text-xs font-bold text-cyan-300 mb-3 flex items-center gap-2">
                        <Zap className="w-4 h-4" />
                        FUSED PROPOSAL
                      </div>
                      
                      <div className="mb-4 p-3 rounded-lg" style={{
                        background: 'rgba(0, 0, 0, 0.3)',
                        border: '1px solid rgba(255, 255, 255, 0.1)'
                      }}>
                        <div className="text-sm text-white font-semibold">{result.fusedProposal.summary}</div>
                      </div>

                      {result.fusedProposal.concreteNextSteps && (
                        <div className="mb-4">
                          <div className="text-xs text-cyan-300 mb-2">Concrete Next Steps:</div>
                          <ol className="space-y-2">
                            {result.fusedProposal.concreteNextSteps.map((step, i) => (
                              <li key={i} className="flex items-start gap-2 text-xs text-gray-200 p-3 rounded-lg"
                                style={{
                                  background: 'rgba(36, 228, 255, 0.1)',
                                  border: '1px solid rgba(36, 228, 255, 0.3)'
                                }}
                              >
                                <span className="text-cyan-400 font-bold">{i + 1}.</span>
                                <span>{step}</span>
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}

                      {result.fusedProposal.architectureHint && (
                        <div className="mb-4 p-3 rounded-lg" style={{
                          background: 'rgba(183, 136, 255, 0.1)',
                          border: '1px solid rgba(183, 136, 255, 0.3)'
                        }}>
                          <div className="text-xs text-purple-300 mb-1">Architecture Integration:</div>
                          <div className="text-xs text-gray-200">{result.fusedProposal.architectureHint}</div>
                        </div>
                      )}

                      {result.fusedProposal.riskMap && (
                        <div className="mb-4">
                          <div className="text-xs text-cyan-300 mb-2">Risk Map:</div>
                          <div className="space-y-2">
                            {result.fusedProposal.riskMap.map((r, i) => (
                              <div key={i} className="p-3 rounded-lg"
                                style={{
                                  background: 'rgba(239, 68, 68, 0.1)',
                                  border: '1px solid rgba(239, 68, 68, 0.3)'
                                }}
                              >
                                <div className="text-xs text-red-300 font-semibold mb-1">⚠ {r.risk}</div>
                                <div className="text-xs text-gray-300">→ {r.mitigation}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {result.fusedProposal.devNotes && (
                        <div className="p-3 rounded-lg" style={{
                          background: 'rgba(0, 0, 0, 0.3)',
                          border: '1px solid rgba(255, 255, 255, 0.1)'
                        }}>
                          <div className="text-xs text-gray-400 mb-1">Developer Notes:</div>
                          <div className="text-xs text-gray-300 italic">{result.fusedProposal.devNotes}</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>NQ-FICE Engine :: Negative Quantum Full-Inversion Causality Engine</p>
          <p className="mt-1">Backend: http://localhost:8099/api/nqfice/run</p>
        </div>
      </div>
    </div>
  );
}