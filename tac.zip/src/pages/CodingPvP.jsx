import React, { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Swords, Trophy, Zap, Clock, Code2, 
  Flame, Target, Users, DollarSign, RefreshCw 
} from "lucide-react";
import { toast } from "sonner";
import io from "socket.io-client";
import ChallengeCard from "../components/ChallengeCard";
import ArenaView from "../components/ArenaView";

const PVP_API = import.meta.env.VITE_PVP_BACKEND_URL || "http://localhost:4000";

export default function CodingPvP() {
  const [challenges, setChallenges] = useState([]);
  const [loadingChallenges, setLoadingChallenges] = useState(false);
  
  // Company challenge creation
  const [chTitle, setChTitle] = useState("");
  const [chDesc, setChDesc] = useState("");
  const [chLang, setChLang] = useState("JavaScript");
  const [chDiff, setChDiff] = useState("medium");
  const [chTime, setChTime] = useState("900");
  const [chReward, setChReward] = useState("100");
  const [creating, setCreating] = useState(false);

  // Arena state
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [currentMatch, setCurrentMatch] = useState(null);
  const [arenaSocket, setArenaSocket] = useState(null);
  const [latestScores, setLatestScores] = useState([]);
  const [remainingMs, setRemainingMs] = useState(null);
  const [matchFinishedData, setMatchFinishedData] = useState(null);
  const [codeInput, setCodeInput] = useState("");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Load challenges
  const loadChallenges = async () => {
    setLoadingChallenges(true);
    try {
      const res = await fetch(`${PVP_API}/api/challenges/open`);
      if (res.ok) {
        const data = await res.json();
        setChallenges(data);
      }
    } catch (error) {
      console.error("Load challenges error:", error);
      toast.error("Failed to load challenges");
    } finally {
      setLoadingChallenges(false);
    }
  };

  useEffect(() => {
    loadChallenges();
  }, []);

  // Create challenge (company only)
  const handleCreateChallenge = async () => {
    if (!user) {
      toast.error("Please login first");
      return;
    }
    if (!chTitle) {
      toast.error("Challenge title required");
      return;
    }

    setCreating(true);
    try {
      const res = await fetch(`${PVP_API}/api/challenge/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companyId: user.email,
          title: chTitle,
          description: chDesc,
          language: chLang,
          difficulty: chDiff,
          timeLimitSec: Number(chTime),
          rewardEUR: Number(chReward)
        })
      });

      if (res.ok) {
        toast.success("Challenge created!");
        setChTitle("");
        setChDesc("");
        setChLang("JavaScript");
        setChTime("900");
        setChReward("100");
        loadChallenges();
      } else {
        const data = await res.json();
        toast.error(data.error || "Failed to create challenge");
      }
    } catch (error) {
      console.error("Create challenge error:", error);
      toast.error("Network error");
    } finally {
      setCreating(false);
    }
  };

  // Join arena
  const handleJoinArena = async (challengeId) => {
    if (!user) {
      toast.error("Please login first");
      return;
    }

    try {
      const res = await fetch(`${PVP_API}/api/challenge/${challengeId}`);
      if (!res.ok) {
        toast.error("Challenge not found");
        return;
      }
      const challenge = await res.json();
      
      setCurrentChallenge(challenge);
      setMatchFinishedData(null);
      setLatestScores([]);
      setRemainingMs(null);
      setCodeInput("");

      // Initialize Socket.IO
      if (!arenaSocket) {
        const socket = io(`${PVP_API}/arena`);
        
        socket.on("connect", () => {
          console.log("Arena connected");
        });

        socket.on("joinError", (payload) => {
          toast.error(payload.error || "Join failed");
        });

        socket.on("matchUpdate", (payload) => {
          setCurrentMatch(payload);
        });

        socket.on("matchStarted", () => {
          toast.success("Match started! Code now!");
        });

        socket.on("timerUpdate", (payload) => {
          setRemainingMs(payload.remainingMs);
        });

        socket.on("scoreUpdate", (payload) => {
          setLatestScores(payload.scores || []);
        });

        socket.on("matchFinished", (payload) => {
          setMatchFinishedData(payload);
          toast.success(`Match finished! Winner: ${payload.winnerName}`);
        });

        setArenaSocket(socket);

        // Join after socket setup
        setTimeout(() => {
          socket.emit("joinChallenge", {
            challengeId: challenge.id,
            userId: user.email,
            username: user.full_name || user.email.split('@')[0]
          });
        }, 100);
      } else {
        arenaSocket.emit("joinChallenge", {
          challengeId: challenge.id,
          userId: user.email,
          username: user.full_name || user.email.split('@')[0]
        });
      }
    } catch (error) {
      console.error("Join arena error:", error);
      toast.error("Failed to join arena");
    }
  };

  // Submit code
  const handleSubmitCode = () => {
    if (!arenaSocket || !codeInput) {
      toast.error("Write some code first");
      return;
    }
    arenaSocket.emit("submitCode", { code: codeInput });
    toast.success("Code submitted!");
  };

  // Cleanup socket on unmount
  useEffect(() => {
    return () => {
      if (arenaSocket) {
        arenaSocket.disconnect();
      }
    };
  }, [arenaSocket]);

  const isRunning = currentMatch?.status === "running";
  const isFinished = currentMatch?.status === "finished";

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Swords className="w-4 h-4 text-red-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Esport Programming</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #ff3366, #ff9933, #ffff00)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            Coding PvP Arena
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Real-time coding battles. Companies post challenges, devs compete live. Winner takes the reward and rank points.
          </p>
        </div>

        {/* Stats Banner */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Flame className="w-6 h-6 text-red-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{challenges.length}</div>
            <div className="text-xs text-gray-400">Active Challenges</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Users className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {currentMatch?.players?.length || 0}
            </div>
            <div className="text-xs text-gray-400">Players in Arena</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Trophy className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              €{challenges.reduce((sum, c) => sum + (c.rewardEUR || 0), 0)}
            </div>
            <div className="text-xs text-gray-400">Total Prize Pool</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Zap className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">Live</div>
            <div className="text-xs text-gray-400">Real-Time Battles</div>
          </Card>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-[1fr_1.5fr] gap-8">
          {/* Left: Challenges */}
          <div className="space-y-6">
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-black text-white">Open Challenges</h2>
                <Button
                  onClick={loadChallenges}
                  disabled={loadingChallenges}
                  size="sm"
                  variant="outline"
                  className="border-[#1a1f2e] text-gray-300"
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${loadingChallenges ? 'animate-spin' : ''}`} />
                  Refresh
                </Button>
              </div>

              <div className="space-y-3 max-h-[600px] overflow-y-auto">
                {challenges.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 text-sm">
                    No active challenges. Companies can create one below.
                  </div>
                ) : (
                  challenges.map((challenge) => (
                    <ChallengeCard
                      key={challenge.id}
                      challenge={challenge}
                      onJoin={() => handleJoinArena(challenge.id)}
                    />
                  ))
                )}
              </div>
            </Card>

            {/* Create Challenge (Company only) */}
            {user && (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-lg font-bold text-white mb-4">Create Challenge</h3>
                <p className="text-xs text-gray-400 mb-4">
                  Companies can post real-time coding challenges with rewards
                </p>

                <div className="space-y-3">
                  <Input
                    value={chTitle}
                    onChange={(e) => setChTitle(e.target.value)}
                    placeholder="Challenge title (e.g. Optimize sorting algo)"
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                  />

                  <Textarea
                    value={chDesc}
                    onChange={(e) => setChDesc(e.target.value)}
                    placeholder="Description (optional)"
                    className="bg-[#141923] border-[#1a1f2e] text-white h-20"
                  />

                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      value={chLang}
                      onChange={(e) => setChLang(e.target.value)}
                      placeholder="Language"
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                    />

                    <Select value={chDiff} onValueChange={setChDiff}>
                      <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Easy</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="hard">Hard</SelectItem>
                        <SelectItem value="demigod">Demigod</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      type="number"
                      value={chTime}
                      onChange={(e) => setChTime(e.target.value)}
                      placeholder="Time limit (seconds)"
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                    />

                    <Input
                      type="number"
                      value={chReward}
                      onChange={(e) => setChReward(e.target.value)}
                      placeholder="Reward (EUR)"
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                    />
                  </div>

                  <Button
                    onClick={handleCreateChallenge}
                    disabled={creating || !chTitle}
                    className="w-full bg-gradient-to-r from-red-600 to-orange-600 text-white font-bold"
                  >
                    {creating ? "Creating..." : "Create Challenge"}
                  </Button>
                </div>
              </Card>
            )}
          </div>

          {/* Right: Arena */}
          <ArenaView
            currentChallenge={currentChallenge}
            currentMatch={currentMatch}
            latestScores={latestScores}
            remainingMs={remainingMs}
            matchFinishedData={matchFinishedData}
            codeInput={codeInput}
            setCodeInput={setCodeInput}
            onSubmitCode={handleSubmitCode}
            isRunning={isRunning}
            isFinished={isFinished}
          />
        </div>
      </div>
    </div>
  );
}