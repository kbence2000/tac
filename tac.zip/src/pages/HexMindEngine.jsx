import React, { useState, useRef, useEffect } from 'react';
import { Hexagon, Loader2, AlertTriangle, ArrowRightLeft, Zap, Activity, TrendingUp, BarChart3, Eye, Copy, Check } from 'lucide-react';

export default function HexMindEngine() {
  const [mode, setMode] = useState('hex'); // 'hex' or 'antihex'
  const [input, setInput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [copiedField, setCopiedField] = useState(null);
  const canvasRef = useRef(null);

  // Animated hex grid background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let time = 0;

    let animationId;
    const animate = () => {
      ctx.fillStyle = mode === 'hex' 
        ? 'rgba(2, 8, 3, 0.15)' 
        : 'rgba(8, 2, 8, 0.15)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      time += 0.01;

      // Draw animated hexagons
      const hexSize = 40;
      const rows = Math.ceil(canvas.height / (hexSize * 1.5));
      const cols = Math.ceil(canvas.width / (hexSize * 2));

      ctx.strokeStyle = mode === 'hex' 
        ? 'rgba(76, 255, 168, 0.15)' 
        : 'rgba(168, 76, 255, 0.15)';
      ctx.lineWidth = 1;

      for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
          const x = col * hexSize * 1.73 + (row % 2) * hexSize * 0.87;
          const y = row * hexSize * 1.5;

          const pulse = Math.sin(time + row * 0.5 + col * 0.5) * 0.3 + 0.7;

          ctx.globalAlpha = pulse * 0.6;
          drawHexagon(ctx, x, y, hexSize * 0.8);
          ctx.globalAlpha = 1;
        }
      }

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, [mode]);

  const drawHexagon = (ctx, x, y, size) => {
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const angle = (Math.PI / 3) * i;
      const hx = x + size * Math.cos(angle);
      const hy = y + size * Math.sin(angle);
      if (i === 0) {
        ctx.moveTo(hx, hy);
      } else {
        ctx.lineTo(hx, hy);
      }
    }
    ctx.closePath();
    ctx.stroke();
  };

  const runAnalysis = async () => {
    if (!input.trim() || isRunning) return;

    setIsRunning(true);
    setError(null);
    setResult(null);

    try {
      const endpoint = mode === 'hex' 
        ? 'http://localhost:9944/api/hex/analyze'
        : 'http://localhost:9944/api/antihex/analyze';

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error(data.message || 'Analysis failed');
      }

      setResult(data);

    } catch (err) {
      console.error('HexMind analysis error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const copyToClipboard = (text, field) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const getModeColor = () => {
    return mode === 'hex' ? '#4cffa8' : '#a84cff';
  };

  const getModeBg = () => {
    return mode === 'hex' 
      ? 'rgba(76, 255, 168, 0.1)' 
      : 'rgba(168, 76, 255, 0.1)';
  };

  const getModeBorder = () => {
    return mode === 'hex' 
      ? 'rgba(76, 255, 168, 0.4)' 
      : 'rgba(168, 76, 255, 0.4)';
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: mode === 'hex'
        ? 'radial-gradient(circle at 50% 0%, #0a2818 0%, #020803 30%, #02000c 70%)'
        : 'radial-gradient(circle at 50% 0%, #28180a 0%, #080302 30%, #0c0002 70%)'
    }}>
      <style>{`
        @keyframes hexPulse {
          0%, 100% { opacity: 0.8; transform: scale(1) rotate(0deg); }
          50% { opacity: 1; transform: scale(1.05) rotate(180deg); }
        }

        @keyframes hexFloat {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-12px) rotate(10deg); }
        }

        .hex-badge {
          animation: hexPulse 4s ease-in-out infinite;
        }

        .hex-card {
          animation: hexFloat 6s ease-in-out infinite;
        }

        .mode-toggle {
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.4 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1600px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Hexagon className="w-16 h-16 hex-badge" style={{ color: getModeColor() }} />
            <h1 className="text-5xl md:text-6xl font-black tracking-wider uppercase text-white">
              HEX MIND ENGINE
            </h1>
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            Byte-Level Pattern Analysis · Entropy Computation · Bit Inversion Space
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: getModeBg(),
              border: `1px solid ${getModeBorder()}`,
              boxShadow: `0 0 20px ${getModeColor()}66`
            }}
          >
            <Hexagon className="w-3 h-3" />
            {mode === 'hex' ? 'HEX MODE' : 'ANTI-HEX MODE'}
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border"
          style={{
            background: getModeBg(),
            borderColor: getModeBorder()
          }}
        >
          <div className="flex items-start gap-3">
            <Eye className="w-5 h-5 mt-0.5 flex-shrink-0" style={{ color: getModeColor() }} />
            <div className="text-xs text-gray-300">
              <span className="font-bold" style={{ color: getModeColor() }}>
                {mode === 'hex' ? 'Hex Mind:' : 'Anti-Hex Mind:'}
              </span>
              <br />
              {mode === 'hex' ? (
                <>
                  Analyzes raw byte patterns, entropy levels, and frequency distributions.
                  Detects structured vs random data, compression indicators, and text vs binary signatures.
                </>
              ) : (
                <>
                  Inverts all bits (byte-level NOT operation) and analyzes the inverted space.
                  Reveals complementary patterns, entropy shifts, and symmetry breaks in the data structure.
                </>
              )}
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Backend: <code className="bg-black/40 px-2 py-0.5 rounded">http://localhost:9944</code>
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Input & Controls */}
          <div className="xl:col-span-4 space-y-4">
            {/* Mode Toggle */}
            <div className="rounded-2xl border p-6"
              style={{
                borderColor: getModeBorder(),
                background: 'rgba(10, 12, 18, 0.95)',
                boxShadow: `0 0 40px ${getModeColor()}33`
              }}
            >
              <div className="text-xs tracking-widest uppercase mb-4" style={{ color: getModeColor() }}>
                MODE SELECTION
              </div>

              <div className="flex gap-3 mb-6">
                <button
                  onClick={() => setMode('hex')}
                  className="mode-toggle flex-1 py-3 rounded-xl text-sm font-bold uppercase tracking-wider"
                  style={{
                    background: mode === 'hex' 
                      ? 'linear-gradient(135deg, #4cffa8, #32e67c)' 
                      : 'transparent',
                    color: mode === 'hex' ? '#020309' : '#4cffa8',
                    border: mode === 'hex' ? 'none' : '1px solid rgba(76, 255, 168, 0.4)'
                  }}
                >
                  <Hexagon className="w-4 h-4 inline mr-2" />
                  HEX MODE
                </button>
                <button
                  onClick={() => setMode('antihex')}
                  className="mode-toggle flex-1 py-3 rounded-xl text-sm font-bold uppercase tracking-wider"
                  style={{
                    background: mode === 'antihex' 
                      ? 'linear-gradient(135deg, #a84cff, #7c32e6)' 
                      : 'transparent',
                    color: mode === 'antihex' ? '#020309' : '#a84cff',
                    border: mode === 'antihex' ? 'none' : '1px solid rgba(168, 76, 255, 0.4)'
                  }}
                >
                  <ArrowRightLeft className="w-4 h-4 inline mr-2" />
                  ANTI-HEX
                </button>
              </div>

              {/* Input */}
              <div className="mb-4">
                <label className="text-xs tracking-widest uppercase mb-2 block" style={{ color: getModeColor() }}>
                  INPUT DATA
                </label>
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={isRunning}
                  rows={8}
                  className="w-full rounded-xl border px-4 py-3 text-sm resize-none font-mono"
                  style={{
                    borderColor: getModeBorder(),
                    background: 'rgba(2, 0, 12, 0.9)',
                    color: '#f6fff6'
                  }}
                  placeholder={mode === 'hex' 
                    ? "Enter text or paste hex string...\n\nExample:\nHello World\n\nOr hex:\n48656c6c6f20576f726c64"
                    : "Enter text for bit inversion analysis...\n\nThe engine will flip all bits and analyze the inverted space."}
                />
              </div>

              {/* Run Button */}
              <button
                onClick={runAnalysis}
                disabled={isRunning || !input.trim()}
                className="w-full py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: `linear-gradient(135deg, ${getModeColor()}, ${mode === 'hex' ? '#32e67c' : '#7c32e6'})`,
                  color: '#020309',
                  boxShadow: isRunning ? 'none' : `0 0 30px ${getModeColor()}99`
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    ANALYZING...
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    RUN {mode.toUpperCase()} ANALYSIS
                  </>
                )}
              </button>

              {/* Stats */}
              {result && (
                <div className="mt-6 pt-4 border-t" style={{ borderColor: getModeBorder() }}>
                  <div className="text-xs text-gray-400 mb-3">Analysis Stats</div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Input Length:</span>
                      <span className="text-white font-semibold">{result.length} bytes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Mode:</span>
                      <span className="font-semibold" style={{ color: getModeColor() }}>
                        {result.mode}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">AI Narrative:</span>
                      <span className="text-white font-semibold">
                        {result.narrative?.summary ? 'Available' : 'N/A'}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right: Results */}
          <div className="xl:col-span-8">
            {!result && !isRunning && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: getModeBorder(),
                  background: 'rgba(10, 12, 18, 0.95)'
                }}
              >
                <div>
                  <Hexagon className="w-24 h-24 mx-auto mb-4" style={{ color: `${getModeColor()}44` }} />
                  <p className="text-sm text-gray-500">
                    No analysis result yet.
                    <br />
                    Enter data and run {mode.toUpperCase()} analysis.
                  </p>
                </div>
              </div>
            )}

            {isRunning && !result && (
              <div className="rounded-2xl border p-12 text-center h-full flex items-center justify-center"
                style={{
                  borderColor: getModeBorder(),
                  background: 'rgba(10, 12, 18, 0.95)'
                }}
              >
                <div>
                  <Loader2 className="w-24 h-24 mx-auto mb-4 animate-spin" style={{ color: getModeColor() }} />
                  <p className="text-sm text-gray-400">
                    Running {mode.toUpperCase()} analysis...
                  </p>
                </div>
              </div>
            )}

            {result && (
              <div className="space-y-4">
                {/* HEX MODE RESULTS */}
                {result.mode === 'HEX' && (
                  <>
                    {/* Hex Output */}
                    <div className="hex-card rounded-2xl border p-6"
                      style={{
                        borderColor: getModeBorder(),
                        background: 'rgba(10, 12, 18, 0.95)',
                        animationDelay: '0s'
                      }}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-sm font-bold uppercase tracking-wider" style={{ color: getModeColor() }}>
                          Hex Output
                        </h3>
                        <button
                          onClick={() => copyToClipboard(result.analysis.hex, 'hex')}
                          className="px-3 py-1 rounded-full text-xs transition-all hover:scale-105"
                          style={{
                            background: 'rgba(76, 255, 168, 0.1)',
                            border: '1px solid rgba(76, 255, 168, 0.3)'
                          }}
                        >
                          {copiedField === 'hex' ? (
                            <>
                              <Check className="w-3 h-3 inline mr-1" />
                              Copied
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3 inline mr-1" />
                              Copy
                            </>
                          )}
                        </button>
                      </div>
                      <pre className="text-xs text-gray-300 font-mono whitespace-pre-wrap break-all bg-black/40 p-4 rounded-xl max-h-[200px] overflow-auto">
                        {result.analysis.hex}
                      </pre>
                    </div>

                    {/* Entropy */}
                    <div className="hex-card rounded-2xl border p-6"
                      style={{
                        borderColor: getModeBorder(),
                        background: 'rgba(10, 12, 18, 0.95)',
                        animationDelay: '0.1s'
                      }}
                    >
                      <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: getModeColor() }}>
                        <Activity className="w-4 h-4 inline mr-2" />
                        Shannon Entropy
                      </h3>
                      <div className="flex items-center gap-4">
                        <div className="text-4xl font-black" style={{ color: getModeColor() }}>
                          {result.analysis.entropy.toFixed(4)}
                        </div>
                        <div className="flex-1">
                          <div className="h-3 bg-gray-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full transition-all duration-500"
                              style={{ 
                                width: `${(result.analysis.entropy / 8) * 100}%`,
                                background: `linear-gradient(90deg, ${getModeColor()}, ${mode === 'hex' ? '#32e67c' : '#7c32e6'})`
                              }}
                            />
                          </div>
                          <div className="flex justify-between text-xs text-gray-500 mt-1">
                            <span>0 (structured)</span>
                            <span>8 (random)</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Patterns */}
                    <div className="hex-card rounded-2xl border p-6"
                      style={{
                        borderColor: getModeBorder(),
                        background: 'rgba(10, 12, 18, 0.95)',
                        animationDelay: '0.2s'
                      }}
                    >
                      <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: getModeColor() }}>
                        <BarChart3 className="w-4 h-4 inline mr-2" />
                        Top Byte Frequencies
                      </h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {result.analysis.patterns.freq.slice(0, 8).map((item, idx) => (
                          <div 
                            key={idx}
                            className="p-3 rounded-lg text-center"
                            style={{
                              background: 'rgba(76, 255, 168, 0.05)',
                              border: '1px solid rgba(76, 255, 168, 0.2)'
                            }}
                          >
                            <div className="text-xs text-gray-400 mb-1">0x{item.byte}</div>
                            <div className="text-lg font-bold" style={{ color: getModeColor() }}>
                              {item.count}
                            </div>
                            <div className="text-xs text-gray-500">
                              {(item.p * 100).toFixed(1)}%
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                {/* ANTI-HEX MODE RESULTS */}
                {result.mode === 'ANTI_HEX' && (
                  <>
                    {/* Original vs Inverted */}
                    <div className="hex-card rounded-2xl border p-6"
                      style={{
                        borderColor: getModeBorder(),
                        background: 'rgba(10, 12, 18, 0.95)',
                        animationDelay: '0s'
                      }}
                    >
                      <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: getModeColor() }}>
                        <ArrowRightLeft className="w-4 h-4 inline mr-2" />
                        Original vs Inverted Hex
                      </h3>
                      
                      <div className="space-y-4">
                        <div>
                          <div className="text-xs text-gray-400 mb-2">Original:</div>
                          <pre className="text-xs text-gray-300 font-mono whitespace-pre-wrap break-all bg-black/40 p-3 rounded-lg max-h-[120px] overflow-auto">
                            {result.analysis.original.hex.substring(0, 200)}
                            {result.analysis.original.hex.length > 200 && '...'}
                          </pre>
                        </div>

                        <div className="flex items-center justify-center">
                          <ArrowRightLeft className="w-6 h-6" style={{ color: getModeColor() }} />
                        </div>

                        <div>
                          <div className="text-xs text-gray-400 mb-2">Inverted (bit-flipped):</div>
                          <pre className="text-xs font-mono whitespace-pre-wrap break-all p-3 rounded-lg max-h-[120px] overflow-auto"
                            style={{
                              background: 'rgba(168, 76, 255, 0.15)',
                              color: '#a84cff'
                            }}
                          >
                            {result.analysis.inverted.hex.substring(0, 200)}
                            {result.analysis.inverted.hex.length > 200 && '...'}
                          </pre>
                        </div>
                      </div>
                    </div>

                    {/* Entropy Comparison */}
                    <div className="hex-card grid grid-cols-1 md:grid-cols-2 gap-4"
                      style={{ animationDelay: '0.1s' }}
                    >
                      <div className="rounded-2xl border p-6"
                        style={{
                          borderColor: 'rgba(76, 255, 168, 0.4)',
                          background: 'rgba(10, 12, 18, 0.95)'
                        }}
                      >
                        <h4 className="text-xs font-bold uppercase tracking-wider mb-3 text-green-400">
                          Original Entropy
                        </h4>
                        <div className="text-3xl font-black text-green-400 mb-2">
                          {result.analysis.original.entropy.toFixed(4)}
                        </div>
                        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full"
                            style={{ 
                              width: `${(result.analysis.original.entropy / 8) * 100}%`,
                              background: 'linear-gradient(90deg, #4cffa8, #32e67c)'
                            }}
                          />
                        </div>
                      </div>

                      <div className="rounded-2xl border p-6"
                        style={{
                          borderColor: 'rgba(168, 76, 255, 0.4)',
                          background: 'rgba(10, 12, 18, 0.95)'
                        }}
                      >
                        <h4 className="text-xs font-bold uppercase tracking-wider mb-3 text-purple-400">
                          Inverted Entropy
                        </h4>
                        <div className="text-3xl font-black text-purple-400 mb-2">
                          {result.analysis.inverted.entropy.toFixed(4)}
                        </div>
                        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full"
                            style={{ 
                              width: `${(result.analysis.inverted.entropy / 8) * 100}%`,
                              background: 'linear-gradient(90deg, #a84cff, #7c32e6)'
                            }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Similarity Metrics */}
                    <div className="hex-card rounded-2xl border p-6"
                      style={{
                        borderColor: getModeBorder(),
                        background: 'rgba(10, 12, 18, 0.95)',
                        animationDelay: '0.2s'
                      }}
                    >
                      <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: getModeColor() }}>
                        <TrendingUp className="w-4 h-4 inline mr-2" />
                        Bit-Level Relation
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 rounded-xl text-center"
                          style={{
                            background: 'rgba(76, 255, 168, 0.1)',
                            border: '1px solid rgba(76, 255, 168, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-2">Similarity</div>
                          <div className="text-2xl font-bold text-green-400">
                            {(result.analysis.relation.similarity * 100).toFixed(1)}%
                          </div>
                        </div>
                        <div className="p-4 rounded-xl text-center"
                          style={{
                            background: 'rgba(168, 76, 255, 0.1)',
                            border: '1px solid rgba(168, 76, 255, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-2">Difference</div>
                          <div className="text-2xl font-bold text-purple-400">
                            {(result.analysis.relation.differenceRatio * 100).toFixed(1)}%
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* AI Narrative */}
                {result.narrative?.summary && (
                  <div className="hex-card rounded-2xl border p-6"
                    style={{
                      borderColor: getModeBorder(),
                      background: 'rgba(10, 12, 18, 0.95)',
                      animationDelay: '0.3s'
                    }}
                  >
                    <h3 className="text-sm font-bold uppercase tracking-wider mb-4" style={{ color: getModeColor() }}>
                      <Zap className="w-4 h-4 inline mr-2" />
                      AI Narrative
                    </h3>
                    
                    <div className="space-y-4">
                      <div>
                        <div className="text-xs font-bold text-gray-400 mb-2">SUMMARY</div>
                        <div className="text-sm text-gray-300 leading-relaxed">
                          {result.narrative.summary}
                        </div>
                      </div>

                      {result.narrative.riskHint && (
                        <div>
                          <div className="text-xs font-bold text-gray-400 mb-2">DATA TYPE</div>
                          <div className="text-sm text-gray-300">
                            {result.narrative.riskHint}
                          </div>
                        </div>
                      )}

                      {result.narrative.interestingPatterns?.length > 0 && (
                        <div>
                          <div className="text-xs font-bold text-gray-400 mb-2">INTERESTING PATTERNS</div>
                          <ul className="space-y-1">
                            {result.narrative.interestingPatterns.map((pattern, idx) => (
                              <li key={idx} className="text-sm text-gray-300 flex items-start gap-2">
                                <span style={{ color: getModeColor() }}>•</span>
                                <span>{pattern}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {result.narrative.recommendation && (
                        <div>
                          <div className="text-xs font-bold text-gray-400 mb-2">RECOMMENDATION</div>
                          <div className="text-sm text-gray-300">
                            {result.narrative.recommendation}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Hex Mind Engine :: Byte-Level Pattern Analysis + Bit Inversion Space Exploration</p>
          <p className="mt-1">Backend: http://localhost:9944/api/{mode}/analyze</p>
        </div>
      </div>
    </div>
  );
}