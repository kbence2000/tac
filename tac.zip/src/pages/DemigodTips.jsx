import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DollarSign, Sparkles, Users, Award,
  Zap, TrendingUp, MessageSquare, Clock
} from "lucide-react";
import TipRequestPanel from "../components/TipRequestPanel";
import DemigodTipQueue from "../components/DemigodTipQueue";
import TipHistory from "../components/TipHistory";
import TipEarningsPanel from "../components/TipEarningsPanel";
import RankBadge from "../components/RankBadge";

const TIP_API = import.meta.env.VITE_TIP_BACKEND_URL || "http://localhost:3004";
const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function DemigodTips() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Fetch available demigods
  const { data: demigods = [], isLoading: loadingDemigods } = useQuery({
    queryKey: ['availableDemigods'],
    queryFn: async () => {
      const res = await fetch(`${TIP_API}/api/demigods/list`);
      if (!res.ok) return [];
      return res.json();
    },
    refetchInterval: 30000,
  });

  // Check if current user is demigod
  const { data: profile } = useQuery({
    queryKey: ['userDemigodProfile', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      try {
        const res = await fetch(`${BACKEND_URL}/api/profile/${user.email}`);
        if (!res.ok) return null;
        return res.json();
      } catch {
        return null;
      }
    },
    enabled: !!user?.email,
  });

  const isDemigod = profile?.mdcTier?.id === "R6" || profile?.mdcTier?.id === "R7";
  const availableDemigods = demigods.filter(d => d.isAvailable);

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <DollarSign className="w-4 h-4 text-green-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Paid Expert Advice</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #10B981, #059669)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            Demigod Tips
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Get instant expert advice from R6/R7 elite developers. Pay per tip, answers within 1 hour.
          </p>
        </div>

        {/* Stats Banner */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Users className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{availableDemigods.length}</div>
            <div className="text-xs text-gray-400">Demigods Online</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Zap className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">&lt;1h</div>
            <div className="text-xs text-gray-400">Avg Response Time</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <DollarSign className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">€1-5</div>
            <div className="text-xs text-gray-400">Price Range</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Award className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">80%</div>
            <div className="text-xs text-gray-400">Demigod Share</div>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue={isDemigod ? "queue" : "request"} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="request" className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Request Tip
            </TabsTrigger>
            {isDemigod && (
              <TabsTrigger value="queue" className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                My Queue
              </TabsTrigger>
            )}
            <TabsTrigger value="history" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              History
            </TabsTrigger>
          </TabsList>

          {/* Request Tip Tab */}
          <TabsContent value="request">
            <div className="grid lg:grid-cols-[1fr_320px] gap-8">
              <TipRequestPanel 
                userId={user?.email || 'demo_user'}
                userName={user?.full_name || user?.email?.split('@')[0] || 'Demo User'}
              />

              <div className="space-y-6">
                {/* Available Demigods */}
                <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                  <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <Users className="w-5 h-5 text-green-400" />
                    Online Demigods
                  </h3>
                  {loadingDemigods ? (
                    <div className="text-center py-4">
                      <div className="w-6 h-6 border-2 border-green-500 border-t-transparent rounded-full animate-spin mx-auto" />
                    </div>
                  ) : availableDemigods.length === 0 ? (
                    <div className="text-center py-4 text-gray-500 text-sm">
                      No demigods online
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {availableDemigods.slice(0, 5).map((d) => (
                        <div key={d.id} className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e] flex items-center justify-between">
                          <div>
                            <div className="text-sm font-semibold text-white">{d.username}</div>
                            <div className="text-xs text-gray-400">Score: {d.score}</div>
                          </div>
                          <RankBadge rank={d.tier.id} size="xs" />
                        </div>
                      ))}
                    </div>
                  )}
                </Card>

                {/* How It Works */}
                <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                  <h3 className="text-lg font-bold text-white mb-4">How It Works</h3>
                  <div className="space-y-3 text-sm text-gray-400">
                    <div className="flex gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-600/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-green-400">1</span>
                      </div>
                      <div>
                        <div className="font-semibold text-white">Submit Code</div>
                        <div className="text-xs">Paste snippet + question</div>
                      </div>
                    </div>
                    
                    <div className="flex gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-600/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-green-400">2</span>
                      </div>
                      <div>
                        <div className="font-semibold text-white">Choose Price</div>
                        <div className="text-xs">€1 (micro) to €5 (deep)</div>
                      </div>
                    </div>
                    
                    <div className="flex gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-600/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-green-400">3</span>
                      </div>
                      <div>
                        <div className="font-semibold text-white">Get Answer</div>
                        <div className="text-xs">Demigod responds &lt;1h</div>
                      </div>
                    </div>
                    
                    <div className="flex gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-600/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-green-400">4</span>
                      </div>
                      <div>
                        <div className="font-semibold text-white">Apply Fix</div>
                        <div className="text-xs">Implement expert advice</div>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Queue Tab (Demigods only) */}
          {isDemigod && (
            <TabsContent value="queue">
              <div className="grid lg:grid-cols-[1fr_320px] gap-8">
                <DemigodTipQueue demigodId={user?.email} />
                <TipEarningsPanel demigodId={user?.email} />
              </div>
            </TabsContent>
          )}

          {/* History Tab */}
          <TabsContent value="history">
            <TipHistory userId={user?.email} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}