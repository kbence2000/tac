import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  MessageSquare, Zap, Users, Target, Code2, 
  CheckCircle2, ArrowRight, Copy, ExternalLink,
  Sparkles, Shield, Rocket, Terminal
} from "lucide-react";
import { toast } from "sonner";

export default function SlackIntegration() {
  const [copied, setCopied] = useState(false);

  const BASE_URL = window.location.origin;
  const installUrl = `${BASE_URL}/slack/install`;

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success("Copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const features = [
    {
      icon: Target,
      title: "AI Recruiter",
      description: "Find demigod talent instantly with /mdc match",
      command: "/mdc match senior node dev",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      icon: Code2,
      title: "Snippet Analyzer",
      description: "Evaluate code quality in seconds",
      command: "/mdc snippet <paste code>",
      gradient: "from-cyan-500 to-blue-500"
    },
    {
      icon: Sparkles,
      title: "Project Valuation",
      description: "Get instant project complexity estimates",
      command: "/mdc value <project description>",
      gradient: "from-yellow-500 to-orange-500"
    },
    {
      icon: Users,
      title: "Talent Pool Access",
      description: "Browse verified demigod developer profiles",
      command: "/mdc profiles",
      gradient: "from-green-500 to-emerald-500"
    }
  ];

  const steps = [
    {
      number: "01",
      title: "Install to Slack",
      description: "Click the install button and authorize MDC in your workspace",
      icon: MessageSquare
    },
    {
      number: "02",
      title: "Run Commands",
      description: "Use /mdc in any channel to access AI-powered recruitment tools",
      icon: Terminal
    },
    {
      number: "03",
      title: "Find Talent",
      description: "Get instant matches from our verified demigod talent pool",
      icon: Zap
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-30" />
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 py-20">
          <div className="text-center mb-16">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6" style={{
              background: 'rgba(183, 136, 255, 0.1)',
              border: '1px solid rgba(183, 136, 255, 0.3)'
            }}>
              <MessageSquare className="w-4 h-4 text-purple-400" />
              <span className="text-sm font-mono uppercase tracking-wider text-purple-300">
                Slack Integration
              </span>
            </div>

            {/* Title */}
            <h1 className="text-5xl lg:text-6xl font-black mb-6">
              <span className="gradient-text">MDC × Slack</span>
              <br />
              AI Recruiting, Instant
            </h1>

            {/* Subtitle */}
            <p className="text-xl text-gray-400 mb-12 max-w-3xl mx-auto leading-relaxed">
              Connect MadDevCity's AI-powered talent platform directly to your Slack workspace.
              Find demigod developers, analyze code, and value projects—all without leaving Slack.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4 justify-center">
              <Button 
                className="btn-primary group"
                onClick={() => window.open(installUrl, '_blank')}
              >
                <MessageSquare className="w-5 h-5 mr-2" />
                Add to Slack
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button 
                variant="outline"
                className="btn-secondary"
                onClick={() => copyToClipboard(installUrl)}
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 mr-2 text-green-400" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5 mr-2" />
                    Copy Install Link
                  </>
                )}
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="flex flex-wrap gap-4 justify-center mt-12">
              <div className="badge-premium">
                <Shield className="w-4 h-4 text-cyan-400" />
                <span className="text-cyan-300">Secure OAuth</span>
              </div>
              <div className="badge-premium">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span className="text-yellow-300">Instant Results</span>
              </div>
              <div className="badge-premium">
                <Users className="w-4 h-4 text-purple-400" />
                <span className="text-purple-300">1200+ Talents</span>
              </div>
            </div>
          </div>

          {/* Demo Video/Screenshot Placeholder */}
          <div className="max-w-5xl mx-auto">
            <div className="premium-card p-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-cyan-500/10" />
              
              <div className="relative">
                {/* Mock Slack Interface */}
                <div className="bg-[#0b0816] rounded-xl border border-purple-500/30 overflow-hidden">
                  {/* Slack Header */}
                  <div className="bg-[#0f0a1f] border-b border-purple-500/20 px-4 py-3 flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                      #
                    </div>
                    <span className="font-semibold text-white">recruitment</span>
                  </div>
                  
                  {/* Slack Messages */}
                  <div className="p-4 space-y-4">
                    {/* User Command */}
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center text-white text-sm font-bold">
                        JD
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-white mb-1">Jane Doe</div>
                        <div className="text-sm text-gray-400 font-mono">
                          /mdc match senior fullstack developer with AI experience
                        </div>
                      </div>
                    </div>

                    {/* MDC Bot Response */}
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded bg-gradient-to-br from-purple-500 via-pink-500 to-cyan-500 flex items-center justify-center text-white font-bold">
                        M
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-semibold text-purple-400 mb-2">MDC Bot</div>
                        <div className="bg-[#130d24] rounded-lg p-4 border border-purple-500/30">
                          <div className="font-semibold text-white mb-3">🤖 AI Recruiter – Top Matches</div>
                          <div className="space-y-3">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-white font-bold">1. Nova</span>
                                <Badge className="bg-purple-600/20 text-purple-300 border-purple-600/30 text-xs">
                                  Demigod
                                </Badge>
                                <span className="text-cyan-400 text-sm ml-auto">Score: 96</span>
                              </div>
                              <div className="text-sm text-gray-400">
                                Senior Node + TS + scalable backend · built 3 SaaS from scratch
                              </div>
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-white font-bold">2. Lyra</span>
                                <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-600/30 text-xs">
                                  Elite
                                </Badge>
                                <span className="text-cyan-400 text-sm ml-auto">Score: 91</span>
                              </div>
                              <div className="text-sm text-gray-400">
                                Fullstack React/Next + Node dev · strong in DX & frontend polish
                              </div>
                            </div>
                          </div>
                          <div className="mt-4 pt-3 border-t border-purple-500/20">
                            <button className="text-purple-400 text-sm font-semibold hover:text-purple-300">
                              View full profiles →
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black mb-4">
              Powerful <span className="gradient-text">Slack Commands</span>
            </h2>
            <p className="text-gray-400 text-lg">
              Access MDC's full AI suite directly from your Slack workspace
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div key={idx} className="premium-card hover-lift">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  
                  <h3 className="text-xl font-bold mb-2 text-white">{feature.title}</h3>
                  <p className="text-gray-400 mb-4">{feature.description}</p>
                  
                  <div className="bg-[#0b0816] rounded-lg p-3 border border-purple-500/20">
                    <code className="text-purple-300 text-sm font-mono">{feature.command}</code>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black mb-4">
              Get Started in <span className="gradient-text">3 Steps</span>
            </h2>
            <p className="text-gray-400 text-lg">
              Connect your Slack workspace in minutes
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              return (
                <div key={idx} className="glass-card p-8 text-center hover-lift">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 mb-6">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="text-4xl font-black gradient-text mb-4">{step.number}</div>
                  <h3 className="text-xl font-bold mb-3 text-white">{step.title}</h3>
                  <p className="text-gray-400">{step.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Installation Code Block */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4">
          <Card className="border-purple-500/30 bg-[#0b0816] p-8">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">Installation URL</h3>
                <p className="text-gray-400 text-sm">
                  Share this link with your workspace admin to install MDC
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(installUrl)}
                className="border-purple-500/30 hover:border-purple-500/50"
              >
                {copied ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2 text-green-400" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </>
                )}
              </Button>
            </div>

            <div className="bg-[#02000c] rounded-lg p-4 border border-purple-500/20 font-mono text-sm text-purple-300 break-all">
              {installUrl}
            </div>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="premium-card p-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-cyan-500/10" />
            
            <div className="relative">
              <Rocket className="w-16 h-16 mx-auto mb-6 text-purple-400" />
              
              <h2 className="text-4xl font-black mb-4">
                Ready to <span className="gradient-text">Supercharge</span> Recruiting?
              </h2>
              
              <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
                Join forward-thinking companies using MDC's AI to find demigod-tier talent instantly
              </p>
              
              <div className="flex flex-wrap gap-4 justify-center">
                <Button 
                  className="btn-primary"
                  onClick={() => window.open(installUrl, '_blank')}
                >
                  <MessageSquare className="w-5 h-5 mr-2" />
                  Install to Slack
                </Button>
                
                <Button 
                  className="btn-secondary"
                  onClick={() => window.open('https://docs.maddevcity.com/slack', '_blank')}
                >
                  <ExternalLink className="w-5 h-5 mr-2" />
                  View Documentation
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}