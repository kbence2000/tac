import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Crown, Trophy, Calendar, Star, Swords, Brain } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DemigodRankTracker from "../components/DemigodRankTracker";
import DemigodMentoringBooker from "../components/DemigodMentoringBooker";
import DemigodSpotlightFeed from "../components/DemigodSpotlightFeed";
import DemigodPvPArena from "../components/DemigodPvPArena";
import DemigodInsightsPanel from "../components/DemigodInsightsPanel";

export default function DemigodHub() {
  const [selectedBattle, setSelectedBattle] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-yellow-500 to-orange-500">
              <Crown className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white">Demigod Hub</h1>
              <p className="text-gray-400">Your path to digital godhood</p>
            </div>
          </div>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="rank" className="space-y-6">
          <TabsList className="bg-[#0f1419] border border-[#1a1f2e]">
            <TabsTrigger value="rank" className="data-[state=active]:bg-yellow-600/20">
              <Trophy className="w-4 h-4 mr-2" />
              Rank
            </TabsTrigger>
            <TabsTrigger value="spotlight" className="data-[state=active]:bg-purple-600/20">
              <Star className="w-4 h-4 mr-2" />
              Spotlight
            </TabsTrigger>
            <TabsTrigger value="pvp" className="data-[state=active]:bg-orange-600/20">
              <Swords className="w-4 h-4 mr-2" />
              PvP Arena
            </TabsTrigger>
            <TabsTrigger value="mentoring" className="data-[state=active]:bg-cyan-600/20">
              <Calendar className="w-4 h-4 mr-2" />
              Mentoring
            </TabsTrigger>
            <TabsTrigger value="insights" className="data-[state=active]:bg-blue-600/20">
              <Brain className="w-4 h-4 mr-2" />
              Insights
            </TabsTrigger>
          </TabsList>

          <TabsContent value="rank">
            {user && <DemigodRankTracker userId={user.email} />}
          </TabsContent>

          <TabsContent value="spotlight">
            <DemigodSpotlightFeed limit={20} />
          </TabsContent>

          <TabsContent value="pvp">
            {selectedBattle ? (
              <DemigodPvPArena
                battleId={selectedBattle.id}
                userId={user?.email}
                battleData={selectedBattle}
              />
            ) : (
              <div className="text-center py-12">
                <Swords className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Active Battle</h3>
                <p className="text-gray-400 mb-4">
                  Join a battle or create your own challenge
                </p>
                <button
                  onClick={() => setSelectedBattle({
                    id: "demo-battle-001",
                    title: "React Performance Challenge",
                    type: "coding",
                    participants: 2,
                    prize: 500,
                    timeLeft: "2h 30m",
                    challenge: "Optimize this React component to reduce render count by at least 50%",
                    testCases: {
                      input: "Component with 1000 items",
                      expected: "< 5 renders on scroll"
                    }
                  })}
                  className="px-6 py-3 rounded-full text-white font-semibold"
                  style={{
                    background: 'linear-gradient(135deg, #f97316, #dc2626)'
                  }}
                >
                  Join Demo Battle
                </button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="mentoring">
            <div className="grid lg:grid-cols-2 gap-6">
              <DemigodMentoringBooker
                mentorId="mentor-demo"
                mentorName="Senior Demigod"
              />
              
              {/* Upcoming Sessions */}
              <div className="text-center py-12 border rounded-xl" style={{
                background: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(148, 163, 184, 0.35)'
              }}>
                <Calendar className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <h4 className="text-lg font-bold text-white mb-2">
                  No Upcoming Sessions
                </h4>
                <p className="text-gray-400 text-sm">
                  Book your first mentoring session
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="insights">
            {user && <DemigodInsightsPanel userId={user.email} />}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}