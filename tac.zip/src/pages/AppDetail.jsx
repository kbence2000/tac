
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Star,
  Download,
  CheckCircle2,
  Award,
  ShoppingCart,
  Play,
  ChevronLeft,
  ChevronRight,
  Code2,
  Package,
  MessageSquare,
  Sparkles,
  Zap
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import ShopifyBuyButton from "../components/ShopifyBuyButton";
import EnhancedRevolutButton from "../components/EnhancedRevolutButton";
import ProtectedDownloadButton from "../components/ProtectedDownloadButton";
import CommissionCalculator from "../components/CommissionCalculator";

const categoryNames = {
  productivity: "Produktivitás",
  development: "Fejlesztés",
  design: "Dizájn",
  business: "Üzleti",
  games: "Játékok",
  education: "Oktatás",
  utilities: "Segédprogramok",
  other: "Egyéb"
};

const licenseNames = {
  BASIC: "Alap Licenc",
  EXTENDED: "Kibővített Licenc",
  EXCLUSIVE: "Exkluzív Licenc"
};

const licenseDescriptions = {
  BASIC: "Személyes használatra, egy projekthez",
  EXTENDED: "Kereskedelmi használatra, több projekthez",
  EXCLUSIVE: "Teljes jogok, forráskóddal együtt"
};

export default function AppDetail() {
  const location = useLocation();
  const queryClient = useQueryClient();
  const searchParams = new URLSearchParams(location.search);
  const appId = searchParams.get("id");

  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [selectedLicense, setSelectedLicense] = useState("BASIC");
  const [currentScreenshot, setCurrentScreenshot] = useState(0);
  const [activeTab, setActiveTab] = useState("description");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: app, isLoading } = useQuery({
    queryKey: ['app', appId],
    queryFn: async () => {
      const apps = await base44.entities.App.list();
      return apps.find(a => a.id === appId);
    },
    enabled: !!appId,
  });

  const { data: reviews } = useQuery({
    queryKey: ['reviews', appId],
    queryFn: async () => {
      const allReviews = await base44.entities.Review.list('-created_date');
      return allReviews.filter(r => r.app_id === appId);
    },
    enabled: !!appId,
    initialData: []
  });

  const { data: versions } = useQuery({
    queryKey: ['versions', appId],
    queryFn: async () => {
      const allVersions = await base44.entities.Version.list('-created_date');
      return allVersions.filter(v => v.app_id === appId);
    },
    enabled: !!appId,
    initialData: []
  });

  const { data: hasPurchased } = useQuery({
    queryKey: ['purchase', appId, user?.email],
    queryFn: async () => {
      if (!user?.email) return false;
      const purchases = await base44.entities.Purchase.list();
      return purchases.some(p => p.app_id === appId && p.user_email === user.email);
    },
    enabled: !!appId && !!user,
    initialData: false
  });

  const { data: sellerStats } = useQuery({
    queryKey: ['sellerStats', app?.created_by],
    queryFn: async () => {
      if (!app?.created_by) return { totalApps: 0, totalDownloads: 0, avgRating: '0.0' };
      const allApps = await base44.entities.App.list();
      const sellerApps = allApps.filter(a => a.created_by === app.created_by);
      const totalDownloads = sellerApps.reduce((sum, a) => sum + (a.downloads || 0), 0);
      const totalRating = sellerApps.reduce((sum, a) => sum + (a.rating || 0), 0);
      const avgRating = sellerApps.length > 0 ? (totalRating / sellerApps.length).toFixed(1) : '0.0';
      return {
        totalApps: sellerApps.length,
        totalDownloads,
        avgRating
      };
    },
    enabled: !!app?.created_by,
    initialData: { totalApps: 0, totalDownloads: 0, avgRating: '0.0' }
  });

  const submitReviewMutation = useMutation({
    mutationFn: async (reviewData) => {
      await base44.entities.Review.create(reviewData);
      const allReviewsForApp = await base44.entities.Review.filter({ app_id: appId });
      const totalRating = allReviewsForApp.reduce((sum, r) => sum + r.rating, 0);
      const avgRating = allReviewsForApp.length > 0 ? totalRating / allReviewsForApp.length : 0;
      await base44.entities.App.update(appId, {
        rating: avgRating,
        rating_count: allReviewsForApp.length
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reviews', appId] });
      queryClient.invalidateQueries({ queryKey: ['app', appId] });
      toast.success("Értékelés sikeresen elküldve!");
      setComment("");
      setRating(5);
    }
  });

  const downloadMutation = useMutation({
    mutationFn: async () => {
      const purchases = await base44.entities.Purchase.filter({
        app_id: appId,
        user_email: user.email
      });
      const existingPurchase = purchases[0];
      if (existingPurchase) {
        return await base44.entities.Purchase.update(existingPurchase.id, {
          download_count: (existingPurchase.download_count || 0) + 1
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchase', appId, user?.email] });
      toast.success("Letöltés megkezdve!");
      if (app.download_url) {
        window.open(app.download_url, '_blank');
      }
    }
  });

  const purchaseMutation = useMutation({
    mutationFn: async (purchaseData) => {
      const newPurchase = await base44.entities.Purchase.create(purchaseData);
      await base44.entities.App.update(appId, {
        downloads: (app.downloads || 0) + 1
      });
      const platformFeeRate = 0.08 + (Math.min(app.downloads || 0, 200) / 200) * 0.07;
      const platformFee = purchaseData.amount_paid * platformFeeRate;
      const sellerNet = purchaseData.amount_paid - platformFee;
      await base44.entities.Transaction.create({
        app_id: appId,
        buyer_email: user.email,
        seller_email: app.created_by,
        license_type: selectedLicense,
        amount_paid: purchaseData.amount_paid,
        platform_fee: platformFee,
        seller_net: sellerNet,
        commission_rate: platformFeeRate,
        currency: app.currency || 'HUF',
        status: 'completed'
      });
      return newPurchase;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchase', appId, user?.email] });
      queryClient.invalidateQueries({ queryKey: ['app', appId] });
      queryClient.invalidateQueries({ queryKey: ['sellerStats', app?.created_by] });
      toast.success("Sikeres vásárlás!");
    }
  });

  const handleReviewSubmit = () => {
    if (!user) {
      toast.error("Jelentkezz be az értékeléshez!");
      return;
    }
    submitReviewMutation.mutate({
      app_id: appId,
      user_email: user.email,
      rating,
      comment,
      verified_purchase: hasPurchased
    });
  };

  const handlePurchase = () => {
    if (!user) {
      toast.error("Jelentkezz be a vásárláshoz!");
      return;
    }
    if (hasPurchased) {
      toast.info("Már megvásároltad ezt a programot!");
      return;
    }
    const licensePrice = selectedLicense === "BASIC" ? app.price :
                        selectedLicense === "EXTENDED" ? Math.round(app.price * 1.5) :
                        Math.round(app.price * 3);
    purchaseMutation.mutate({
      app_id: appId,
      user_email: user.email,
      license_type: selectedLicense,
      amount_paid: licensePrice,
      currency: app.currency || 'HUF',
      download_count: 0
    });
  };

  const handleDownload = () => {
    if (!hasPurchased && app.price > 0) {
      toast.error("Először vásárold meg a programot!");
      return;
    }
    downloadMutation.mutate();
  };

  useEffect(() => {
    if (app?.screenshots && app.screenshots.length > 0) {
      setCurrentScreenshot(0);
    }
  }, [app]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-t-transparent" style={{ borderColor: 'var(--accent)' }}></div>
      </div>
    );
  }

  if (!app) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Program nem található</h2>
          <Link to={createPageUrl("Marketplace")}>
            <Button>Vissza a piactérre</Button>
          </Link>
        </div>
      </div>
    );
  }

  const currentAppRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : '0.0';

  const licensePrices = {
    BASIC: app.price,
    EXTENDED: Math.round(app.price * 1.5),
    EXCLUSIVE: Math.round(app.price * 3)
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to={createPageUrl("Marketplace")}>
          <Button variant="ghost" className="mb-6 text-gray-400 hover:text-white">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Vissza a piactérre
          </Button>
        </Link>

        <div className="grid lg:grid-cols-[1fr_400px] gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            {/* Header Card */}
            <Card className="border p-6" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(148, 163, 184, 0.35)'
            }}>
              <div className="flex items-start gap-6">
                <div className="w-24 h-24 rounded-2xl flex items-center justify-center flex-shrink-0" style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.2), rgba(36, 228, 255, 0.2))',
                  border: '1px solid rgba(148, 163, 184, 0.3)'
                }}>
                  {app.icon_url ? (
                    <img src={app.icon_url} alt={app.name} className="w-full h-full object-contain rounded-xl" />
                  ) : (
                    <div className="text-4xl font-black text-black">
                      {app.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>

                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <h1 className="text-3xl font-black text-white">{app.name}</h1>
                        {app.verified && (
                          <CheckCircle2 className="w-6 h-6 text-blue-400" />
                        )}
                        {app.featured && (
                          <Award className="w-6 h-6 text-yellow-400" />
                        )}
                      </div>
                      <p className="text-gray-400">by {app.developer}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-black text-white">
                        {app.price === 0 ? 'INGYENES' : `${app.price} ${app.currency || 'Ft'}`}
                      </div>
                      <p className="text-sm text-gray-400">v{app.version}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-3 mb-4">
                    <div className="flex items-center gap-2">
                      <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                      <span className="text-white font-semibold">{currentAppRating}</span>
                      <span className="text-gray-400">({reviews.length} értékelés)</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-400">
                      <Download className="w-5 h-5" />
                      <span>{app.downloads || 0} letöltés</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Badge className="bg-purple-600/20 text-purple-300 border border-purple-600/30">
                      {categoryNames[app.category]}
                    </Badge>
                    <Badge className="bg-cyan-600/20 text-cyan-300 border border-cyan-600/30">
                      {licenseNames[app.license_type || 'BASIC']}
                    </Badge>
                    {app.tech_stack && app.tech_stack.slice(0, 3).map((tech, idx) => (
                      <Badge key={idx} className="bg-gray-600/20 text-gray-300 border border-gray-600/30">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            {/* Screenshots */}
            {app.screenshots && app.screenshots.length > 0 && (
              <Card className="border p-4" style={{
                background: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(148, 163, 184, 0.35)'
              }}>
                <div className="relative">
                  <img
                    src={app.screenshots[currentScreenshot]}
                    alt={`Screenshot ${currentScreenshot + 1}`}
                    className="w-full rounded-lg aspect-video object-contain"
                  />
                  {app.screenshots.length > 1 && (
                    <>
                      <button
                        onClick={() => setCurrentScreenshot((currentScreenshot - 1 + app.screenshots.length) % app.screenshots.length)}
                        className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 hover:bg-black/70 text-white"
                      >
                        <ChevronLeft className="w-6 h-6" />
                      </button>
                      <button
                        onClick={() => setCurrentScreenshot((currentScreenshot + 1) % app.screenshots.length)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 hover:bg-black/70 text-white"
                      >
                        <ChevronRight className="w-6 h-6" />
                      </button>
                    </>
                  )}
                </div>
                {app.screenshots.length > 1 && (
                  <div className="flex gap-2 mt-4 overflow-x-auto">
                    {app.screenshots.map((screenshot, idx) => (
                      <img
                        key={idx}
                        src={screenshot}
                        alt={`Thumbnail ${idx + 1}`}
                        className={`w-20 h-20 rounded-lg object-cover cursor-pointer border-2 transition-all ${
                          idx === currentScreenshot ? 'border-purple-500' : 'border-transparent hover:border-gray-600'
                        }`}
                        onClick={() => setCurrentScreenshot(idx)}
                      />
                    ))}
                  </div>
                )}
              </Card>
            )}

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="bg-[#0f1419] border border-[#1a1f2e] w-full grid grid-cols-5">
                <TabsTrigger value="description">Leírás</TabsTrigger>
                <TabsTrigger value="tech">Technológia</TabsTrigger>
                <TabsTrigger value="ai">AI Elemzés</TabsTrigger>
                {versions.length > 0 && (
                  <TabsTrigger value="versions">Verziók</TabsTrigger>
                )}
                <TabsTrigger value="reviews">Értékelések</TabsTrigger>
              </TabsList>

              <TabsContent value="description" className="mt-6">
                <Card className="border p-6" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  <h3 className="text-xl font-bold text-white mb-4">Leírás</h3>
                  <p className="text-gray-300 leading-relaxed whitespace-pre-line">
                    {app.description}
                  </p>
                  {app.changelog && (
                    <div className="mt-6 p-4 bg-[#141923] rounded-lg border border-[#1a1f2e]">
                      <h4 className="font-bold text-white mb-2 flex items-center gap-2">
                        <Package className="w-4 h-4" />
                        Változásnapló
                      </h4>
                      <p className="text-gray-300 text-sm whitespace-pre-line">{app.changelog}</p>
                    </div>
                  )}
                </Card>
              </TabsContent>

              <TabsContent value="tech" className="mt-6">
                <Card className="border p-6" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  <h3 className="text-xl font-bold text-white mb-4">Technológiai Stack</h3>
                  {app.tech_stack && app.tech_stack.length > 0 ? (
                    <div className="flex flex-wrap gap-3">
                      {app.tech_stack.map((tech, idx) => (
                        <Badge key={idx} className="text-base px-4 py-2 bg-cyan-600/20 text-cyan-300 border border-cyan-600/30">
                          <Code2 className="w-4 h-4 mr-2" />
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-400">Nincs megadva technológiai stack</p>
                  )}
                   {app.tags && app.tags.length > 0 && (
                      <div className="mt-6">
                        <h4 className="font-bold text-white mb-3">Címkék</h4>
                        <div className="flex flex-wrap gap-2">
                          {app.tags.map((tag, idx) => (
                            <Badge key={idx} variant="outline" className="border-[#1a1f2e] text-gray-400">
                              #{tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                </Card>
              </TabsContent>

              <TabsContent value="ai" className="mt-6">
                <div className="space-y-4">
                  {/* AI Quality Score */}
                  {app.ai_quality_score || app.ai_analysis ? (
                    <Card className="border p-6" style={{
                      background: 'linear-gradient(135deg, rgba(139, 92, 255, 0.05), rgba(36, 228, 255, 0.05))',
                      borderColor: 'rgba(139, 92, 255, 0.3)'
                    }}>
                      <div className="flex items-center gap-3 mb-4">
                        <Sparkles className="w-6 h-6 text-purple-400" />
                        <h3 className="text-xl font-bold text-white">AI Quality Assessment</h3>
                      </div>

                      {(app.ai_quality_score || app.ai_complexity || app.ai_estimated_price) && (
                        <div className="grid grid-cols-3 gap-4 mb-6">
                          {app.ai_quality_score && (
                            <div className="text-center p-4 rounded-xl border" style={{
                              background: 'rgba(15, 23, 42, 0.9)',
                              borderColor: 'rgba(148, 163, 184, 0.25)'
                            }}>
                              <div className="text-3xl font-bold mb-1 gradient-text">
                                {app.ai_quality_score}/5
                              </div>
                              <div className="text-sm text-gray-400">Quality Score</div>
                            </div>
                          )}

                          {app.ai_complexity && (
                            <div className="text-center p-4 rounded-xl border" style={{
                              background: 'rgba(15, 23, 42, 0.9)',
                              borderColor: 'rgba(148, 163, 184, 0.25)'
                            }}>
                              <Badge className={`text-base px-3 py-1 ${
                                app.ai_complexity === 'low' ? 'bg-green-600/20 text-green-300 border-green-600/30' :
                                app.ai_complexity === 'medium' ? 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30' :
                                'bg-red-600/20 text-red-300 border-red-600/30'
                              }`}>
                                {app.ai_complexity.toUpperCase()}
                              </Badge>
                              <div className="text-sm text-gray-400 mt-1">Complexity</div>
                            </div>
                          )}

                          {app.ai_estimated_price && (
                            <div className="text-center p-4 rounded-xl border" style={{
                              background: 'rgba(15, 23, 42, 0.9)',
                              borderColor: 'rgba(148, 163, 184, 0.25)'
                            }}>
                              <div className="text-2xl font-bold text-green-400 mb-1">
                                ${app.ai_estimated_price}
                              </div>
                              <div className="text-sm text-gray-400">AI Estimate</div>
                            </div>
                          )}
                        </div>
                      )}

                      {app.ai_analysis && (
                        <div className="p-4 rounded-xl border" style={{
                          background: 'rgba(5, 8, 22, 0.9)',
                          borderColor: 'rgba(148, 163, 184, 0.2)'
                        }}>
                          <div className="text-sm text-gray-400 mb-2">Detailed Analysis:</div>
                          <p className="text-gray-300 leading-relaxed whitespace-pre-line">
                            {app.ai_analysis}
                          </p>
                        </div>
                      )}
                    </Card>
                  ) : (
                    /* No AI data message */
                    <Card className="border p-6" style={{
                      background: 'rgba(15, 23, 42, 0.95)',
                      borderColor: 'rgba(148, 163, 184, 0.35)'
                    }}>
                      <div className="text-center py-8">
                        <Zap className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                        <h3 className="text-lg font-bold text-white mb-2">
                          Még nincs AI elemzés
                        </h3>
                        <p className="text-gray-400">
                          Ez a program még nem lett AI elemzéssel értékelve.
                        </p>
                      </div>
                    </Card>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="versions" className="mt-6">
                <Card className="border p-6" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  <h3 className="text-xl font-bold text-white mb-4">Verzió Történet</h3>
                  {versions.length > 0 ? (
                    <div className="space-y-4">
                      {versions.map(version => (
                        <div key={version.id} className="border-l-2 border-purple-500 pl-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Package className="w-4 h-4 text-purple-400" />
                            <span className="font-bold text-white">v{version.version_number}</span>
                            {version.is_stable && (
                              <Badge className="bg-green-600/20 text-green-300 border border-green-600/30">
                                Stable
                              </Badge>
                            )}
                          </div>
                          <p className="text-gray-300 mb-2">{version.changelog || version.release_notes}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(version.created_date).toLocaleDateString('hu-HU')}
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-400">Nincs verzió történet</p>
                  )}
                </Card>
              </TabsContent>

              <TabsContent value="reviews" className="mt-6">
                  <div className="space-y-4">
                  {user && (
                    <Card className="border p-6 bg-[#141923] rounded-lg border border-[#1a1f2e]">
                      <h4 className="text-lg font-bold text-white mb-4">Írj értékelést</h4>

                      <div className="flex items-center gap-2 mb-4">
                        {[1, 2, 3, 4, 5].map(i => (
                          <button
                            key={i}
                            onClick={() => setRating(i)}
                            className="transition-transform hover:scale-110"
                          >
                            <Star
                              className={`w-8 h-8 ${
                                i <= rating
                                  ? 'text-yellow-500 fill-yellow-500'
                                  : 'text-gray-600'
                              }`}
                            />
                          </button>
                        ))}
                      </div>

                      <Textarea
                        placeholder="Oszd meg véleményedet..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        className="bg-[#0f1419] border-[#1a1f2e] text-white mb-4"
                        rows={4}
                      />

                      <Button
                        onClick={handleReviewSubmit}
                        disabled={submitReviewMutation.isPending}
                        className="bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold hover:opacity-90"
                      >
                        {submitReviewMutation.isPending ? 'Küldés...' : 'Értékelés Küldése'}
                      </Button>
                    </Card>
                  )}

                  <div className="space-y-4">
                    {reviews.length === 0 ? (
                      <Card className="border p-6 bg-[#141923] rounded-lg border border-[#1a1f2e]">
                        <p className="text-gray-400 text-center py-8">
                          Még nincs értékelés. Légy te az első!
                        </p>
                      </Card>
                    ) : (
                      reviews.map(review => (
                        <Card key={review.id} className="p-4 bg-[#141923] rounded-lg border border-[#1a1f2e]">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-[#00E599]/20 flex items-center justify-center">
                                <MessageSquare className="w-5 h-5 text-[#00E599]" />
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <p className="font-semibold text-white">
                                    {review.user_email.split('@')[0]}
                                  </p>
                                  {review.verified_purchase && (
                                    <Badge className="bg-green-600/20 text-green-400 border border-green-600/30 text-xs">
                                      <CheckCircle2 className="w-3 h-3 mr-1" />
                                      Ellenőrzött vásárló
                                    </Badge>
                                  )}
                                </div>
                                <div className="flex items-center gap-1">
                                  {[1, 2, 3, 4, 5].map(i => (
                                    <Star
                                      key={i}
                                      className={`w-4 h-4 ${
                                        i <= review.rating
                                          ? 'text-yellow-500 fill-yellow-500'
                                          : 'text-gray-600'
                                      }`}
                                    />
                                  ))}
                                </div>
                              </div>
                            </div>
                            <span className="text-xs text-gray-500">
                              {new Date(review.created_date).toLocaleDateString('hu-HU')}
                            </span>
                          </div>
                          {review.comment && (
                            <p className="text-gray-300 mt-2">{review.comment}</p>
                          )}
                          <div className="flex items-center gap-2 mt-3">
                          </div>
                        </Card>
                      ))
                    )}
                  </div>
                  </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Column - Purchase */}
          <div className="space-y-6">
            <Card className="border p-6 sticky top-24" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(148, 163, 184, 0.35)'
            }}>
              <h3 className="text-xl font-bold text-white mb-4">Vásárlás</h3>

              {app.price > 0 && !hasPurchased && ( // Only show license selection if not free and not purchased
                <div className="space-y-4 mb-6">
                  <div>
                    <label htmlFor="license-type" className="text-sm text-gray-400 mb-2 block">Licenc típus</label>
                    <select
                      id="license-type"
                      value={selectedLicense}
                      onChange={(e) => setSelectedLicense(e.target.value)}
                      className="w-full p-3 rounded-lg border bg-[#141923] border-[#1a1f2e] text-white"
                    >
                      <option value="BASIC">Alap - {licensePrices.BASIC} {app.currency || 'Ft'}</option>
                      <option value="EXTENDED">Kibővített - {licensePrices.EXTENDED} {app.currency || 'Ft'}</option>
                      <option value="EXCLUSIVE">Exkluzív - {licensePrices.EXCLUSIVE} {app.currency || 'Ft'}</option>
                    </select>
                    <p className="text-xs text-gray-500 mt-2">
                      {licenseDescriptions[selectedLicense]}
                    </p>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {hasPurchased ? (
                  <>
                    <ProtectedDownloadButton
                      appId={app.id}
                      downloadUrl={app.download_url}
                      hasPurchased={hasPurchased}
                      onDownload={handleDownload}
                      className="w-full bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold text-lg py-6 hover:opacity-90"
                    />
                    <div className="text-center">
                      <CheckCircle2 className="w-5 h-5 text-green-400 inline mr-2" />
                      <span className="text-sm text-green-400">Már megvásároltad</span>
                    </div>
                  </>
                ) : app.price === 0 ? (
                  <Button
                    onClick={handleDownload}
                    disabled={downloadMutation.isPending}
                    className="w-full bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold text-lg py-6 hover:opacity-90"
                  >
                    <Download className="w-5 h-5 mr-2" />
                    {downloadMutation.isPending ? 'Letöltés...' : 'Ingyenes Letöltés'}
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={handlePurchase}
                      disabled={purchaseMutation.isPending || !user}
                      className="w-full bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold text-lg py-6 hover:opacity-90"
                    >
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      {purchaseMutation.isPending ? 'Feldolgozás...' : 'Közvetlen Vásárlás'}
                    </Button>

                    {app.shopify_store_url && app.shopify_handle && (
                       <>
                        <div className="relative my-4">
                          <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-[#1a1f2e]"></div>
                          </div>
                          <div className="relative flex justify-center text-xs">
                            <span className="bg-[#0f1419] px-2 text-gray-500">vagy</span>
                          </div>
                        </div>
                        <ShopifyBuyButton app={app} size="lg" className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold text-lg py-6 hover:opacity-90" />
                       </>
                    )}

                    {app.revolut_username && user && ( // Check if user is logged in for Revolut Pay
                      <>
                        <div className="relative my-4">
                          <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-[#1a1f2e]"></div>
                          </div>
                          <div className="relative flex justify-center text-xs">
                            <span className="bg-[#0f1419] px-2 text-gray-500">vagy</span>
                          </div>
                        </div>
                        <EnhancedRevolutButton
                          revolutUsername={app.revolut_username}
                          amount={licensePrices[selectedLicense]}
                          description={`${app.name} - ${licenseNames[selectedLicense]}`}
                          reference={`app-${app.id}-${selectedLicense}`}
                          className="w-full py-6"
                          disabled={purchaseMutation.isPending}
                        />
                        <p className="text-xs text-gray-500 text-center">
                          Revolut Pay támogatja az Apple Pay-t és Google Pay-t is
                        </p>
                      </>
                    )}
                  </>
                )}

                {app.demo_url && (
                  <Button
                    variant="outline"
                    onClick={() => window.open(app.demo_url, '_blank')}
                    className="w-full border-[#1a1f2e] text-white hover:bg-[#1a1f2e] text-lg py-6"
                  >
                    <Play className="w-5 h-5 mr-2" />
                    Demo
                  </Button>
                )}
              </div>

              {app.support_email && (
                <div className="mt-6 pt-6 border-t border-[#1a1f2e]">
                  <p className="text-sm text-gray-400 mb-2">Támogatás</p>
                  <a href={`mailto:${app.support_email}`} className="text-cyan-400 hover:underline text-sm">
                    {app.support_email}
                  </a>
                </div>
              )}
            </Card>

            {app.price > 0 && app.created_by === user?.email && ( // Only show if not free, and seller is current user
              <CommissionCalculator
                saleAmount={licensePrices[selectedLicense]}
                salesCount={app.downloads || 0}
                currency={app.currency || 'HUF'}
              />
            )}

            {app.created_by && (
              <Card className="border p-6" style={{
                background: 'rgba(15, 23, 42, 0.95)',
                borderColor: 'rgba(148, 163, 184, 0.35)'
              }}>
                <h3 className="text-lg font-bold text-white mb-4">Fejlesztő</h3>
                <p className="text-white font-semibold mb-4">{app.developer}</p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Programok:</span>
                    <span className="text-white">{sellerStats.totalApps}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Összes letöltés:</span>
                    <span className="text-white">{sellerStats.totalDownloads}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Átlag értékelés:</span>
                    <span className="text-white flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      {sellerStats.avgRating}
                    </span>
                  </div>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
