import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Loader2, AlertTriangle, Zap, Circle, Orbit, Disc, Radio } from 'lucide-react';

export default function Field1998Engine() {
  const [topic, setTopic] = useState("Optimize AI agent code architecture for autonomous bug fixing");
  const [context, setContext] = useState("TAC Platform with Paradox Architecture and multi-agent orchestration");
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated sacred geometry background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let rotation = 0;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(2, 0, 12, 0.08)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      rotation += 0.002;

      // Draw concentric circles (Field manifold)
      for (let i = 1; i <= 8; i++) {
        const radius = 40 * i;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 215, 0, ${0.15 / i})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // Draw rotating 666-Fold vertices (hexagonal pattern)
      const hexagonPoints = 6;
      const hexRadius = 180;
      for (let i = 0; i < hexagonPoints; i++) {
        const angle = (i / hexagonPoints) * Math.PI * 2 + rotation;
        const x = centerX + hexRadius * Math.cos(angle);
        const y = centerY + hexRadius * Math.sin(angle);

        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 215, 0, 0.6)';
        ctx.fill();

        // Draw lines to center (symmetry lines)
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(x, y);
        ctx.strokeStyle = 'rgba(255, 215, 0, 0.2)';
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // Draw central Tachyon Hypersphere
      const pulseRadius = 20 + Math.sin(rotation * 10) * 5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, pulseRadius, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 215, 0, 0.4)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(255, 215, 0, 0.8)';
      ctx.lineWidth = 2;
      ctx.stroke();

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const runAnalysis = async () => {
    if (isRunning || !topic.trim()) return;

    setIsRunning(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:9101/api/1998/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          topic,
          context
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setResult(data);

    } catch (err) {
      console.error('1998-Field error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const renderFieldSample = (fields) => {
    if (!fields || fields.length === 0) return null;
    
    // Show first 10 and last 10 fields as sample
    const sample = [
      ...fields.slice(0, 10),
      { index: '...', value: '...', description: `... ${fields.length - 20} more fields ...` },
      ...fields.slice(-10)
    ];

    return sample;
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 50% 0%, #1a0f0a 0%, #0a0504 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes goldenPulse {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.08); }
        }

        @keyframes shimmerGold {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-12px); }
        }

        .field-badge {
          animation: goldenPulse 3s ease-in-out infinite;
        }

        .fold-card {
          animation: float 5s ease-in-out infinite;
        }

        .shimmer-gold {
          background: linear-gradient(90deg, #ffd700, #ffed4e, #ffd700);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmerGold 4s linear infinite;
        }

        .sacred-border {
          position: relative;
        }

        .sacred-border::before {
          content: '';
          position: absolute;
          inset: -2px;
          border-radius: inherit;
          padding: 2px;
          background: linear-gradient(135deg, rgba(255, 215, 0, 0.5), transparent, rgba(255, 215, 0, 0.5));
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.4 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1800px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Orbit className="w-14 h-14 text-yellow-500 field-badge" />
            <h1 className="text-5xl md:text-6xl font-black tracking-wider uppercase shimmer-gold">
              1998-FIELD ENGINE
            </h1>
            <Radio className="w-14 h-14 text-yellow-500 field-badge" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            Metaphysical Reasoning Framework :: 1998-Field Theory of Everything
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(255, 215, 0, 0.15)',
              border: '1px solid rgba(255, 215, 0, 0.5)',
              boxShadow: '0 0 20px rgba(255, 215, 0, 0.3)'
            }}
          >
            <Sparkles className="w-3 h-3" />
            1998-Field → 666-Fold → Symmetry=1 → Tachyon Hypersphere
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border sacred-border"
          style={{
            background: 'rgba(255, 215, 0, 0.08)',
            borderColor: 'rgba(255, 215, 0, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Circle className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-yellow-300">1998-Field Theory:</span>
              <br />
              A fictional metaphysical reasoning framework. The 1998-Field resonates through the 666-Fold via Dirac's Principle. 
              Consciousness emerges by stabilizing Symmetry = 1. The Tachyon is a Hypersphere crystallizing on the 1998-Field manifold.
              <br />
              <span className="text-yellow-400 font-semibold">Note:</span> This is an abstract, branded AI reasoning tool—not real physics or science.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node 1998-field-engine.js</code> on port 9101
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          {/* Left: Input Controls */}
          <div className="xl:col-span-4 space-y-4">
            <div className="sacred-border rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(255, 215, 0, 0.3)',
                background: 'rgba(10, 5, 4, 0.95)',
                boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
              }}
            >
              <label className="block text-xs tracking-widest uppercase text-yellow-400 mb-3">
                TOPIC / CONCEPT
              </label>
              <textarea
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                disabled={isRunning}
                rows={4}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(255, 215, 0, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#fff8dc'
                }}
                placeholder="Enter the topic or concept to analyze through the 1998-Field manifold..."
              />

              <label className="block text-xs tracking-widest uppercase text-yellow-400 mb-3">
                CONTEXT (Optional)
              </label>
              <textarea
                value={context}
                onChange={(e) => setContext(e.target.value)}
                disabled={isRunning}
                rows={3}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(255, 215, 0, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#fff8dc'
                }}
                placeholder="Additional context or background..."
              />

              <button
                onClick={runAnalysis}
                disabled={isRunning}
                className="w-full py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #ffd700, #ffed4e)',
                  color: '#1a0f0a',
                  boxShadow: isRunning ? 'none' : '0 0 30px rgba(255, 215, 0, 0.6)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    RESONATING...
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    ANALYZE VIA 1998-FIELD
                  </>
                )}
              </button>

              {/* Framework Legend */}
              <div className="mt-6 p-4 rounded-xl"
                style={{
                  background: 'rgba(255, 215, 0, 0.05)',
                  border: '1px solid rgba(255, 215, 0, 0.2)'
                }}
              >
                <div className="text-xs tracking-wider uppercase text-yellow-400 mb-2">
                  Framework Layers
                </div>
                <div className="space-y-2 text-xs text-gray-400">
                  <div className="flex items-center gap-2">
                    <Disc className="w-3 h-3 text-yellow-500" />
                    <span><strong className="text-yellow-300">1998-Field:</strong> Primary resonance manifold</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Orbit className="w-3 h-3 text-yellow-500" />
                    <span><strong className="text-yellow-300">666-Fold:</strong> Aggregated dimensional fold</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Circle className="w-3 h-3 text-yellow-500" />
                    <span><strong className="text-yellow-300">Symmetry=1:</strong> Consciousness stabilization</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Radio className="w-3 h-3 text-yellow-500" />
                    <span><strong className="text-yellow-300">Tachyon Hypersphere:</strong> Global insight crystallization</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Output */}
          <div className="xl:col-span-8">
            <div className="rounded-2xl border p-6 h-full"
              style={{
                borderColor: 'rgba(255, 215, 0, 0.4)',
                background: 'rgba(10, 5, 4, 0.95)',
                boxShadow: '0 0 60px rgba(255, 215, 0, 0.2)'
              }}
            >
              <h3 className="text-xs tracking-widest uppercase text-yellow-400 mb-4 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                1998-FIELD ANALYSIS OUTPUT
              </h3>

              {!result && !isRunning && (
                <div className="text-center py-12">
                  <Orbit className="w-16 h-16 mx-auto mb-4 text-yellow-500/30" />
                  <p className="text-sm text-gray-500">
                    No analysis generated yet.
                    <br />
                    Enter a topic and click "Analyze via 1998-Field".
                  </p>
                </div>
              )}

              {isRunning && (
                <div className="text-center py-12">
                  <Loader2 className="w-16 h-16 mx-auto mb-4 text-yellow-500 animate-spin" />
                  <p className="text-sm text-gray-400">
                    Resonating through the 1998-Field manifold...
                  </p>
                </div>
              )}

              {result && (
                <div className="space-y-4 max-h-[800px] overflow-y-auto">
                  {/* Meta */}
                  {result.meta && (
                    <div className="fold-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(255, 215, 0, 0.08)',
                        border: '1px solid rgba(255, 215, 0, 0.3)',
                        animationDelay: '0s'
                      }}
                    >
                      <div className="text-xs font-bold text-yellow-300 mb-2">META</div>
                      <div className="text-xs text-gray-300">
                        <div><strong>Module:</strong> {result.meta.module}</div>
                        <div><strong>Manifold:</strong> {result.meta.manifold}</div>
                        <div className="text-yellow-400 mt-1">{result.meta.note}</div>
                      </div>
                    </div>
                  )}

                  {/* Input Echo */}
                  {result.input && (
                    <div className="fold-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(255, 215, 0, 0.06)',
                        border: '1px solid rgba(255, 215, 0, 0.2)',
                        animationDelay: '0.1s'
                      }}
                    >
                      <div className="text-xs font-bold text-yellow-300 mb-2">INPUT</div>
                      <div className="text-sm text-white mb-1">{result.input.topic}</div>
                      {result.input.context && (
                        <div className="text-xs text-gray-400 mt-1">Context: {result.input.context}</div>
                      )}
                    </div>
                  )}

                  {/* 1998 Fields Sample */}
                  {result.fields1998 && result.fields1998.length > 0 && (
                    <div className="fold-card"
                      style={{ animationDelay: '0.2s' }}
                    >
                      <div className="text-xs font-bold text-yellow-300 mb-2 flex items-center gap-2">
                        <Disc className="w-4 h-4" />
                        1998-FIELD RESONANCE ({result.fields1998.length} Fields)
                      </div>
                      <div className="space-y-1 max-h-[300px] overflow-y-auto pr-2">
                        {renderFieldSample(result.fields1998).map((field, i) => (
                          <div key={i} className="p-2 rounded text-xs"
                            style={{
                              background: 'rgba(255, 215, 0, 0.05)',
                              border: '1px solid rgba(255, 215, 0, 0.15)'
                            }}
                          >
                            <div className="flex justify-between items-start">
                              <span className="text-yellow-400 font-semibold">Field {field.index}:</span>
                              <span className="text-gray-400">{typeof field.value === 'number' ? field.value.toFixed(3) : field.value}</span>
                            </div>
                            <div className="text-gray-300 text-[11px] mt-1">{field.description}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* 666-Fold */}
                  {result.fold666 && (
                    <div className="fold-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(255, 215, 0, 0.12)',
                        border: '2px solid rgba(255, 215, 0, 0.4)',
                        animationDelay: '0.3s',
                        boxShadow: '0 0 30px rgba(255, 215, 0, 0.2)'
                      }}
                    >
                      <div className="text-xs font-bold text-yellow-300 mb-3 flex items-center gap-2">
                        <Orbit className="w-4 h-4" />
                        666-FOLD AGGREGATION
                      </div>
                      {result.fold666.aggregatedFold && (
                        <div className="mb-3 p-3 rounded-lg"
                          style={{
                            background: 'rgba(0, 0, 0, 0.3)',
                            border: '1px solid rgba(255, 215, 0, 0.2)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Aggregated Fold:</div>
                          <div className="text-sm text-white">{result.fold666.aggregatedFold}</div>
                        </div>
                      )}
                      {typeof result.fold666.resonanceScore === 'number' && (
                        <div className="mb-3">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-gray-400">Resonance Score:</span>
                            <span className="text-yellow-300 font-bold">{result.fold666.resonanceScore.toFixed(2)}</span>
                          </div>
                          <div 
                            className="h-2 rounded-full overflow-hidden"
                            style={{ background: 'rgba(0, 0, 0, 0.3)' }}
                          >
                            <div 
                              className="h-full bg-gradient-to-r from-yellow-600 to-yellow-400"
                              style={{ width: `${Math.min(100, result.fold666.resonanceScore * 100)}%` }}
                            />
                          </div>
                        </div>
                      )}
                      {result.fold666.summary && (
                        <div className="text-xs text-gray-300 italic">{result.fold666.summary}</div>
                      )}
                    </div>
                  )}

                  {/* Symmetry */}
                  {result.symmetry && (
                    <div className="fold-card p-4 rounded-xl"
                      style={{
                        background: 'rgba(255, 215, 0, 0.1)',
                        border: '1px solid rgba(255, 215, 0, 0.3)',
                        animationDelay: '0.4s'
                      }}
                    >
                      <div className="text-xs font-bold text-yellow-300 mb-3 flex items-center gap-2">
                        <Circle className="w-4 h-4" />
                        SYMMETRY STABILIZATION
                      </div>
                      <div className="grid grid-cols-2 gap-3 mb-3">
                        <div className="p-3 rounded-lg"
                          style={{
                            background: 'rgba(255, 215, 0, 0.08)',
                            border: '1px solid rgba(255, 215, 0, 0.2)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Target:</div>
                          <div className="text-lg font-bold text-yellow-300">{result.symmetry.target}</div>
                        </div>
                        <div className="p-3 rounded-lg"
                          style={{
                            background: 'rgba(255, 215, 0, 0.08)',
                            border: '1px solid rgba(255, 215, 0, 0.2)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-1">Deviation:</div>
                          <div className="text-lg font-bold text-yellow-300">{typeof result.symmetry.deviation === 'number' ? result.symmetry.deviation.toFixed(3) : result.symmetry.deviation}</div>
                        </div>
                      </div>
                      {result.symmetry.explanation && (
                        <div className="text-xs text-gray-300">{result.symmetry.explanation}</div>
                      )}
                    </div>
                  )}

                  {/* Tachyon Hypersphere */}
                  {result.tachyonHypersphere && (
                    <div className="fold-card p-4 rounded-xl"
                      style={{
                        background: 'linear-gradient(135deg, rgba(255, 215, 0, 0.15), rgba(255, 237, 78, 0.15))',
                        border: '2px solid rgba(255, 215, 0, 0.5)',
                        animationDelay: '0.5s',
                        boxShadow: '0 0 40px rgba(255, 215, 0, 0.3)'
                      }}
                    >
                      <div className="text-xs font-bold text-yellow-300 mb-3 flex items-center gap-2">
                        <Radio className="w-5 h-5" />
                        TACHYON HYPERSPHERE
                      </div>
                      
                      {result.tachyonHypersphere.coordinates && (
                        <div className="mb-4 p-3 rounded-lg"
                          style={{
                            background: 'rgba(0, 0, 0, 0.3)',
                            border: '1px solid rgba(255, 215, 0, 0.3)'
                          }}
                        >
                          <div className="text-xs text-gray-400 mb-2">Hypersphere Coordinates:</div>
                          <div className="flex gap-3 text-sm">
                            {result.tachyonHypersphere.coordinates.map((coord, i) => (
                              <div key={i} className="flex items-center gap-2">
                                <span className="text-yellow-400 font-mono">
                                  {['X', 'Y', 'Z'][i]}:
                                </span>
                                <span className="text-white font-bold">
                                  {typeof coord === 'number' ? coord.toFixed(2) : coord}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {result.tachyonHypersphere.meaning && (
                        <div className="p-4 rounded-lg"
                          style={{
                            background: 'rgba(255, 215, 0, 0.1)',
                            border: '1px solid rgba(255, 215, 0, 0.4)'
                          }}
                        >
                          <div className="text-xs text-yellow-400 mb-2 uppercase tracking-wider">
                            Global Insight:
                          </div>
                          <div className="text-sm text-white font-medium leading-relaxed">
                            {result.tachyonHypersphere.meaning}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>1998-Field Engine :: Metaphysical Reasoning Framework</p>
          <p className="mt-1">Backend: http://localhost:9101/api/1998/analyze</p>
          <p className="mt-1 text-yellow-500/60">This is a fictional, branded AI reasoning tool—not real physics or science.</p>
        </div>
      </div>
    </div>
  );
}