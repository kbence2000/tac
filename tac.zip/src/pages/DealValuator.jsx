import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Calculator, Sparkles, Target, AlertTriangle,
  TrendingUp, Users, DollarSign, Clock, Zap
} from "lucide-react";
import { toast } from "sonner";
import DeveloperMatchCard from "../components/DeveloperMatchCard";
import DealPackageCard from "../components/DealPackageCard";

const DEAL_API = import.meta.env.VITE_DEAL_VALUATOR_URL || "http://localhost:4200";

const RISK_CONFIG = {
  low: { color: "text-green-400", bg: "bg-green-600/20", border: "border-green-600/30" },
  medium: { color: "text-yellow-400", bg: "bg-yellow-600/20", border: "border-yellow-600/30" },
  "medium-high": { color: "text-orange-400", bg: "bg-orange-600/20", border: "border-orange-600/30" },
  high: { color: "text-red-400", bg: "bg-red-600/20", border: "border-red-600/30" }
};

export default function DealValuator() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [techStack, setTechStack] = useState("React, Node.js, PostgreSQL");
  const [deadline, setDeadline] = useState("8");
  const [budget, setBudget] = useState("20000");
  const [quality, setQuality] = useState("high");
  const [aiIntensity, setAiIntensity] = useState("medium");
  const [features, setFeatures] = useState("auth, payment, admin, dashboard");
  const [integrations, setIntegrations] = useState("Stripe, OpenAI");
  
  const [evaluating, setEvaluating] = useState(false);
  const [result, setResult] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const handleEvaluate = async () => {
    if (!title && !description) {
      toast.error("Please provide at least a title or description");
      return;
    }

    setEvaluating(true);
    setResult(null);

    try {
      const techArray = techStack.split(",").map(s => s.trim()).filter(Boolean);
      const featuresArray = features.split(",").map(s => s.trim()).filter(Boolean);
      const integrationsArray = integrations.split(",").map(s => s.trim()).filter(Boolean);

      const res = await fetch(`${DEAL_API}/api/deal/evaluate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          techStack: techArray,
          deadlineWeeks: deadline ? Number(deadline) : undefined,
          budgetEUR: budget ? Number(budget) : undefined,
          qualityLevel: quality,
          aiIntensity,
          features: featuresArray,
          integrations: integrationsArray
        })
      });

      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error || "Evaluation failed");
        return;
      }

      const data = await res.json();
      setResult(data);
      toast.success("AI evaluation complete!");
    } catch (error) {
      console.error("Evaluation error:", error);
      toast.error("Network error");
    } finally {
      setEvaluating(false);
    }
  };

  const riskCfg = result?.estimation?.riskLevel 
    ? RISK_CONFIG[result.estimation.riskLevel] || RISK_CONFIG.medium
    : RISK_CONFIG.medium;

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Calculator className="w-4 h-4 text-purple-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">AI Deal Valuator</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #a855f7, #ec4899)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            Deal Valuator AI
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Describe your project and get AI-powered estimates on complexity, timeline, cost, risk, and matched with top 10 Demigod developers or teams.
          </p>
        </div>

        <div className="grid lg:grid-cols-[1fr_1.3fr] gap-8">
          {/* Left: Input Form */}
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
            <h2 className="text-xl font-black text-white mb-6">Project Details</h2>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold text-white block mb-2">
                  Project Title
                </label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="E.g. AI-powered code marketplace MVP"
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-white block mb-2">
                  Description
                </label>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe your project in detail..."
                  className="bg-[#141923] border-[#1a1f2e] text-white h-32"
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-white block mb-2">
                  Tech Stack (comma-separated)
                </label>
                <Input
                  value={techStack}
                  onChange={(e) => setTechStack(e.target.value)}
                  placeholder="React, Node.js, PostgreSQL, OpenAI"
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold text-white block mb-2">
                    Deadline (weeks)
                  </label>
                  <Input
                    type="number"
                    value={deadline}
                    onChange={(e) => setDeadline(e.target.value)}
                    placeholder="8"
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                  />
                </div>

                <div>
                  <label className="text-sm font-semibold text-white block mb-2">
                    Budget (EUR)
                  </label>
                  <Input
                    type="number"
                    value={budget}
                    onChange={(e) => setBudget(e.target.value)}
                    placeholder="20000"
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold text-white block mb-2">
                    Quality Level
                  </label>
                  <Select value={quality} onValueChange={setQuality}>
                    <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="enterprise">Enterprise</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-semibold text-white block mb-2">
                    AI Intensity
                  </label>
                  <Select value={aiIntensity} onValueChange={setAiIntensity}>
                    <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-semibold text-white block mb-2">
                  Key Features (comma-separated)
                </label>
                <Input
                  value={features}
                  onChange={(e) => setFeatures(e.target.value)}
                  placeholder="auth, payment, admin, ai_search"
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-white block mb-2">
                  Integrations (comma-separated)
                </label>
                <Input
                  value={integrations}
                  onChange={(e) => setIntegrations(e.target.value)}
                  placeholder="Stripe, OpenAI, OAuth"
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                />
              </div>

              <Button
                onClick={handleEvaluate}
                disabled={evaluating}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-lg py-6"
              >
                {evaluating ? (
                  <>
                    <Sparkles className="w-5 h-5 mr-2 animate-pulse" />
                    AI Analyzing...
                  </>
                ) : (
                  <>
                    <Calculator className="w-5 h-5 mr-2" />
                    Get AI Valuation
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Right: Results */}
          <div className="space-y-6">
            {!result ? (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="text-center py-20">
                  <Calculator className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-white mb-2">No Evaluation Yet</h3>
                  <p className="text-gray-400">
                    Fill out the form and click "Get AI Valuation" to see estimates
                  </p>
                </div>
              </Card>
            ) : (
              <>
                {/* Estimation Summary */}
                <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                  <h2 className="text-xl font-black text-white mb-4">AI Estimation</h2>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <div className="flex items-center gap-2 mb-2">
                        <Target className="w-4 h-4 text-purple-400" />
                        <div className="text-xs text-gray-400">Complexity Score</div>
                      </div>
                      <div className="text-3xl font-bold text-purple-400">
                        {result.estimation.complexityScore}/100
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className={`w-4 h-4 ${riskCfg.color}`} />
                        <div className="text-xs text-gray-400">Risk Level</div>
                      </div>
                      <Badge className={`${riskCfg.bg} ${riskCfg.color} border ${riskCfg.border} text-base px-3 py-1`}>
                        {result.estimation.riskLevel}
                      </Badge>
                      <div className="text-xs text-gray-500 mt-1">
                        {result.estimation.riskScore}/100
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="w-4 h-4 text-cyan-400" />
                        <div className="text-xs text-gray-400">Estimated Hours</div>
                      </div>
                      <div className="text-2xl font-bold text-cyan-400">
                        {result.estimation.hoursRange.min}-{result.estimation.hoursRange.max}h
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <div className="flex items-center gap-2 mb-2">
                        <DollarSign className="w-4 h-4 text-green-400" />
                        <div className="text-xs text-gray-400">Cost Range</div>
                      </div>
                      <div className="text-2xl font-bold text-green-400">
                        €{result.estimation.costRangeEUR.min.toLocaleString()}-{result.estimation.costRangeEUR.max.toLocaleString()}
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-lg bg-gradient-to-br from-purple-600/10 to-pink-600/10 border border-purple-600/30">
                    <div className="flex items-center gap-2 mb-1">
                      <Users className="w-4 h-4 text-purple-400" />
                      <span className="text-sm font-bold text-white">Suggested Team Size</span>
                    </div>
                    <div className="text-xs text-purple-200">
                      {result.estimation.suggestedTeamSize} {result.estimation.suggestedTeamSize === 1 ? 'developer' : 'developers'} recommended for optimal delivery
                    </div>
                  </div>
                </Card>

                {/* Deal Packages */}
                <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                  <h2 className="text-xl font-black text-white mb-4">Recommended Packages</h2>
                  <div className="space-y-4">
                    {result.packages.map((pkg) => (
                      <DealPackageCard key={pkg.id} package={pkg} />
                    ))}
                  </div>
                </Card>

                {/* Top Matches */}
                <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                  <h2 className="text-xl font-black text-white mb-4 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    Top 10 Matched Developers
                  </h2>
                  <p className="text-sm text-gray-400 mb-6">
                    AI-ranked developers and teams based on tech fit, innovation score, availability, and rate alignment
                  </p>
                  <div className="space-y-3">
                    {result.topMatches.map((match, index) => (
                      <DeveloperMatchCard 
                        key={match.id} 
                        match={match} 
                        rank={index + 1}
                      />
                    ))}
                  </div>
                </Card>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}