import React, { useState, useEffect, useRef } from 'react';
import { Zap, Send, Radio, Hexagon, Brain, GitBranch, RefreshCw, CheckCircle2, AlertTriangle, Loader2, Activity, Eye, ArrowRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  NineMindsMetadata, 
  DistortedSynergyMetadata, 
  distortedSynergyBridge,
  simulateBrainProcessing,
  dualLoop
} from '../components/DistortedSynergyUtils';

export default function MissionLoop() {
  const [missionDescription, setMissionDescription] = useState("Create an autonomous AI agent that monitors system health and self-heals critical issues");
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentPhase, setCurrentPhase] = useState(null);
  const [activeLoop, setActiveLoop] = useState(null);
  const [phaseData, setPhaseData] = useState({});
  const [autoLoop, setAutoLoop] = useState(false);
  const queryClient = useQueryClient();
  const phaseLogRef = useRef(null);

  const { data: loops = [] } = useQuery({
    queryKey: ['mission-loops'],
    queryFn: async () => {
      const list = await base44.entities.MissionLoop.list('-created_date', 20);
      return list;
    },
    refetchInterval: 5000
  });

  const createLoopMutation = useMutation({
    mutationFn: async (loopData) => {
      return await base44.entities.MissionLoop.create(loopData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mission-loops'] });
    }
  });

  const updateLoopMutation = useMutation({
    mutationFn: async ({ id, updates }) => {
      return await base44.entities.MissionLoop.update(id, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mission-loops'] });
    }
  });

  useEffect(() => {
    if (phaseLogRef.current) {
      phaseLogRef.current.scrollTop = phaseLogRef.current.scrollHeight;
    }
  }, [phaseData]);

  const addPhaseLog = (phase, data) => {
    setPhaseData(prev => ({
      ...prev,
      [phase]: { ...data, timestamp: new Date().toISOString() }
    }));
  };

  const createMission = async (loopId) => {
    setCurrentPhase('mission_created');
    addPhaseLog('mission_created', { description: missionDescription, status: 'creating' });
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const mission = {
      id: `mission_${Date.now()}`,
      description: missionDescription,
      type: 'autonomous_loop',
      complexity: 'high',
      status: 'created'
    };
    
    addPhaseLog('mission_created', { ...mission, status: 'completed' });
    
    await updateLoopMutation.mutateAsync({
      id: loopId,
      updates: {
        phase: 'mission_created',
        initialMission: mission
      }
    });
    
    return mission;
  };

  const processN8N = async (loopId, mission) => {
    setCurrentPhase('n8n_processing');
    addPhaseLog('n8n_processing', { status: 'sending', workflowId: 'wf_' + Date.now() });
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const n8nResult = {
      workflowId: 'wf_' + Date.now(),
      status: 'success',
      data: {
        processed: mission.description,
        aiEnhancements: [
          "Added self-monitoring capability",
          "Implemented predictive failure detection",
          "Enhanced recovery protocols"
        ],
        confidence: 0.87
      }
    };
    
    addPhaseLog('n8n_processing', { ...n8nResult, status: 'completed' });
    
    await updateLoopMutation.mutateAsync({
      id: loopId,
      updates: {
        phase: 'n8n_processing',
        n8nWorkflowId: n8nResult.workflowId,
        n8nResult
      }
    });
    
    return n8nResult;
  };

  const createFeedback = async (loopId, n8nResult) => {
    setCurrentPhase('feedback_received');
    addPhaseLog('feedback_received', { status: 'creating' });
    
    const feedbackContent = `n8n AI workflow processed mission: ${JSON.stringify(n8nResult.data)}`;
    
    const feedback = await base44.entities.Feedback.create({
      content: feedbackContent,
      source: 'n8n',
      userId: 'mission_loop',
      metadata: {
        loopId,
        n8nWorkflowId: n8nResult.workflowId,
        phase: 'automated_loop'
      },
      status: 'pending',
      raw: JSON.stringify({ loopId, n8nResult })
    });
    
    addPhaseLog('feedback_received', { feedbackId: feedback.id, status: 'completed' });
    
    await updateLoopMutation.mutateAsync({
      id: loopId,
      updates: {
        phase: 'feedback_received',
        feedbackId: feedback.id
      }
    });
    
    return feedback;
  };

  const runParadoxAnalysis = async (loopId, feedback) => {
    setCurrentPhase('paradox_analyzing');
    addPhaseLog('paradox_analyzing', { status: 'analyzing' });
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const paradoxAnalysis = {
      entropy: Math.random() * 0.4 + 0.6,
      coherence: Math.random() * 0.3 + 0.6,
      complexity: Math.random() * 0.3 + 0.7,
      innovation: Math.random() * 0.4 + 0.5,
      stability: Math.random() * 0.2 + 0.7,
      summary: "High complexity autonomous system with strong stability markers"
    };
    
    addPhaseLog('paradox_analyzing', { ...paradoxAnalysis, status: 'completed' });
    
    await base44.entities.Feedback.update(feedback.id, {
      paradoxAnalysis,
      status: 'analyzed'
    });
    
    await updateLoopMutation.mutateAsync({
      id: loopId,
      updates: {
        phase: 'paradox_analyzing',
        paradoxAnalysis
      }
    });
    
    return paradoxAnalysis;
  };

  const runNinefold = async (loopId, feedback) => {
    setCurrentPhase('ninefold_processing');
    addPhaseLog('ninefold_processing', { status: 'processing', system: 'nine_minds' });
    
    const bridge = distortedSynergyBridge(feedback.content);
    let signal = feedback.content;
    
    const nineMindsOutput = [];
    for (const brain of NineMindsMetadata) {
      const output = await simulateBrainProcessing(brain.name, signal, 150);
      nineMindsOutput.push({ brain: brain.name, output });
      signal = output;
    }
    
    addPhaseLog('ninefold_processing', { status: 'processing', system: 'distorted_synergy' });
    
    signal = bridge.distorted;
    const distortedOutput = [];
    for (const brain of DistortedSynergyMetadata) {
      const output = await simulateBrainProcessing(brain.name, signal, 150);
      distortedOutput.push({ brain: brain.name, output });
      signal = output;
    }
    
    const deltaAnalysis = dualLoop(feedback.content);
    
    const ninefoldResult = {
      nineMindsOutput,
      distortedOutput,
      deltaAnalysis: deltaAnalysis.delta,
      finalNine: nineMindsOutput[nineMindsOutput.length - 1]?.output,
      finalDistorted: distortedOutput[distortedOutput.length - 1]?.output
    };
    
    addPhaseLog('ninefold_processing', { ...ninefoldResult, status: 'completed' });
    
    await updateLoopMutation.mutateAsync({
      id: loopId,
      updates: {
        phase: 'ninefold_processing',
        ninefoldProcessing: ninefoldResult
      }
    });
    
    return ninefoldResult;
  };

  const generateNewMission = async (loopId, ninefoldResult, paradoxAnalysis) => {
    setCurrentPhase('mission_generating');
    addPhaseLog('mission_generating', { status: 'synthesizing' });
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const synthesis = `${ninefoldResult.finalNine} + ${ninefoldResult.finalDistorted}`;
    const innovationBoost = paradoxAnalysis.innovation > 0.7 ? "BREAKTHROUGH" : "INCREMENTAL";
    
    const newMission = {
      id: `mission_${Date.now()}`,
      description: `[${innovationBoost}] ${synthesis.substring(0, 100)}...`,
      type: 'generated_loop',
      complexity: paradoxAnalysis.complexity > 0.8 ? 'extreme' : 'high',
      parentLoopId: loopId,
      status: 'ready'
    };
    
    addPhaseLog('mission_generating', { ...newMission, status: 'completed' });
    
    await updateLoopMutation.mutateAsync({
      id: loopId,
      updates: {
        phase: 'completed',
        status: 'completed',
        generatedMission: newMission,
        completedAt: new Date().toISOString()
      }
    });
    
    return newMission;
  };

  const runLoop = async () => {
    if (isProcessing) return;
    
    setIsProcessing(true);
    setPhaseData({});
    setCurrentPhase(null);
    
    try {
      const loop = await createLoopMutation.mutateAsync({
        loopId: `loop_${Date.now()}`,
        phase: 'mission_created',
        status: 'active',
        loopCount: 1,
        metrics: {
          startTime: Date.now()
        }
      });
      
      setActiveLoop(loop);
      
      const mission = await createMission(loop.id);
      const n8nResult = await processN8N(loop.id, mission);
      const feedback = await createFeedback(loop.id, n8nResult);
      const paradoxAnalysis = await runParadoxAnalysis(loop.id, feedback);
      const ninefoldResult = await runNinefold(loop.id, feedback);
      const newMission = await generateNewMission(loop.id, ninefoldResult, paradoxAnalysis);
      
      const endTime = Date.now();
      const startTime = loop.metrics?.startTime || endTime;
      await updateLoopMutation.mutateAsync({
        id: loop.id,
        updates: {
          metrics: {
            ...loop.metrics,
            totalDuration: endTime - startTime,
            endTime
          }
        }
      });
      
      setCurrentPhase('completed');
      
      if (autoLoop && newMission) {
        setTimeout(() => {
          setMissionDescription(newMission.description);
          runLoop();
        }, 2000);
      }
      
    } catch (err) {
      console.error('Loop failed:', err);
      setCurrentPhase('failed');
      addPhaseLog('error', { message: String(err), status: 'failed' });
      
      if (activeLoop) {
        await updateLoopMutation.mutateAsync({
          id: activeLoop.id,
          updates: {
            phase: 'failed',
            status: 'failed',
            error: String(err)
          }
        });
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const phases = [
    { id: 'mission_created', label: 'Mission Created', icon: Send, color: '#4f7cff' },
    { id: 'n8n_processing', label: 'n8n AI Workflow', icon: Radio, color: '#24e4ff' },
    { id: 'feedback_received', label: 'Feedback Received', icon: Activity, color: '#4cffa8' },
    { id: 'paradox_analyzing', label: 'Paradox Analysis', icon: Hexagon, color: '#a84cff' },
    { id: 'ninefold_processing', label: 'Ninefold Processing', icon: Brain, color: '#ff6ec7' },
    { id: 'mission_generating', label: 'Mission Generation', icon: Zap, color: '#ffdb7c' },
    { id: 'completed', label: 'Loop Completed', icon: CheckCircle2, color: '#00ff8a' }
  ];

  const getPhaseStatus = (phaseId) => {
    if (!currentPhase) return 'pending';
    const currentIndex = phases.findIndex(p => p.id === currentPhase);
    const phaseIndex = phases.findIndex(p => p.id === phaseId);
    
    if (phaseIndex < currentIndex) return 'completed';
    if (phaseIndex === currentIndex) return 'active';
    return 'pending';
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .phase-item {
          transition: all 0.3s ease-out;
        }
        
        .phase-item.active {
          animation: pulseGlow 1.5s ease-in-out infinite;
        }
        
        @keyframes pulseGlow {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }
        
        .loop-card {
          transition: all 0.2s;
        }
        
        .loop-card:hover {
          transform: translateY(-2px);
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <GitBranch className="w-8 h-8 text-cyan-400" />
            <h1 className="text-3xl font-black tracking-wider uppercase text-white">
              TAC MISSION LOOP
            </h1>
            <RefreshCw className="w-8 h-8 text-purple-400" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide">
            Self-Feeding AI System • Mission → n8n → Feedback → Paradox → Ninefold → New Mission
          </p>
        </div>

        <div className="mb-6 rounded-2xl border p-6" style={{
          borderColor: 'rgba(36, 228, 255, 0.4)',
          background: 'rgba(7, 7, 18, 0.95)',
          boxShadow: '0 0 40px rgba(36, 228, 255, 0.2)'
        }}>
          <label className="block text-xs tracking-widest uppercase text-cyan-400 mb-3">
            INITIAL MISSION
          </label>
          <textarea
            value={missionDescription}
            onChange={(e) => setMissionDescription(e.target.value)}
            disabled={isProcessing}
            rows={3}
            className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
            style={{
              borderColor: 'rgba(36, 228, 255, 0.3)',
              background: 'rgba(2, 0, 12, 0.9)',
              color: '#f6fff6'
            }}
            placeholder="Describe the mission to start the loop..."
          />
          
          <div className="flex items-center justify-between flex-wrap gap-3">
            <button
              onClick={runLoop}
              disabled={isProcessing}
              className="px-6 py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center gap-2 transition-all disabled:opacity-40"
              style={{
                background: 'linear-gradient(135deg, #24e4ff, #a84cff)',
                color: '#000',
                boxShadow: isProcessing ? 'none' : '0 0 30px rgba(36, 228, 255, 0.7)'
              }}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  LOOP RUNNING...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  START LOOP
                </>
              )}
            </button>

            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoLoop}
                  onChange={(e) => setAutoLoop(e.target.checked)}
                  className="w-4 h-4"
                  disabled={isProcessing}
                />
                <span className="text-xs text-gray-400">Auto-loop (infinite)</span>
              </label>
            </div>
          </div>
        </div>

        <div className="mb-6 rounded-2xl border p-6" style={{
          borderColor: 'rgba(168, 85, 247, 0.3)',
          background: 'rgba(7, 7, 18, 0.95)'
        }}>
          <div className="text-xs tracking-widest uppercase text-purple-400 mb-4">
            LOOP PHASES
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
            {phases.map((phase) => {
              const Icon = phase.icon;
              const status = getPhaseStatus(phase.id);
              
              return (
                <div
                  key={phase.id}
                  className={`phase-item text-center p-3 rounded-xl border ${status === 'active' ? 'active' : ''}`}
                  style={{
                    borderColor: status === 'completed' ? `${phase.color}80` : status === 'active' ? `${phase.color}` : 'rgba(255, 255, 255, 0.1)',
                    background: status === 'completed' ? `${phase.color}20` : status === 'active' ? `${phase.color}15` : 'rgba(0, 0, 0, 0.3)',
                    boxShadow: status === 'active' ? `0 0 20px ${phase.color}60` : 'none'
                  }}
                >
                  <Icon 
                    className="w-5 h-5 mx-auto mb-2" 
                    style={{ color: status === 'pending' ? '#666' : phase.color }}
                  />
                  <div className="text-[0.65rem] font-semibold" style={{
                    color: status === 'pending' ? '#666' : '#fff'
                  }}>
                    {phase.label}
                  </div>
                  {status === 'active' && (
                    <div className="text-[0.55rem] text-gray-400 mt-1">Processing...</div>
                  )}
                  {status === 'completed' && (
                    <CheckCircle2 className="w-3 h-3 mx-auto mt-1" style={{ color: phase.color }} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7">
            <div className="rounded-2xl border p-6" style={{
              borderColor: 'rgba(255, 255, 255, 0.1)',
              background: 'rgba(7, 7, 18, 0.95)',
              minHeight: '500px'
            }}>
              <div className="text-xs tracking-widest uppercase text-gray-400 mb-4">
                PHASE LOG STREAM
              </div>
              
              <div 
                ref={phaseLogRef}
                className="space-y-3 max-h-[450px] overflow-y-auto"
              >
                {Object.keys(phaseData).length === 0 && (
                  <div className="text-center py-12 text-sm text-gray-600">
                    No loop running. Start a loop to see phase logs.
                  </div>
                )}
                
                {Object.entries(phaseData).map(([phase, data], idx) => {
                  const phaseInfo = phases.find(p => p.id === phase) || { label: phase, color: '#8c8faf', icon: Activity };
                  const Icon = phaseInfo.icon;
                  
                  return (
                    <div
                      key={idx}
                      className="p-3 rounded-xl border"
                      style={{
                        borderColor: `${phaseInfo.color}40`,
                        background: 'rgba(0, 0, 0, 0.4)',
                        borderLeft: `3px solid ${phaseInfo.color}`
                      }}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className="w-4 h-4" style={{ color: phaseInfo.color }} />
                        <span className="text-xs font-bold" style={{ color: phaseInfo.color }}>
                          {phaseInfo.label}
                        </span>
                        <span className="text-[0.65rem] text-gray-500 ml-auto">
                          {new Date(data.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <pre className="text-[0.65rem] text-gray-300 font-mono whitespace-pre-wrap">
                        {JSON.stringify(data, null, 2)}
                      </pre>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-2xl border p-6" style={{
              borderColor: 'rgba(255, 255, 255, 0.1)',
              background: 'rgba(7, 7, 18, 0.95)',
              minHeight: '500px'
            }}>
              <div className="text-xs tracking-widest uppercase text-gray-400 mb-4">
                LOOP HISTORY ({loops.length})
              </div>
              
              <div className="space-y-3 max-h-[450px] overflow-y-auto">
                {loops.length === 0 && (
                  <div className="text-center py-12 text-sm text-gray-600">
                    No loops yet. Start your first loop.
                  </div>
                )}
                
                {loops.map((loop) => (
                  <div
                    key={loop.id}
                    className="loop-card p-3 rounded-xl border cursor-pointer"
                    style={{
                      borderColor: loop.status === 'completed' ? 'rgba(0, 255, 138, 0.4)' : loop.status === 'failed' ? 'rgba(255, 75, 129, 0.4)' : 'rgba(36, 228, 255, 0.4)',
                      background: 'rgba(0, 0, 0, 0.3)'
                    }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-white">
                        {loop.loopId}
                      </span>
                      <span 
                        className="text-[0.65rem] px-2 py-0.5 rounded-full font-bold uppercase"
                        style={{
                          background: loop.status === 'completed' ? 'rgba(0, 255, 138, 0.2)' : loop.status === 'failed' ? 'rgba(255, 75, 129, 0.2)' : 'rgba(36, 228, 255, 0.2)',
                          color: loop.status === 'completed' ? '#00ff8a' : loop.status === 'failed' ? '#ff4b81' : '#24e4ff'
                        }}
                      >
                        {loop.status}
                      </span>
                    </div>
                    <div className="text-[0.65rem] text-gray-400">
                      Phase: {loop.phase}
                    </div>
                    {loop.initialMission && (
                      <div className="text-[0.65rem] text-gray-500 mt-1 truncate">
                        {loop.initialMission.description}
                      </div>
                    )}
                    {loop.metrics?.totalDuration && (
                      <div className="text-[0.6rem] text-gray-600 mt-1">
                        Duration: {(loop.metrics.totalDuration / 1000).toFixed(1)}s
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 p-4 rounded-xl border" style={{
          background: 'rgba(36, 228, 255, 0.1)',
          borderColor: 'rgba(36, 228, 255, 0.3)'
        }}>
          <div className="flex items-start gap-3">
            <Eye className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <strong className="text-cyan-400">Mission Loop Architecture:</strong> Initial mission → n8n AI workflow (simulated) → Feedback entity → Paradox fusion analysis → Ninefold (9×9 minds) processing → New mission generation → Auto-loop (optional)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}