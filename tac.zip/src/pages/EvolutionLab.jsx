import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Zap, TrendingUp, Brain, Eye, Lock, Clock, Layers, GitBranch, Shield } from 'lucide-react';

export default function EvolutionLab() {
  const [brief, setBrief] = useState("Build an AI-powered code marketplace module that evaluates, ranks, and prices code assets based on quality, uniqueness, execution performance, and real market demand.");
  const [isRunning, setIsRunning] = useState(false);
  const [timeline, setTimeline] = useState([]);
  const [finalConcept, setFinalConcept] = useState("No evolution yet.");
  const [currentLevel, setCurrentLevel] = useState(0);
  const timelineEndRef = useRef(null);

  const brains = [
    {
      id: "chaos",
      name: "Chaos Architect",
      icon: Sparkles,
      color: "#ff66e7",
      role: "Generate primal radical seed",
      transform: (idea, brief, lvl) => {
        const spice = [
          "toxic-neon OS layer",
          "self-mutating interaction pattern",
          "semi-abstract neural UI",
          "glitch-reactive visual language",
          "mission-driven operator cockpit"
        ];
        const s = spice[Math.floor(Math.random() * spice.length)];
        idea.core = `Primal seed: turn "${brief}" into a ${s} that feels alive and slightly unstable on purpose.`;
        idea.tags.push("radical", "weird", "non-linear");
        return `Forms a primal concept: "${idea.core}"`;
      }
    },
    {
      id: "neuro",
      name: "Neuro Evolution",
      icon: TrendingUp,
      color: "#9fa8ff",
      role: "Flow & optimization",
      transform: (idea, brief, lvl) => {
        const routes = [
          "tri-stage flow (scan → focus → execute)",
          "two-layer experience (fast lane vs deep lane)",
          "context-aware surfaces that expand only when needed"
        ];
        const r = routes[Math.floor(Math.random() * routes.length)];
        idea.flow = `Wraps the seed into ${r}, minimizing friction while keeping the weirdness controlled.`;
        idea.tags.push("flow", "efficiency");
        return `Defines flow: ${idea.flow}`;
      }
    },
    {
      id: "dream",
      name: "Dream Renderer",
      icon: Eye,
      color: "#3bd3ff",
      role: "Visual blueprint",
      transform: (idea, brief, lvl) => {
        const moods = [
          "dark glass, toxic green plasma halos",
          "bio-mechanical chrome with neon veins",
          "radiation-bleached minimal lab",
          "silent tactical HUD with soft glow"
        ];
        const m = moods[Math.floor(Math.random() * moods.length)];
        idea.ui = `Visualize the system as ${m}, with the core node pulsing whenever critical AI insights appear.`;
        idea.tags.push("visual", "cinematic");
        return `Blueprints UI: ${idea.ui}`;
      }
    },
    {
      id: "glitch",
      name: "Glitch Engineer",
      icon: Zap,
      color: "#ff4b5c",
      role: "Controlled distortion",
      transform: (idea, brief, lvl) => {
        const effects = [
          "micro-jitter on important nodes to draw attention",
          "ghost duplicates on hover for key actions",
          "scanline waves when data refreshes or missions resolve",
          "periodic color inversion pulses for critical states"
        ];
        const e = effects[Math.floor(Math.random() * effects.length)];
        idea.glitch = `Introduce controlled glitch: ${e}, but only when the system wants the user to notice a state change.`;
        idea.tags.push("glitch", "attention");
        return `Injects glitch logic: ${idea.glitch}`;
      }
    },
    {
      id: "shadow",
      name: "Shadow Architect",
      icon: Lock,
      color: "#9b9bbb",
      role: "Hidden dimension & secret routes",
      transform: (idea, brief, lvl) => {
        const secrets = [
          "a hidden 'ghost layer' admin view, revealed by rare interaction patterns",
          "secret mission panel triggered by a specific sequence of actions",
          "shadow analytics dashboard only accessible after certain milestones",
          "stealth debug route that overlays live agent activity without clutter"
        ];
        const s = secrets[Math.floor(Math.random() * secrets.length)];
        idea.shadow = `Define hidden layer: ${s}. Exposed only to founders / power users.`;
        idea.tags.push("hidden", "power-user");
        return `Adds shadow dimension: ${idea.shadow}`;
      }
    },
    {
      id: "temporal",
      name: "Temporal Engine",
      icon: Clock,
      color: "#b788ff",
      role: "Time-based behavior",
      transform: (idea, brief, lvl) => {
        const windows = [
          "first 60 seconds after login",
          "mission-critical phases only",
          "moments of inactivity > 12 seconds",
          "time windows aligned with traffic peaks"
        ];
        const w = windows[Math.floor(Math.random() * windows.length)];
        idea.time = `Decode time: certain visual + data behaviors only appear during ${w}, so the system feels alive and responsive to time.`;
        idea.tags.push("time", "dynamic");
        return `Embeds time logic: ${idea.time}`;
      }
    },
    {
      id: "parallel",
      name: "Parallel Architect",
      icon: Layers,
      color: "#24e4ff",
      role: "Multiverse variants",
      transform: (idea, brief, lvl) => {
        const modes = [
          "Operator Mode (dense, fast, raw info)",
          "Investor Mode (clean, high-level, story-driven)",
          "Creator Mode (deep details, code-centric, exploratory)"
        ];
        const m1 = modes[Math.floor(Math.random() * modes.length)];
        const m2 = modes[Math.floor(Math.random() * modes.length)];
        idea.modes = `Create parallel modes: ${m1} vs ${m2}, both mapping to the same core engine but with radically different surface.`;
        idea.tags.push("modes", "personalization");
        return `Splits experience: ${idea.modes}`;
      }
    },
    {
      id: "fractal",
      name: "Fractal Engineer",
      icon: GitBranch,
      color: "#4eff8b",
      role: "Recursive structure",
      transform: (idea, brief, lvl) => {
        idea.structure = `Use fractal grouping: every view can collapse into a single card, and every card can expand into a full dashboard – same logic, different scale.`;
        idea.tags.push("fractal", "scalable");
        return `Applies fractal structure: ${idea.structure}`;
      }
    },
    {
      id: "arbiter",
      name: "Logic Arbiter",
      icon: Shield,
      color: "#00ff8a",
      role: "Stability & filter",
      transform: (idea, brief, lvl) => {
        idea.summary = `Filter all above into one coherent spec, keeping the wild aesthetics but enforcing: usability, legible hierarchy, and technical feasibility.`;
        idea.tags.push("stable", "implementable");
        return `Stabilizes & filters → ready as LVL${lvl} evolved concept.`;
      }
    }
  ];

  useEffect(() => {
    if (timelineEndRef.current) {
      timelineEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [timeline]);

  const runEvolutionLoop = async () => {
    if (isRunning) return;
    if (!brief.trim()) {
      alert("Please enter a brief first.");
      return;
    }

    setIsRunning(true);
    setTimeline([]);
    setFinalConcept("Evolution running...");
    setCurrentLevel(1);

    const maxLvl = 3;
    let lvl = 1;
    let idea = {
      brief: brief.trim(),
      core: null,
      flow: null,
      ui: null,
      glitch: null,
      shadow: null,
      time: null,
      modes: null,
      structure: null,
      summary: null,
      tags: []
    };

    const newTimeline = [];

    const runLevel = async () => {
      if (lvl > maxLvl) {
        finishEvolution(idea, maxLvl);
        return;
      }

      setCurrentLevel(lvl);

      for (let i = 0; i < brains.length; i++) {
        const brain = brains[i];
        const desc = brain.transform(idea, brief.trim(), lvl);
        
        newTimeline.push({
          brain,
          lvl,
          desc
        });

        setTimeline([...newTimeline]);
        await new Promise(resolve => setTimeout(resolve, 220));
      }

      lvl++;
      await new Promise(resolve => setTimeout(resolve, 400));
      await runLevel();
    };

    await runLevel();
  };

  const finishEvolution = (idea, maxLvl) => {
    setIsRunning(false);
    setCurrentLevel(0);

    const out = [];
    out.push(`BRIEF\n-----\n${idea.brief}\n`);
    out.push(`CORE CONCEPT (from Chaos)\n---------------------------\n${idea.core || "–"}\n`);
    out.push(`FLOW (Neuro Evolution)\n-----------------------\n${idea.flow || "–"}\n`);
    out.push(`UI / VISUAL LANGUAGE (Dream Renderer)\n--------------------------------------\n${idea.ui || "–"}\n`);
    out.push(`GLITCH BEHAVIOR (Glitch Engineer)\n----------------------------------\n${idea.glitch || "–"}\n`);
    out.push(`HIDDEN LAYER (Shadow Architect)\n--------------------------------\n${idea.shadow || "–"}\n`);
    out.push(`TIME BEHAVIOR (Temporal Engine)\n--------------------------------\n${idea.time || "–"}\n`);
    out.push(`PARALLEL MODES (Parallel Architect)\n------------------------------------\n${idea.modes || "–"}\n`);
    out.push(`STRUCTURE (Fractal Engineer)\n-----------------------------\n${idea.structure || "–"}\n`);
    out.push(`LOGIC ARBITER SUMMARY (LVL${maxLvl})\n------------------------------------\n${idea.summary || "–"}\n`);
    out.push(`TAGS\n----\n${idea.tags.join(", ")}`);

    setFinalConcept(out.join("\n\n"));
  };

  return (
    <div className="min-h-screen p-4 md:p-6" style={{
      background: 'radial-gradient(circle at 10% 0%, #041408 0%, #020504 55%, #000 100%)'
    }}>
      <style>{`
        @keyframes stepAppear {
          from {
            opacity: 0;
            transform: translateX(-10px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        .timeline-step {
          animation: stepAppear 0.3s ease-out;
        }

        .evolution-timeline::-webkit-scrollbar {
          width: 8px;
        }

        .evolution-timeline::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.3);
          border-radius: 4px;
        }

        .evolution-timeline::-webkit-scrollbar-thumb {
          background: rgba(0, 255, 138, 0.5);
          border-radius: 4px;
        }

        .evolution-timeline::-webkit-scrollbar-thumb:hover {
          background: rgba(0, 255, 138, 0.7);
        }
      `}</style>

      {/* Container */}
      <div className="max-w-[1040px] mx-auto rounded-3xl border p-4 md:p-6" style={{
        borderColor: 'rgba(200, 255, 190, 0.4)',
        background: 'radial-gradient(circle at 0% 0%, rgba(0,255,138,0.12), transparent 60%), radial-gradient(circle at 100% 100%, rgba(248,255,61,0.12), transparent 60%), rgba(2,8,4,0.98)',
        boxShadow: '0 0 40px rgba(0,0,0,0.7), 0 0 120px rgba(0,255,120,0.4)'
      }}>
        {/* Header */}
        <div className="flex justify-between items-start mb-4 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-5 h-5 rounded-full" style={{
              background: 'conic-gradient(from 0deg, #00ff8a, #f8ff3d, #00ff8a)',
              boxShadow: '0 0 15px rgba(0,255,138,0.9)'
            }} />
            <div>
              <div className="text-xs md:text-sm tracking-widest uppercase" style={{ color: 'rgba(232,255,220,0.94)' }}>
                THE ALMIGHTY COLLECTIVE
              </div>
              <div className="text-[0.65rem] md:text-xs tracking-wider uppercase" style={{ color: 'rgba(180,210,180,0.9)' }}>
                EVOLUTION LAB · 9-BRAIN LOOP
              </div>
            </div>
          </div>
          <div className="px-3 py-1.5 rounded-full border text-xs flex items-center gap-2" style={{
            borderColor: 'rgba(180,255,190,0.4)',
            color: '#b8ffd9'
          }}>
            <div className="w-2 h-2 rounded-full" style={{
              background: 'radial-gradient(circle, #00ff8a, #0c9151)',
              boxShadow: '0 0 8px rgba(0,255,138,0.9)'
            }} />
            <span>COUNCIL STATUS: {isRunning ? 'RUNNING' : 'READY'}</span>
          </div>
        </div>

        {/* Two Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Left Column */}
          <div className="space-y-4">
            {/* Input Brief Panel */}
            <div className="rounded-2xl border p-4" style={{
              borderColor: 'rgba(190,255,190,0.35)',
              background: 'linear-gradient(145deg, rgba(2,10,5,0.96), rgba(3,14,7,0.98))'
            }}>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-xs tracking-widest uppercase" style={{ color: '#b8ffd9' }}>
                  INPUT BRIEF
                </h3>
                <span className="text-[0.6rem]" style={{ color: '#98a89c' }}>
                  mit kell megoldani?
                </span>
              </div>
              <p className="text-[0.65rem] mb-3" style={{ color: '#98a89c' }}>
                Írj be egy rövid feladatot / modult (pl.: <em>"code marketplace AI pricing engine"</em>), a 9 agy ezen fog dolgozni.
              </p>
              <textarea
                value={brief}
                onChange={(e) => setBrief(e.target.value)}
                rows={4}
                disabled={isRunning}
                className="w-full rounded-xl border px-3 py-2 text-sm resize-vertical"
                style={{
                  borderColor: 'rgba(180,255,190,0.3)',
                  background: 'rgba(2,8,4,0.96)',
                  color: '#f6fff6'
                }}
                placeholder="Pl.: Build an AI-driven module that values and prices code assets..."
              />
              <div className="flex items-center justify-between gap-3 mt-3 flex-wrap">
                <button
                  onClick={runEvolutionLoop}
                  disabled={isRunning}
                  className="px-4 py-2 rounded-full text-xs font-semibold tracking-wider uppercase flex items-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'linear-gradient(135deg, #00ff8a, #f8ff3d)',
                    color: '#000',
                    boxShadow: isRunning ? 'none' : '0 0 18px rgba(0,255,138,0.65)'
                  }}
                >
                  {isRunning ? (
                    <>
                      <div className="w-3 h-3 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                      RUNNING...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3 h-3" />
                      RUN EVOLUTION LOOP
                    </>
                  )}
                </button>
                <div className="text-[0.65rem]" style={{ color: '#98a89c' }}>
                  LVL cycles: <span className="text-white">3</span> ·
                  Est. runtime: <span className="text-white">~30–45 sec</span>
                  {currentLevel > 0 && <span> · Current: <span className="text-yellow-400">LVL{currentLevel}</span></span>}
                </div>
              </div>
              <p className="text-[0.65rem] mt-2" style={{ color: '#98a89c' }}>
                <span style={{ color: '#00ff8a' }}>Tip:</span> később ide tudod bekötni az OpenAI-t → a végső koncepcióból konkrét kódot generálni.
              </p>
            </div>

            {/* Brain Council Panel */}
            <div className="rounded-2xl border p-4" style={{
              borderColor: 'rgba(190,255,190,0.35)',
              background: 'linear-gradient(145deg, rgba(2,10,5,0.96), rgba(3,14,7,0.98))'
            }}>
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-xs tracking-widest uppercase" style={{ color: '#b8ffd9' }}>
                  BRAIN COUNCIL
                </h3>
                <span className="text-[0.6rem]" style={{ color: '#98a89c' }}>
                  9 aktív modul
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {brains.map((brain, idx) => {
                  const Icon = brain.icon;
                  return (
                    <div
                      key={idx}
                      className="px-2 py-1 rounded-full border text-[0.62rem] flex items-center gap-1.5"
                      style={{
                        borderColor: `${brain.color}80`,
                        color: '#b8ffd9'
                      }}
                    >
                      <Icon className="w-3 h-3" style={{ color: brain.color }} />
                      {brain.name}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-4">
            {/* Evolution Timeline Panel */}
            <div className="rounded-2xl border p-4" style={{
              borderColor: 'rgba(190,255,190,0.35)',
              background: 'linear-gradient(145deg, rgba(2,10,5,0.96), rgba(3,14,7,0.98))'
            }}>
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-xs tracking-widest uppercase" style={{ color: '#b8ffd9' }}>
                  EVOLUTION TIMELINE
                </h3>
                <span className="text-[0.6rem]" style={{ color: isRunning ? '#f8ff3d' : '#98a89c' }}>
                  {isRunning ? 'RUNNING' : 'IDLE'}
                </span>
              </div>
              <div className="evolution-timeline max-h-[260px] overflow-y-auto pr-1 space-y-3">
                {timeline.map((step, idx) => {
                  const Icon = step.brain.icon;
                  return (
                    <div key={idx} className="timeline-step relative border-l-2 pl-3 ml-1" style={{ borderColor: 'rgba(0,255,138,0.5)' }}>
                      <div 
                        className="absolute left-[-5px] top-1 w-2 h-2 rounded-full"
                        style={{
                          background: 'radial-gradient(circle, #f8ff3d, #00ff8a)',
                          boxShadow: '0 0 8px rgba(0,255,138,0.8)'
                        }}
                      />
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[0.62rem] uppercase tracking-wider" style={{ color: '#f8ff3d' }}>
                          LVL{step.lvl} · {step.brain.name}
                        </span>
                        <Icon className="w-3 h-3" style={{ color: step.brain.color }} />
                      </div>
                      <div className="text-[0.64rem]" style={{ color: '#98a89c' }}>
                        {step.brain.role}
                      </div>
                      <div className="text-[0.68rem] mt-1" style={{ color: '#f6fff6' }}>
                        {step.desc}
                      </div>
                    </div>
                  );
                })}
                {timeline.length === 0 && (
                  <div className="text-center text-sm py-8" style={{ color: '#98a89c' }}>
                    No evolution steps yet. Click "RUN EVOLUTION LOOP" to start.
                  </div>
                )}
                <div ref={timelineEndRef} />
              </div>
            </div>

            {/* Final Evolved Concept Panel */}
            <div className="rounded-2xl border p-4" style={{
              borderColor: 'rgba(190,255,190,0.35)',
              background: 'linear-gradient(145deg, rgba(2,10,5,0.96), rgba(3,14,7,0.98))'
            }}>
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-xs tracking-widest uppercase" style={{ color: '#b8ffd9' }}>
                  FINAL EVOLVED CONCEPT (LVL2+)
                </h3>
                <span className="text-[0.6rem]" style={{ color: '#98a89c' }}>
                  alap a high-end kódhoz
                </span>
              </div>
              <pre className="rounded-xl border p-3 text-[0.68rem] whitespace-pre-wrap max-h-[300px] overflow-y-auto" style={{
                borderColor: 'rgba(0,255,138,0.5)',
                background: 'radial-gradient(circle at 0% 0%, rgba(0,255,138,0.16), transparent 60%)',
                color: '#f6fff6'
              }}>
                {finalConcept}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}