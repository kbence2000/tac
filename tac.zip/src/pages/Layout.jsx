
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Code2, LogOut, User, FileCode, Menu, X, Home, Package, 
  Crown, Building, TrendingUp, Sparkles, Shield, Users,
  MessageSquare, BarChart3, Zap
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { BackgroundSettingsProvider } from "@/components/BackgroundSettingsContext";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    initialData: null,
  });

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', path: 'Home', icon: Home },
    { name: 'Code Vault', path: 'CodeRepository', icon: FileCode },
    { name: 'Marketplace', path: 'Marketplace', icon: Package },
    { name: 'Demigods', path: 'DemigodHub', icon: Crown },
    { name: 'Enterprise', path: 'CompanyPortal', icon: Building },
  ];

  return (
    <BackgroundSettingsProvider>
      <div className="min-h-screen" style={{ 
        background: 'radial-gradient(ellipse at top, #1a0f2e 0%, #0a0514 30%, #02000c 70%)',
        backgroundAttachment: 'fixed'
      }}>
        <style>{`
          .nav-glow {
            position: relative;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
  
          .nav-glow::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: -2px;
            height: 2px;
            width: 0;
            background: linear-gradient(90deg, #24e4ff, #b788ff);
            border-radius: 2px;
            transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
  
          .nav-glow:hover::after,
          .nav-glow.active::after {
            width: 100%;
          }
  
          .logo-pulse {
            animation: pulse-glow 3s ease-in-out infinite;
          }
  
          @keyframes pulse-glow {
            0%, 100% {
              box-shadow: 0 0 20px rgba(139, 92, 255, 0.4);
            }
            50% {
              box-shadow: 0 0 40px rgba(139, 92, 255, 0.8);
            }
          }
  
          .header-blur {
            backdrop-filter: blur(20px) saturate(180%);
            background: rgba(2, 0, 12, 0.85);
            border-bottom: 1px solid rgba(183, 136, 255, 0.15);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
  
          .header-scrolled {
            backdrop-filter: blur(30px) saturate(200%);
            background: rgba(2, 0, 12, 0.95);
            border-bottom: 1px solid rgba(183, 136, 255, 0.3);
            box-shadow: 0 8px 32px rgba(139, 92, 255, 0.15);
          }
  
          .mobile-menu {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            width: 85%;
            max-width: 320px;
            background: rgba(2, 0, 12, 0.98);
            backdrop-filter: blur(30px) saturate(200%);
            border-left: 1px solid rgba(183, 136, 255, 0.2);
            transform: translateX(100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            overflow-y: auto;
          }
  
          .mobile-menu.open {
            transform: translateX(0);
          }
  
          .mobile-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(4px);
            z-index: 999;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
  
          .mobile-overlay.open {
            opacity: 1;
            pointer-events: auto;
          }
  
          .user-badge {
            background: rgba(183, 136, 255, 0.1);
            border: 1px solid rgba(183, 136, 255, 0.3);
            backdrop-filter: blur(10px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
  
          .user-badge:hover {
            background: rgba(183, 136, 255, 0.2);
            border-color: rgba(183, 136, 255, 0.5);
            box-shadow: 0 0 20px rgba(139, 92, 255, 0.3);
          }
  
          @media (max-width: 768px) {
            header {
              position: sticky;
              top: 0;
              z-index: 100;
            }
          }
        `}</style>
        
        {/* Header */}
        <header className={`sticky top-0 z-50 header-blur ${scrolled ? 'header-scrolled' : ''}`}>
          <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-3">
            <div className="flex items-center justify-between gap-4">
              {/* Logo */}
              <Link to={createPageUrl("Home")} className="flex items-center gap-3 group">
                <div 
                  className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl logo-pulse flex items-center justify-center relative overflow-hidden transition-transform duration-300 group-hover:scale-110" 
                  style={{ 
                    background: 'radial-gradient(circle at 20% 20%, rgba(255, 255, 255, 0.4), #4d0d6f 40%, #2a0742)',
                    border: '2px solid rgba(183, 136, 255, 0.4)'
                  }}
                >
                  <div className="absolute inset-[2px] rounded-[14px] border border-white/20" />
                  <Code2 className="w-5 h-5 sm:w-6 sm:h-6 text-white relative z-10" />
                </div>
                <div className="hidden sm:block">
                  <div className="text-lg sm:text-xl font-black tracking-[0.09em] uppercase leading-none text-white">
                    MadDevCity
                  </div>
                  <div className="text-[9px] sm:text-[10px] tracking-[0.21em] uppercase leading-none mt-0.5 text-gradient">
                    Code Demigods
                  </div>
                </div>
              </Link>
  
              {/* Desktop Navigation */}
              <nav className="hidden lg:flex items-center gap-6 text-sm">
                {navItems.map(item => {
                  const Icon = item.icon;
                  const isActive = location.pathname === createPageUrl(item.path);
                  return (
                    <Link
                      key={item.path}
                      to={createPageUrl(item.path)}
                      className={`nav-glow flex items-center gap-2 px-1 py-2 ${
                        isActive ? 'active text-white' : 'text-gray-400 hover:text-white'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
  
              {/* User Actions */}
              <div className="hidden md:flex items-center gap-3">
                {user ? (
                  <>
                    <div className="user-badge flex items-center gap-2 px-4 py-2 rounded-full">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
                        <User className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-white text-sm font-semibold max-w-[120px] truncate">
                        {user.full_name || user.email?.split('@')[0]}
                      </span>
                    </div>
                    <button 
                      onClick={() => base44.auth.logout()}
                      className="w-10 h-10 rounded-full flex items-center justify-center transition-all hover:bg-white/5 hover:scale-110"
                      style={{ border: '1px solid rgba(183, 136, 255, 0.3)' }}
                    >
                      <LogOut className="w-4 h-4 text-gray-400" />
                    </button>
                  </>
                ) : (
                  <button 
                    onClick={() => base44.auth.redirectToLogin()}
                    className="btn-primary btn-sm"
                  >
                    Sign In
                  </button>
                )}
              </div>
  
              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(true)}
                className="md:hidden w-10 h-10 rounded-full border flex items-center justify-center transition-all hover:border-[var(--mdc-neon-cyan)] hover:bg-white/5"
                style={{ borderColor: 'rgba(183, 136, 255, 0.3)' }}
              >
                <Menu className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </div>
        </header>
  
        {/* Mobile Overlay */}
        <div 
          className={`mobile-overlay ${mobileMenuOpen ? 'open' : ''}`} 
          onClick={() => setMobileMenuOpen(false)} 
        />
  
        {/* Mobile Menu */}
        <div className={`mobile-menu ${mobileMenuOpen ? 'open' : ''}`}>
          <div className="p-6">
            {/* Close Button */}
            <button 
              onClick={() => setMobileMenuOpen(false)} 
              className="absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center transition-all hover:bg-white/10"
              style={{ 
                background: 'rgba(10, 5, 32, 0.9)', 
                border: '1px solid rgba(183, 136, 255, 0.3)' 
              }}
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
  
            {/* Logo */}
            <div className="mb-8">
              <div className="text-xl font-black tracking-wide uppercase text-white">MadDevCity</div>
              <div className="text-xs tracking-widest uppercase mt-1 text-gradient">Code Demigods</div>
            </div>
  
            {/* User Info */}
            {user && (
              <div className="mb-6 p-4 rounded-2xl border card-glass animate-fade-in">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="text-white font-bold text-sm">
                      {user.full_name || 'Developer'}
                    </div>
                    <div className="text-gray-400 text-xs">{user.email}</div>
                  </div>
                </div>
              </div>
            )}
  
            {/* Navigation Links */}
            <nav className="space-y-2">
              {navItems.map((item, idx) => {
                const Icon = item.icon;
                const isActive = location.pathname === createPageUrl(item.path);
                return (
                  <Link
                    key={item.path}
                    to={createPageUrl(item.path)}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      isActive 
                        ? 'bg-gradient-to-r from-purple-900/50 to-cyan-900/30 border-purple-500/50 text-white' 
                        : 'border-white/5 text-gray-400 hover:text-white hover:border-white/10'
                    }`}
                    style={{ 
                      border: '1px solid',
                      animationDelay: `${idx * 0.05}s`,
                      animation: 'slideInRight 0.3s ease forwards'
                    }}
                  >
                    <Icon className={`w-5 h-5 ${isActive ? 'text-cyan-400' : ''}`} />
                    <span className="font-medium">{item.name}</span>
                  </Link>
                );
              })}
            </nav>
  
            {/* Auth Actions */}
            <div className="mt-8 pt-6 border-t" style={{ borderColor: 'rgba(183, 136, 255, 0.2)' }}>
              {user ? (
                <button 
                  onClick={() => { 
                    base44.auth.logout(); 
                    setMobileMenuOpen(false); 
                  }} 
                  className="flex items-center gap-3 px-4 py-3 rounded-xl w-full transition-all text-gray-400 hover:text-white hover:bg-white/5"
                  style={{ border: '1px solid rgba(183, 136, 255, 0.2)' }}
                >
                  <LogOut className="w-5 h-5" />
                  <span className="font-medium">Sign Out</span>
                </button>
              ) : (
                <button 
                  onClick={() => { 
                    base44.auth.redirectToLogin(); 
                    setMobileMenuOpen(false); 
                  }} 
                  className="btn-neon w-full flex items-center justify-center gap-3 py-3"
                >
                  <User className="w-5 h-5" />
                  <span>Sign In</span>
                </button>
              )}
            </div>
          </div>
        </div>
  
        {/* Main Content */}
        <main className="animate-fade-in">
          {children}
        </main>
  
        {/* Footer */}
        <footer className="mt-20 border-t px-4 py-8" style={{ borderColor: 'rgba(183, 136, 255, 0.15)' }}>
          <div className="max-w-[1440px] mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              {/* Brand */}
              <div className="md:col-span-2">
                <div className="flex items-center gap-3 mb-4">
                  <div 
                    className="w-10 h-10 rounded-xl logo-pulse flex items-center justify-center" 
                    style={{ 
                      background: 'radial-gradient(circle at 20% 20%, rgba(255, 255, 255, 0.3), #4d0d6f)',
                      border: '1px solid rgba(183, 136, 255, 0.3)'
                    }}
                  >
                    <Code2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="font-black text-white">MadDevCity</div>
                    <div className="text-xs text-gray-400">Where Code Demigods Rise</div>
                  </div>
                </div>
                <p className="text-sm text-gray-400 max-w-md">
                  AI-powered development platform connecting elite developers with enterprise missions.
                </p>
              </div>
  
              {/* Quick Links */}
              <div>
                <h4 className="font-bold text-white mb-4 text-sm">Platform</h4>
                <div className="space-y-2 text-sm">
                  <Link to={createPageUrl("Marketplace")} className="block text-gray-400 hover:text-cyan-400 transition-colors">
                    Marketplace
                  </Link>
                  <Link to={createPageUrl("DemigodHub")} className="block text-gray-400 hover:text-cyan-400 transition-colors">
                    Demigods
                  </Link>
                  <Link to={createPageUrl("CompanyPortal")} className="block text-gray-400 hover:text-cyan-400 transition-colors">
                    Enterprise
                  </Link>
                </div>
              </div>
  
              {/* Resources */}
              <div>
                <h4 className="font-bold text-white mb-4 text-sm">Resources</h4>
                <div className="space-y-2 text-sm">
                  <a href="#" className="block text-gray-400 hover:text-cyan-400 transition-colors">
                    Documentation
                  </a>
                  <a href="#" className="block text-gray-400 hover:text-cyan-400 transition-colors">
                    API Reference
                  </a>
                  <a href="#" className="block text-gray-400 hover:text-cyan-400 transition-colors">
                    Support
                  </a>
                </div>
              </div>
            </div>
  
            {/* Bottom Bar */}
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-8 border-t" style={{ borderColor: 'rgba(183, 136, 255, 0.1)' }}>
              <div className="flex flex-wrap justify-center sm:justify-start items-center gap-4 text-xs text-gray-400">
                <span className="mono-font">© 2025 MadDevCity</span>
                <span className="hidden sm:inline">•</span>
                <span>All Rights Reserved</span>
              </div>
              <div className="flex gap-6 text-xs">
                <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">Terms</a>
                <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">Privacy</a>
                <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">Security</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </BackgroundSettingsProvider>
  );
}
