import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Plus, X, Star, Briefcase, Sparkles, Linkedin, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

export default function MyExpertProfile() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: existingProfiles } = useQuery({
    queryKey: ['myExpertProfile', user?.email],
    queryFn: () => base44.entities.ExpertProfile.filter({ user_email: user.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const existingProfile = existingProfiles[0];

  const [formData, setFormData] = useState({
    headline: existingProfile?.headline || "",
    pitch: existingProfile?.pitch || "",
    bio: existingProfile?.bio || "",
    hourly_rate: existingProfile?.hourly_rate || 0,
    experience_level: existingProfile?.experience_level || "mid",
    linkedin_url: existingProfile?.linkedin_url || "",
    available: existingProfile?.available !== false
  });

  const [skills, setSkills] = useState(existingProfile?.skills || []);
  const [newSkill, setNewSkill] = useState("");
  const [portfolioLinks, setPortfolioLinks] = useState(existingProfile?.portfolio_links || []);
  const [newPortfolio, setNewPortfolio] = useState("");
  const [linkedinSyncing, setLinkedinSyncing] = useState(false);

  const saveProfileMutation = useMutation({
    mutationFn: async (profileData) => {
      if (existingProfile) {
        return await base44.entities.ExpertProfile.update(existingProfile.id, profileData);
      } else {
        return await base44.entities.ExpertProfile.create({
          ...profileData,
          user_email: user.email
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myExpertProfile'] });
      queryClient.invalidateQueries({ queryKey: ['expertProfiles'] });
      toast.success("Profil sikeresen mentve!");
    },
    onError: () => {
      toast.error("Hiba a mentés során!");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.headline) {
      toast.error("A headline mező kötelező!");
      return;
    }

    saveProfileMutation.mutate({
      ...formData,
      skills,
      portfolio_links: portfolioLinks
    });
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill("");
    }
  };

  const removeSkill = (skill) => {
    setSkills(skills.filter(s => s !== skill));
  };

  const addPortfolio = () => {
    if (newPortfolio.trim() && !portfolioLinks.includes(newPortfolio.trim())) {
      setPortfolioLinks([...portfolioLinks, newPortfolio.trim()]);
      setNewPortfolio("");
    }
  };

  const removePortfolio = (link) => {
    setPortfolioLinks(portfolioLinks.filter(l => l !== link));
  };

  const syncLinkedIn = async () => {
    if (!formData.linkedin_url) {
      toast.error("Adj meg egy LinkedIn profil URL-t!");
      return;
    }

    setLinkedinSyncing(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Extract professional information from this LinkedIn profile URL: ${formData.linkedin_url}
        
Please provide:
- headline (professional title/position)
- bio (summary/about section, 2-3 sentences)
- skills (array of technical skills)
- experience_level (junior/mid/senior/lead based on years and roles)
- portfolio_links (any GitHub, personal website, or portfolio links mentioned)

Return ONLY valid JSON, no markdown.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            headline: { type: "string" },
            bio: { type: "string" },
            skills: { type: "array", items: { type: "string" } },
            experience_level: { type: "string", enum: ["junior", "mid", "senior", "lead"] },
            portfolio_links: { type: "array", items: { type: "string" } }
          }
        }
      });

      if (response) {
        setFormData(prev => ({
          ...prev,
          headline: response.headline || prev.headline,
          bio: response.bio || prev.bio,
          experience_level: response.experience_level || prev.experience_level
        }));

        if (response.skills && response.skills.length > 0) {
          setSkills(response.skills);
        }

        if (response.portfolio_links && response.portfolio_links.length > 0) {
          setPortfolioLinks(response.portfolio_links);
        }

        toast.success("LinkedIn profil sikeresen szinkronizálva!");
      }
    } catch (error) {
      console.error('LinkedIn sync error:', error);
      toast.error("Hiba a LinkedIn szinkronizálás során");
    } finally {
      setLinkedinSyncing(false);
    }
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Link to={createPageUrl("ExpertMarketplace")}>
          <Button variant="ghost" className="mb-6 text-gray-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Vissza
          </Button>
        </Link>

        <div className="mb-8">
          <h1 className="text-4xl font-black text-white mb-2">Szakértői Profilom</h1>
          <p className="text-gray-400">Állítsd be a szakértői profilodat és tedd láthatóvá magad</p>
          
          {existingProfile && (
            <div className="flex items-center gap-4 mt-4">
              <Badge className="bg-green-600/20 text-green-400 border border-green-600/30">
                <Star className="w-3 h-3 mr-1" />
                {existingProfile.rating?.toFixed(1) || '0.0'} értékelés
              </Badge>
              <Badge className="bg-blue-600/20 text-blue-400 border border-blue-600/30">
                <Briefcase className="w-3 h-3 mr-1" />
                {existingProfile.completed_tasks || 0} befejezett feladat
              </Badge>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* LinkedIn Sync */}
          <Card className="border p-6" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex items-center gap-3 mb-4">
              <Linkedin className="w-6 h-6 text-[#0077b5]" />
              <div>
                <h3 className="text-lg font-bold text-white">LinkedIn Szinkronizálás</h3>
                <p className="text-sm text-gray-400">Importáld automatikusan a LinkedIn profilod adatait</p>
              </div>
            </div>

            <div className="flex gap-3">
              <Input
                type="url"
                placeholder="https://linkedin.com/in/yourprofile"
                value={formData.linkedin_url}
                onChange={(e) => handleChange('linkedin_url', e.target.value)}
                className="flex-1 border text-white"
                style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
              />
              <Button
                type="button"
                onClick={syncLinkedIn}
                disabled={linkedinSyncing || !formData.linkedin_url}
                className="font-bold"
                style={{
                  background: 'linear-gradient(135deg, #0077b5, #00a0dc)',
                  color: 'white'
                }}
              >
                {linkedinSyncing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Szinkronizálás...
                  </>
                ) : (
                  <>
                    <Linkedin className="w-4 h-4 mr-2" />
                    Szinkronizálás
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Pitch - Prominens */}
          <Card className="border p-6" style={{
            background: 'radial-gradient(circle at 0 0, rgba(139, 92, 255, 0.15), transparent 70%), rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(139, 92, 255, 0.5)',
            boxShadow: '0 0 30px rgba(139, 92, 255, 0.3)'
          }}>
            <div className="flex items-center gap-3 mb-4">
              <Sparkles className="w-6 h-6" style={{ color: 'var(--accent-alt)' }} />
              <div>
                <h3 className="text-lg font-bold text-white">Mi jár a fejedben?</h3>
                <p className="text-sm text-gray-400">1 mondatos figyelemfelkeltő bemutatkozás - Ez jelenik meg először!</p>
              </div>
            </div>

            <Textarea
              placeholder='Pl: "Nem kódolok, hanem építek digitális élményeket amik számítanak." vagy "AI + Blockchain = a jövő, és én itt vagyok."'
              value={formData.pitch}
              onChange={(e) => handleChange('pitch', e.target.value)}
              className="border text-white min-h-[80px]"
              style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
              maxLength={200}
            />
            <p className="text-xs text-gray-500 mt-2">
              {formData.pitch?.length || 0}/200 karakter
            </p>
          </Card>

          {/* Basic Info */}
          <Card className="border p-6" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <h3 className="text-lg font-bold text-white mb-4">Alapinformációk</h3>

            <div className="space-y-4">
              <div>
                <Label className="text-white mb-2 block">Headline (Pozíció/Cím) *</Label>
                <Input
                  type="text"
                  placeholder="pl. Senior Full-Stack Developer"
                  value={formData.headline}
                  onChange={(e) => handleChange('headline', e.target.value)}
                  className="border text-white"
                  style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
                  required
                />
              </div>

              <div>
                <Label className="text-white mb-2 block">Bemutatkozás</Label>
                <Textarea
                  placeholder="Írj magadról részletesebben..."
                  value={formData.bio}
                  onChange={(e) => handleChange('bio', e.target.value)}
                  className="border text-white min-h-[120px]"
                  style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white mb-2 block">Óradíj (EUR)</Label>
                  <Input
                    type="number"
                    min="0"
                    placeholder="50"
                    value={formData.hourly_rate}
                    onChange={(e) => handleChange('hourly_rate', Number(e.target.value))}
                    className="border text-white"
                    style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Tapasztalati Szint</Label>
                  <Select value={formData.experience_level} onValueChange={(value) => handleChange('experience_level', value)}>
                    <SelectTrigger className="border text-white" style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="junior">Junior</SelectItem>
                      <SelectItem value="mid">Mid-Level</SelectItem>
                      <SelectItem value="senior">Senior</SelectItem>
                      <SelectItem value="lead">Lead/Principal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Availability Toggle */}
              <div className="flex items-center gap-3 p-4 rounded-lg border" style={{
                background: 'rgba(11, 16, 32, 0.9)',
                borderColor: 'rgba(148, 163, 184, 0.35)'
              }}>
                <input
                  type="checkbox"
                  id="available"
                  checked={formData.available}
                  onChange={(e) => handleChange('available', e.target.checked)}
                  className="w-5 h-5 rounded"
                  style={{ accentColor: 'var(--accent)' }}
                />
                <label htmlFor="available" className="text-white font-medium cursor-pointer">
                  Elérhető vagyok új projektekhez
                </label>
              </div>
            </div>
          </Card>

          {/* Skills */}
          <Card className="border p-6" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <h3 className="text-lg font-bold text-white mb-4">Készségek</h3>

            <div className="flex gap-2 mb-3">
              <Input
                type="text"
                placeholder="React, Node.js, TypeScript..."
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                className="flex-1 border text-white"
                style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
              />
              <Button type="button" onClick={addSkill} style={{ background: 'var(--accent)', color: 'white' }}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex flex-wrap gap-2">
              {skills.map(skill => (
                <Badge key={skill} className="text-sm px-3 py-1" style={{ background: 'rgba(139, 92, 255, 0.2)', border: '1px solid rgba(139, 92, 255, 0.5)' }}>
                  {skill}
                  <button type="button" onClick={() => removeSkill(skill)} className="ml-2 text-gray-400 hover:text-white">
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </Card>

          {/* Portfolio */}
          <Card className="border p-6" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <h3 className="text-lg font-bold text-white mb-4">Portfolio Linkek</h3>

            <div className="flex gap-2 mb-3">
              <Input
                type="url"
                placeholder="https://github.com/yourprofile"
                value={newPortfolio}
                onChange={(e) => setNewPortfolio(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addPortfolio())}
                className="flex-1 border text-white"
                style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
              />
              <Button type="button" onClick={addPortfolio} style={{ background: 'var(--accent)', color: 'white' }}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            <div className="space-y-2">
              {portfolioLinks.map(link => (
                <div key={link} className="flex items-center justify-between p-3 rounded-lg border" style={{
                  background: 'rgba(11, 16, 32, 0.9)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  <a href={link} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-400 hover:underline truncate">
                    {link}
                  </a>
                  <button type="button" onClick={() => removePortfolio(link)} className="text-gray-400 hover:text-white ml-2">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </Card>

          {/* Submit */}
          <div className="flex gap-4">
            <Link to={createPageUrl("ExpertMarketplace")} className="flex-1">
              <Button type="button" variant="outline" className="w-full border text-white" style={{ borderColor: 'rgba(148, 163, 184, 0.35)' }}>
                Mégse
              </Button>
            </Link>
            <Button
              type="submit"
              disabled={saveProfileMutation.isPending}
              className="flex-1 font-bold"
              style={{
                background: 'radial-gradient(circle at 0 0, var(--accent-alt), transparent 45%), var(--accent)',
                color: 'white'
              }}
            >
              {saveProfileMutation.isPending ? 'Mentés...' : 'Profil Mentése'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}