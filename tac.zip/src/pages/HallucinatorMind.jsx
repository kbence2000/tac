import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Brain, Zap, Loader2, TrendingUp, Eye, AlertTriangle, Wand2 } from 'lucide-react';

export default function HallucinatorMind() {
  const [brief, setBrief] = useState("Design a code marketplace where algorithms compete in gladiator-style battles for developer attention.");
  const [wildness, setWildness] = useState(5);
  const [context, setContext] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [hallucinationResult, setHallucinationResult] = useState(null);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);

  // Animated background particles
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = [];
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        radius: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.2
      });
    }

    let animationId;
    const animate = () => {
      ctx.fillStyle = 'rgba(2, 6, 23, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(168, 85, 247, ${p.opacity})`;
        ctx.fill();
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const runHallucination = async () => {
    if (isRunning || !brief.trim()) return;

    setIsRunning(true);
    setError(null);
    setHallucinationResult(null);

    try {
      const response = await fetch('http://localhost:7070/api/hallucinator/imagine', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          brief,
          wildness,
          context: context || undefined
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error(data.error || 'Unknown backend error');
      }

      setHallucinationResult(data.hallucination || null);

    } catch (err) {
      console.error('Hallucinator Mind error:', err);
      setError(err.message);
    } finally {
      setIsRunning(false);
    }
  };

  const getWildnessLabel = (level) => {
    if (level <= 2) return "Subtle";
    if (level <= 4) return "Moderate";
    if (level <= 6) return "Creative";
    if (level <= 8) return "Surreal";
    return "Extreme";
  };

  const getWildnessColor = (level) => {
    if (level <= 2) return "#3b82f6";
    if (level <= 4) return "#22c55e";
    if (level <= 6) return "#a855f7";
    if (level <= 8) return "#f97316";
    return "#ef4444";
  };

  return (
    <div className="relative min-h-screen overflow-hidden" style={{
      background: 'radial-gradient(circle at 20% 0%, #1a0f2e 0%, #0a0514 30%, #02000c 70%)'
    }}>
      <style>{`
        @keyframes pulseGlow {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }

        @keyframes shimmer {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }

        .hallucinator-badge {
          animation: pulseGlow 2s ease-in-out infinite;
        }

        .concept-card {
          animation: float 3s ease-in-out infinite;
        }

        .shimmer-text {
          background: linear-gradient(90deg, #a855f7, #ec4899, #8b5cf6, #a855f7);
          background-size: 200% 100%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmer 3s linear infinite;
        }
      `}</style>

      {/* Animated Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ opacity: 0.4 }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-[1400px] mx-auto px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Brain className="w-10 h-10 text-purple-400 hallucinator-badge" />
            <h1 className="text-4xl md:text-5xl font-black tracking-wider uppercase shimmer-text">
              HALLUCINATOR MIND
            </h1>
            <Wand2 className="w-10 h-10 text-pink-400 hallucinator-badge" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide mb-2">
            DM-0 · Controlled Hallucination Engine
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
            style={{
              background: 'rgba(168, 85, 247, 0.2)',
              border: '1px solid rgba(168, 85, 247, 0.5)',
              boxShadow: '0 0 20px rgba(168, 85, 247, 0.4)'
            }}
          >
            <Sparkles className="w-3 h-3" />
            Extreme Creativity · Non-Linear Concepts
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border"
          style={{
            background: 'rgba(168, 85, 247, 0.1)',
            borderColor: 'rgba(168, 85, 247, 0.3)'
          }}
        >
          <div className="flex items-start gap-3">
            <Eye className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <span className="font-bold text-purple-300">What is Hallucinator Mind?</span> 
              <br />
              A controlled hallucination engine that generates surreal, non-linear, unexpected concept jumps. 
              It produces wild, creative ideas that other modules (Order Council, Paradox Engine) can later refine and stabilize.
              Works alongside Nine Minds, Distorted Synergy, and Paradox Engine.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure the backend server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node hallucinator-mind-server.js</code>
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Input Controls */}
          <div className="space-y-4">
            <div className="rounded-2xl border p-6"
              style={{
                borderColor: 'rgba(168, 85, 247, 0.3)',
                background: 'rgba(7, 7, 18, 0.95)',
                boxShadow: '0 0 40px rgba(0, 0, 0, 0.7)'
              }}
            >
              <label className="block text-xs tracking-widest uppercase text-purple-400 mb-3">
                CREATIVE BRIEF
              </label>
              <textarea
                value={brief}
                onChange={(e) => setBrief(e.target.value)}
                disabled={isRunning}
                rows={4}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="Enter your concept to hallucinate on..."
              />

              <label className="block text-xs tracking-widest uppercase text-purple-400 mb-3">
                CONTEXT (Optional)
              </label>
              <textarea
                value={context}
                onChange={(e) => setContext(e.target.value)}
                disabled={isRunning}
                rows={2}
                className="w-full rounded-xl border px-4 py-3 text-sm resize-none mb-4"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.4)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="Previous outputs from other minds..."
              />

              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs tracking-widest uppercase text-purple-400">
                    WILDNESS LEVEL
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">{wildness}</span>
                    <span 
                      className="text-xs font-bold px-2 py-0.5 rounded-full"
                      style={{
                        color: getWildnessColor(wildness),
                        background: `${getWildnessColor(wildness)}20`,
                        border: `1px solid ${getWildnessColor(wildness)}40`
                      }}
                    >
                      {getWildnessLabel(wildness)}
                    </span>
                  </div>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={wildness}
                  onChange={(e) => setWildness(parseInt(e.target.value))}
                  disabled={isRunning}
                  className="w-full"
                  style={{
                    accentColor: getWildnessColor(wildness)
                  }}
                />
                <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                  <span>Subtle</span>
                  <span>Moderate</span>
                  <span>Creative</span>
                  <span>Surreal</span>
                  <span>Extreme</span>
                </div>
              </div>

              <button
                onClick={runHallucination}
                disabled={isRunning}
                className="w-full py-3 rounded-full text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #a855f7, #ec4899)',
                  color: '#fff',
                  boxShadow: isRunning ? 'none' : '0 0 30px rgba(168, 85, 247, 0.7)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    HALLUCINATING...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5" />
                    GENERATE HALLUCINATION
                  </>
                )}
              </button>
            </div>

            {/* Mind Context */}
            <div className="rounded-2xl border p-4"
              style={{
                borderColor: 'rgba(168, 85, 247, 0.3)',
                background: 'rgba(7, 7, 18, 0.95)'
              }}
            >
              <h3 className="text-xs tracking-widest uppercase text-purple-400 mb-3 flex items-center gap-2">
                <Brain className="w-4 h-4" />
                ADJACENT MINDS
              </h3>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div>
                  <div className="text-blue-400 font-semibold mb-1">ORDER (9 Minds)</div>
                  <div className="text-gray-500 space-y-0.5">
                    <div>Origin Pulse</div>
                    <div>Logic Weaver</div>
                    <div>Convergence Core</div>
                    <div className="text-gray-600">+6 more...</div>
                  </div>
                </div>
                <div>
                  <div className="text-red-400 font-semibold mb-1">DISTORTED (9 Minds)</div>
                  <div className="text-gray-500 space-y-0.5">
                    <div>Mirrorbreaker</div>
                    <div>Logic Bender</div>
                    <div>Abyssal Mind</div>
                    <div className="text-gray-600">+6 more...</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Output */}
          <div>
            <div className="rounded-2xl border p-6 h-full"
              style={{
                borderColor: 'rgba(168, 85, 247, 0.4)',
                background: 'rgba(7, 7, 18, 0.95)',
                boxShadow: '0 0 60px rgba(168, 85, 247, 0.2)'
              }}
            >
              <h3 className="text-xs tracking-widest uppercase text-purple-400 mb-4 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                HALLUCINATION OUTPUT
              </h3>

              {!hallucinationResult && !isRunning && (
                <div className="text-center py-12">
                  <Brain className="w-16 h-16 mx-auto mb-4 text-purple-400/30" />
                  <p className="text-sm text-gray-500">
                    No hallucination generated yet.
                    <br />
                    Enter a brief and click "Generate Hallucination".
                  </p>
                </div>
              )}

              {isRunning && (
                <div className="text-center py-12">
                  <Loader2 className="w-16 h-16 mx-auto mb-4 text-purple-400 animate-spin" />
                  <p className="text-sm text-gray-400">
                    DM-0 is generating surreal concepts...
                  </p>
                </div>
              )}

              {hallucinationResult && (
                <div className="space-y-4 max-h-[600px] overflow-y-auto">
                  {/* Summary */}
                  <div className="concept-card p-4 rounded-xl"
                    style={{
                      background: 'rgba(168, 85, 247, 0.1)',
                      border: '1px solid rgba(168, 85, 247, 0.3)',
                      animationDelay: '0s'
                    }}
                  >
                    <div className="text-xs font-bold text-purple-300 mb-2">SUMMARY</div>
                    <div className="text-sm text-white">{hallucinationResult.summary}</div>
                  </div>

                  {/* Surreal Concepts */}
                  {hallucinationResult.surrealConcepts && (
                    <div className="concept-card"
                      style={{ animationDelay: '0.2s' }}
                    >
                      <div className="text-xs font-bold text-pink-300 mb-2">SURREAL CONCEPTS</div>
                      <ul className="space-y-2">
                        {hallucinationResult.surrealConcepts.map((concept, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs text-gray-300 p-3 rounded-lg"
                            style={{
                              background: 'rgba(236, 72, 153, 0.1)',
                              border: '1px solid rgba(236, 72, 153, 0.2)'
                            }}
                          >
                            <Sparkles className="w-3 h-3 text-pink-400 mt-0.5 flex-shrink-0" />
                            <span>{concept}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Metaphors */}
                  {hallucinationResult.metaphors && (
                    <div className="concept-card"
                      style={{ animationDelay: '0.4s' }}
                    >
                      <div className="text-xs font-bold text-cyan-300 mb-2">METAPHORS & ANALOGIES</div>
                      <div className="space-y-2">
                        {hallucinationResult.metaphors.map((metaphor, i) => (
                          <div key={i} className="text-xs text-gray-300 p-3 rounded-lg"
                            style={{
                              background: 'rgba(34, 211, 238, 0.1)',
                              border: '1px solid rgba(34, 211, 238, 0.2)'
                            }}
                          >
                            {metaphor}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Unexpected Angles */}
                  {hallucinationResult.unexpectedAngles && (
                    <div className="concept-card"
                      style={{ animationDelay: '0.6s' }}
                    >
                      <div className="text-xs font-bold text-yellow-300 mb-2">UNEXPECTED ANGLES</div>
                      <div className="space-y-2">
                        {hallucinationResult.unexpectedAngles.map((angle, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-gray-300 p-3 rounded-lg"
                            style={{
                              background: 'rgba(234, 179, 8, 0.1)',
                              border: '1px solid rgba(234, 179, 8, 0.2)'
                            }}
                          >
                            <Zap className="w-3 h-3 text-yellow-400 mt-0.5 flex-shrink-0" />
                            <span>{angle}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Risk Assessment */}
                  {hallucinationResult.riskNote && (
                    <div className="concept-card p-3 rounded-lg"
                      style={{
                        background: 'rgba(239, 68, 68, 0.1)',
                        border: '1px solid rgba(239, 68, 68, 0.3)',
                        animationDelay: '0.8s'
                      }}
                    >
                      <div className="flex items-start gap-2 text-xs text-gray-300">
                        <AlertTriangle className="w-3 h-3 text-red-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <span className="font-bold text-red-300">Risk Note:</span> {hallucinationResult.riskNote}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>Hallucinator Mind (DM-0) · Controlled Hallucination Engine</p>
          <p className="mt-1">Backend: http://localhost:7070/api/hallucinator/imagine</p>
        </div>
      </div>
    </div>
  );
}