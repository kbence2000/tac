import React, { useState } from 'react';
import CodeRepoTopBar from '../components/CodeRepoTopBar';
import CodeRepoSidebar from '../components/CodeRepoSidebar';
import CodeRepoViewer from '../components/CodeRepoViewer';

export default function CodeRepository() {
  const [selectedRepo, setSelectedRepo] = useState('tac-core-system');
  const [selectedFile, setSelectedFile] = useState('src/paradoxEngine.js');

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-slate-950 to-[#170022] text-slate-100">
      <style>{`
        .perspective-3d {
          perspective: 1800px;
          perspective-origin: 50% 10%;
        }

        .panel-3d {
          transform-style: preserve-3d;
          transition: transform 0.5s ease, box-shadow 0.4s ease, border-color 0.3s ease;
        }

        .panel-3d-base {
          transform: rotateX(18deg) rotateY(-20deg) translateY(20px);
        }

        .panel-3d-center {
          transform: rotateX(16deg) rotateY(-8deg) translateY(10px) translateZ(40px);
        }

        .panel-3d-right {
          transform: rotateX(19deg) rotateY(6deg) translateY(20px) translateZ(20px);
        }

        .panel-3d:hover {
          transform: translateY(0) translateZ(80px) rotateX(10deg) rotateY(0deg);
          box-shadow: 0 25px 60px rgba(0, 0, 0, 0.9), 0 0 24px rgba(168, 85, 247, 0.9);
          border-color: rgba(244, 244, 245, 0.95);
        }

        .glow-outline {
          box-shadow: 0 0 12px rgba(168,85,247,0.9);
          border-color: rgba(196,181,253,0.85);
        }

        .shadow-depth {
          box-shadow: 0 25px 45px rgba(0,0,0,0.85);
        }

        .shadow-glow {
          box-shadow: 0 0 18px rgba(168,85,247,0.85);
        }

        .shadow-glowSoft {
          box-shadow: 0 0 12px rgba(168,85,247,0.55);
        }

        .shadow-glowNeon {
          box-shadow: 0 0 14px rgba(34,197,94,0.9);
        }
      `}</style>

      {/* Background grid / glow */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_top,_#4c1d95,_transparent_55%),_radial-gradient(circle_at_bottom,_#14b8a6,_transparent_55%)]"></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(148,163,184,0.18)_1px,transparent_1px),linear-gradient(to_bottom,rgba(148,163,184,0.12)_1px,transparent_1px)] bg-[size:80px_80px] opacity-25"></div>
      </div>

      {/* Top Bar */}
      <CodeRepoTopBar />

      {/* Main 3D Stage */}
      <main className="relative z-10 max-w-6xl mx-auto px-4 pt-6 pb-16">
        <div className="perspective-3d">
          <div className="flex flex-col lg:flex-row gap-6 items-start">
            {/* Left Panel: Repo List */}
            <CodeRepoSidebar 
              selectedRepo={selectedRepo}
              onRepoSelect={setSelectedRepo}
              onFileSelect={setSelectedFile}
            />

            {/* Center Panel: README + Code */}
            <CodeRepoViewer 
              selectedRepo={selectedRepo}
              selectedFile={selectedFile}
            />

            {/* Right Panel: Activity */}
            <div className="panel-3d panel-3d-right hidden lg:block w-72 bg-[#0c0217] border border-purple-900/80 rounded-2xl shadow-depth p-4">
              <div className="glow-outline inline-flex items-center gap-2 px-2.5 py-1 rounded-full border bg-black/60 mb-4">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-300 shadow-glowSoft"></span>
                <span className="text-[11px] uppercase tracking-[0.22em] text-purple-100">Activity</span>
              </div>

              <ul className="space-y-3 text-[12px]">
                <li className="border border-slate-700/70 rounded-xl bg-black/60 px-3 py-2 shadow-glowSoft">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 font-medium">v1.7 · Deep recursion</span>
                    <span className="text-[11px] text-slate-400">2h ago</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Optimized multi-layer recursion, +32% solving speed.
                  </p>
                </li>

                <li className="border border-slate-700/70 rounded-xl bg-black/60 px-3 py-2 hover:shadow-glow cursor-pointer transition-all">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 font-medium">v1.6 · Paradox split</span>
                    <span className="text-[11px] text-slate-400">1d ago</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Introduced paradox-splitting branches for complex flows.
                  </p>
                </li>

                <li className="border border-slate-700/70 rounded-xl bg-black/60 px-3 py-2 hover:shadow-glow cursor-pointer transition-all">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-200 font-medium">v1.5 · Multi-agent</span>
                    <span className="text-[11px] text-slate-400">3d ago</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Enabled seamless orchestration with TAC agent pools.
                  </p>
                </li>
              </ul>

              <div className="mt-5 border-t border-purple-900/70 pt-3">
                <p className="text-[11px] text-slate-400 mb-2">Linked entities</p>
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full border border-slate-600/80 bg-black/60 shadow-glowSoft">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-glowNeon"></span>
                    <span className="text-[11px]">Agent Orchestrator</span>
                  </div>
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full border border-slate-600/80 bg-black/60 shadow-glowSoft">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-300 shadow-glowSoft"></span>
                    <span className="text-[11px]">Innovation Vault</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}