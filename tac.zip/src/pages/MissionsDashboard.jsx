import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Rocket, Terminal, CheckCircle2, XCircle, Clock } from "lucide-react";
import { Card } from "@/components/ui/card";
import MissionCreator from "../components/MissionCreator";
import MissionList from "../components/MissionList";
import MissionDetail from "../components/MissionDetail";

export default function MissionsDashboard() {
  const [selectedMission, setSelectedMission] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: missions } = useQuery({
    queryKey: ['missions'],
    queryFn: () => base44.entities.Mission.list('-created_date', 100),
    initialData: [],
  });

  // Admin check
  if (user && user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full p-8 text-center border" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Terminal className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Admin Only</h2>
          <p className="text-gray-400">
            Mission Control requires administrator privileges
          </p>
        </Card>
      </div>
    );
  }

  // Stats
  const totalMissions = missions.length;
  const runningMissions = missions.filter(m => m.status === 'running').length;
  const completedMissions = missions.filter(m => m.status === 'completed').length;
  const failedMissions = missions.filter(m => m.status === 'failed' || m.status === 'expired').length;

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-purple-500 to-pink-500">
              <Rocket className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white">Mission Control</h1>
              <p className="text-gray-400">AI-powered sandbox workload manager</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex items-center gap-3">
              <Terminal className="w-8 h-8 text-purple-400" />
              <div>
                <div className="text-2xl font-bold text-white">{totalMissions}</div>
                <div className="text-xs text-gray-400">Total Missions</div>
              </div>
            </div>
          </Card>

          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(59, 130, 246, 0.5)'
          }}>
            <div className="flex items-center gap-3">
              <Clock className="w-8 h-8 text-blue-400" />
              <div>
                <div className="text-2xl font-bold text-white">{runningMissions}</div>
                <div className="text-xs text-gray-400">Running</div>
              </div>
            </div>
          </Card>

          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(34, 197, 94, 0.5)'
          }}>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-8 h-8 text-green-400" />
              <div>
                <div className="text-2xl font-bold text-white">{completedMissions}</div>
                <div className="text-xs text-gray-400">Completed</div>
              </div>
            </div>
          </Card>

          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(239, 68, 68, 0.5)'
          }}>
            <div className="flex items-center gap-3">
              <XCircle className="w-8 h-8 text-red-400" />
              <div>
                <div className="text-2xl font-bold text-white">{failedMissions}</div>
                <div className="text-xs text-gray-400">Failed</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Main Content */}
        {selectedMission ? (
          <MissionDetail
            mission={selectedMission}
            onBack={() => setSelectedMission(null)}
          />
        ) : (
          <div className="grid lg:grid-cols-[1fr_1.5fr] gap-6">
            {/* Creator */}
            <div>
              <MissionCreator />
            </div>

            {/* List */}
            <div>
              <MissionList onSelectMission={setSelectedMission} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}