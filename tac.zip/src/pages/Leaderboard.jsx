import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import RankBadge, { RANK_CONFIG } from "../components/RankBadge";
import { Trophy, Crown, Medal, Search, TrendingUp, Github, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function Leaderboard() {
  const [minTier, setMinTier] = useState("R1");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: searchResults, isLoading } = useQuery({
    queryKey: ["leaderboard", minTier],
    queryFn: async () => {
      const url = minTier !== "R1" 
        ? `${BACKEND_URL}/api/search?minTier=${minTier}`
        : `${BACKEND_URL}/api/search`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch leaderboard");
      const data = await res.json();
      return data.result || [];
    },
  });

  const filteredResults = (searchResults || [])
    .filter(profile => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return (
        profile.github?.username?.toLowerCase().includes(query) ||
        profile.reddit?.username?.toLowerCase().includes(query) ||
        profile.userId.toLowerCase().includes(query)
      );
    })
    .sort((a, b) => b.scores.totalScore - a.scores.totalScore);

  const topThree = filteredResults.slice(0, 3);
  const restOfList = filteredResults.slice(3);

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Trophy className="w-4 h-4 text-amber-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Elite Rankings</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #8B5CF6, #24E4FF)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            Code Demigods Leaderboard
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            AI-ranked developers. GitHub + Reddit + Code Quality + Peer Feedback.
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search by username..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-[#0f1419] border-[#1a1f2e] text-white"
            />
          </div>
          <Select value={minTier} onValueChange={setMinTier}>
            <SelectTrigger className="w-full md:w-48 bg-[#0f1419] border-[#1a1f2e] text-white">
              <SelectValue placeholder="Minimum Rank" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="R1">All Ranks</SelectItem>
              <SelectItem value="R2">R2+ (Builder)</SelectItem>
              <SelectItem value="R3">R3+ (Architect)</SelectItem>
              <SelectItem value="R4">R4+ (Shadow Elite)</SelectItem>
              <SelectItem value="R5">R5+ (Mythic)</SelectItem>
              <SelectItem value="R6">R6+ (Demigod)</SelectItem>
              <SelectItem value="R7">R7 (Vault Tier)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-purple-600 border-t-transparent"></div>
            <p className="text-gray-400 mt-4">Loading rankings...</p>
          </div>
        ) : (
          <>
            {/* Top 3 Podium */}
            {topThree.length > 0 && (
              <div className="mb-12">
                <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                  <Crown className="w-6 h-6 text-amber-500" />
                  Top 3 Demigods
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {topThree.map((profile, idx) => (
                    <PodiumCard key={profile.userId} profile={profile} position={idx + 1} />
                  ))}
                </div>
              </div>
            )}

            {/* Rest of Leaderboard */}
            <div>
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-purple-500" />
                All Rankings
              </h2>
              <div className="space-y-3">
                {restOfList.length === 0 ? (
                  <Card className="border-[#1a1f2e] bg-[#0f1419] p-8 text-center">
                    <p className="text-gray-400">No demigods found with current filters.</p>
                  </Card>
                ) : (
                  restOfList.map((profile, idx) => (
                    <LeaderboardRow 
                      key={profile.userId} 
                      profile={profile} 
                      position={idx + 4}
                    />
                  ))
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function PodiumCard({ profile, position }) {
  const positionIcons = {
    1: { icon: Trophy, color: "#F4C76A", label: "1st" },
    2: { icon: Medal, color: "#C0C0C0", label: "2nd" },
    3: { icon: Medal, color: "#CD7F32", label: "3rd" },
  };

  const config = positionIcons[position];
  const Icon = config.icon;

  return (
    <Link to={createPageUrl("DemigodProfile") + `?userId=${profile.userId}`}>
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-6 hover:border-[#262637] transition-all cursor-pointer">
        <div className="text-center mb-4">
          <div 
            className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center"
            style={{
              background: `radial-gradient(circle, ${config.color}33, transparent 70%)`,
              border: `2px solid ${config.color}`,
            }}
          >
            <Icon className="w-8 h-8" style={{ color: config.color }} />
          </div>
          <div className="text-xs text-gray-500 mb-1">{config.label} Place</div>
          <h3 className="text-xl font-bold text-white mb-2">
            {profile.github?.username || profile.reddit?.username || profile.userId}
          </h3>
          <RankBadge 
            rank={profile.mdcTier.id} 
            size="md" 
            showName 
            className="justify-center"
          />
        </div>

        <div className="text-center mb-4">
          <div className="text-4xl font-black" style={{
            background: "linear-gradient(135deg, #8B5CF6, #24E4FF)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            {profile.scores.totalScore}
          </div>
          <div className="text-xs text-gray-500">Total Score</div>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          {profile.github && (
            <div className="text-center p-2 rounded bg-[#141923]">
              <Github className="w-4 h-4 mx-auto mb-1 text-gray-400" />
              <div className="text-white font-semibold">{profile.github.publicRepos}</div>
              <div className="text-gray-500">Repos</div>
            </div>
          )}
          {profile.feedbackStats?.count > 0 && (
            <div className="text-center p-2 rounded bg-[#141923]">
              <Users className="w-4 h-4 mx-auto mb-1 text-gray-400" />
              <div className="text-white font-semibold">{profile.feedbackStats.count}</div>
              <div className="text-gray-500">Feedback</div>
            </div>
          )}
        </div>
      </Card>
    </Link>
  );
}

function LeaderboardRow({ profile, position }) {
  return (
    <Link to={createPageUrl("DemigodProfile") + `?userId=${profile.userId}`}>
      <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 hover:border-[#262637] transition-all cursor-pointer">
        <div className="flex items-center gap-4">
          <div className="w-12 text-center">
            <div className="text-2xl font-bold text-gray-600">#{position}</div>
          </div>

          <RankBadge rank={profile.mdcTier.id} size="sm" showName={false} />

          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold text-white truncate">
              {profile.github?.username || profile.reddit?.username || profile.userId}
            </h3>
            <div className="text-sm text-gray-400">
              {profile.mdcTier.name}
            </div>
          </div>

          <div className="hidden md:flex items-center gap-6 text-sm">
            {profile.github && (
              <div className="text-center">
                <div className="text-white font-semibold">{profile.scores.hardSkill}</div>
                <div className="text-xs text-gray-500">Hard Skill</div>
              </div>
            )}
            {profile.aiCode && (
              <div className="text-center">
                <div className="text-white font-semibold">{profile.scores.aiQuality}</div>
                <div className="text-xs text-gray-500">AI Quality</div>
              </div>
            )}
          </div>

          <div className="text-right">
            <div className="text-3xl font-black" style={{
              background: "linear-gradient(135deg, #8B5CF6, #24E4FF)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}>
              {profile.scores.totalScore}
            </div>
            <div className="text-xs text-gray-500">Score</div>
          </div>
        </div>
      </Card>
    </Link>
  );
}