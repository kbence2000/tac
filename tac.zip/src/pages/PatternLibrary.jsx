import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Sparkles, 
  Search, 
  Filter, 
  Code2, 
  Lightbulb, 
  TrendingUp,
  Database,
  Calendar,
  Tag,
  Trash2,
  Copy,
  Check,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

export default function PatternLibrary() {
  const [assets, setAssets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [complexityFilter, setComplexityFilter] = useState("all");
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [expandedAssets, setExpandedAssets] = useState({});
  const [copiedAssets, setCopiedAssets] = useState({});

  useEffect(() => {
    fetchAssets();
  }, []);

  const fetchAssets = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/market/assets');
      if (response.ok) {
        const data = await response.json();
        setAssets(data.assets || []);
      } else {
        setAssets([]);
        toast.error("Failed to load assets");
      }
    } catch (error) {
      console.error('Error fetching assets:', error);
      setAssets([]);
      toast.error("Error loading Pattern Library");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAsset = async (assetId) => {
    setDeleting(true);
    try {
      const response = await fetch(`/api/market/assets/${assetId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setAssets(prev => prev.filter(a => a.id !== assetId));
        toast.success("Asset deleted successfully");
      } else {
        toast.error("Failed to delete asset");
      }
    } catch (error) {
      console.error('Delete error:', error);
      toast.error("Error deleting asset");
    } finally {
      setDeleting(false);
      setDeleteConfirm(null);
    }
  };

  const toggleExpanded = (assetId) => {
    setExpandedAssets(prev => ({
      ...prev,
      [assetId]: !prev[assetId]
    }));
  };

  const handleCopyCode = (assetId, code) => {
    if (code) {
      navigator.clipboard.writeText(code);
      setCopiedAssets(prev => ({ ...prev, [assetId]: true }));
      toast.success("Code copied to clipboard!");
      setTimeout(() => {
        setCopiedAssets(prev => ({ ...prev, [assetId]: false }));
      }, 2000);
    }
  };

  const filteredAssets = assets
    .filter(asset => {
      const matchesSearch = !searchQuery || 
        asset.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        asset.summary?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        asset.patterns?.some(p => p.name?.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesComplexity = complexityFilter === "all" || 
        asset.value?.complexity?.toLowerCase() === complexityFilter;
      
      return matchesSearch && matchesComplexity;
    })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{
              background: 'linear-gradient(135deg, #8b5cff, #24e4ff)'
            }}>
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-black gradient-text">Pattern Library</h1>
              <p className="text-gray-400">Your saved code patterns & AI-analyzed assets</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mt-6">
            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(139, 92, 255, 0.3)'
            }}>
              <div className="flex items-center gap-3">
                <Code2 className="w-8 h-8 text-purple-400" />
                <div>
                  <div className="text-2xl font-bold text-white">{assets.length}</div>
                  <div className="text-sm text-gray-400">Total Assets</div>
                </div>
              </div>
            </Card>

            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(36, 228, 255, 0.3)'
            }}>
              <div className="flex items-center gap-3">
                <Sparkles className="w-8 h-8 text-cyan-400" />
                <div>
                  <div className="text-2xl font-bold text-white">
                    {assets.reduce((sum, a) => sum + (a.patterns?.length || 0), 0)}
                  </div>
                  <div className="text-sm text-gray-400">Patterns Extracted</div>
                </div>
              </div>
            </Card>

            <Card className="border p-4" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(255, 184, 77, 0.3)'
            }}>
              <div className="flex items-center gap-3">
                <Lightbulb className="w-8 h-8 text-yellow-400" />
                <div>
                  <div className="text-2xl font-bold text-white">
                    {assets.reduce((sum, a) => sum + (a.suggestions?.length || 0), 0)}
                  </div>
                  <div className="text-sm text-gray-400">Suggestions</div>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Search & Filters */}
        <section className="mb-8">
          <Card className="border p-4" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search patterns, languages, concepts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-[#141923] border-[#1a1f2e] text-white"
                />
              </div>

              <Select value={complexityFilter} onValueChange={setComplexityFilter}>
                <SelectTrigger className="w-48 bg-[#141923] border-[#1a1f2e] text-white">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Complexity</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>

              <Button
                onClick={fetchAssets}
                variant="outline"
                className="border-cyan-600/50 text-cyan-400 hover:bg-cyan-600/20"
              >
                <Database className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </Card>
        </section>

        {/* Assets Grid */}
        <section>
          {loading ? (
            <div className="text-center py-20">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-t-transparent" style={{ borderColor: 'var(--accent)' }}></div>
              <p className="text-gray-400 mt-4">Loading patterns...</p>
            </div>
          ) : filteredAssets.length === 0 ? (
            <Card className="border p-12 text-center" style={{
              background: 'rgba(15, 23, 42, 0.95)',
              borderColor: 'rgba(148, 163, 184, 0.35)'
            }}>
              <Database className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">No Patterns Found</h3>
              <p className="text-gray-400 mb-6">
                {searchQuery || complexityFilter !== "all" 
                  ? "Try adjusting your search filters"
                  : "Start by analyzing code in Code Maker to build your library"}
              </p>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredAssets.map(asset => (
                <Card key={asset.id} className="border p-6 hover:shadow-lg transition-all animate-fade-in relative group" style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)'
                }}>
                  {/* Delete Button */}
                  <Button
                    onClick={() => setDeleteConfirm(asset)}
                    variant="ghost"
                    size="icon"
                    className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity text-red-400 hover:text-red-300 hover:bg-red-900/20"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>

                  {/* Header */}
                  <div className="flex items-start justify-between mb-4 pr-8">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white mb-2 leading-tight">
                        {asset.title}
                      </h3>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Calendar className="w-3 h-3" />
                        {new Date(asset.createdAt).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric',
                          year: 'numeric'
                        })}
                      </div>
                    </div>
                    {asset.value?.complexity && (
                      <Badge className={`${
                        asset.value.complexity === 'low' ? 'bg-green-600/20 text-green-300 border-green-600/30' :
                        asset.value.complexity === 'medium' ? 'bg-yellow-600/20 text-yellow-300 border-yellow-600/30' :
                        'bg-red-600/20 text-red-300 border-red-600/30'
                      }`}>
                        {asset.value.complexity.toUpperCase()}
                      </Badge>
                    )}
                  </div>

                  {/* Summary */}
                  {asset.summary && (
                    <p className="text-sm text-gray-300 mb-4 line-clamp-3 leading-relaxed">
                      {asset.summary}
                    </p>
                  )}

                  {/* Value Metrics */}
                  {asset.value && (
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      {asset.value.quality && (
                        <div className="p-2 rounded-lg border text-center" style={{
                          background: 'rgba(5, 8, 22, 0.9)',
                          borderColor: 'rgba(148, 163, 184, 0.2)'
                        }}>
                          <div className="text-sm font-bold gradient-text">
                            {typeof asset.value.quality === 'number' 
                              ? `${asset.value.quality}/5` 
                              : asset.value.quality}
                          </div>
                          <div className="text-xs text-gray-500">Quality</div>
                        </div>
                      )}
                      {asset.value.price_estimate && (
                        <div className="p-2 rounded-lg border text-center" style={{
                          background: 'rgba(5, 8, 22, 0.9)',
                          borderColor: 'rgba(148, 163, 184, 0.2)'
                        }}>
                          <div className="text-sm font-bold text-green-400">
                            ${asset.value.price_estimate}
                          </div>
                          <div className="text-xs text-gray-500">Value</div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Patterns Count */}
                  {asset.patterns && asset.patterns.length > 0 && (
                    <div className="flex items-center gap-2 mb-3">
                      <Code2 className="w-4 h-4 text-cyan-400" />
                      <span className="text-sm text-gray-400">
                        {asset.patterns.length} pattern{asset.patterns.length !== 1 ? 's' : ''} detected
                      </span>
                    </div>
                  )}

                  {/* Pattern Tags */}
                  {asset.patterns && asset.patterns.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {asset.patterns.slice(0, 3).map((pattern, idx) => (
                        <Badge key={idx} className="text-xs bg-cyan-600/20 text-cyan-300 border-cyan-600/30">
                          <Tag className="w-3 h-3 mr-1" />
                          {pattern.name || `Pattern ${idx + 1}`}
                        </Badge>
                      ))}
                      {asset.patterns.length > 3 && (
                        <Badge className="text-xs bg-gray-600/20 text-gray-400 border-gray-600/30">
                          +{asset.patterns.length - 3} more
                        </Badge>
                      )}
                    </div>
                  )}

                  {/* Code Preview (Expandable) */}
                  {asset.code && (
                    <div className="mt-4 pt-4 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
                      <div className="flex items-center justify-between mb-2">
                        <button
                          onClick={() => toggleExpanded(asset.id)}
                          className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
                        >
                          <Code2 className="w-4 h-4" />
                          <span>Code</span>
                          {expandedAssets[asset.id] ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </button>
                        <Button
                          onClick={() => handleCopyCode(asset.id, asset.code)}
                          variant="ghost"
                          size="sm"
                          className="text-xs text-gray-400 hover:text-white"
                        >
                          {copiedAssets[asset.id] ? (
                            <>
                              <Check className="w-3 h-3 mr-1" />
                              Copied
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3 mr-1" />
                              Copy
                            </>
                          )}
                        </Button>
                      </div>
                      {expandedAssets[asset.id] && (
                        <pre className="p-3 rounded-lg border overflow-x-auto text-xs font-mono" style={{
                          background: 'rgba(5, 8, 22, 0.9)',
                          borderColor: 'rgba(148, 163, 184, 0.2)',
                          maxHeight: '300px',
                          overflowY: 'auto'
                        }}>
                          <code className="text-gray-300">{asset.code}</code>
                        </pre>
                      )}
                    </div>
                  )}

                  {/* Suggestions */}
                  {asset.suggestions && asset.suggestions.length > 0 && !expandedAssets[asset.id] && (
                    <div className="pt-4 border-t" style={{ borderColor: 'rgba(148, 163, 184, 0.2)' }}>
                      <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                        <Lightbulb className="w-4 h-4 text-yellow-400" />
                        <span>{asset.suggestions.length} improvement{asset.suggestions.length !== 1 ? 's' : ''}</span>
                      </div>
                      <ul className="space-y-1">
                        {asset.suggestions.slice(0, 2).map((suggestion, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-xs text-gray-400">
                            <TrendingUp className="w-3 h-3 text-yellow-400 mt-0.5 flex-shrink-0" />
                            <span className="line-clamp-2">
                              {typeof suggestion === 'string' ? suggestion : suggestion.text || suggestion.description}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent style={{
          background: 'rgba(15, 23, 42, 0.98)',
          border: '1px solid rgba(148, 163, 184, 0.35)'
        }}>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Delete Asset?</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              Are you sure you want to delete "{deleteConfirm?.title}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              className="bg-[#141923] border-[#1a1f2e] text-white hover:bg-[#1a1f2e]"
              disabled={deleting}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => handleDeleteAsset(deleteConfirm?.id)}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deleting ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}