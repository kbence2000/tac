import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Sparkles, Code2, Lightbulb, RefreshCw,
  Trophy, Target, Zap
} from "lucide-react";
import { toast } from "sonner";
import DemigodFeedItem from "../components/DemigodFeedItem";
import { AI } from "../components/AppAI";

const TOP_API = import.meta.env.VITE_TOP_BACKEND_URL || "http://localhost:3000";

export default function StraightFromTop() {
  const [feed, setFeed] = useState([]);
  const [loadingFeed, setLoadingFeed] = useState(false);
  
  // Showcase form
  const [scDemigod, setScDemigod] = useState("dg001");
  const [scTitle, setScTitle] = useState("");
  const [scDesc, setScDesc] = useState("");
  const [addingShowcase, setAddingShowcase] = useState(false);

  // Snippet form
  const [snDemigod, setSnDemigod] = useState("dg001");
  const [snCode, setSnCode] = useState("");
  const [addingSnippet, setAddingSnippet] = useState(false);
  const [snippetPreview, setSnippetPreview] = useState(null);

  // Help drop form
  const [hdDemigod, setHdDemigod] = useState("dg001");
  const [hdMsg, setHdMsg] = useState("");
  const [addingHelp, setAddingHelp] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Load feed
  const loadFeed = async () => {
    setLoadingFeed(true);
    try {
      const res = await fetch(`${TOP_API}/api/top/feed`);
      if (res.ok) {
        const data = await res.json();
        setFeed(data.feed || []);
      }
    } catch (error) {
      console.error("Load feed error:", error);
    } finally {
      setLoadingFeed(false);
    }
  };

  useEffect(() => {
    loadFeed();
    const interval = setInterval(loadFeed, 60000); // Refresh every 60s
    return () => clearInterval(interval);
  }, []);

  // AI Snippet Preview (local analysis)
  useEffect(() => {
    const analyzeSnippet = async () => {
      if (snCode && snCode.length > 10) {
        const analysis = await AI.snippetAnalyzer(snCode);
        setSnippetPreview(analysis);
      } else {
        setSnippetPreview(null);
      }
    };
    
    const debounce = setTimeout(analyzeSnippet, 500);
    return () => clearTimeout(debounce);
  }, [snCode]);

  // Add showcase
  const handleAddShowcase = async () => {
    if (!scTitle || !scDesc) {
      toast.error("Title and description required");
      return;
    }

    setAddingShowcase(true);
    try {
      const res = await fetch(`${TOP_API}/api/top/addShowcase`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          demigodId: scDemigod,
          title: scTitle,
          description: scDesc
        })
      });

      if (res.ok) {
        toast.success("Showcase published!");
        setScTitle("");
        setScDesc("");
        loadFeed();
      } else {
        toast.error("Failed to publish showcase");
      }
    } catch (error) {
      console.error("Add showcase error:", error);
      toast.error("Network error");
    } finally {
      setAddingShowcase(false);
    }
  };

  // Add snippet
  const handleAddSnippet = async () => {
    if (!snCode) {
      toast.error("Code snippet required");
      return;
    }

    setAddingSnippet(true);
    try {
      const res = await fetch(`${TOP_API}/api/top/addSnippet`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          demigodId: snDemigod,
          code: snCode
        })
      });

      if (res.ok) {
        toast.success("Godlike snippet published! AI analyzing...");
        setSnCode("");
        setSnippetPreview(null);
        loadFeed();
      } else {
        toast.error("Failed to publish snippet");
      }
    } catch (error) {
      console.error("Add snippet error:", error);
      toast.error("Network error");
    } finally {
      setAddingSnippet(false);
    }
  };

  // Add help drop
  const handleAddHelp = async () => {
    if (!hdMsg) {
      toast.error("Help message required");
      return;
    }

    setAddingHelp(true);
    try {
      const res = await fetch(`${TOP_API}/api/top/helpdrop`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          demigodId: hdDemigod,
          message: hdMsg
        })
      });

      if (res.ok) {
        toast.success("Help dropped to the community!");
        setHdMsg("");
        loadFeed();
      } else {
        toast.error("Failed to drop help");
      }
    } catch (error) {
      console.error("Add help error:", error);
      toast.error("Network error");
    } finally {
      setAddingHelp(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Trophy className="w-4 h-4 text-purple-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Demigods Community</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #a855f7, #ec4899, #f59e0b)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            Straight From The Top
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Elite R6-R7 demigods share <strong className="text-purple-400">breakthrough ideas</strong>, <strong className="text-cyan-400">godlike code snippets</strong>, and <strong className="text-yellow-400">random help drops</strong>. Learn from the masters.
          </p>
        </div>

        <div className="grid lg:grid-cols-[1fr_1.5fr] gap-8">
          {/* Left: Post Forms */}
          <div className="space-y-6">
            {/* Showcase Form */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                Elite Showcase
              </h3>
              <p className="text-xs text-gray-400 mb-4">
                Share your breakthrough presentation, methodology, or architecture insight
              </p>

              <div className="space-y-3">
                <Select value={scDemigod} onValueChange={setScDemigod}>
                  <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dg001">🜁 Nova - Demigod</SelectItem>
                    <SelectItem value="dg002">✦ Lyra - Demigod</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  value={scTitle}
                  onChange={(e) => setScTitle(e.target.value)}
                  placeholder="Presentation title"
                  className="bg-[#141923] border-[#1a1f2e] text-white"
                />

                <Textarea
                  value={scDesc}
                  onChange={(e) => setScDesc(e.target.value)}
                  placeholder="Describe your idea, method, or breakdown..."
                  className="bg-[#141923] border-[#1a1f2e] text-white h-32"
                />

                <Button
                  onClick={handleAddShowcase}
                  disabled={addingShowcase || !scTitle || !scDesc}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold"
                >
                  {addingShowcase ? "Publishing..." : "Publish Showcase"}
                </Button>
              </div>
            </Card>

            {/* Snippet Form */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Code2 className="w-5 h-5 text-cyan-400" />
                Godlike Code Snippet
              </h3>
              <p className="text-xs text-gray-400 mb-4">
                Share an elegant, performant, or innovative code snippet - AI will analyze it
              </p>

              <div className="space-y-3">
                <Select value={snDemigod} onValueChange={setSnDemigod}>
                  <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dg001">🜁 Nova - Demigod</SelectItem>
                    <SelectItem value="dg002">✦ Lyra - Demigod</SelectItem>
                  </SelectContent>
                </Select>

                <Textarea
                  value={snCode}
                  onChange={(e) => setSnCode(e.target.value)}
                  placeholder="// Paste your elegant, godlike snippet here..."
                  className="bg-[#141923] border-[#1a1f2e] text-white font-mono text-sm h-48"
                />

                {/* AI Preview */}
                {snippetPreview && (
                  <div className="p-3 rounded-lg bg-gradient-to-br from-cyan-600/10 to-blue-600/10 border border-cyan-600/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-cyan-300 font-semibold">Live AI Preview</span>
                      <Badge className="bg-cyan-600/30 text-cyan-300 border-cyan-600/50">
                        {snippetPreview.score}/100
                      </Badge>
                    </div>
                    <p className="text-xs text-cyan-200 mb-2">{snippetPreview.label}</p>
                    <div className="text-[0.65rem] text-gray-400">
                      💡 Tip: {snippetPreview.tips[Math.floor(Math.random() * snippetPreview.tips.length)]}
                    </div>
                  </div>
                )}

                <Button
                  onClick={handleAddSnippet}
                  disabled={addingSnippet || !snCode}
                  className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold"
                >
                  {addingSnippet ? "Publishing..." : "Publish Snippet (AI Score)"}
                </Button>
              </div>
            </Card>

            {/* Help Drop Form */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-yellow-400" />
                Random Help Drop
              </h3>
              <p className="text-xs text-gray-400 mb-4">
                Drop a quick tip, answer, or wisdom bomb for the community
              </p>

              <div className="space-y-3">
                <Select value={hdDemigod} onValueChange={setHdDemigod}>
                  <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dg001">🜁 Nova - Demigod</SelectItem>
                    <SelectItem value="dg002">✦ Lyra - Demigod</SelectItem>
                  </SelectContent>
                </Select>

                <Textarea
                  value={hdMsg}
                  onChange={(e) => setHdMsg(e.target.value)}
                  placeholder="One helpful tip or quick answer..."
                  className="bg-[#141923] border-[#1a1f2e] text-white h-24"
                />

                <Button
                  onClick={handleAddHelp}
                  disabled={addingHelp || !hdMsg}
                  className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 text-white font-bold"
                >
                  {addingHelp ? "Dropping..." : "Drop Help"}
                </Button>
              </div>
            </Card>
          </div>

          {/* Right: Elite Feed */}
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-black text-white flex items-center gap-2">
                🔥 Elite Feed
              </h2>
              <Button
                onClick={loadFeed}
                disabled={loadingFeed}
                size="sm"
                variant="outline"
                className="border-[#1a1f2e] text-gray-300"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${loadingFeed ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>

            <p className="text-sm text-gray-400 mb-6">
              Real-time feed from R6-R7 code demigods. Showcases, snippets, and wisdom drops.
            </p>

            {loadingFeed && feed.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-gray-400">Loading elite feed...</p>
              </div>
            ) : feed.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Trophy className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p>No posts yet. Be the first to share!</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[800px] overflow-y-auto pr-2">
                {feed.map((item) => (
                  <DemigodFeedItem key={item.id} item={item} />
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}