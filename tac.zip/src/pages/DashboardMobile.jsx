import React, { useEffect, useRef, useState } from "react";

const AGENT_ROLES = ["planner", "critic", "executor", "overseer"];
const ROLE_COLORS = {
  planner: "rgba(77, 255, 184,",
  critic: "rgba(255, 184, 77,",
  executor: "rgba(77, 183, 255,",
  overseer: "rgba(255, 75, 154,"
};
const AGENT_STATUSES = ["Idle", "Analyzing", "Routing", "Evolving"];
const AGENT_ACTIONS = [
  "Evaluating pattern",
  "Routing token",
  "Building abstraction",
  "Syncing cluster"
];
const PULSE_EVENTS = [
  "FutureMind accepted new hybrid node",
  "Agents shifted routing layer",
  "Overseer meta-sync applied",
  "Pattern conflict resolved",
  "DebugAI refined abstraction"
];

export default function DashboardMobile() {
  const [activeScreen, setActiveScreen] = useState("dashboard");
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [agentInfoOpen, setAgentInfoOpen] = useState(false);
  const [timelineEvents, setTimelineEvents] = useState([]);

  const fCanvasRef = useRef(null);
  const gCanvasRef = useRef(null);
  const pulseCanvasRef = useRef(null);
  const fNodesRef = useRef([]);
  const gNodesRef = useRef([]);
  const pulseDataRef = useRef([]);
  const pulseTimeRef = useRef(0);

  // FutureMind Canvas Animation
  useEffect(() => {
    const canvas = fCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    let animationFrameId;

    function fitCanvas() {
      const box = canvas.parentElement.getBoundingClientRect();
      canvas.width = box.width * window.devicePixelRatio;
      canvas.height = box.height * window.devicePixelRatio;
    }

    function initNodes() {
      fNodesRef.current = [];
      for (let i = 0; i < 18; i++) {
        fNodesRef.current.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3
        });
      }
    }

    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const nodes = fNodesRef.current;

      // Links
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 150) {
            ctx.strokeStyle = `rgba(136, 110, 157, ${1 - dist / 150})`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      // Nodes
      for (const n of nodes) {
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0 || n.x > canvas.width) n.vx *= -1;
        if (n.y < 0 || n.y > canvas.height) n.vy *= -1;

        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(n.x, n.y, 3 * window.devicePixelRatio, 0, Math.PI * 2);
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(draw);
    }

    fitCanvas();
    initNodes();
    draw();

    const handleResize = () => {
      fitCanvas();
      initNodes();
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, []);

  // Global Agent Map Canvas Animation
  useEffect(() => {
    const canvas = gCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    let animationFrameId;

    function fitCanvas() {
      const box = canvas.parentElement.getBoundingClientRect();
      canvas.width = box.width * window.devicePixelRatio;
      canvas.height = box.height * window.devicePixelRatio;
    }

    function initNodes() {
      gNodesRef.current = [];
      for (let i = 0; i < 26; i++) {
        const role = AGENT_ROLES[Math.floor(Math.random() * AGENT_ROLES.length)];
        gNodesRef.current.push({
          id: i,
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.25,
          vy: (Math.random() - 0.5) * 0.25,
          role,
          status: AGENT_STATUSES[Math.floor(Math.random() * AGENT_STATUSES.length)],
          action: AGENT_ACTIONS[Math.floor(Math.random() * AGENT_ACTIONS.length)],
          conf: (60 + Math.floor(Math.random() * 40)) + "%",
          depth: Math.floor(Math.random() * 4) + 1,
          impact: ["Low", "Mid", "High"][Math.floor(Math.random() * 3)]
        });
      }
    }

    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const nodes = gNodesRef.current;

      // Update positions
      for (const n of nodes) {
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0 || n.x > canvas.width) n.vx *= -1;
        if (n.y < 0 || n.y > canvas.height) n.vy *= -1;
      }

      // Draw nodes
      for (const n of nodes) {
        const r = 3 * window.devicePixelRatio;
        
        // Glow
        const glow = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, r * 4);
        const base = ROLE_COLORS[n.role] || "rgba(255, 255, 255,";
        glow.addColorStop(0, base + "1)");
        glow.addColorStop(1, base + "0)");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(n.x, n.y, r * 4, 0, Math.PI * 2);
        ctx.fill();

        // Core
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(draw);
    }

    function handleCanvasClick(event) {
      const rect = canvas.getBoundingClientRect();
      const scaleX = canvas.width / rect.width;
      const scaleY = canvas.height / rect.height;
      const mx = (event.clientX - rect.left) * scaleX;
      const my = (event.clientY - rect.top) * scaleY;

      const clickRadius = 14 * window.devicePixelRatio;
      const nodes = gNodesRef.current;

      for (const node of nodes) {
        const dx = mx - node.x;
        const dy = my - node.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < clickRadius) {
          setSelectedAgent(node);
          setAgentInfoOpen(true);
          return;
        }
      }
    }

    canvas.addEventListener("click", handleCanvasClick);
    canvas.addEventListener("touchstart", handleCanvasClick);

    fitCanvas();
    initNodes();
    draw();

    const handleResize = () => {
      fitCanvas();
      initNodes();
    };
    window.addEventListener("resize", handleResize);

    return () => {
      canvas.removeEventListener("click", handleCanvasClick);
      canvas.removeEventListener("touchstart", handleCanvasClick);
      window.removeEventListener("resize", handleResize);
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, []);

  // Pulse Canvas Animation
  useEffect(() => {
    const canvas = pulseCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    let animationFrameId;

    function fitCanvas() {
      const box = canvas.parentElement.getBoundingClientRect();
      canvas.width = box.width * window.devicePixelRatio;
      canvas.height = 70 * window.devicePixelRatio;
    }

    pulseDataRef.current = [];
    for (let i = 0; i < 80; i++) {
      pulseDataRef.current.push(0);
    }

    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const w = canvas.width;
      const h = canvas.height;
      const mid = h / 2;

      // Center line
      ctx.strokeStyle = "rgba(136, 110, 157, 0.25)";
      ctx.beginPath();
      ctx.moveTo(0, mid);
      ctx.lineTo(w, mid);
      ctx.stroke();

      // Update data
      pulseTimeRef.current += 0.08;
      const spike = Math.random() < 0.1 ? (0.7 + Math.random() * 0.8) : 0.1;
      const v = Math.sin(pulseTimeRef.current) * 0.2 + spike;
      pulseDataRef.current.push(v);
      if (pulseDataRef.current.length > 100) {
        pulseDataRef.current.shift();
      }

      // Draw pulse line
      ctx.strokeStyle = "#ff4b9a";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      pulseDataRef.current.forEach((vv, i) => {
        const x = (i / (pulseDataRef.current.length - 1)) * w;
        const y = mid - vv * (h * 0.35);
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();

      animationFrameId = requestAnimationFrame(draw);
    }

    fitCanvas();
    draw();

    const handleResize = () => {
      fitCanvas();
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, []);

  // Timeline events auto-update
  useEffect(() => {
    const pushEvent = () => {
      const tags = ["FM", "AC", "CL", "DB", "PX"];
      const event = {
        text: PULSE_EVENTS[Math.floor(Math.random() * PULSE_EVENTS.length)],
        tag: tags[Math.floor(Math.random() * tags.length)]
      };
      setTimelineEvents(prev => [event, ...prev].slice(0, 5));
    };

    pushEvent();
    const interval = setInterval(pushEvent, 4500);
    return () => clearInterval(interval);
  }, []);

  const screens = ["dashboard", "agents", "market", "profile"];

  return (
    <div className="fixed inset-0 flex flex-col" style={{ 
      background: 'radial-gradient(circle at top, rgba(77, 13, 111, 0.13), transparent), radial-gradient(circle at bottom, rgba(136, 110, 157, 0.13), transparent), #020007'
    }}>
      {/* TOPBAR */}
      <div className="h-[54px] px-4 flex items-center justify-between border-b z-10" style={{
        background: 'rgba(5, 0, 20, 0.9)',
        backdropFilter: 'blur(14px)',
        borderColor: 'rgba(255, 255, 255, 0.13)'
      }}>
        <div>
          <div className="text-[15px] font-bold" style={{
            background: 'linear-gradient(120deg, #fff, #886E9D, #ffb3ff)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}>
            MDC • Mobile Intelligence OS
          </div>
          <div className="text-[10px]" style={{ color: '#b8a6cf' }}>
            FutureMind · AlmightyCollective
          </div>
        </div>
        <div className="text-[10px] px-2.5 py-1 rounded-full border" style={{
          borderColor: 'rgba(255, 255, 255, 0.2)',
          color: '#b8a6cf'
        }}>
          Early Access
        </div>
      </div>

      {/* MAIN SCREENS */}
      <div className="flex-1 relative overflow-hidden">
        {/* DASHBOARD SCREEN */}
        <section 
          className={`absolute inset-0 px-4 pt-4 pb-20 overflow-y-auto transition-all duration-250 ${
            activeScreen === 'dashboard' ? 'opacity-100 translate-x-0 pointer-events-auto' : 'opacity-0 translate-x-3 pointer-events-none'
          }`}
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          {/* FutureMind Panel */}
          <div className="rounded-[18px] border p-4 mb-4 shadow-lg" style={{
            background: 'linear-gradient(160deg, #080015, #020006)',
            borderColor: 'rgba(255, 255, 255, 0.13)'
          }}>
            <div className="text-[11px] uppercase tracking-wider mb-1.5" style={{ color: '#b8a6cf' }}>
              FutureMind
            </div>
            <div className="text-[18px] font-semibold mb-2" style={{
              background: 'linear-gradient(120deg, #fff, #886E9D, #ffaaff)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Live Evolution
            </div>
            <div className="text-xs mb-3" style={{ color: '#b8a6cf', opacity: 0.8 }}>
              Autonomous micro-patterns & hybrid logic mapping.
            </div>
            <div className="w-full h-[200px] rounded-2xl overflow-hidden" style={{ background: '#05000f' }}>
              <canvas ref={fCanvasRef} className="w-full h-full" />
            </div>
          </div>

          {/* Collective Pulse Panel */}
          <div className="rounded-[18px] border p-4 mb-4 shadow-lg" style={{
            background: 'linear-gradient(160deg, #080015, #020006)',
            borderColor: 'rgba(255, 255, 255, 0.13)'
          }}>
            <div className="text-[11px] uppercase tracking-wider mb-1.5" style={{ color: '#b8a6cf' }}>
              Collective Pulse
            </div>
            <div className="text-[18px] font-semibold mb-2" style={{
              background: 'linear-gradient(120deg, #fff, #886E9D, #ffaaff)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Heartbeat & Decisions
            </div>
            <div className="text-xs mb-3" style={{ color: '#b8a6cf', opacity: 0.8 }}>
              Last 90 seconds of cluster activity.
            </div>
            <canvas ref={pulseCanvasRef} className="w-full mb-3" style={{ height: '70px' }} />
            <div className="space-y-1.5">
              {timelineEvents.map((event, idx) => (
                <div 
                  key={idx}
                  className="px-2 py-1.5 rounded-xl border flex justify-between items-center text-[11px]"
                  style={{
                    background: '#070015',
                    borderColor: 'rgba(255, 255, 255, 0.13)',
                    color: '#b8a6cf'
                  }}
                >
                  <span>{event.text}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full border" style={{
                    borderColor: 'rgba(255, 255, 255, 0.2)',
                    background: 'rgba(0, 0, 0, 0.5)'
                  }}>
                    {event.tag}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* AGENTS SCREEN */}
        <section 
          className={`absolute inset-0 px-4 pt-4 pb-20 overflow-y-auto transition-all duration-250 ${
            activeScreen === 'agents' ? 'opacity-100 translate-x-0 pointer-events-auto' : 'opacity-0 translate-x-3 pointer-events-none'
          }`}
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          <div className="rounded-[18px] border p-4 shadow-lg" style={{
            background: 'linear-gradient(160deg, #080015, #020006)',
            borderColor: 'rgba(255, 255, 255, 0.13)'
          }}>
            <div className="text-[11px] uppercase tracking-wider mb-1.5" style={{ color: '#b8a6cf' }}>
              Agents
            </div>
            <div className="text-[18px] font-semibold mb-2" style={{
              background: 'linear-gradient(120deg, #fff, #886E9D, #ffaaff)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Global Multi-Agent Map
            </div>
            <div className="text-xs mb-3" style={{ color: '#b8a6cf', opacity: 0.8 }}>
              Tap on a node to inspect agent role & state.
            </div>
            <div className="w-full h-[240px] rounded-2xl overflow-hidden" style={{ background: '#05000f' }}>
              <canvas ref={gCanvasRef} className="w-full h-full" />
            </div>
          </div>
        </section>

        {/* MARKETPLACE SCREEN */}
        <section 
          className={`absolute inset-0 px-4 pt-4 pb-20 overflow-y-auto transition-all duration-250 ${
            activeScreen === 'market' ? 'opacity-100 translate-x-0 pointer-events-auto' : 'opacity-0 translate-x-3 pointer-events-none'
          }`}
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          <div className="rounded-[18px] border p-4 shadow-lg" style={{
            background: 'linear-gradient(160deg, #080015, #020006)',
            borderColor: 'rgba(255, 255, 255, 0.13)'
          }}>
            <div className="text-[11px] uppercase tracking-wider mb-1.5" style={{ color: '#b8a6cf' }}>
              Marketplace
            </div>
            <div className="text-[18px] font-semibold mb-2" style={{
              background: 'linear-gradient(120deg, #fff, #886E9D, #ffaaff)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Code, Patterns & Modules
            </div>
            <div className="text-xs mb-4" style={{ color: '#b8a6cf', opacity: 0.8 }}>
              Curated assets powered by MDC's intelligence stack.
            </div>

            {[
              { title: "Async event pipeline · TypeScript", meta: "Rated: ★ 4.8 · FutureMind", price: "€240" },
              { title: "Recruiter AI scorer · Python", meta: "Code value: A+", price: "€180" },
              { title: "Multi-agent orchestrator template", meta: "Planner · Critic · Executor", price: "€420" }
            ].map((item, idx) => (
              <div 
                key={idx}
                className="rounded-2xl border p-2.5 mb-2 text-xs"
                style={{
                  background: '#070015',
                  borderColor: 'rgba(255, 255, 255, 0.13)'
                }}
              >
                <div className="text-[13px] mb-1" style={{ color: '#f5e8ff' }}>
                  {item.title}
                </div>
                <div className="flex justify-between items-center text-[11px]" style={{ color: '#b8a6cf' }}>
                  <span>{item.meta}</span>
                  <span className="font-semibold" style={{ color: '#fce3ff' }}>{item.price}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* PROFILE SCREEN */}
        <section 
          className={`absolute inset-0 px-4 pt-4 pb-20 overflow-y-auto transition-all duration-250 ${
            activeScreen === 'profile' ? 'opacity-100 translate-x-0 pointer-events-auto' : 'opacity-0 translate-x-3 pointer-events-none'
          }`}
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          <div className="rounded-[18px] border p-4 shadow-lg" style={{
            background: 'linear-gradient(160deg, #080015, #020006)',
            borderColor: 'rgba(255, 255, 255, 0.13)'
          }}>
            <div className="text-[11px] uppercase tracking-wider mb-1.5" style={{ color: '#b8a6cf' }}>
              Profile
            </div>
            <div className="text-[18px] font-semibold mb-2" style={{
              background: 'linear-gradient(120deg, #fff, #886E9D, #ffaaff)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Demigod Snapshot
            </div>
            <div className="text-xs mb-4" style={{ color: '#b8a6cf', opacity: 0.8 }}>
              A lightweight mock of how your MDC profile could look.
            </div>

            {[
              { label: "Rank", value: "Demigod · S-tier" },
              { label: "Patterns contributed", value: "128" },
              { label: "Modules improved", value: "37" },
              { label: "PvP wins", value: "24" }
            ].map((stat, idx) => (
              <div 
                key={idx}
                className="flex justify-between py-1.5 text-xs"
                style={{ color: '#b8a6cf' }}
              >
                <span>{stat.label}</span>
                <span style={{ color: '#f5e8ff' }}>{stat.value}</span>
              </div>
            ))}

            <div className="inline-flex px-2.5 py-1 rounded-full border text-[11px] mt-3" style={{
              borderColor: 'rgba(255, 255, 255, 0.2)',
              color: '#b8a6cf'
            }}>
              Godlike code insight · beta
            </div>
          </div>
        </section>
      </div>

      {/* BOTTOM NAVIGATION */}
      <div className="h-[60px] border-t flex justify-around items-center z-10" style={{
        background: 'rgba(5, 0, 20, 0.95)',
        backdropFilter: 'blur(14px)',
        borderColor: 'rgba(255, 255, 255, 0.13)'
      }}>
        {[
          { id: "dashboard", icon: "🏠", label: "Dashboard" },
          { id: "agents", icon: "🔮", label: "Agents" },
          { id: "market", icon: "💠", label: "Market" },
          { id: "profile", icon: "👤", label: "Profile" }
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveScreen(item.id)}
            className="flex flex-col items-center gap-0.5 text-[10px] transition-colors"
            style={{ 
              color: activeScreen === item.id ? '#fff' : '#b8a6cf',
              WebkitTapHighlightColor: 'transparent'
            }}
          >
            <span className="text-[17px]">{item.icon}</span>
            <span>{item.label}</span>
          </button>
        ))}
      </div>

      {/* AGENT INFO SHEET */}
      <div 
        className="fixed left-0 right-0 rounded-t-[20px] border-t transition-all duration-300 z-50"
        style={{
          bottom: agentInfoOpen ? '0' : '-60%',
          height: '55%',
          background: '#04000a',
          borderColor: 'rgba(255, 255, 255, 0.13)',
          boxShadow: '0 -4px 22px #000'
        }}
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            setAgentInfoOpen(false);
          }
        }}
      >
        <div className="p-4">
          <div className="w-10 h-1 rounded-full mx-auto mb-2.5" style={{ background: 'rgba(255, 255, 255, 0.2)' }} />
          
          {selectedAgent && (
            <>
              <h3 className="text-base font-semibold mb-2.5" style={{
                background: 'linear-gradient(120deg, #fff, #886E9D, #ffaaff)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}>
                {selectedAgent.role.toUpperCase()} AGENT
              </h3>

              <div className="space-y-2">
                {[
                  { label: "Status", value: selectedAgent.status },
                  { label: "Last Action", value: selectedAgent.action },
                  { label: "Confidence", value: selectedAgent.conf },
                  { label: "Pattern Depth", value: selectedAgent.depth },
                  { label: "Impact", value: selectedAgent.impact }
                ].map((field, idx) => (
                  <div key={idx} className="text-[13px]" style={{ color: '#f5e8ff' }}>
                    <span className="text-[11px]" style={{ color: '#b8a6cf' }}>{field.label}: </span>
                    {field.value}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Overlay when agent info open */}
      {agentInfoOpen && (
        <div 
          className="fixed inset-0 bg-black/40 z-40"
          onClick={() => setAgentInfoOpen(false)}
        />
      )}
    </div>
  );
}