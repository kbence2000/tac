import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CodeAnalysisPanel from "../components/CodeAnalysisPanel";
import { 
  DollarSign, ShoppingCart, TrendingUp, Award,
  Users, Code2, Zap, AlertCircle 
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const BACKEND_URL = import.meta.env.VITE_MDC_BACKEND_URL || "http://localhost:3000";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: transactions } = useQuery({
    queryKey: ['transactions'],
    queryFn: () => base44.entities.Transaction.list('-created_date'),
    enabled: user?.role === 'admin',
    initialData: [],
  });

  const { data: apps } = useQuery({
    queryKey: ['apps'],
    queryFn: () => base44.entities.App.list('-created_date'),
    enabled: user?.role === 'admin',
    initialData: [],
  });

  const { data: users } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list('-created_date'),
    enabled: user?.role === 'admin',
    initialData: [],
  });

  // Fetch demigod profiles
  const { data: demigods } = useQuery({
    queryKey: ['allDemigods'],
    queryFn: async () => {
      try {
        const res = await fetch(`${BACKEND_URL}/api/search`);
        if (!res.ok) return [];
        const data = await res.json();
        return data.result || [];
      } catch {
        return [];
      }
    },
    enabled: user?.role === 'admin',
    initialData: [],
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <Card className="border-[#1a1f2e] bg-[#0f1419] p-8 text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Access Denied</h2>
          <p className="text-gray-400">You need admin privileges to access this page.</p>
        </Card>
      </div>
    );
  }

  const totalRevenue = transactions.reduce((sum, t) => sum + t.amount_paid, 0);
  const totalPlatformFee = transactions.reduce((sum, t) => sum + t.platform_fee, 0);
  const totalSellerNet = transactions.reduce((sum, t) => sum + t.seller_net, 0);
  const avgCommission = transactions.length > 0
    ? transactions.reduce((sum, t) => sum + t.commission_rate, 0) / transactions.length
    : 0;

  const sellerStats = transactions.reduce((acc, t) => {
    if (!acc[t.seller_email]) {
      acc[t.seller_email] = { totalNet: 0, count: 0 };
    }
    acc[t.seller_email].totalNet += t.seller_net;
    acc[t.seller_email].count += 1;
    return acc;
  }, {});

  const topSellers = Object.entries(sellerStats)
    .map(([email, stats]) => ({ email, ...stats }))
    .sort((a, b) => b.totalNet - a.totalNet)
    .slice(0, 5);

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl font-black text-white mb-8">Admin Dashboard</h1>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-[#0f1419] border border-[#1a1f2e] mb-6">
            <TabsTrigger value="overview" className="data-[state=active]:bg-[#1a1f2e]">
              Overview
            </TabsTrigger>
            <TabsTrigger value="transactions" className="data-[state=active]:bg-[#1a1f2e]">
              Transactions
            </TabsTrigger>
            <TabsTrigger value="demigods" className="data-[state=active]:bg-[#1a1f2e]">
              Demigods
            </TabsTrigger>
            <TabsTrigger value="tools" className="data-[state=active]:bg-[#1a1f2e]">
              Dev Tools
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center justify-between mb-4">
                  <DollarSign className="w-8 h-8 text-green-500" />
                  <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                    Revenue
                  </Badge>
                </div>
                <div className="text-3xl font-black text-white mb-1">
                  {totalPlatformFee.toLocaleString()} Ft
                </div>
                <p className="text-sm text-gray-400">Platform Fee Earned</p>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center justify-between mb-4">
                  <TrendingUp className="w-8 h-8 text-blue-500" />
                  <Badge className="bg-blue-600/20 text-blue-400 border-blue-600/30">
                    Total
                  </Badge>
                </div>
                <div className="text-3xl font-black text-white mb-1">
                  {totalRevenue.toLocaleString()} Ft
                </div>
                <p className="text-sm text-gray-400">Total Transaction Volume</p>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center justify-between mb-4">
                  <ShoppingCart className="w-8 h-8 text-purple-500" />
                  <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30">
                    Sales
                  </Badge>
                </div>
                <div className="text-3xl font-black text-white mb-1">
                  {transactions.length}
                </div>
                <p className="text-sm text-gray-400">Total Purchases</p>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center justify-between mb-4">
                  <Award className="w-8 h-8 text-amber-500" />
                  <Badge className="bg-amber-600/20 text-amber-400 border-amber-600/30">
                    Avg
                  </Badge>
                </div>
                <div className="text-3xl font-black text-white mb-1">
                  {(avgCommission * 100).toFixed(1)}%
                </div>
                <p className="text-sm text-gray-400">Average Commission Rate</p>
              </Card>
            </div>

            {/* Top Sellers */}
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-xl font-bold text-white mb-4">Top Sellers</h3>
              <div className="space-y-3">
                {topSellers.map((seller, idx) => (
                  <div key={seller.email} className="flex items-center justify-between p-3 rounded-lg bg-[#141923]">
                    <div className="flex items-center gap-3">
                      <div className="text-lg font-bold text-gray-600">#{idx + 1}</div>
                      <div>
                        <div className="text-sm font-semibold text-white">{seller.email}</div>
                        <div className="text-xs text-gray-500">{seller.count} transactions</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-green-400">
                        {seller.totalNet.toLocaleString()} Ft
                      </div>
                      <div className="text-xs text-gray-500">Net earnings</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-xl font-bold text-white mb-4">Recent Transactions</h3>
              <div className="space-y-3">
                {transactions.slice(0, 10).map(transaction => (
                  <div key={transaction.id} className="p-3 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className="bg-purple-600/20 text-purple-400 border-purple-600/30">
                          {transaction.license_type}
                        </Badge>
                        <span className="text-sm text-gray-400">
                          {formatDistanceToNow(new Date(transaction.created_date), { addSuffix: true })}
                        </span>
                      </div>
                      <div className="text-lg font-bold text-white">
                        {transaction.amount_paid.toLocaleString()} Ft
                      </div>
                    </div>
                    <div className="text-xs text-gray-400 space-y-1">
                      <div>Buyer: <span className="text-gray-300">{transaction.buyer_email}</span></div>
                      <div>Seller: <span className="text-gray-300">{transaction.seller_email}</span></div>
                      <div className="flex gap-3 mt-2">
                        <span>Platform: <span className="text-green-400">{transaction.platform_fee} Ft</span></span>
                        <span>Seller Net: <span className="text-blue-400">{transaction.seller_net} Ft</span></span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="demigods" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Users className="w-6 h-6 text-purple-400" />
                  <span className="text-sm text-gray-400">Total Demigods</span>
                </div>
                <div className="text-3xl font-black text-white">{demigods.length}</div>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Award className="w-6 h-6 text-amber-500" />
                  <span className="text-sm text-gray-400">R6+ Demigods</span>
                </div>
                <div className="text-3xl font-black text-white">
                  {demigods.filter(d => ['R6', 'R7'].includes(d.mdcTier.id)).length}
                </div>
              </Card>

              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Zap className="w-6 h-6 text-cyan-400" />
                  <span className="text-sm text-gray-400">Avg Score</span>
                </div>
                <div className="text-3xl font-black text-white">
                  {demigods.length > 0 
                    ? (demigods.reduce((sum, d) => sum + d.scores.totalScore, 0) / demigods.length).toFixed(0)
                    : 0}
                </div>
              </Card>
            </div>

            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-xl font-bold text-white mb-4">Top Demigods</h3>
              <div className="space-y-2">
                {demigods
                  .sort((a, b) => b.scores.totalScore - a.scores.totalScore)
                  .slice(0, 10)
                  .map((demigod, idx) => (
                    <div key={demigod.userId} className="p-3 rounded-lg bg-[#141923] flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-bold text-gray-600">#{idx + 1}</div>
                        <div>
                          <div className="text-sm font-semibold text-white">
                            {demigod.github?.username || demigod.userId}
                          </div>
                          <div className="text-xs text-gray-500">{demigod.mdcTier.name}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-purple-400">{demigod.scores.totalScore}</div>
                        <div className="text-xs text-gray-500">Score</div>
                      </div>
                    </div>
                  ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="tools" className="space-y-6">
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <div className="flex items-center gap-3 mb-4">
                <Code2 className="w-6 h-6 text-purple-400" />
                <div>
                  <h3 className="text-xl font-bold text-white">Developer Tools</h3>
                  <p className="text-sm text-gray-400">Docker code analysis and testing</p>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-blue-600/10 border border-blue-600/30 mb-6">
                <p className="text-sm text-blue-300 leading-relaxed">
                  <strong>Admin Only:</strong> Run code analysis on any GitHub repository. Results are used for AI quality scoring.
                </p>
              </div>

              <CodeAnalysisPanel 
                userId="admin"
                initialRepoUrl=""
                onAnalysisComplete={(result) => {
                  console.log("Analysis complete:", result);
                }}
              />
            </Card>

            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-xl font-bold text-white mb-4">Platform Stats</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-[#141923]">
                  <div className="text-2xl font-bold text-white">{apps.length}</div>
                  <div className="text-sm text-gray-400">Total Apps</div>
                </div>
                <div className="p-4 rounded-lg bg-[#141923]">
                  <div className="text-2xl font-bold text-white">{users.length}</div>
                  <div className="text-sm text-gray-400">Total Users</div>
                </div>
                <div className="p-4 rounded-lg bg-[#141923]">
                  <div className="text-2xl font-bold text-white">
                    {apps.filter(a => a.verified).length}
                  </div>
                  <div className="text-sm text-gray-400">Verified Apps</div>
                </div>
                <div className="p-4 rounded-lg bg-[#141923]">
                  <div className="text-2xl font-bold text-white">
                    {apps.filter(a => a.featured).length}
                  </div>
                  <div className="text-sm text-gray-400">Featured Apps</div>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}