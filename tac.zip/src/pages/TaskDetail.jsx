import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  ArrowLeft, Calendar, DollarSign, Code, ExternalLink,
  User, Send, Briefcase
} from "lucide-react";
import { toast } from "sonner";

export default function TaskDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const taskId = urlParams.get('id');
  const queryClient = useQueryClient();

  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const [applicationData, setApplicationData] = useState({
    cover_letter: "",
    bid_type: "fixed",
    bid_amount: "",
    estimated_hours: ""
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: task, isLoading } = useQuery({
    queryKey: ['task', taskId],
    queryFn: async () => {
      const tasks = await base44.entities.Task.filter({ id: taskId });
      return tasks[0];
    },
    enabled: !!taskId,
  });

  const { data: applications } = useQuery({
    queryKey: ['task-applications', taskId],
    queryFn: () => base44.entities.Application.filter({ task_id: taskId }, '-created_date'),
    enabled: !!taskId,
    initialData: [],
  });

  const { data: expertProfile } = useQuery({
    queryKey: ['my-expert-profile', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const profiles = await base44.entities.ExpertProfile.filter({ user_email: user.email });
      return profiles[0] || null;
    },
    enabled: !!user,
  });

  const applyMutation = useMutation({
    mutationFn: (data) => base44.entities.Application.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['task-applications', taskId] });
      setShowApplicationForm(false);
      toast.success("Jelentkezés elküldve!");
      setApplicationData({ cover_letter: "", bid_type: "fixed", bid_amount: "", estimated_hours: "" });
    },
    onError: () => {
      toast.error("Hiba a jelentkezés során!");
    }
  });

  const handleApply = (e) => {
    e.preventDefault();
    
    if (!user) {
      toast.error("Jelentkezz be a jelentkezéshez!");
      return;
    }

    if (!expertProfile) {
      toast.error("Először hozz létre szakértői profilt!");
      return;
    }

    if (!applicationData.cover_letter || !applicationData.bid_amount) {
      toast.error("Töltsd ki az összes kötelező mezőt!");
      return;
    }

    applyMutation.mutate({
      task_id: taskId,
      expert_email: user.email,
      cover_letter: applicationData.cover_letter,
      bid_type: applicationData.bid_type,
      bid_amount: Number(applicationData.bid_amount),
      estimated_hours: applicationData.estimated_hours ? Number(applicationData.estimated_hours) : null
    });
  };

  const myApplication = applications.find(app => app.expert_email === user?.email);
  const isTaskOwner = user && task && task.company_id === user.email;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-[#00E599] border-t-transparent"></div>
      </div>
    );
  }

  if (!task) {
    return (
      <div className="min-h-screen bg-[#0A0E14] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Feladat nem található</h2>
          <Link to={createPageUrl("ExpertMarketplace")}>
            <Button className="bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold">
              Vissza a piactérre
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to={createPageUrl("ExpertMarketplace")}>
          <Button variant="ghost" className="mb-6 text-gray-400 hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Vissza
          </Button>
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h1 className="text-3xl font-black text-white mb-2">{task.title}</h1>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <User className="w-4 h-4" />
                    <span>{task.company_id}</span>
                    <span>•</span>
                    <span>{new Date(task.created_date).toLocaleDateString('hu-HU')}</span>
                  </div>
                </div>
                <Badge className={task.status === 'open' ? 'bg-green-600/20 text-green-400' : 'bg-gray-600/20 text-gray-400'}>
                  {task.status === 'open' ? '🟢 Nyitott' : task.status === 'in_progress' ? '🔵 Folyamatban' : '✅ Befejezett'}
                </Badge>
              </div>

              <div className="prose prose-invert max-w-none">
                <p className="text-gray-300 whitespace-pre-line">{task.description}</p>
              </div>

              {(task.repo_link || task.file_link) && (
                <div className="mt-6 flex flex-wrap gap-3">
                  {task.repo_link && (
                    <a
                      href={task.repo_link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#1a1f2e] text-gray-300 hover:text-white hover:border-[#00E599] transition-colors"
                    >
                      <Code className="w-4 h-4" />
                      Repository
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                  {task.file_link && (
                    <a
                      href={task.file_link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#1a1f2e] text-gray-300 hover:text-white hover:border-[#00E599] transition-colors"
                    >
                      <Briefcase className="w-4 h-4" />
                      Dokumentáció
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              )}
            </Card>

            {/* Application Form */}
            {task.status === 'open' && !isTaskOwner && !myApplication && (
              <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
                {!showApplicationForm ? (
                  <Button
                    onClick={() => setShowApplicationForm(true)}
                    className="w-full bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Jelentkezés a feladatra
                  </Button>
                ) : (
                  <form onSubmit={handleApply} className="space-y-4">
                    <h3 className="text-xl font-bold text-white mb-4">Jelentkezési adatok</h3>
                    
                    <div>
                      <Label className="text-white mb-2 block">Motivációs levél *</Label>
                      <Textarea
                        value={applicationData.cover_letter}
                        onChange={(e) => setApplicationData({...applicationData, cover_letter: e.target.value})}
                        className="bg-[#141923] border-[#1a1f2e] text-white min-h-[120px]"
                        placeholder="Mutatkozz be és mondd el, miért Te vagy a megfelelő szakértő..."
                        required
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-white mb-2 block">Ajánlat típusa *</Label>
                        <select
                          value={applicationData.bid_type}
                          onChange={(e) => setApplicationData({...applicationData, bid_type: e.target.value})}
                          className="w-full px-4 py-2 rounded-lg bg-[#141923] border border-[#1a1f2e] text-white"
                        >
                          <option value="fixed">Fix ár</option>
                          <option value="hourly">Óradíj alapú</option>
                        </select>
                      </div>

                      <div>
                        <Label className="text-white mb-2 block">Ajánlat ({task.currency}) *</Label>
                        <Input
                          type="number"
                          value={applicationData.bid_amount}
                          onChange={(e) => setApplicationData({...applicationData, bid_amount: e.target.value})}
                          className="bg-[#141923] border-[#1a1f2e] text-white"
                          placeholder={applicationData.bid_type === 'fixed' ? 'Teljes összeg' : 'Óradíj'}
                          required
                        />
                      </div>
                    </div>

                    {applicationData.bid_type === 'hourly' && (
                      <div>
                        <Label className="text-white mb-2 block">Becsült óraszám</Label>
                        <Input
                          type="number"
                          value={applicationData.estimated_hours}
                          onChange={(e) => setApplicationData({...applicationData, estimated_hours: e.target.value})}
                          className="bg-[#141923] border-[#1a1f2e] text-white"
                          placeholder="Körülbelül hány óra kell a feladat elvégzéséhez?"
                        />
                      </div>
                    )}

                    <div className="flex gap-3 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowApplicationForm(false)}
                        className="flex-1 border-[#1a1f2e] text-white"
                      >
                        Mégse
                      </Button>
                      <Button
                        type="submit"
                        disabled={applyMutation.isPending}
                        className="flex-1 bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold"
                      >
                        {applyMutation.isPending ? 'Küldés...' : 'Jelentkezés Elküldése'}
                      </Button>
                    </div>
                  </form>
                )}
              </Card>
            )}

            {myApplication && (
              <Card className="border border-green-600/30 bg-green-600/10 p-6">
                <div className="flex items-center gap-2 mb-2">
                  <Badge className="bg-green-600/20 text-green-400">
                    {myApplication.status === 'pending' ? '⏳ Függőben' : myApplication.status === 'accepted' ? '✅ Elfogadva' : '❌ Elutasítva'}
                  </Badge>
                </div>
                <p className="text-green-200 text-sm">
                  Jelentkeztél erre a feladatra{myApplication.bid_type === 'fixed' ? ` ${myApplication.bid_amount} ${task.currency} fix árral` : ` ${myApplication.bid_amount} ${task.currency}/óra óradíjjal`}
                </p>
              </Card>
            )}

            {/* Applications List (Task Owner Only) */}
            {isTaskOwner && applications.length > 0 && (
              <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-xl font-bold text-white mb-4">
                  Jelentkezések ({applications.length})
                </h3>
                <div className="space-y-4">
                  {applications.map(app => (
                    <div key={app.id} className="p-4 rounded-lg bg-[#141923] border border-[#1a1f2e]">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-semibold text-white">{app.expert_email}</p>
                          <p className="text-sm text-gray-400">
                            {app.bid_type === 'fixed' ? `${app.bid_amount} ${task.currency} fix` : `${app.bid_amount} ${task.currency}/óra`}
                            {app.estimated_hours && ` · ~${app.estimated_hours} óra`}
                          </p>
                        </div>
                        <Badge className={`${app.status === 'accepted' ? 'bg-green-600/20 text-green-400' : 'bg-gray-600/20 text-gray-400'}`}>
                          {app.status === 'pending' ? 'Függőben' : app.status === 'accepted' ? 'Elfogadva' : 'Elutasítva'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-300 whitespace-pre-line">{app.cover_letter}</p>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
              <h3 className="text-lg font-bold text-white mb-4">Feladat részletek</h3>
              
              <div className="space-y-4">
                {task.budget_min && task.budget_max && (
                  <div className="flex items-center gap-3">
                    <DollarSign className="w-5 h-5 text-[#00E599]" />
                    <div>
                      <p className="text-xs text-gray-400">Költségvetés</p>
                      <p className="text-white font-semibold">
                        {task.budget_min}-{task.budget_max} {task.currency}
                      </p>
                    </div>
                  </div>
                )}

                {task.deadline && (
                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-blue-400" />
                    <div>
                      <p className="text-xs text-gray-400">Határidő</p>
                      <p className="text-white font-semibold">
                        {new Date(task.deadline).toLocaleDateString('hu-HU')}
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <Briefcase className="w-5 h-5 text-purple-400" />
                  <div>
                    <p className="text-xs text-gray-400">Típus</p>
                    <p className="text-white font-semibold capitalize">{task.type}</p>
                  </div>
                </div>
              </div>
            </Card>

            {task.tech_stack && task.tech_stack.length > 0 && (
              <Card className="border border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-lg font-bold text-white mb-4">Technológiák</h3>
                <div className="flex flex-wrap gap-2">
                  {task.tech_stack.map((tech, idx) => (
                    <Badge key={idx} variant="outline" className="border-[#1a1f2e] text-gray-300">
                      <Code className="w-3 h-3 mr-1" />
                      {tech}
                    </Badge>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}