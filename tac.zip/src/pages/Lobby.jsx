import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, Send, Users, Sparkles, Zap, Code2, Crown } from "lucide-react";
import { toast } from "sonner";

export default function Lobby() {
  const [messageText, setMessageText] = useState("");
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: messages, isLoading } = useQuery({
    queryKey: ['chatMessages'],
    queryFn: async () => {
      const msgs = await base44.entities.ChatMessage.list('-created_date', 100);
      return msgs.reverse(); // Oldest first for chat display
    },
    initialData: [],
    refetchInterval: 3000, // Auto-refresh every 3 seconds
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (msg) => {
      return await base44.entities.ChatMessage.create({
        user_email: user.email,
        user_name: user.full_name || user.email.split('@')[0],
        message: msg,
        is_system: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatMessages'] });
      setMessageText("");
    },
    onError: () => {
      toast.error("Hiba az üzenet küldése során");
    }
  });

  const handleSend = (e) => {
    e.preventDefault();
    
    if (!user) {
      toast.error("Jelentkezz be a chathez!");
      return;
    }

    if (!messageText.trim()) {
      return;
    }

    sendMessageMutation.mutate(messageText.trim());
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const onlineUsers = [...new Set(messages
    .filter(m => !m.is_system)
    .map(m => m.user_name || m.user_email)
  )].length;

  const formatTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "most";
    if (diffMins < 60) return `${diffMins}p`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}ó`;
    return date.toLocaleDateString('hu-HU', { month: 'short', day: 'numeric' });
  };

  const getUserColor = (email) => {
    const colors = [
      'from-purple-500 to-pink-500',
      'from-blue-500 to-cyan-500',
      'from-green-500 to-emerald-500',
      'from-orange-500 to-red-500',
      'from-yellow-500 to-orange-500',
      'from-indigo-500 to-purple-500',
      'from-pink-500 to-rose-500',
      'from-cyan-500 to-blue-500',
    ];
    const index = email.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return colors[index % colors.length];
  };

  const getUserBadge = (email) => {
    if (email.includes('admin')) {
      return { icon: Crown, label: 'Admin', color: 'text-yellow-400' };
    }
    if (email.includes('pro') || email.includes('dev')) {
      return { icon: Code2, label: 'Dev', color: 'text-blue-400' };
    }
    return null;
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-[1120px] mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl relative overflow-hidden" style={{
                background: 'radial-gradient(circle at 0 0, rgba(139, 92, 255, 0.3), transparent 70%)',
                border: '1px solid rgba(139, 92, 255, 0.5)'
              }}>
                <MessageSquare className="w-8 h-8" style={{ color: 'var(--accent-alt)' }} />
                <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-green-400" style={{
                  boxShadow: '0 0 12px rgba(74, 222, 128, 0.9)',
                  animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite'
                }} />
              </div>
              <div>
                <h1 className="text-4xl font-black text-white">Code Demigods Lobby</h1>
                <p className="text-gray-400 mt-1">Közösségi chat tér - Csatlakozz a beszélgetéshez!</p>
              </div>
            </div>

            <div className="hidden md:flex items-center gap-3">
              <Badge className="bg-green-600/20 text-green-400 border border-green-600/30 px-4 py-2">
                <Users className="w-4 h-4 mr-2" />
                {onlineUsers} aktív
              </Badge>
            </div>
          </div>

          {/* Mobile stats */}
          <div className="md:hidden">
            <Badge className="bg-green-600/20 text-green-400 border border-green-600/30">
              <Users className="w-4 h-4 mr-2" />
              {onlineUsers} aktív felhasználó
            </Badge>
          </div>
        </div>

        {/* Chat Container */}
        <Card 
          className="border relative overflow-hidden"
          style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)',
            boxShadow: '0 12px 28px rgba(15, 23, 42, 0.8)',
            borderRadius: '18px',
            height: 'calc(100vh - 280px)',
            minHeight: '500px',
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          {/* Animated background */}
          <div className="absolute inset-0 pointer-events-none opacity-30">
            <div 
              className="absolute top-0 right-0 w-96 h-96 rounded-full blur-3xl"
              style={{
                background: 'radial-gradient(circle, rgba(139, 92, 255, 0.3), transparent 70%)',
                animation: 'float 8s ease-in-out infinite'
              }}
            />
            <div 
              className="absolute bottom-0 left-0 w-96 h-96 rounded-full blur-3xl"
              style={{
                background: 'radial-gradient(circle, rgba(36, 228, 255, 0.3), transparent 70%)',
                animation: 'float 10s ease-in-out infinite reverse'
              }}
            />
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 relative z-10" style={{
            scrollbarWidth: 'thin',
            scrollbarColor: 'rgba(139, 92, 255, 0.5) rgba(15, 23, 42, 0.5)'
          }}>
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-t-transparent mb-4" style={{ borderColor: 'var(--accent)' }}></div>
                  <p className="text-gray-400">Betöltés...</p>
                </div>
              </div>
            ) : messages.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <Sparkles className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                  <h3 className="text-xl font-bold text-white mb-2">Üdv a Lobby-ban!</h3>
                  <p className="text-gray-400">Légy te az első aki üzenetet küld!</p>
                </div>
              </div>
            ) : (
              <>
                {messages.map((msg) => {
                  const isCurrentUser = user && msg.user_email === user.email;
                  const userBadge = getUserBadge(msg.user_email);
                  const BadgeIcon = userBadge?.icon;

                  if (msg.is_system) {
                    return (
                      <div key={msg.id} className="flex justify-center">
                        <div className="px-4 py-2 rounded-full border text-xs" style={{
                          background: 'rgba(139, 92, 255, 0.1)',
                          borderColor: 'rgba(139, 92, 255, 0.3)',
                          color: 'var(--accent-alt)'
                        }}>
                          <Sparkles className="w-3 h-3 inline mr-1" />
                          {msg.message}
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div key={msg.id} className={`flex gap-3 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
                      {/* Avatar */}
                      <div 
                        className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-gradient-to-br ${getUserColor(msg.user_email)}`}
                      >
                        <span className="text-white font-bold text-sm">
                          {(msg.user_name || msg.user_email).charAt(0).toUpperCase()}
                        </span>
                      </div>

                      {/* Message Bubble */}
                      <div className={`flex-1 max-w-[70%] ${isCurrentUser ? 'text-right' : 'text-left'}`}>
                        {/* User name & badge */}
                        <div className={`flex items-center gap-2 mb-1 ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
                          <span className="text-sm font-semibold text-white">
                            {msg.user_name || msg.user_email.split('@')[0]}
                          </span>
                          {userBadge && (
                            <Badge className={`text-xs px-1.5 py-0 ${userBadge.color}`} style={{
                              background: 'rgba(15, 23, 42, 0.9)',
                              border: `1px solid ${userBadge.color === 'text-yellow-400' ? 'rgba(250, 204, 21, 0.5)' : 'rgba(96, 165, 250, 0.5)'}`
                            }}>
                              <BadgeIcon className="w-3 h-3 mr-0.5" />
                              {userBadge.label}
                            </Badge>
                          )}
                          <span className="text-xs text-gray-500">{formatTime(msg.created_date)}</span>
                        </div>

                        {/* Message content */}
                        <div 
                          className={`inline-block px-4 py-2.5 rounded-2xl ${
                            isCurrentUser 
                              ? 'rounded-tr-sm' 
                              : 'rounded-tl-sm'
                          }`}
                          style={{
                            background: isCurrentUser 
                              ? 'linear-gradient(135deg, rgba(139, 92, 255, 0.3), rgba(139, 92, 255, 0.15))' 
                              : 'rgba(11, 16, 32, 0.9)',
                            border: `1px solid ${isCurrentUser ? 'rgba(139, 92, 255, 0.5)' : 'rgba(148, 163, 184, 0.35)'}`
                          }}
                        >
                          <p className="text-white text-sm leading-relaxed break-words whitespace-pre-wrap">
                            {msg.message}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          {/* Input Area */}
          <div className="border-t p-4 relative z-10" style={{ borderColor: 'rgba(148, 163, 184, 0.35)' }}>
            {user ? (
              <form onSubmit={handleSend} className="flex gap-3">
                <Input
                  type="text"
                  placeholder="Írj egy üzenetet..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  className="flex-1 h-12 border text-white placeholder:text-gray-500"
                  style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
                  maxLength={500}
                  disabled={sendMessageMutation.isPending}
                />
                <Button 
                  type="submit"
                  disabled={sendMessageMutation.isPending || !messageText.trim()}
                  className="h-12 px-6 font-bold"
                  style={{
                    background: 'radial-gradient(circle at 0 0, var(--accent-alt), transparent 45%), var(--accent)',
                    color: 'white'
                  }}
                >
                  {sendMessageMutation.isPending ? (
                    <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full" />
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Küldés
                    </>
                  )}
                </Button>
              </form>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-400 mb-4">Jelentkezz be, hogy csatlakozhass a beszélgetéshez!</p>
                <Button
                  onClick={() => base44.auth.redirectToLogin()}
                  className="font-bold"
                  style={{
                    background: 'radial-gradient(circle at 0 0, var(--accent-alt), transparent 45%), var(--accent)',
                    color: 'white'
                  }}
                >
                  Bejelentkezés
                </Button>
              </div>
            )}
          </div>
        </Card>

        {/* Info Cards */}
        <div className="grid md:grid-cols-3 gap-4 mt-6">
          <Card className="border p-4 text-center" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <MessageSquare className="w-8 h-8 mx-auto mb-2" style={{ color: 'var(--accent-alt)' }} />
            <div className="text-2xl font-bold text-white mb-1">{messages.length}</div>
            <div className="text-xs text-gray-400">Összes üzenet</div>
          </Card>

          <Card className="border p-4 text-center" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <Users className="w-8 h-8 mx-auto mb-2 text-green-400" />
            <div className="text-2xl font-bold text-white mb-1">{onlineUsers}</div>
            <div className="text-xs text-gray-400">Aktív felhasználó</div>
          </Card>

          <Card className="border p-4 text-center" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <Zap className="w-8 h-8 mx-auto mb-2" style={{ color: 'var(--accent)' }} />
            <div className="text-2xl font-bold text-white mb-1">Live</div>
            <div className="text-xs text-gray-400">Real-time chat</div>
          </Card>
        </div>

        <style jsx>{`
          @keyframes float {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
          }
        `}</style>
      </div>
    </div>
  );
}