import React from 'react';

export default function MatrixHub() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-4">Matrix Hub</h1>
        <p className="text-gray-400">Clean slate - ready to rebuild</p>
      </div>
    </div>
  );
}