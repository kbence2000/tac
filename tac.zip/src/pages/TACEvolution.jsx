import React, { useState } from 'react';
import { Shield, Zap, Brain, Target, CheckCircle2, Loader2, AlertTriangle, Code, Lock, Sparkles, Eye } from 'lucide-react';

export default function TACEvolution() {
  const [moduleName, setModuleName] = useState("TrendHarvester");
  const [currentSpec, setCurrentSpec] = useState("Real-time trend monitoring system that scans multiple sources and extracts code patterns.");
  const [currentCode, setCurrentCode] = useState("");
  const [intensity, setIntensity] = useState(7);
  const [isRunning, setIsRunning] = useState(false);
  const [currentStage, setCurrentStage] = useState(null);
  const [evolutionResult, setEvolutionResult] = useState(null);
  const [error, setError] = useState(null);

  const runEvolution = async () => {
    if (isRunning || !moduleName.trim() || !currentSpec.trim()) return;

    setIsRunning(true);
    setError(null);
    setEvolutionResult(null);
    setCurrentStage('harmony');

    try {
      // Simulate stage progression
      setTimeout(() => setCurrentStage('distorted'), 2000);
      setTimeout(() => setCurrentStage('paradox'), 4000);
      setTimeout(() => setCurrentStage('hallucinator'), 6000);
      setTimeout(() => setCurrentStage('stabilizer'), 8000);

      const response = await fetch('http://localhost:8090/api/evolution/evolve-module', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          moduleName,
          currentSpec,
          currentCode: currentCode || undefined,
          intensity
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setEvolutionResult(data.result);
      setCurrentStage('complete');

    } catch (err) {
      console.error('Evolution error:', err);
      setError(err.message);
      setCurrentStage(null);
    } finally {
      setIsRunning(false);
    }
  };

  const getIntensityLabel = (level) => {
    if (level <= 2) return "Controlled";
    if (level <= 4) return "Enhanced";
    if (level <= 6) return "Amplified";
    if (level <= 8) return "Radical";
    return "Extreme";
  };

  const getIntensityColor = (level) => {
    if (level <= 2) return "#3b82f6";
    if (level <= 4) return "#22c55e";
    if (level <= 6) return "#a855f7";
    if (level <= 8) return "#f97316";
    return "#ef4444";
  };

  const stages = [
    { 
      id: 'harmony', 
      name: 'Harmony 9', 
      icon: Shield, 
      color: '#3b82f6',
      description: 'Stability & Structure Council'
    },
    { 
      id: 'distorted', 
      name: 'Distorted 9', 
      icon: Zap, 
      color: '#ef4444',
      description: 'Radical Mutation Council'
    },
    { 
      id: 'paradox', 
      name: 'Paradox Core', 
      icon: Target, 
      color: '#a855f7',
      description: 'Conflict Resolution Engine'
    },
    { 
      id: 'hallucinator', 
      name: 'Hallucinator', 
      icon: Brain, 
      color: '#ec4899',
      description: 'Creative Augmentation Node'
    },
    { 
      id: 'stabilizer', 
      name: 'Stabilizer', 
      icon: Lock, 
      color: '#22c55e',
      description: 'Final Assembly Core'
    },
  ];

  return (
    <div className="relative min-h-screen p-4 md:p-6" style={{
      background: 'radial-gradient(circle at 0% 0%, #0f0a1e 0%, #030108 40%, #000 80%)'
    }}>
      <style>{`
        @keyframes tacPulse {
          0%, 100% { opacity: 0.4; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.08); }
        }

        @keyframes tacFlicker {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }

        @keyframes tacSlideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .tac-active {
          animation: tacPulse 1.8s ease-in-out infinite;
        }

        .tac-stage-item {
          animation: tacSlideUp 0.4s ease-out;
        }

        .tac-border {
          border: 1px solid rgba(168, 85, 247, 0.2);
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.8);
        }

        .tac-title {
          text-shadow: 0 0 10px rgba(168, 85, 247, 0.5);
        }
      `}</style>

      {/* Container */}
      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-4 mb-3">
            <Lock className="w-9 h-9 text-purple-400" style={{ opacity: 0.7 }} />
            <h1 className="text-4xl md:text-5xl font-black tracking-[0.15em] uppercase tac-title text-white">
              TAC EVOLUTION
            </h1>
            <Eye className="w-9 h-9 text-purple-400" style={{ opacity: 0.7 }} />
          </div>
          <p className="text-[10px] text-gray-500 tracking-[0.25em] uppercase mb-2">
            [ TACTICAL AUGMENTED COGNITION ]
          </p>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] uppercase tracking-[0.2em]"
            style={{
              background: 'rgba(168, 85, 247, 0.15)',
              border: '1px solid rgba(168, 85, 247, 0.3)',
              boxShadow: '0 0 15px rgba(168, 85, 247, 0.2)'
            }}
          >
            <Lock className="w-3 h-3" />
            CLASSIFIED: PARADOXON ENGINE v1.0
          </div>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-xl tac-border"
          style={{
            background: 'rgba(15, 10, 30, 0.8)'
          }}
        >
          <div className="flex items-start gap-3">
            <Eye className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" style={{ opacity: 0.6 }} />
            <div className="text-xs text-gray-400 leading-relaxed">
              <span className="font-bold text-purple-300">TAC Paradoxon Evolution Engine:</span> 
              {' '}A hidden 5-stage system for evolving API modules through: 
              <strong className="text-blue-400"> Harmony 9</strong> (stability), 
              <strong className="text-red-400"> Distorted 9</strong> (radical mutations), 
              <strong className="text-purple-400"> Paradox Core</strong> (conflict fusion), 
              <strong className="text-pink-400"> Hallucinator</strong> (creative augmentation), 
              <strong className="text-green-400"> Stabilizer</strong> (final assembly).
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-500 mt-2">
                Ensure server is running: <code className="bg-black/40 px-2 py-0.5 rounded">node tac-evolution-engine.js</code> on port 8090
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Input Controls */}
          <div className="lg:col-span-4">
            <div className="rounded-xl p-5 sticky top-6 tac-border"
              style={{
                background: 'rgba(10, 5, 20, 0.95)'
              }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Code className="w-4 h-4 text-purple-400" />
                <label className="block text-[10px] tracking-[0.2em] uppercase text-purple-300">
                  Module Input
                </label>
              </div>

              <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-2">
                Module Name
              </label>
              <input
                type="text"
                value={moduleName}
                onChange={(e) => setModuleName(e.target.value)}
                disabled={isRunning}
                className="w-full rounded-lg border px-3 py-2 text-sm mb-4"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.3)',
                  background: 'rgba(0, 0, 0, 0.5)',
                  color: '#f6f6f6'
                }}
                placeholder="e.g. TrendHarvester"
              />

              <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-2">
                Current Spec
              </label>
              <textarea
                value={currentSpec}
                onChange={(e) => setCurrentSpec(e.target.value)}
                disabled={isRunning}
                rows={4}
                className="w-full rounded-lg border px-3 py-2 text-xs resize-none mb-4"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.3)',
                  background: 'rgba(0, 0, 0, 0.5)',
                  color: '#f6f6f6'
                }}
                placeholder="Enter module specification..."
              />

              <label className="block text-[10px] tracking-widest uppercase text-gray-500 mb-2">
                Current Code (Optional)
              </label>
              <textarea
                value={currentCode}
                onChange={(e) => setCurrentCode(e.target.value)}
                disabled={isRunning}
                rows={3}
                className="w-full rounded-lg border px-3 py-2 text-xs resize-none mb-4 font-mono"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.3)',
                  background: 'rgba(0, 0, 0, 0.5)',
                  color: '#f6f6f6'
                }}
                placeholder="// Existing code (optional)..."
              />

              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-[10px] tracking-widest uppercase text-gray-500">
                    Evolution Intensity
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">{intensity}</span>
                    <span 
                      className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                      style={{
                        color: getIntensityColor(intensity),
                        background: `${getIntensityColor(intensity)}15`,
                        border: `1px solid ${getIntensityColor(intensity)}30`
                      }}
                    >
                      {getIntensityLabel(intensity)}
                    </span>
                  </div>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={intensity}
                  onChange={(e) => setIntensity(parseInt(e.target.value))}
                  disabled={isRunning}
                  className="w-full"
                  style={{
                    accentColor: getIntensityColor(intensity)
                  }}
                />
              </div>

              <button
                onClick={runEvolution}
                disabled={isRunning || !moduleName.trim() || !currentSpec.trim()}
                className="w-full py-3 rounded-lg text-xs font-bold tracking-[0.15em] uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-30"
                style={{
                  background: 'linear-gradient(135deg, #3b82f6, #a855f7, #ef4444)',
                  color: '#fff',
                  boxShadow: isRunning ? 'none' : '0 0 25px rgba(168, 85, 247, 0.5)'
                }}
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    EVOLVING MODULE...
                  </>
                ) : (
                  <>
                    <Target className="w-4 h-4" />
                    INITIATE EVOLUTION
                  </>
                )}
              </button>

              {/* Stage Progress */}
              {isRunning && (
                <div className="mt-5 space-y-2">
                  <div className="text-[10px] tracking-widest uppercase text-purple-400 mb-2 flex items-center gap-2">
                    <div className="w-1 h-1 rounded-full bg-purple-400" style={{ animation: 'tacFlicker 1s infinite' }} />
                    Evolution Progress
                  </div>
                  {stages.map((stage, idx) => {
                    const isActive = currentStage === stage.id;
                    const isComplete = stages.findIndex(s => s.id === currentStage) > idx || currentStage === 'complete';
                    const Icon = stage.icon;

                    return (
                      <div 
                        key={stage.id}
                        className={`flex items-center gap-2 p-2 rounded-lg border transition-all ${isActive ? 'tac-active' : ''}`}
                        style={{
                          borderColor: isActive ? `${stage.color}60` : 'rgba(100, 100, 100, 0.15)',
                          background: isActive ? `${stage.color}10` : isComplete ? 'rgba(34, 197, 94, 0.08)' : 'rgba(0, 0, 0, 0.3)'
                        }}
                      >
                        {isComplete ? (
                          <CheckCircle2 className="w-4 h-4 text-green-400" style={{ opacity: 0.7 }} />
                        ) : isActive ? (
                          <Loader2 className="w-4 h-4 animate-spin" style={{ color: stage.color }} />
                        ) : (
                          <Icon className="w-4 h-4 text-gray-700" />
                        )}
                        <div className="flex-1">
                          <div className="text-[10px] font-semibold text-white">{stage.name}</div>
                          <div className="text-[9px] text-gray-600">{stage.description}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-8">
            {!evolutionResult && !isRunning && (
              <div className="rounded-xl p-12 text-center h-full flex items-center justify-center tac-border"
                style={{
                  background: 'rgba(10, 5, 20, 0.95)'
                }}
              >
                <div>
                  <Lock className="w-16 h-16 mx-auto mb-4 text-purple-400" style={{ opacity: 0.2 }} />
                  <p className="text-sm text-gray-600">
                    No evolution initiated.
                    <br />
                    <span className="text-xs text-gray-700">Configure module input and initiate evolution sequence.</span>
                  </p>
                </div>
              </div>
            )}

            {isRunning && !evolutionResult && (
              <div className="rounded-xl p-12 text-center h-full flex items-center justify-center tac-border"
                style={{
                  background: 'rgba(10, 5, 20, 0.95)'
                }}
              >
                <div>
                  <Loader2 className="w-16 h-16 mx-auto mb-4 text-purple-400 animate-spin" style={{ opacity: 0.6 }} />
                  <p className="text-sm text-gray-400">
                    Running 5-stage evolution...
                    <br />
                    <span className="text-xs text-gray-600">
                      {currentStage === 'harmony' && 'Harmony 9 analyzing stability...'}
                      {currentStage === 'distorted' && 'Distorted 9 generating mutations...'}
                      {currentStage === 'paradox' && 'Paradox Core resolving conflicts...'}
                      {currentStage === 'hallucinator' && 'Hallucinator augmenting capabilities...'}
                      {currentStage === 'stabilizer' && 'Stabilizer finalizing blueprint...'}
                    </span>
                  </p>
                </div>
              </div>
            )}

            {evolutionResult && (
              <div className="space-y-4">
                {/* Stage 1: Harmony 9 */}
                <div className="tac-stage-item rounded-xl p-5 tac-border"
                  style={{
                    background: 'rgba(10, 5, 20, 0.95)',
                    animationDelay: '0s'
                  }}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <Shield className="w-5 h-5 text-blue-400" style={{ opacity: 0.7 }} />
                    <h3 className="text-sm font-bold text-white tracking-wider">HARMONY 9 COUNCIL</h3>
                  </div>

                  {evolutionResult.stages?.harmony && (
                    <div className="space-y-2">
                      <div className="p-3 rounded-lg" style={{ background: 'rgba(59, 130, 246, 0.08)' }}>
                        <div className="text-[10px] font-bold text-blue-300 mb-1">SUMMARY</div>
                        <div className="text-xs text-gray-300">{evolutionResult.stages.harmony.harmonySummary}</div>
                      </div>

                      {evolutionResult.stages.harmony.upgradeDirectives && (
                        <div>
                          <div className="text-[10px] font-bold text-blue-300 mb-1">UPGRADE DIRECTIVES</div>
                          <ul className="space-y-1">
                            {evolutionResult.stages.harmony.upgradeDirectives.map((dir, i) => (
                              <li key={i} className="text-[10px] text-gray-400 flex items-start gap-2">
                                <span className="text-blue-400">▸</span>
                                <span>{dir}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Stage 2: Distorted 9 */}
                <div className="tac-stage-item rounded-xl p-5 tac-border"
                  style={{
                    background: 'rgba(10, 5, 20, 0.95)',
                    animationDelay: '0.1s'
                  }}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <Zap className="w-5 h-5 text-red-400" style={{ opacity: 0.7 }} />
                    <h3 className="text-sm font-bold text-white tracking-wider">DISTORTED 9 COUNCIL</h3>
                  </div>

                  {evolutionResult.stages?.distorted && (
                    <div className="space-y-2">
                      <div className="p-3 rounded-lg" style={{ background: 'rgba(239, 68, 68, 0.08)' }}>
                        <div className="text-[10px] font-bold text-red-300 mb-1">RADICAL SUMMARY</div>
                        <div className="text-xs text-gray-300">{evolutionResult.stages.distorted.distortedSummary}</div>
                      </div>

                      {evolutionResult.stages.distorted.mutationIdeas && (
                        <div>
                          <div className="text-[10px] font-bold text-red-300 mb-1">MUTATION IDEAS</div>
                          <div className="space-y-1">
                            {evolutionResult.stages.distorted.mutationIdeas.map((idea, i) => (
                              <div key={i} className="text-[10px] text-gray-400 p-2 rounded" style={{ background: 'rgba(239, 68, 68, 0.05)' }}>
                                <Zap className="w-3 h-3 inline mr-1 text-red-400" style={{ opacity: 0.5 }} />
                                {idea}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Stage 3: Paradox Core */}
                <div className="tac-stage-item rounded-xl p-5 tac-border"
                  style={{
                    background: 'rgba(10, 5, 20, 0.95)',
                    animationDelay: '0.2s'
                  }}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <Target className="w-5 h-5 text-purple-400" style={{ opacity: 0.7 }} />
                    <h3 className="text-sm font-bold text-white tracking-wider">PARADOX CORE</h3>
                  </div>

                  {evolutionResult.stages?.paradox && (
                    <div className="space-y-2">
                      <div className="p-3 rounded-lg" style={{ background: 'rgba(168, 85, 247, 0.08)' }}>
                        <div className="text-[10px] font-bold text-purple-300 mb-1">FUSION SUMMARY</div>
                        <div className="text-xs text-gray-300">{evolutionResult.stages.paradox.paradoxSummary}</div>
                      </div>

                      {evolutionResult.stages.paradox.coreUpgrades && (
                        <div>
                          <div className="text-[10px] font-bold text-purple-300 mb-1">CORE UPGRADES</div>
                          <ul className="space-y-1">
                            {evolutionResult.stages.paradox.coreUpgrades.map((upgrade, i) => (
                              <li key={i} className="text-[10px] text-gray-400 flex items-start gap-2">
                                <Sparkles className="w-3 h-3 text-purple-400 mt-0.5 flex-shrink-0" style={{ opacity: 0.6 }} />
                                <span>{upgrade}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Stage 4: Hallucinator */}
                <div className="tac-stage-item rounded-xl p-5 tac-border"
                  style={{
                    background: 'rgba(10, 5, 20, 0.95)',
                    animationDelay: '0.3s'
                  }}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <Brain className="w-5 h-5 text-pink-400" style={{ opacity: 0.7 }} />
                    <h3 className="text-sm font-bold text-white tracking-wider">HALLUCINATOR NODE</h3>
                  </div>

                  {evolutionResult.stages?.hallucinator && (
                    <div className="space-y-2">
                      <div className="p-3 rounded-lg" style={{ background: 'rgba(236, 72, 153, 0.08)' }}>
                        <div className="text-[10px] font-bold text-pink-300 mb-1">AUGMENTATION SUMMARY</div>
                        <div className="text-xs text-gray-300">{evolutionResult.stages.hallucinator.hallucinationSummary}</div>
                      </div>

                      {evolutionResult.stages.hallucinator.augmentedFeatures && (
                        <div>
                          <div className="text-[10px] font-bold text-pink-300 mb-1">AUGMENTED FEATURES</div>
                          <div className="space-y-2">
                            {evolutionResult.stages.hallucinator.augmentedFeatures.map((feat, i) => (
                              <div key={i} className="p-2 rounded border" style={{
                                background: 'rgba(236, 72, 153, 0.05)',
                                borderColor: 'rgba(236, 72, 153, 0.2)'
                              }}>
                                <div className="text-[10px] font-semibold text-pink-300 mb-0.5">{feat.label}</div>
                                <div className="text-[9px] text-gray-500">{feat.description}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Stage 5: Stabilizer (Final) */}
                <div className="tac-stage-item rounded-xl p-6 tac-border"
                  style={{
                    background: 'rgba(10, 5, 20, 0.95)',
                    boxShadow: '0 0 40px rgba(34, 197, 94, 0.2)',
                    animationDelay: '0.4s'
                  }}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <Lock className="w-6 h-6 text-green-400" style={{ opacity: 0.7 }} />
                    <h3 className="text-base font-bold text-white tracking-wider">STABILIZER CORE (FINAL)</h3>
                  </div>

                  {evolutionResult.stages?.stabilizer && (
                    <div className="space-y-3">
                      <div className="p-4 rounded-lg" style={{ background: 'rgba(34, 197, 94, 0.08)' }}>
                        <div className="text-[10px] font-bold text-green-300 mb-2">FINAL SUMMARY</div>
                        <div className="text-sm text-white font-semibold">{evolutionResult.stages.stabilizer.finalSummary}</div>
                      </div>

                      {evolutionResult.stages.stabilizer.finalApiSpec && (
                        <div className="p-4 rounded-lg" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                          <div className="text-[10px] font-bold text-green-300 mb-2">FINAL API SPEC</div>
                          <div className="text-xs text-gray-300 whitespace-pre-wrap font-mono">{evolutionResult.stages.stabilizer.finalApiSpec}</div>
                        </div>
                      )}

                      {evolutionResult.stages.stabilizer.finalImplementationSketch && (
                        <div className="p-4 rounded-lg" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                          <div className="text-[10px] font-bold text-green-300 mb-2">IMPLEMENTATION SKETCH</div>
                          <div className="text-xs text-gray-300 whitespace-pre-wrap font-mono">{evolutionResult.stages.stabilizer.finalImplementationSketch}</div>
                        </div>
                      )}

                      {evolutionResult.stages.stabilizer.changelog && (
                        <div>
                          <div className="text-[10px] font-bold text-green-300 mb-2">CHANGELOG</div>
                          <ul className="space-y-1">
                            {evolutionResult.stages.stabilizer.changelog.map((change, i) => (
                              <li key={i} className="text-[10px] text-gray-400 flex items-start gap-2">
                                <CheckCircle2 className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" style={{ opacity: 0.6 }} />
                                <span>{change}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Info */}
        <div className="text-center text-[10px] text-gray-700 mt-8">
          <p className="tracking-[0.2em]">TAC PARADOXON EVOLUTION ENGINE · CLASSIFIED</p>
          <p className="mt-1 tracking-wider">Backend: http://localhost:8090/api/evolution/evolve-module</p>
        </div>
      </div>
    </div>
  );
}