import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Grid3x3, Package, Crown, Building, Code2, TrendingUp, 
  Sparkles, Shield, Users, MessageSquare, BarChart3, Zap,
  Brain, Eye, Flame, Layers, Clock, GitBranch, Lock, Activity, Wand2, Database, Command, Box, Orbit, Radio, Infinity, Rocket, Settings, Hexagon, RefreshCw, DollarSign, Lightbulb
} from "lucide-react";
import { useBackgroundSettings } from '../components/BackgroundSettingsContext';
import BackgroundSettings from '../components/BackgroundSettings';
import NeuroEvolutionPanel from '../components/NeuroEvolutionPanel';
import ChaosArchitectPanel from '../components/ChaosArchitectPanel';
import DreamRendererPanel from '../components/DreamRendererPanel';
import TriMindDashboardPanel from '../components/TriMindDashboardPanel';
import GlitchEngineerPanel from '../components/GlitchEngineerPanel';
import ShadowArchivistPanel from '../components/ShadowArchivistPanel';
import TemporalEnginePanel from '../components/TemporalEnginePanel';
import ParallelArchitectPanel from '../components/ParallelArchitectPanel';
import FractalEngineerPanel from '../components/FractalEngineerPanel';
import { TriMindProvider } from '../components/TriMindContext';

export default function NeuralCore() {
  const navigate = useNavigate();
  const { settings } = useBackgroundSettings();
  const [coreExpanded, setCoreExpanded] = useState(false);
  const [selectedModule, setSelectedModule] = useState(null);
  const [showModuleDetails, setShowModuleDetails] = useState(false);
  
  const [neuroOpen, setNeuroOpen] = useState(false);
  const [chaosOpen, setChaosOpen] = useState(false);
  const [dreamOpen, setDreamOpen] = useState(false);
  const [dashboardOpen, setDashboardOpen] = useState(false);
  const [glitchOpen, setGlitchOpen] = useState(false);
  const [shadowOpen, setShadowOpen] = useState(false);
  const [temporalOpen, setTemporalOpen] = useState(false);
  const [parallelOpen, setParallelOpen] = useState(false);
  const [fractalOpen, setFractalOpen] = useState(false);

  const modules = [
    { name: "Matrix Hub", path: "MatrixHub", icon: Grid3x3, color: "#24e4ff" },
    { name: "Marketplace", path: "Marketplace", icon: Package, color: "#b788ff" },
    { name: "Demigods", path: "DemigodHub", icon: Crown, color: "#ff6ec7" },
    { name: "Enterprise", path: "CompanyPortal", icon: Building, color: "#4eff8b" },
  ];

  const coreActions = [
    { label: "Module Detail", icon: Activity, action: () => navigate(createPageUrl('TACDashboard')) },
    { label: "Core Intelligence", icon: Brain, action: () => navigate(createPageUrl('TriMindOS')) },
    { label: "Evolution Lab", icon: TrendingUp, action: () => navigate(createPageUrl('EvolutionLab')) },
    { label: "Dual Loop System", icon: Activity, action: () => navigate(createPageUrl('DualLoop')) },
    { label: "Paradox Engine", icon: Flame, action: () => navigate(createPageUrl('ParadoxEngine')) },
    { label: "Hallucinator Mind", icon: Wand2, action: () => navigate(createPageUrl('HallucinatorMind')) },
    { label: "Full Pipeline", icon: Layers, action: () => navigate(createPageUrl('PipelineEngine')) },
    { label: "TAC Evolution", icon: Lock, action: () => navigate(createPageUrl('TACEvolution')) },
    { label: "Module Vault", icon: Database, action: () => navigate(createPageUrl('ModuleVault')) },
    { label: "Module Idea Vault", icon: Lightbulb, action: () => navigate(createPageUrl('ModuleIdeaVault')) },
    { label: "Security Oversight", icon: Shield, action: () => navigate(createPageUrl('SecurityOversight')) },
    { label: "Control Hub", icon: Command, action: () => navigate(createPageUrl('ControlHub')) },
    { label: "NQ-FICE Engine", icon: Box, action: () => navigate(createPageUrl('NQFiceEngine')) },
    { label: "1998-Field Engine", icon: Orbit, action: () => navigate(createPageUrl('Field1998Engine')) },
    { label: "Anti-1998-Field", icon: Radio, action: () => navigate(createPageUrl('AntiField1998Engine')) },
    { label: "Infinity Expansion", icon: Infinity, action: () => navigate(createPageUrl('InfinityExpansionEngine')) },
    { label: "Universal Upgrade", icon: Rocket, action: () => navigate(createPageUrl('UniversalUpgradeEngine')) },
    { label: "Chaos Pipeline", icon: Flame, action: () => navigate(createPageUrl('ChaosUpgradePipeline')) },
    { label: "Master Orchestrator", icon: Crown, action: () => navigate(createPageUrl('MasterOrchestratorEngine')) },
    { label: "Founder Panel", icon: Settings, action: () => navigate(createPageUrl('FounderPanel')) },
    { label: "Hex Mind", icon: Hexagon, action: () => navigate(createPageUrl('HexMindEngine')) },
    { label: "Paradox Fusion HEX", icon: Flame, action: () => navigate(createPageUrl('ParadoxFusionHexEngine')) },
    { label: "Feedback Hub", icon: MessageSquare, action: () => navigate(createPageUrl('TACFeedbackHub')) },
    { label: "Mission Loop", icon: RefreshCw, action: () => navigate(createPageUrl('MissionLoop')) },
    { label: "Anti-n8n Engine", icon: Shield, action: () => navigate(createPageUrl('AntiN8NEngine')) },
    { label: "Dual Automation", icon: GitBranch, action: () => navigate(createPageUrl('DualAutomation')) },
    { label: "Arch Integration", icon: Box, action: () => navigate(createPageUrl('ArchIntegration')) },
    { label: "AI Rental Engine", icon: DollarSign, action: () => navigate(createPageUrl('AIRentalEngine')) },
    { label: "Neural Dashboard", icon: Eye, action: () => setDashboardOpen(true) },
  ];

  const centerX = typeof window !== 'undefined' ? window.innerWidth / 2 : 0;
  const centerY = typeof window !== 'undefined' ? window.innerHeight / 2 : 0;
  const radius = 180;

  const calculatePosition = (index, total) => {
    const angle = (index / total) * 2 * Math.PI - Math.PI / 2;
    return {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle),
    };
  };

  const handleModuleClick = (module) => {
    setSelectedModule(module);
    setShowModuleDetails(true);
    setTimeout(() => {
      navigate(createPageUrl(module.path));
    }, 800);
  };

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        setCoreExpanded(false);
        setShowModuleDetails(false);
      }
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, []);

  const renderBackground = () => {
    // Simple gradient background instead of WebGPU components
    return (
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900" />
    );
  };

  return (
    <TriMindProvider>
      <div className="relative w-screen h-screen overflow-hidden">
        <div className="absolute inset-0 z-0">
          {renderBackground()}
        </div>

        <BackgroundSettings />

        <div className="absolute top-6 left-6 z-20 space-y-3">
          <div className="card-glass px-4 py-2 rounded-xl">
            <div className="text-xs text-gray-400">NEURAL CORE</div>
            <div className="text-xl font-black text-white">MadDevCity</div>
          </div>
          <div className="card-glass px-4 py-2 rounded-xl">
            <div className="text-xs text-gray-400">STATUS</div>
            <div className="flex items-center gap-2">
              <div className="live-indicator" />
              <span className="text-sm text-white">ONLINE</span>
            </div>
          </div>
        </div>

        <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none">
          <button
            onClick={() => setCoreExpanded(!coreExpanded)}
            className="pointer-events-auto relative group"
            style={{
              width: coreExpanded ? '200px' : '120px',
              height: coreExpanded ? '200px' : '120px',
              transition: 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)',
            }}
          >
            <div
              className="absolute inset-0 rounded-full transition-all duration-600"
              style={{
                background: coreExpanded
                  ? 'radial-gradient(circle, rgba(139, 92, 255, 0.4), rgba(36, 228, 255, 0.2))'
                  : 'radial-gradient(circle, rgba(139, 92, 255, 0.3), transparent)',
                boxShadow: coreExpanded
                  ? '0 0 100px rgba(139, 92, 255, 0.8), inset 0 0 50px rgba(255, 255, 255, 0.2)'
                  : '0 0 60px rgba(139, 92, 255, 0.6)',
                animation: 'pulse-glow 3s ease-in-out infinite',
              }}
            />
            <div className="absolute inset-4 rounded-full border-2 border-white/20" />
            <div className="absolute inset-0 flex items-center justify-center">
              <Code2
                className="text-white transition-all duration-600"
                style={{
                  width: coreExpanded ? '80px' : '48px',
                  height: coreExpanded ? '80px' : '48px',
                }}
              />
            </div>
          </button>
        </div>

        {coreExpanded && (
          <div className="absolute inset-0 z-10 pointer-events-none">
            {modules.map((module, idx) => {
              const pos = calculatePosition(idx, modules.length);
              const Icon = module.icon;
              return (
                <div
                  key={module.name}
                  className="absolute pointer-events-auto cursor-pointer"
                  style={{
                    left: `${pos.x}px`,
                    top: `${pos.y}px`,
                    transform: 'translate(-50%, -50%)',
                    animation: 'matrix-expand 0.5s ease-out',
                    animationDelay: `${idx * 0.1}s`,
                    opacity: 0,
                    animationFillMode: 'forwards',
                  }}
                  onClick={() => handleModuleClick(module)}
                >
                  <div
                    className="card-glass px-6 py-4 rounded-2xl hover:scale-110 transition-all duration-300 min-w-[160px]"
                    style={{
                      boxShadow: `0 0 30px ${module.color}66`,
                      border: `1px solid ${module.color}44`,
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-6 h-6" style={{ color: module.color }} />
                      <span className="text-white font-semibold text-sm">{module.name}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {coreExpanded && (
          <div
            className="absolute z-10 pointer-events-auto"
            style={{
              left: '50%',
              top: '50%',
              transform: 'translate(-50%, calc(-50% + 140px))',
              animation: 'fadeIn 0.4s ease-out 0.3s both',
            }}
          >
            <div className="card-glass px-6 py-4 rounded-2xl max-w-4xl" style={{
              background: 'rgba(10, 5, 32, 0.95)',
              border: '1px solid rgba(183, 136, 255, 0.4)',
              boxShadow: '0 0 40px rgba(139, 92, 255, 0.6)',
            }}>
              <div className="flex flex-wrap items-center justify-center gap-3">
                {coreActions.map((action, idx) => {
                  const Icon = action.icon;
                  return (
                    <button
                      key={idx}
                      onClick={action.action}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:scale-105"
                      style={{
                        background: 'rgba(139, 92, 255, 0.2)',
                        border: '1px solid rgba(183, 136, 255, 0.4)',
                      }}
                    >
                      <Icon className="w-4 h-4 text-purple-400" />
                      <span className="text-xs text-white font-semibold">{action.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {showModuleDetails && selectedModule && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 backdrop-blur-md animate-fade-in">
            <div className="card-premium p-8 max-w-md animate-slide-up">
              <div className="flex items-center gap-4 mb-4">
                {React.createElement(selectedModule.icon, {
                  className: "w-12 h-12",
                  style: { color: selectedModule.color },
                })}
                <div>
                  <h2 className="text-2xl font-black text-white">{selectedModule.name}</h2>
                  <p className="text-sm text-gray-400">Initializing neural pathway...</p>
                </div>
              </div>
              <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-cyan-500"
                  style={{
                    width: '100%',
                    animation: 'slideInLeft 0.8s ease-out',
                  }}
                />
              </div>
            </div>
          </div>
        )}

        <NeuroEvolutionPanel isOpen={neuroOpen} onClose={() => setNeuroOpen(false)} />
        <ChaosArchitectPanel isOpen={chaosOpen} onClose={() => setChaosOpen(false)} />
        <DreamRendererPanel isOpen={dreamOpen} onClose={() => setDreamOpen(false)} />
        <TriMindDashboardPanel isOpen={dashboardOpen} onClose={() => setDashboardOpen(false)} />
        <GlitchEngineerPanel isOpen={glitchOpen} onClose={() => setGlitchOpen(false)} />
        <ShadowArchivistPanel isOpen={shadowOpen} onClose={() => setShadowOpen(false)} />
        <TemporalEnginePanel isOpen={temporalOpen} onClose={() => setTemporalOpen(false)} />
        <ParallelArchitectPanel isOpen={parallelOpen} onClose={() => setParallelOpen(false)} />
        <FractalEngineerPanel isOpen={fractalOpen} onClose={() => setFractalOpen(false)} />

        <div className="absolute bottom-6 right-6 z-20 flex flex-col gap-2">
          <button
            onClick={() => setNeuroOpen(true)}
            className="card-glass p-3 rounded-xl hover:scale-110 transition-all"
            style={{ border: '1px solid rgba(159, 168, 255, 0.4)' }}
          >
            <TrendingUp className="w-5 h-5 text-purple-400" />
          </button>
          <button
            onClick={() => setChaosOpen(true)}
            className="card-glass p-3 rounded-xl hover:scale-110 transition-all"
            style={{ border: '1px solid rgba(255, 102, 231, 0.4)' }}
          >
            <Sparkles className="w-5 h-5 text-pink-400" />
          </button>
          <button
            onClick={() => setDreamOpen(true)}
            className="card-glass p-3 rounded-xl hover:scale-110 transition-all"
            style={{ border: '1px solid rgba(59, 211, 255, 0.4)' }}
          >
            <Eye className="w-5 h-5 text-cyan-400" />
          </button>
        </div>
      </div>
    </TriMindProvider>
  );
}