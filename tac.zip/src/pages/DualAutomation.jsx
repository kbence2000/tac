import React, { useState } from 'react';
import { GitBranch, Zap, Shield, Activity, CheckCircle2, AlertTriangle, Loader2, TrendingUp, Eye, ArrowRight, RefreshCw, Radio } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function DualAutomation() {
  const [workflowId, setWorkflowId] = useState('customer-onboarding');
  const [payload, setPayload] = useState(JSON.stringify({
    email: 'user@example.com',
    name: 'John Doe',
    plan: 'premium'
  }, null, 2));
  
  const [workflowMeta, setWorkflowMeta] = useState(JSON.stringify({
    name: 'Customer Onboarding',
    nodes: [
      { id: 'webhook', type: 'webhook' },
      { id: 'validate', type: 'function' },
      { id: 'crm', type: 'http' },
      { id: 'email', type: 'email' },
      { id: 'analytics', type: 'http' }
    ],
    connections: {
      'webhook': [{ node: 'validate' }],
      'validate': [{ node: 'crm' }, { node: 'email' }],
      'crm': [{ node: 'analytics' }],
      'email': [{ node: 'analytics' }]
    }
  }, null, 2));
  
  const [runHistory, setRunHistory] = useState(JSON.stringify([
    { status: 'success', durationMs: 3200 },
    { status: 'success', durationMs: 2800 },
    { status: 'error', durationMs: 5600, errorMessage: 'CRM timeout' },
    { status: 'success', durationMs: 3100 },
    { status: 'error', durationMs: 8200, errorMessage: 'Email service down' }
  ], null, 2));

  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState(null);
  const [error, setError] = useState(null);
  const [currentPhase, setCurrentPhase] = useState(null);
  const [backendUrl] = useState('http://localhost:8088');
  const queryClient = useQueryClient();

  // Fetch execution history
  const { data: executionHistory = [] } = useQuery({
    queryKey: ['dual-automation'],
    queryFn: async () => {
      const list = await base44.entities.DualAutomation.list('-created_date', 20);
      return list;
    },
    refetchInterval: 10000
  });

  // Save execution mutation
  const saveExecutionMutation = useMutation({
    mutationFn: async (executionData) => {
      return await base44.entities.DualAutomation.create(executionData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dual-automation'] });
    }
  });

  const runDualExecution = async () => {
    setIsExecuting(true);
    setError(null);
    setExecutionResult(null);
    setCurrentPhase('initializing');

    const startTime = Date.now();

    try {
      const parsedPayload = JSON.parse(payload);
      const parsedWorkflowMeta = JSON.parse(workflowMeta);
      const parsedRunHistory = JSON.parse(runHistory);

      // Phase 1: Running n8n
      setCurrentPhase('n8n_executing');
      const n8nStart = Date.now();
      
      // Simulate n8n call (replace with real backend call)
      await new Promise(resolve => setTimeout(resolve, 1500));
      const n8nResult = {
        status: 'success',
        execution: {
          id: `exec_${Date.now()}`,
          output: {
            userCreated: true,
            crmId: 'crm_12345',
            emailSent: true
          }
        },
        durationMs: Date.now() - n8nStart
      };

      // Phase 2: Getting Anti-n8n plan
      setCurrentPhase('anti_analyzing');
      const antiStart = Date.now();
      
      const antiResponse = await fetch(`${backendUrl}/api/antin8n/evaluate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workflow: parsedWorkflowMeta,
          runs: parsedRunHistory
        })
      });

      if (!antiResponse.ok) {
        throw new Error(`Anti-n8n error: ${antiResponse.status}`);
      }

      const antiData = await antiResponse.json();
      const antiLatency = Date.now() - antiStart;

      // Phase 3: Running audit
      setCurrentPhase('auditing');
      const auditStart = Date.now();
      
      const auditResponse = await fetch(`${backendUrl}/api/antin8n/compare`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          n8nResult,
          antiPlan: antiData.antiPlan
        })
      });

      if (!auditResponse.ok) {
        throw new Error(`Audit error: ${auditResponse.status}`);
      }

      const auditData = await auditResponse.json();
      const auditLatency = Date.now() - auditStart;

      // Phase 4: Decision making
      setCurrentPhase('deciding');
      const decisionStart = Date.now();
      
      let decision = 'use_n8n_result';
      if (auditData.audit.antiPotential > 0.65 && auditData.audit.riskScore > 0.40) {
        decision = 'test_anti_n8n_path';
      } else if (auditData.audit.antiPotential > 0.85) {
        decision = 'fallback_to_anti';
      }
      
      const decisionLatency = Date.now() - decisionStart;
      const totalTime = Date.now() - startTime;

      const result = {
        n8nResult,
        antiPlan: antiData.antiPlan,
        audit: auditData.audit,
        decision,
        executionTime: totalTime,
        metrics: {
          n8nLatency: n8nResult.durationMs,
          antiAnalysisLatency: antiLatency,
          auditLatency,
          decisionLatency
        }
      };

      setExecutionResult(result);
      setCurrentPhase('completed');

      // Save to database
      await saveExecutionMutation.mutateAsync({
        executionId: `exec_${Date.now()}`,
        workflowId,
        workflowName: parsedWorkflowMeta.name,
        payload: parsedPayload,
        n8nResult,
        antiPlan: antiData.antiPlan,
        audit: auditData.audit,
        decision,
        executionTime: totalTime,
        status: 'completed',
        metrics: result.metrics
      });

    } catch (err) {
      console.error('Dual execution error:', err);
      setError(err.message);
      setCurrentPhase('failed');
    } finally {
      setIsExecuting(false);
    }
  };

  const getDecisionColor = (decision) => {
    switch (decision) {
      case 'use_n8n_result': return '#4cffa8';
      case 'test_anti_n8n_path': return '#ffdb7c';
      case 'fallback_to_anti': return '#ff4b81';
      default: return '#8c8faf';
    }
  };

  const getDecisionIcon = (decision) => {
    switch (decision) {
      case 'use_n8n_result': return CheckCircle2;
      case 'test_anti_n8n_path': return AlertTriangle;
      case 'fallback_to_anti': return Shield;
      default: return Activity;
    }
  };

  const phases = [
    { id: 'initializing', label: 'Initialize', icon: RefreshCw, color: '#8c8faf' },
    { id: 'n8n_executing', label: 'n8n Execution', icon: Zap, color: '#24e4ff' },
    { id: 'anti_analyzing', label: 'Anti-n8n Analysis', icon: Shield, color: '#a84cff' },
    { id: 'auditing', label: 'Audit Comparison', icon: Activity, color: '#ff6ec7' },
    { id: 'deciding', label: 'Decision Making', icon: GitBranch, color: '#ffdb7c' },
    { id: 'completed', label: 'Completed', icon: CheckCircle2, color: '#4cffa8' }
  ];

  const getPhaseIndex = (phaseId) => phases.findIndex(p => p.id === phaseId);
  const currentPhaseIndex = getPhaseIndex(currentPhase);

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .phase-indicator {
          transition: all 0.3s ease-out;
        }
        
        .phase-indicator.active {
          animation: pulseGlow 1.5s ease-in-out infinite;
        }
        
        @keyframes pulseGlow {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.7; }
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <GitBranch className="w-10 h-10 text-cyan-400" />
            <h1 className="text-3xl md:text-4xl font-black tracking-wider uppercase text-white">
              DUAL AUTOMATION KERNEL
            </h1>
            <Radio className="w-10 h-10 text-purple-400" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide">
            Unified n8n + Anti-n8n Orchestrator • Real-time Decision Engine
          </p>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border" style={{
          background: 'rgba(36, 228, 255, 0.1)',
          borderColor: 'rgba(36, 228, 255, 0.4)'
        }}>
          <div className="flex items-start gap-3">
            <Eye className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <strong className="text-cyan-400">What is Dual Automation?</strong> Runs n8n primary automation AND Anti-n8n shadow analysis simultaneously. Compares results, calculates risk scores, and makes intelligent decisions about which path to use. Perfect for mission-critical workflows.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Execution Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Backend: <code className="bg-black/40 px-2 py-0.5 rounded">node dual-automation-kernel.js</code> on port 8088
              </div>
            </div>
          </div>
        )}

        {/* Phase Progress */}
        {isExecuting && (
          <div className="mb-6 rounded-2xl border p-5" style={{
            borderColor: 'rgba(168, 85, 247, 0.4)',
            background: 'rgba(7, 7, 18, 0.95)',
            boxShadow: '0 0 40px rgba(168, 85, 247, 0.2)'
          }}>
            <div className="text-xs font-bold text-purple-400 mb-4">EXECUTION PHASES</div>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
              {phases.map((phase, idx) => {
                const Icon = phase.icon;
                const isCompleted = idx < currentPhaseIndex;
                const isActive = idx === currentPhaseIndex;
                
                return (
                  <div
                    key={phase.id}
                    className={`phase-indicator text-center p-3 rounded-xl border ${isActive ? 'active' : ''}`}
                    style={{
                      borderColor: isCompleted ? `${phase.color}80` : isActive ? phase.color : 'rgba(255, 255, 255, 0.1)',
                      background: isCompleted ? `${phase.color}20` : isActive ? `${phase.color}15` : 'rgba(0, 0, 0, 0.3)',
                      boxShadow: isActive ? `0 0 20px ${phase.color}60` : 'none'
                    }}
                  >
                    <Icon 
                      className="w-5 h-5 mx-auto mb-2" 
                      style={{ color: isCompleted || isActive ? phase.color : '#666' }}
                    />
                    <div className="text-[0.65rem] font-semibold" style={{
                      color: isCompleted || isActive ? '#fff' : '#666'
                    }}>
                      {phase.label}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
          {/* Left: Input Configuration */}
          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-2xl border p-4" style={{
              borderColor: 'rgba(36, 228, 255, 0.3)',
              background: 'rgba(7, 7, 18, 0.95)'
            }}>
              <label className="block text-xs tracking-widest uppercase text-cyan-400 mb-3">
                WORKFLOW ID
              </label>
              <input
                type="text"
                value={workflowId}
                onChange={(e) => setWorkflowId(e.target.value)}
                disabled={isExecuting}
                className="w-full rounded-xl border px-4 py-2 text-sm mb-4"
                style={{
                  borderColor: 'rgba(36, 228, 255, 0.3)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
                placeholder="customer-onboarding"
              />

              <label className="block text-xs tracking-widest uppercase text-cyan-400 mb-3">
                PAYLOAD (JSON)
              </label>
              <textarea
                value={payload}
                onChange={(e) => setPayload(e.target.value)}
                disabled={isExecuting}
                rows={6}
                className="w-full rounded-xl border px-3 py-2 text-xs font-mono resize-none mb-4"
                style={{
                  borderColor: 'rgba(36, 228, 255, 0.3)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
              />

              <label className="block text-xs tracking-widest uppercase text-purple-400 mb-3">
                WORKFLOW METADATA (JSON)
              </label>
              <textarea
                value={workflowMeta}
                onChange={(e) => setWorkflowMeta(e.target.value)}
                disabled={isExecuting}
                rows={8}
                className="w-full rounded-xl border px-3 py-2 text-xs font-mono resize-none mb-4"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.3)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
              />

              <label className="block text-xs tracking-widest uppercase text-pink-400 mb-3">
                RUN HISTORY (JSON)
              </label>
              <textarea
                value={runHistory}
                onChange={(e) => setRunHistory(e.target.value)}
                disabled={isExecuting}
                rows={6}
                className="w-full rounded-xl border px-3 py-2 text-xs font-mono resize-none mb-4"
                style={{
                  borderColor: 'rgba(255, 110, 199, 0.3)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
              />

              <button
                onClick={runDualExecution}
                disabled={isExecuting}
                className="w-full px-6 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #24e4ff, #a84cff, #ff6ec7)',
                  color: '#fff',
                  boxShadow: isExecuting ? 'none' : '0 0 30px rgba(168, 85, 247, 0.7)'
                }}
              >
                {isExecuting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    EXECUTING...
                  </>
                ) : (
                  <>
                    <GitBranch className="w-5 h-5" />
                    RUN DUAL EXECUTION
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-7">
            {!executionResult && !isExecuting && (
              <div className="rounded-2xl border p-12 text-center" style={{
                background: 'rgba(7, 7, 18, 0.95)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
                minHeight: '600px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <div>
                  <GitBranch className="w-20 h-20 mx-auto mb-4 text-purple-400/30" />
                  <p className="text-sm text-gray-400">
                    No execution yet.
                    <br />
                    Configure inputs and run dual automation.
                  </p>
                </div>
              </div>
            )}

            {executionResult && (
              <div className="space-y-4">
                {/* Decision Panel */}
                <div className="rounded-2xl border p-6" style={{
                  borderColor: `${getDecisionColor(executionResult.decision)}60`,
                  background: 'rgba(7, 7, 18, 0.95)',
                  boxShadow: `0 0 40px ${getDecisionColor(executionResult.decision)}40`
                }}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-xs font-bold uppercase tracking-wider" style={{
                      color: getDecisionColor(executionResult.decision)
                    }}>
                      FINAL DECISION
                    </div>
                    <div className="text-xs text-gray-400">
                      {executionResult.executionTime}ms total
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-4 rounded-xl" style={{
                    background: `${getDecisionColor(executionResult.decision)}20`,
                    border: `2px solid ${getDecisionColor(executionResult.decision)}`
                  }}>
                    {React.createElement(getDecisionIcon(executionResult.decision), {
                      className: "w-8 h-8 flex-shrink-0",
                      style: { color: getDecisionColor(executionResult.decision) }
                    })}
                    <div className="flex-1">
                      <div className="text-lg font-bold text-white mb-1">
                        {executionResult.decision.replace(/_/g, ' ').toUpperCase()}
                      </div>
                      <div className="text-xs text-gray-300">
                        {executionResult.decision === 'use_n8n_result' && 'n8n execution was successful and reliable. Using primary result.'}
                        {executionResult.decision === 'test_anti_n8n_path' && 'High risk detected. Recommend testing Anti-n8n alternative path.'}
                        {executionResult.decision === 'fallback_to_anti' && 'Critical issues found. Falling back to Anti-n8n shadow automation.'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(36, 228, 255, 0.1)',
                    border: '1px solid rgba(36, 228, 255, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">n8n Latency</div>
                    <div className="text-xl font-bold text-cyan-400">
                      {executionResult.metrics.n8nLatency}ms
                    </div>
                  </div>
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(168, 85, 247, 0.1)',
                    border: '1px solid rgba(168, 85, 247, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Anti Analysis</div>
                    <div className="text-xl font-bold text-purple-400">
                      {executionResult.metrics.antiAnalysisLatency}ms
                    </div>
                  </div>
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(255, 110, 199, 0.1)',
                    border: '1px solid rgba(255, 110, 199, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Audit</div>
                    <div className="text-xl font-bold text-pink-400">
                      {executionResult.metrics.auditLatency}ms
                    </div>
                  </div>
                  <div className="p-3 rounded-xl text-center" style={{
                    background: 'rgba(255, 219, 124, 0.1)',
                    border: '1px solid rgba(255, 219, 124, 0.3)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Decision</div>
                    <div className="text-xl font-bold text-yellow-400">
                      {executionResult.metrics.decisionLatency}ms
                    </div>
                  </div>
                </div>

                {/* n8n Result */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(36, 228, 255, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}>
                  <div className="text-xs font-bold text-cyan-400 mb-3 flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    N8N EXECUTION RESULT
                  </div>
                  <pre className="text-xs text-gray-300 font-mono whitespace-pre-wrap p-3 rounded-lg" style={{
                    background: 'rgba(0, 0, 0, 0.4)'
                  }}>
                    {JSON.stringify(executionResult.n8nResult, null, 2)}
                  </pre>
                </div>

                {/* Anti-n8n Plan */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(139, 0, 139, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}>
                  <div className="text-xs font-bold text-purple-400 mb-3 flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    ANTI-N8N SHADOW STRATEGY
                  </div>
                  
                  <div className="space-y-3">
                    {executionResult.antiPlan.strategies?.length > 0 && (
                      <div>
                        <div className="text-xs text-gray-400 mb-2">Strategies:</div>
                        <div className="space-y-1">
                          {executionResult.antiPlan.strategies.map((strategy, i) => (
                            <div key={i} className="flex items-center gap-2 p-2 rounded-lg text-xs" style={{
                              background: 'rgba(139, 0, 139, 0.1)',
                              border: '1px solid rgba(139, 0, 139, 0.3)'
                            }}>
                              <ArrowRight className="w-3 h-3 text-purple-400 flex-shrink-0" />
                              <span className="text-gray-300">{strategy}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Audit Comparison */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(255, 110, 199, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}>
                  <div className="text-xs font-bold text-pink-400 mb-3 flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    AUDIT COMPARISON
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl text-center" style={{
                      background: 'rgba(255, 75, 129, 0.1)',
                      border: '1px solid rgba(255, 75, 129, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Risk Score</div>
                      <div className="text-2xl font-bold text-red-400">
                        {(executionResult.audit.riskScore * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div className="p-3 rounded-xl text-center" style={{
                      background: 'rgba(139, 0, 139, 0.1)',
                      border: '1px solid rgba(139, 0, 139, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Anti Potential</div>
                      <div className="text-2xl font-bold text-purple-400">
                        {(executionResult.audit.antiPotential * 100).toFixed(0)}%
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 p-3 rounded-xl" style={{
                    background: 'rgba(0, 0, 0, 0.4)'
                  }}>
                    <div className="text-xs text-gray-400 mb-1">Suggestion:</div>
                    <div className="text-sm text-white">
                      {executionResult.audit.suggestion?.replace(/-/g, ' ').toUpperCase()}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Execution History */}
        <div className="rounded-2xl border p-5" style={{
          borderColor: 'rgba(255, 255, 255, 0.1)',
          background: 'rgba(7, 7, 18, 0.95)'
        }}>
          <div className="text-xs font-bold text-gray-400 mb-4 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            EXECUTION HISTORY ({executionHistory.length})
          </div>

          {executionHistory.length === 0 && (
            <div className="text-center py-8 text-sm text-gray-600">
              No executions yet. Run your first dual automation.
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {executionHistory.map((exec) => (
              <div
                key={exec.id}
                className="p-3 rounded-xl border transition-all hover:border-purple-400/50"
                style={{
                  background: 'rgba(0, 0, 0, 0.4)',
                  borderColor: `${getDecisionColor(exec.decision)}40`
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-white truncate">
                    {exec.workflowName}
                  </span>
                  {React.createElement(getDecisionIcon(exec.decision), {
                    className: "w-4 h-4 flex-shrink-0",
                    style: { color: getDecisionColor(exec.decision) }
                  })}
                </div>
                <div className="text-[10px] text-gray-500 space-y-1">
                  <div>Decision: {exec.decision.replace(/_/g, ' ')}</div>
                  <div>Status: {exec.status}</div>
                  <div>Time: {exec.executionTime}ms</div>
                  <div className="text-gray-600">
                    {new Date(exec.created_date).toLocaleString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}