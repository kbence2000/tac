import React, { useState } from 'react';
import { Lightbulb, Zap, Activity, CheckCircle2, AlertTriangle, Brain, Sparkles, GitBranch } from 'lucide-react';

export default function IdeaCollectorAI() {
  const [activeTab, setActiveTab] = useState('capture');
  const [ideaText, setIdeaText] = useState('');
  const [moduleName, setModuleName] = useState('');
  const [moduleDesc, setModuleDesc] = useState('');
  const [capabilities, setCapabilities] = useState('');
  const [risk, setRisk] = useState('medium');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleCaptureIdea = async () => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/ideas/capture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: ideaText,
          source: 'manual_input'
        })
      });

      if (!response.ok) throw new Error('Capture failed');
      
      const data = await response.json();
      setResult(data);
      if (data.captured) setIdeaText('');
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRegisterModule = async () => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/ideas/register-module', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: moduleName,
          description: moduleDesc,
          capabilities: capabilities.split(',').map(c => c.trim()).filter(Boolean),
          risk
        })
      });

      if (!response.ok) throw new Error('Registration failed');
      
      const data = await response.json();
      setResult(data);
      setModuleName('');
      setModuleDesc('');
      setCapabilities('');
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleGenerateHybrid = async () => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/ideas/generate-hybrid', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });

      if (!response.ok) throw new Error('Generation failed');
      
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleListItems = async (type) => {
    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const endpoint = type === 'ideas' ? '/ideas/list' : '/ideas/list-modules';
      const response = await fetch(`http://localhost:3000${endpoint}`);

      if (!response.ok) throw new Error('List failed');
      
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .collector-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .tab-button {
          transition: all 0.2s ease-out;
          cursor: pointer;
        }

        .tab-button.active {
          background: rgba(255, 204, 75, 0.1);
          border-color: #ffcc4b;
          color: #ffcc4b;
        }

        .result-panel {
          background: #05050d;
          border: 1px solid #1a1a26;
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #ffcc4b 40%, #b88800)',
                boxShadow: '0 0 30px rgba(255, 204, 75, 0.6)'
              }}
            >
              <Lightbulb className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                IDEA COLLECTOR AI
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                Module Atlas • Hybrid Generator • Concept Vault
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(255, 204, 75, 0.12)',
            border: '1px solid rgba(255, 204, 75, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#ffcc4b' }} />
            <span className="text-xs font-semibold" style={{ color: '#ffcc4b' }}>
              ACTIVE
            </span>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Error</div>
              <div className="text-xs text-gray-300 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          {[
            { id: 'capture', name: 'Capture Idea', icon: Lightbulb },
            { id: 'register', name: 'Register Module', icon: Brain },
            { id: 'hybrid', name: 'Generate Hybrid', icon: GitBranch },
            { id: 'list', name: 'View All', icon: Sparkles }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`tab-button px-4 py-2 rounded-xl border flex items-center gap-2 ${
                  activeTab === tab.id ? 'active' : ''
                }`}
                style={{
                  background: activeTab === tab.id ? '' : '#060612',
                  borderColor: activeTab === tab.id ? '' : 'transparent',
                  color: activeTab === tab.id ? '' : '#9094b2'
                }}
              >
                <Icon className="w-4 h-4" />
                <span className="text-xs font-semibold">{tab.name}</span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Input Area */}
          <div className="lg:col-span-5 collector-panel rounded-2xl p-4">
            {activeTab === 'capture' && (
              <>
                <div className="mb-3">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    Capture New Idea
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Enter concept, philosophy, or module idea
                  </div>
                </div>

                <textarea
                  value={ideaText}
                  onChange={(e) => setIdeaText(e.target.value)}
                  className="w-full h-[300px] rounded-xl p-4 text-xs resize-none"
                  style={{
                    background: '#05050d',
                    border: '1px solid #1a1a26',
                    color: '#a3a7cf'
                  }}
                  placeholder="Describe your idea, modul concept, or philosophy..."
                />

                <button
                  onClick={handleCaptureIdea}
                  disabled={isProcessing || !ideaText}
                  className="w-full mt-4 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'radial-gradient(circle at 20% 0, #ffffff, #ffcc4b 40%, #b88800 70%)',
                    color: '#020206',
                    boxShadow: isProcessing ? 'none' : '0 8px 24px rgba(255, 204, 75, 0.6)'
                  }}
                >
                  {isProcessing ? (
                    <>
                      <Activity className="w-4 h-4 animate-spin" />
                      CAPTURING...
                    </>
                  ) : (
                    <>
                      <Lightbulb className="w-4 h-4" />
                      CAPTURE IDEA
                    </>
                  )}
                </button>
              </>
            )}

            {activeTab === 'register' && (
              <>
                <div className="mb-3">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    Register AI Module
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Add new module to the registry
                  </div>
                </div>

                <div className="space-y-3">
                  <input
                    type="text"
                    value={moduleName}
                    onChange={(e) => setModuleName(e.target.value)}
                    placeholder="Module Name"
                    className="w-full rounded-xl px-4 py-2 text-xs"
                    style={{
                      background: '#05050d',
                      border: '1px solid #1a1a26',
                      color: '#a3a7cf'
                    }}
                  />

                  <textarea
                    value={moduleDesc}
                    onChange={(e) => setModuleDesc(e.target.value)}
                    placeholder="Module Description"
                    className="w-full h-[100px] rounded-xl p-4 text-xs resize-none"
                    style={{
                      background: '#05050d',
                      border: '1px solid #1a1a26',
                      color: '#a3a7cf'
                    }}
                  />

                  <input
                    type="text"
                    value={capabilities}
                    onChange={(e) => setCapabilities(e.target.value)}
                    placeholder="Capabilities (comma separated)"
                    className="w-full rounded-xl px-4 py-2 text-xs"
                    style={{
                      background: '#05050d',
                      border: '1px solid #1a1a26',
                      color: '#a3a7cf'
                    }}
                  />

                  <select
                    value={risk}
                    onChange={(e) => setRisk(e.target.value)}
                    className="w-full rounded-xl px-4 py-2 text-xs"
                    style={{
                      background: '#05050d',
                      border: '1px solid #1a1a26',
                      color: '#a3a7cf'
                    }}
                  >
                    <option value="low">Low Risk</option>
                    <option value="medium">Medium Risk</option>
                    <option value="high">High Risk</option>
                  </select>
                </div>

                <button
                  onClick={handleRegisterModule}
                  disabled={isProcessing || !moduleName || !moduleDesc}
                  className="w-full mt-4 px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'radial-gradient(circle at 20% 0, #ffffff, #24e4ff 40%, #08b8b8 70%)',
                    color: '#020206',
                    boxShadow: isProcessing ? 'none' : '0 8px 24px rgba(36, 228, 255, 0.6)'
                  }}
                >
                  {isProcessing ? (
                    <>
                      <Activity className="w-4 h-4 animate-spin" />
                      REGISTERING...
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4" />
                      REGISTER MODULE
                    </>
                  )}
                </button>
              </>
            )}

            {activeTab === 'hybrid' && (
              <>
                <div className="mb-3">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    Hybrid Fusion Engine
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Generate high-end fused AI module
                  </div>
                </div>

                <div className="result-panel rounded-xl p-4 mb-4">
                  <div className="text-xs text-gray-400 mb-2">How it works:</div>
                  <div className="space-y-2 text-[11px] text-gray-300">
                    <div>1. Analyzes all registered modules</div>
                    <div>2. Selects top 5 by capability score</div>
                    <div>3. Combines their strengths</div>
                    <div>4. Generates unified hybrid module</div>
                  </div>
                </div>

                <button
                  onClick={handleGenerateHybrid}
                  disabled={isProcessing}
                  className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                  style={{
                    background: 'radial-gradient(circle at 20% 0, #ffffff, #b788ff 40%, #8800ff 70%)',
                    color: '#020206',
                    boxShadow: isProcessing ? 'none' : '0 8px 24px rgba(183, 136, 255, 0.6)'
                  }}
                >
                  {isProcessing ? (
                    <>
                      <Activity className="w-4 h-4 animate-spin" />
                      GENERATING...
                    </>
                  ) : (
                    <>
                      <GitBranch className="w-4 h-4" />
                      GENERATE HYBRID
                    </>
                  )}
                </button>
              </>
            )}

            {activeTab === 'list' && (
              <>
                <div className="mb-3">
                  <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                    View Collections
                  </div>
                  <div className="text-[10px] text-gray-500">
                    Browse ideas and modules
                  </div>
                </div>

                <div className="space-y-2">
                  <button
                    onClick={() => handleListItems('ideas')}
                    disabled={isProcessing}
                    className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                    style={{
                      background: 'rgba(255, 204, 75, 0.1)',
                      color: '#ffcc4b',
                      border: '1px solid rgba(255, 204, 75, 0.4)'
                    }}
                  >
                    <Lightbulb className="w-4 h-4" />
                    LIST ALL IDEAS
                  </button>

                  <button
                    onClick={() => handleListItems('modules')}
                    disabled={isProcessing}
                    className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                    style={{
                      background: 'rgba(36, 228, 255, 0.1)',
                      color: '#24e4ff',
                      border: '1px solid rgba(36, 228, 255, 0.4)'
                    }}
                  >
                    <Brain className="w-4 h-4" />
                    LIST ALL MODULES
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-7 collector-panel rounded-2xl p-4">
            <div className="mb-3">
              <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                Results
              </div>
              <div className="text-[10px] text-gray-500">
                Operation output
              </div>
            </div>

            {!result ? (
              <div className="result-panel rounded-xl p-6 h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Sparkles className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <div className="text-sm font-semibold">No Results Yet</div>
                  <div className="text-xs mt-1">Perform an action to see results</div>
                </div>
              </div>
            ) : (
              <div className="result-panel rounded-xl p-4 max-h-[500px] overflow-auto">
                <pre className="text-xs text-gray-300 font-mono whitespace-pre-wrap">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}