
import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Sparkles, Trophy, Clock, Target,
  Flame, Users, DollarSign, RefreshCw,
  Lightbulb, Shield, Zap, Award
} from "lucide-react";
import { toast } from "sonner";
import io from "socket.io-client";
import InnovationChallengeCard from "../components/InnovationChallengeCard";
import InnovationArenaView from "../components/InnovationArenaView";
import TalentDetectionBanner from "../components/TalentDetectionBanner";

const INNOVATION_API = import.meta.env.VITE_INNOVATION_BACKEND_URL || "http://localhost:4000";

export default function InnovationPvP() {
  const [challenges, setChallenges] = useState([]);
  const [loadingChallenges, setLoadingChallenges] = useState(false);
  
  // Company challenge creation
  const [chTitle, setChTitle] = useState("");
  const [chDesc, setChDesc] = useState("");
  const [chLang, setChLang] = useState("JavaScript");
  const [chDiff, setChDiff] = useState("medium");
  const [chTime, setChTime] = useState("900");
  const [chStartOffset, setChStartOffset] = useState("2");
  const [chWindow, setChWindow] = useState("30");
  const [chRewardType, setChRewardType] = useState("money");
  const [chRewardValue, setChRewardValue] = useState("150");
  const [creating, setCreating] = useState(false);

  // Arena state
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [currentMatch, setCurrentMatch] = useState(null);
  const [arenaSocket, setArenaSocket] = useState(null);
  const [latestScores, setLatestScores] = useState([]);
  const [remainingMs, setRemainingMs] = useState(null);
  const [matchFinishedData, setMatchFinishedData] = useState(null);
  const [codeInput, setCodeInput] = useState("");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Load challenges
  const loadChallenges = async () => {
    setLoadingChallenges(true);
    try {
      const res = await fetch(`${INNOVATION_API}/api/challenges`);
      if (res.ok) {
        const data = await res.json();
        setChallenges(data);
      }
    } catch (error) {
      console.error("Load challenges error:", error);
      toast.error("Failed to load challenges");
    } finally {
      setLoadingChallenges(false);
    }
  };

  useEffect(() => {
    loadChallenges();
    const interval = setInterval(loadChallenges, 15000); // Refresh every 15s
    return () => clearInterval(interval);
  }, []);

  // Create challenge (company only)
  const handleCreateChallenge = async () => {
    if (!user) {
      toast.error("Please login first");
      return;
    }
    if (!chTitle) {
      toast.error("Challenge title required");
      return;
    }

    const now = Date.now();
    const startTime = now + Number(chStartOffset) * 60 * 1000;
    const endTime = startTime + Number(chWindow) * 60 * 1000;

    setCreating(true);
    try {
      const res = await fetch(`${INNOVATION_API}/api/challenge/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companyId: user.email,
          title: chTitle,
          description: chDesc,
          language: chLang,
          difficulty: chDiff,
          timeLimitSec: Number(chTime),
          startTime,
          endTime,
          rewardType: chRewardType,
          rewardValue: chRewardType === "money" ? Number(chRewardValue) : chRewardValue
        })
      });

      if (res.ok) {
        toast.success("Innovation Challenge created!");
        setChTitle("");
        setChDesc("");
        setChLang("JavaScript");
        setChTime("900");
        setChStartOffset("2");
        setChWindow("30");
        setChRewardValue("150");
        loadChallenges();
      } else {
        const data = await res.json();
        toast.error(data.error || "Failed to create challenge");
      }
    } catch (error) {
      console.error("Create challenge error:", error);
      toast.error("Network error");
    } finally {
      setCreating(false);
    }
  };

  // Join arena
  const handleJoinArena = async (challengeId) => {
    if (!user) {
      toast.error("Please login first");
      return;
    }

    try {
      const res = await fetch(`${INNOVATION_API}/api/challenge/${challengeId}`);
      if (!res.ok) {
        toast.error("Challenge not found");
        return;
      }
      const challenge = await res.json();
      
      const now = Date.now();
      if (now < challenge.startTime || now > challenge.endTime) {
        toast.error("Join window is closed");
        return;
      }

      setCurrentChallenge(challenge);
      setMatchFinishedData(null);
      setLatestScores([]);
      setRemainingMs(null);
      setCodeInput("");

      // Initialize Socket.IO
      if (!arenaSocket) {
        const socket = io(`${INNOVATION_API}/arena`);
        
        socket.on("connect", () => {
          console.log("Innovation Arena connected");
        });

        socket.on("joinError", (payload) => {
          toast.error(payload.error || "Join failed");
        });

        socket.on("matchUpdate", (payload) => {
          setCurrentMatch(payload);
        });

        socket.on("matchStarted", () => {
          toast.success("Innovation match started! Show your creativity!");
        });

        socket.on("timerUpdate", (payload) => {
          setRemainingMs(payload.remainingMs);
        });

        socket.on("scoreUpdate", (payload) => {
          setLatestScores(payload.scores || []);
        });

        socket.on("matchFinished", (payload) => {
          setMatchFinishedData(payload);
          toast.success(`Innovation Battle finished! Winner: ${payload.winnerName}`);
        });

        setArenaSocket(socket);

        setTimeout(() => {
          socket.emit("joinChallenge", {
            challengeId: challenge.id,
            userId: user.email,
            username: user.full_name || user.email.split('@')[0]
          });
        }, 100);
      } else {
        arenaSocket.emit("joinChallenge", {
          challengeId: challenge.id,
          userId: user.email,
          username: user.full_name || user.email.split('@')[0]
        });
      }
    } catch (error) {
      console.error("Join arena error:", error);
      toast.error("Failed to join arena");
    }
  };

  // Submit code
  const handleSubmitCode = () => {
    if (!arenaSocket || !codeInput) {
      toast.error("Write your innovative solution first");
      return;
    }
    arenaSocket.emit("submitCode", { code: codeInput });
    toast.success("Innovation submitted! AI is scoring...");
  };

  // Cleanup socket on unmount
  useEffect(() => {
    return () => {
      if (arenaSocket) {
        arenaSocket.disconnect();
      }
    };
  }, [arenaSocket]);

  const isRunning = currentMatch?.status === "running";
  const isFinished = currentMatch?.status === "finished";

  // Filter challenges by status
  const scheduledChallenges = challenges.filter(c => c.status === "scheduled");
  const activeChallenges = challenges.filter(c => c.status === "open" || c.status === "running");
  const finishedChallenges = challenges.filter(c => c.status === "finished");

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#1a1f2e] bg-[#0f1419] mb-4">
            <Sparkles className="w-4 h-4 text-purple-500" />
            <span className="text-sm text-gray-400 uppercase tracking-wider">Innovation Index Arena</span>
          </div>
          <h1 className="text-5xl font-black mb-4" style={{
            background: "linear-gradient(135deg, #a855f7, #ec4899, #f59e0b)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}>
            Innovation PvP Arena
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto mb-6">
            Time-window coding battles where the most <strong className="text-purple-400">innovative</strong>, <strong className="text-cyan-400">elegant</strong>, and <strong className="text-green-400">performant</strong> solution wins. AI-scored across 5 dimensions.
          </p>
          
          {/* Innovation Scoring Info */}
          <div className="max-w-3xl mx-auto grid grid-cols-5 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-blue-600/10 border border-blue-600/30">
              <Target className="w-5 h-5 text-blue-400 mx-auto mb-1" />
              <div className="font-bold text-white">Quality</div>
              <div className="text-gray-400">30%</div>
            </div>
            <div className="p-3 rounded-lg bg-green-600/10 border border-green-600/30">
              <Zap className="w-5 h-5 text-green-400 mx-auto mb-1" />
              <div className="font-bold text-white">Performance</div>
              <div className="text-gray-400">20%</div>
            </div>
            <div className="p-3 rounded-lg bg-red-600/10 border border-red-600/30">
              <Shield className="w-5 h-5 text-red-400 mx-auto mb-1" />
              <div className="font-bold text-white">Safety</div>
              <div className="text-gray-400">20%</div>
            </div>
            <div className="p-3 rounded-lg bg-purple-600/10 border border-purple-600/30">
              <Award className="w-5 h-5 text-purple-400 mx-auto mb-1" />
              <div className="font-bold text-white">Elegance</div>
              <div className="text-gray-400">10%</div>
            </div>
            <div className="p-3 rounded-lg bg-yellow-600/10 border border-yellow-600/30">
              <Lightbulb className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
              <div className="font-bold text-white">Innovation</div>
              <div className="text-gray-400">20%</div>
            </div>
          </div>
        </div>

        {/* Talent Detection Banner */}
        <TalentDetectionBanner />

        {/* Stats Banner */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Clock className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{scheduledChallenges.length}</div>
            <div className="text-xs text-gray-400">Scheduled</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Flame className="w-6 h-6 text-orange-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{activeChallenges.length}</div>
            <div className="text-xs text-gray-400">Active Now</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Users className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              {currentMatch?.players?.length || 0}
            </div>
            <div className="text-xs text-gray-400">In Arena</div>
          </Card>

          <Card className="border-[#1a1f2e] bg-[#0f1419] p-4 text-center">
            <Trophy className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">
              €{challenges.filter(c => c.rewardType === "money").reduce((sum, c) => sum + (c.rewardValue || 0), 0)}
            </div>
            <div className="text-xs text-gray-400">Total Prizes</div>
          </Card>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-[1fr_1.5fr] gap-8">
          {/* Left: Challenges */}
          <div className="space-y-6">
            <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-black text-white">Innovation Challenges</h2>
                <Button
                  onClick={loadChallenges}
                  disabled={loadingChallenges}
                  size="sm"
                  variant="outline"
                  className="border-[#1a1f2e] text-gray-300"
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${loadingChallenges ? 'animate-spin' : ''}`} />
                  Refresh
                </Button>
              </div>

              {/* Active Challenges */}
              {activeChallenges.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-bold text-green-400 mb-3 flex items-center gap-2">
                    <Flame className="w-4 h-4" />
                    Active Now (Join!)
                  </h3>
                  <div className="space-y-3">
                    {activeChallenges.map((challenge) => (
                      <InnovationChallengeCard
                        key={challenge.id}
                        challenge={challenge}
                        onJoin={() => handleJoinArena(challenge.id)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Scheduled Challenges */}
              {scheduledChallenges.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-bold text-yellow-400 mb-3 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Upcoming
                  </h3>
                  <div className="space-y-3 max-h-[300px] overflow-y-auto">
                    {scheduledChallenges.map((challenge) => (
                      <InnovationChallengeCard
                        key={challenge.id}
                        challenge={challenge}
                        onJoin={() => handleJoinArena(challenge.id)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {challenges.length === 0 && (
                <div className="text-center py-8 text-gray-500 text-sm">
                  No challenges yet. Companies can create one below.
                </div>
              )}
            </Card>

            {/* Create Challenge (company only) */}
            {user && (
              <Card className="border-[#1a1f2e] bg-[#0f1419] p-6">
                <h3 className="text-lg font-bold text-white mb-4">Create Innovation Challenge</h3>
                <p className="text-xs text-gray-400 mb-4">
                  Schedule a time-window battle with rewards for the most innovative solution
                </p>

                <div className="space-y-3">
                  <Input
                    value={chTitle}
                    onChange={(e) => setChTitle(e.target.value)}
                    placeholder="Challenge title"
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                  />

                  <Textarea
                    value={chDesc}
                    onChange={(e) => setChDesc(e.target.value)}
                    placeholder="Description"
                    className="bg-[#141923] border-[#1a1f2e] text-white h-20"
                  />

                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      value={chLang}
                      onChange={(e) => setChLang(e.target.value)}
                      placeholder="Language"
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                    />

                    <Select value={chDiff} onValueChange={setChDiff}>
                      <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Easy</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="hard">Hard</SelectItem>
                        <SelectItem value="demigod">Demigod</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <Input
                      type="number"
                      value={chTime}
                      onChange={(e) => setChTime(e.target.value)}
                      placeholder="Time (sec)"
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                    />

                    <Input
                      type="number"
                      value={chStartOffset}
                      onChange={(e) => setChStartOffset(e.target.value)}
                      placeholder="Start (min)"
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                    />

                    <Input
                      type="number"
                      value={chWindow}
                      onChange={(e) => setChWindow(e.target.value)}
                      placeholder="Window (min)"
                      className="bg-[#141923] border-[#1a1f2e] text-white"
                    />
                  </div>

                  <Select value={chRewardType} onValueChange={setChRewardType}>
                    <SelectTrigger className="bg-[#141923] border-[#1a1f2e] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="money">Money Prize</SelectItem>
                      <SelectItem value="interview">Fast-track Interview</SelectItem>
                    </SelectContent>
                  </Select>

                  <Input
                    value={chRewardValue}
                    onChange={(e) => setChRewardValue(e.target.value)}
                    placeholder={chRewardType === "money" ? "Amount (EUR)" : "Interview description"}
                    className="bg-[#141923] border-[#1a1f2e] text-white"
                  />

                  <Button
                    onClick={handleCreateChallenge}
                    disabled={creating || !chTitle}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold"
                  >
                    {creating ? "Creating..." : "Create Innovation Challenge"}
                  </Button>
                </div>
              </Card>
            )}
          </div>

          {/* Right: Arena */}
          <InnovationArenaView
            currentChallenge={currentChallenge}
            currentMatch={currentMatch}
            latestScores={latestScores}
            remainingMs={remainingMs}
            matchFinishedData={matchFinishedData}
            codeInput={codeInput}
            setCodeInput={setCodeInput}
            onSubmitCode={handleSubmitCode}
            isRunning={isRunning}
            isFinished={isFinished}
          />
        </div>
      </div>
    </div>
  );
}
