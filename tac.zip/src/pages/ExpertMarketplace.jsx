import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Users, Briefcase, Zap, AlertCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import UrgentTaskCard from "../components/tasks/UrgentTaskCard";

export default function ExpertMarketplace() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("open");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: tasks, isLoading } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.Task.list('-created_date'),
    initialData: [],
  });

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (task.tech_stack && task.tech_stack.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())));
    const matchesType = filterType === "all" || task.type === filterType;
    const matchesStatus = filterStatus === "all" || task.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  // Separate urgent and normal tasks
  const urgentTasks = filteredTasks.filter(task => task.is_urgent && task.status === 'open');
  const normalTasks = filteredTasks.filter(task => !task.is_urgent);

  return (
    <div className="min-h-screen bg-[#0A0E14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-black text-white mb-4 tracking-tight">
            Szakértői Piactér
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Találj vagy légy szakértő! Megbízások, projektek és azonnali segítség.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-4 justify-center mb-8">
          <Link to={createPageUrl("PostTask")}>
            <Button className="bg-gradient-to-r from-[#00E599] to-[#00B8D4] text-black font-bold hover:opacity-90">
              <Plus className="w-5 h-5 mr-2" />
              Feladat Feladása
            </Button>
          </Link>
          <Link to={createPageUrl("ExpertProfiles")}>
            <Button variant="outline" className="border-[#1a1f2e] text-white hover:bg-[#1a1f2e]">
              <Users className="w-5 h-5 mr-2" />
              Szakértők Böngészése
            </Button>
          </Link>
          <Link to={createPageUrl("MyExpertProfile")}>
            <Button variant="outline" className="border-[#1a1f2e] text-white hover:bg-[#1a1f2e]">
              <Briefcase className="w-5 h-5 mr-2" />
              Saját Profil
            </Button>
          </Link>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Keresés feladatok között..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-[#0f1419] border-[#1a1f2e] text-white placeholder:text-gray-500 h-12"
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="bg-[#0f1419] border-[#1a1f2e] text-white">
                <SelectValue placeholder="Típus" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Minden Típus</SelectItem>
                <SelectItem value="bugfix">Bug Javítás</SelectItem>
                <SelectItem value="feature">Új Funkció</SelectItem>
                <SelectItem value="refactor">Refaktorálás</SelectItem>
                <SelectItem value="innovation">Innováció</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="bg-[#0f1419] border-[#1a1f2e] text-white">
                <SelectValue placeholder="Státusz" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Minden Státusz</SelectItem>
                <SelectItem value="open">Nyitott</SelectItem>
                <SelectItem value="in_progress">Folyamatban</SelectItem>
                <SelectItem value="completed">Befejezett</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Urgent Tasks Section */}
        {urgentTasks.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-red-600/20 to-orange-600/20 rounded-lg border border-red-500/50">
                <Zap className="w-6 h-6 text-red-500" />
                <h2 className="text-2xl font-black text-white">Sürgős Feladatok</h2>
                <Badge className="bg-red-600 text-white border-0 ml-2">{urgentTasks.length}</Badge>
              </div>
            </div>
            
            <div className="p-4 bg-yellow-600/10 border border-yellow-600/30 rounded-lg mb-6 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-400 mt-0.5" />
              <div>
                <p className="text-yellow-200 font-semibold mb-1">
                  Dinamikus Árképzés Aktiválva
                </p>
                <p className="text-yellow-200/80 text-sm">
                  Ezek a feladatok azonnali segítséget igényelnek. A díj automatikusan növekszik az idő múlásával, így minél hamarabb jelentkezel, annál jobb!
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {urgentTasks.map(task => (
                <UrgentTaskCard key={task.id} task={task} />
              ))}
            </div>
          </div>
        )}

        {/* Normal Tasks Section */}
        <div>
          {urgentTasks.length > 0 && (
            <div className="flex items-center gap-2 mb-6">
              <Briefcase className="w-6 h-6 text-[#00E599]" />
              <h2 className="text-2xl font-black text-white">Standard Feladatok</h2>
              <Badge variant="outline" className="border-[#1a1f2e] text-gray-400">
                {normalTasks.length}
              </Badge>
            </div>
          )}

          <p className="text-gray-400 mb-6">
            <span className="font-bold text-white">{filteredTasks.length}</span> feladat található
          </p>

          {isLoading ? (
            <div className="text-center py-20">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-[#00E599] border-t-transparent"></div>
              <p className="text-gray-400 mt-4">Betöltés...</p>
            </div>
          ) : normalTasks.length === 0 ? (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">💼</div>
              <h3 className="text-2xl font-bold text-white mb-2">Nincs elérhető feladat</h3>
              <p className="text-gray-400">Próbálj meg más szűrőket használni</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {normalTasks.map(task => (
                <Card key={task.id} className="border border-[#1a1f2e] bg-[#0f1419] p-6 hover:border-[#00E599] transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <Badge className="bg-[#1a1f2e] text-gray-300 hover:bg-[#1a1f2e]">
                      {task.type}
                    </Badge>
                    <Badge 
                      variant="outline" 
                      className={`
                        ${task.status === 'open' ? 'border-green-600/30 text-green-400' : ''}
                        ${task.status === 'in_progress' ? 'border-blue-600/30 text-blue-400' : ''}
                        ${task.status === 'completed' ? 'border-purple-600/30 text-purple-400' : ''}
                      `}
                    >
                      {task.status}
                    </Badge>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-2 line-clamp-2">{task.title}</h3>
                  <p className="text-gray-400 text-sm mb-4 line-clamp-3">{task.description}</p>

                  {task.tech_stack && task.tech_stack.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {task.tech_stack.slice(0, 3).map((tech, idx) => (
                        <Badge key={idx} variant="outline" className="border-[#1a1f2e] text-gray-400 text-xs">
                          {tech}
                        </Badge>
                      ))}
                      {task.tech_stack.length > 3 && (
                        <Badge variant="outline" className="border-[#1a1f2e] text-gray-400 text-xs">
                          +{task.tech_stack.length - 3}
                        </Badge>
                      )}
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t border-[#1a1f2e]">
                    <div className="text-sm text-gray-400">
                      {task.budget_min && task.budget_max ? (
                        <span className="text-[#00E599] font-bold">
                          {task.budget_min}-{task.budget_max} {task.currency || 'EUR'}
                        </span>
                      ) : (
                        <span className="text-gray-500">Egyeztetendő</span>
                      )}
                    </div>
                    <Link to={createPageUrl("TaskDetail") + `?id=${task.id}`}>
                      <Button size="sm" variant="outline" className="border-[#1a1f2e] text-white hover:bg-[#1a1f2e]">
                        Részletek
                      </Button>
                    </Link>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}