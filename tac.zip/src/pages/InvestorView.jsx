import React, { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function InvestorView() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: "Vision – The OS for Hidden Tech Demigods",
      content: (
        <>
          <p>
            MDC is building a <strong>demigod-tier talent layer</strong> on top of the global dev ecosystem –
            a place where the world's most underrated developers, designers and builders are discovered,
            ranked and matched by AI.
          </p>
          <h3>Core idea</h3>
          <ul>
            <li>Most of the world's best problem-solvers are invisible in traditional hiring funnels.</li>
            <li>Current platforms (LinkedIn, Upwork, job boards) optimize for keywords – not true skill.</li>
            <li>MDC turns <strong>code, snippets, behavior and AI analysis</strong> into a dynamic demigod ranking layer.</li>
          </ul>
          <p>
            <span className="badge">
              <span className="badge-dot"></span> Status: Pre-seed ready demo
            </span>
          </p>
        </>
      )
    },
    {
      title: "Problem – Talent Discovery Is Slow & Blind",
      content: (
        <>
          <h3>Hiring today is broken:</h3>
          <ul>
            <li>Recruiters drown in CVs and LinkedIn noise, while true talent stays unseen.</li>
            <li>Candidates are filtered by keywords, schools and company logos – not actual skill.</li>
            <li>Developers with godlike problem-solving skills often hate "traditional" recruitment.</li>
            <li>Companies spend weeks to months for roles that the right person could fill in days.</li>
          </ul>
          <p>
            The result: <strong>slow, expensive, noisy</strong> tech hiring – and a massive mismatch between
            real skill and opportunity.
          </p>
        </>
      )
    },
    {
      title: "Solution – AI-Ranked Demigod Talent Layer",
      content: (
        <>
          <p>
            MDC is a <strong>curated, AI-augmented talent platform</strong>, where devs and creators are not
            judged by job titles, but by:
          </p>
          <ul>
            <li>their code (snippets, mini-projects, problem breakdowns)</li>
            <li>their creativity (micro-showcases, "godlike moments")</li>
            <li>their behavior (help drops, community-driven signal)</li>
            <li>AI evaluation (snippet scorer, project complexity evaluator)</li>
          </ul>
          <p>
            For companies, MDC works as an <strong>instant AI recruiter</strong>: describe the need, get
            <strong> ranked, ready-to-talk talent</strong> in seconds.
          </p>
        </>
      )
    },
    {
      title: "Product – MDC Platform (Live Demo Available)",
      content: (
        <>
          <h3>Core pillars already implemented as demo:</h3>
          <ul>
            <li>
              <strong>Straight From The Top – Demigod Feed</strong><br />
              Live stream of showcases, godlike code snippets and "help drops" from ranked elite talent.
            </li>
            <li>
              <strong>AI Snippet Analyzer</strong><br />
              Evaluates code clarity, structure and style to generate a demigod-grade score.
            </li>
            <li>
              <strong>AI Recruiter (Mini Match Engine)</strong><br />
              Turn a textual role description into a ranked list of top-fit profiles.
            </li>
            <li>
              <strong>Project Valuation AI</strong><br />
              Estimates project complexity, tier (Prototype → Enterprise) and suggested price range.
            </li>
            <li>
              <strong>MDC Support AI</strong><br />
              Always-on assistant helping users navigate the ecosystem (ranks, features, deals).
            </li>
          </ul>
          <p>All of this already exists as an interactive demo (web-first, Base44-ready).</p>
        </>
      )
    },
    {
      title: "Market – Where Talent & AI Hiring Collide",
      content: (
        <>
          <h3>We sit at the intersection of:</h3>
          <ul>
            <li>Global online dev talent (~tens of millions)</li>
            <li>Tech recruiting, staffing & freelance market (multi-billion €)</li>
            <li>AI-native HR tooling and "smart" job platforms (fast-growing segment)</li>
          </ul>
          <p>
            MDC is positioned as a <strong>vertical, high-signal layer</strong> for the top 5–10% of talent:
            demigods, rising elites, and overlooked high-potential builders.
          </p>
          <p>
            Instead of competing with generic job boards, MDC aims to become
            "<em>the undisputed home of the world's most capable builders</em>".
          </p>
        </>
      )
    },
    {
      title: "Business Model – Multiple Strong Monetization Paths",
      content: (
        <>
          <h3>Primary revenue streams (roadmap):</h3>
          <ul>
            <li>
              <strong>AI Recruiter Access (B2B SaaS)</strong><br />
              Companies pay subscription / usage-based fees to search & match top demigod profiles.
            </li>
            <li>
              <strong>Placement / success fees</strong><br />
              Percentage fee on successful hires or larger project deals closed via MDC.
            </li>
            <li>
              <strong>Talent-side premium tiers</strong><br />
              Paid visibility boosts, portfolio enhancements, advanced analytics, and "godlike" verification.
            </li>
            <li>
              <strong>Expert micro-consulting</strong><br />
              "Ask a demigod" feature – paid, short-form code and architecture insights from ranked top talent.
            </li>
          </ul>
          <p>These combine SaaS-like predictability with marketplace upside.</p>
        </>
      )
    },
    {
      title: "Traction & Potential",
      content: (
        <>
          <h3>Already in place:</h3>
          <ul>
            <li>Working MDC core demo (frontend + backend, AI stubs ready for full integration).</li>
            <li>Defined demigod ranking logic (activity + AI-scored snippet quality).</li>
            <li>Clear brand, visual identity and narrative for both builders and companies.</li>
          </ul>
          <h3>Near-term potential (first 3–6 months):</h3>
          <ul>
            <li>Onboard the first wave of "hidden demigod" talent (GitHub, Reddit, AI communities).</li>
            <li>Run pilot AI-recruiter projects with early-adopter startups.</li>
            <li>Refine ranking and matching loops with real data.</li>
          </ul>
          <p>
            The core risk is not "does this make sense?" but rather
            "how fast can we own this niche before bigger platforms copy the model?".
          </p>
        </>
      )
    },
    {
      title: "Roadmap – 12 Month Focus",
      content: (
        <>
          <h3>Phase 1 – Public alpha (0–3 months)</h3>
          <ul>
            <li>Finalize MDC core product and AI integration.</li>
            <li>Launch invite-only early demigod program.</li>
            <li>Secure 1–3 pilot company partnerships for AI recruiter tests.</li>
          </ul>
          <h3>Phase 2 – Signal flywheel (3–9 months)</h3>
          <ul>
            <li>Gamified demigod ranking and monthly elite challenges.</li>
            <li>Refined AI analysis of snippets, projects and collaboration behavior.</li>
            <li>More structured deal flow between companies and top profiles.</li>
          </ul>
          <h3>Phase 3 – Scale (9–12 months)</h3>
          <ul>
            <li>Expand internationally with remote-first companies.</li>
            <li>Layer additional verticals (AI research, design, founder matchmaking).</li>
          </ul>
        </>
      )
    },
    {
      title: "The Ask – Pre-Seed to Build the Demigod Layer",
      content: (
        <>
          <p>
            MDC is currently at <strong>pre-seed ready demo</strong> stage.
            The next step is to turn this into a live, invite-only alpha with real deal flow.
          </p>
          <h3>We're looking for:</h3>
          <ul>
            <li>Pre-seed funding to accelerate product, AI integration and go-to-market.</li>
            <li>Strategic investors who understand AI, talent and marketplaces.</li>
            <li>Pilot partners (startups / tech companies) willing to test AI-powered recruiting.</li>
          </ul>
          <p>
            MDC is not "just another job board" – it's an <strong>AI-native talent OS</strong> for the world's
            most capable builders, with a clear high-end positioning and strong early product vision.
          </p>
        </>
      )
    }
  ];

  const goToSlide = (index) => {
    if (index >= 0 && index < slides.length) {
      setCurrentSlide(index);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowLeft') goToSlide(currentSlide - 1);
      if (e.key === 'ArrowRight') goToSlide(currentSlide + 1);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlide]);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(circle at top, #250746 0%, #0a001c 40%, #02000c 100%)',
      color: '#f6edff',
      fontFamily: 'Inter, system-ui, sans-serif'
    }}>
      <style>{`
        @keyframes logoPulse {
          0% { transform: rotateX(18deg) rotateY(-18deg) scale(1); }
          50% { transform: rotateX(18deg) rotateY(-18deg) scale(1.06); }
          100% { transform: rotateX(18deg) rotateY(-18deg) scale(1); }
        }

        @keyframes logoFloat {
          0% { transform: translateY(0px) rotateX(18deg) rotateY(-18deg); }
          50% { transform: translateY(-5px) rotateX(18deg) rotateY(-18deg); }
          100% { transform: translateY(0px) rotateX(18deg) rotateY(-18deg); }
        }

        .investor-logo {
          animation: logoPulse 4s infinite ease-in-out, logoFloat 7s infinite ease-in-out;
        }

        .slide-content h3 {
          margin: 14px 0 6px;
          font-size: 16px;
          color: #f6edff;
        }

        .slide-content p {
          font-size: 14px;
          opacity: 0.9;
          line-height: 1.6;
          margin: 10px 0;
        }

        .slide-content ul {
          padding-left: 18px;
          font-size: 14px;
          opacity: 0.9;
          line-height: 1.7;
        }

        .slide-content li {
          margin: 8px 0;
        }

        .badge {
          display: inline-flex;
          align-items: center;
          border-radius: 999px;
          border: 1px solid rgba(255,255,255,0.14);
          padding: 4px 8px;
          font-size: 11px;
          opacity: 0.9;
          gap: 6px;
          margin-top: 10px;
        }

        .badge-dot {
          width: 7px;
          height: 7px;
          border-radius: 999px;
          background: #2df59b;
          box-shadow: 0 0 10px rgba(45,245,155,0.9);
        }

        .gradient-title {
          background: linear-gradient(90deg, #b788ff, #ff82e8);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
      `}</style>

      {/* Header */}
      <header style={{
        padding: '20px 24px',
        display: 'flex',
        alignItems: 'center',
        gap: '14px',
        flexWrap: 'wrap'
      }}>
        <div 
          className="investor-logo"
          style={{
            width: '52px',
            height: '52px',
            borderRadius: '15px',
            background: 'radial-gradient(circle at 30% 20%, #b788ff, #ff82e8, #4b2b8f)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '26px',
            fontWeight: '800',
            color: '#fff',
            transform: 'rotateX(18deg) rotateY(-18deg)',
            boxShadow: '0 0 16px #b788ffcc, 0 0 30px #ff82e8aa'
          }}
        >
          M
        </div>
        <div>
          <div className="gradient-title" style={{
            fontSize: '22px',
            fontWeight: '800',
            lineHeight: '1.2'
          }}>
            MDC – Investor View
          </div>
          <div style={{
            fontSize: '12px',
            opacity: '0.82',
            marginTop: '2px'
          }}>
            AI-native demigod talent marketplace
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main style={{
        maxWidth: '960px',
        margin: '0 auto',
        padding: '10px 10px 30px'
      }}>
        {/* Slide Container */}
        <div style={{
          position: 'relative',
          minHeight: '480px'
        }}>
          <div style={{
            background: 'rgba(255,255,255,0.04)',
            borderRadius: '20px',
            border: '1px solid rgba(255,255,255,0.14)',
            backdropFilter: 'blur(14px) saturate(150%)',
            boxShadow: '0 0 20px rgba(160,120,255,0.2)',
            padding: '26px',
            minHeight: '480px'
          }}>
            <h2 className="gradient-title" style={{
              margin: '0 0 8px',
              fontSize: '22px',
              fontWeight: '700'
            }}>
              {slides[currentSlide].title}
            </h2>
            <div className="slide-content">
              {slides[currentSlide].content}
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div style={{
          marginTop: '20px',
          display: 'flex',
          alignItems: 'center',
          gap: '14px',
          justifyContent: 'space-between',
          flexWrap: 'wrap'
        }}>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={() => goToSlide(currentSlide - 1)}
              disabled={currentSlide === 0}
              style={{
                borderRadius: '999px',
                border: 'none',
                padding: '8px 16px',
                fontWeight: '600',
                fontSize: '13px',
                cursor: currentSlide === 0 ? 'default' : 'pointer',
                color: '#fff',
                background: 'linear-gradient(135deg, #b788ff, #ff82e8)',
                boxShadow: currentSlide === 0 ? 'none' : '0 0 14px #b788ffcc',
                opacity: currentSlide === 0 ? 0.4 : 1,
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              <ChevronLeft className="w-4 h-4" />
              Prev
            </button>
          </div>

          {/* Dots */}
          <div style={{
            display: 'flex',
            gap: '6px'
          }}>
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '999px',
                  border: '1px solid rgba(255,255,255,0.14)',
                  background: index === currentSlide ? '#b788ff' : 'transparent',
                  boxShadow: index === currentSlide ? '0 0 12px #b788ffcc' : 'none',
                  cursor: 'pointer',
                  padding: 0
                }}
              />
            ))}
          </div>

          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={() => goToSlide(currentSlide + 1)}
              disabled={currentSlide === slides.length - 1}
              style={{
                borderRadius: '999px',
                border: 'none',
                padding: '8px 16px',
                fontWeight: '600',
                fontSize: '13px',
                cursor: currentSlide === slides.length - 1 ? 'default' : 'pointer',
                color: '#fff',
                background: 'linear-gradient(135deg, #b788ff, #ff82e8)',
                boxShadow: currentSlide === slides.length - 1 ? 'none' : '0 0 14px #b788ffcc',
                opacity: currentSlide === slides.length - 1 ? 0.4 : 1,
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Slide Counter */}
        <div style={{
          textAlign: 'center',
          marginTop: '16px',
          fontSize: '12px',
          opacity: '0.6'
        }}>
          Slide {currentSlide + 1} of {slides.length}
        </div>
      </main>

      {/* Footer */}
      <footer style={{
        textAlign: 'center',
        padding: '16px',
        fontSize: '12px',
        opacity: '0.6',
        marginTop: '20px'
      }}>
        © 2025 MDC – Demigod Talent Platform · Investor View
      </footer>
    </div>
  );
}