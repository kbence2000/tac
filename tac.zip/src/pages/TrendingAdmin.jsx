import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Terminal } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TrendingSnippetsRefresh from "../components/TrendingSnippetsRefresh";
import TrendSourceManager from "../components/TrendSourceManager";
import TrendRealtimeWatcher from "../components/TrendRealtimeWatcher";
import TrendHealthMonitor from "../components/TrendHealthMonitor";
import LiveCodeBillboard from "../components/LiveCodeBillboard";

export default function TrendingAdmin() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Admin check
  if (user && user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md w-full p-8 text-center border" style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(148, 163, 184, 0.35)'
        }}>
          <Terminal className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Admin Only</h2>
          <p className="text-gray-400">
            TrendHarvester requires administrator privileges
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-orange-500 to-red-500">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white">TrendHarvester</h1>
              <p className="text-gray-400">Global tech signal intelligence</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Live Code Billboard */}
          <div>
            <h3 className="text-lg font-bold text-white mb-4">Live Code Feed</h3>
            <LiveCodeBillboard autoRotate={true} rotateInterval={8000} />
          </div>

          {/* Admin Controls */}
          <Tabs defaultValue="refresh" className="space-y-6">
            <TabsList className="bg-[#0f1419] border border-[#1a1f2e]">
              <TabsTrigger value="refresh" className="data-[state=active]:bg-orange-600/20">
                Refresh
              </TabsTrigger>
              <TabsTrigger value="sources" className="data-[state=active]:bg-cyan-600/20">
                Sources
              </TabsTrigger>
              <TabsTrigger value="realtime" className="data-[state=active]:bg-green-600/20">
                Realtime
              </TabsTrigger>
              <TabsTrigger value="health" className="data-[state=active]:bg-purple-600/20">
                Health
              </TabsTrigger>
            </TabsList>

            <TabsContent value="refresh">
              <TrendingSnippetsRefresh />
            </TabsContent>

            <TabsContent value="sources">
              <TrendSourceManager />
            </TabsContent>

            <TabsContent value="realtime">
              <TrendRealtimeWatcher />
            </TabsContent>

            <TabsContent value="health">
              <TrendHealthMonitor />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}