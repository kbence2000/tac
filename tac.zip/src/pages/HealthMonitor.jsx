import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Activity } from 'lucide-react';

export default function HealthMonitor() {
  const [healthData, setHealthData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [events, setEvents] = useState([]);

  const fetchHealth = async () => {
    try {
      const response = await base44.functions.invoke('globalSystemHealth', {
        snapshot: {
          source: "TAC-Core",
          layers: [
            { name: "logic", baseValue: 0.8, drift: 0.2 },
            { name: "creative", baseValue: 1.1, drift: 0.3 },
            { name: "resonance", baseValue: 0.5, drift: 0.1 }
          ],
          paradoxCheck: { exprA: "2+2", exprB: "4" }
        }
      });
      
      setHealthData(response.data);
      setIsLoading(false);
      
      // Add event
      const timestamp = new Date().toLocaleTimeString();
      setEvents(prev => [
        { text: 'Health snapshot updated', time: timestamp },
        ...prev.slice(0, 9)
      ]);
    } catch (err) {
      console.error('Health fetch error:', err);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchHealth();
    const interval = setInterval(fetchHealth, 5000);
    return () => clearInterval(interval);
  }, []);

  if (isLoading || !healthData) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{
        background: 'radial-gradient(circle at top, #4d0d6f 0%, #000000 55%)'
      }}>
        <Activity className="w-12 h-12 animate-spin text-purple-400" />
      </div>
    );
  }

  const { globalHealth, components, engines } = healthData;
  const overallScore = Math.round(
    (globalHealth.neuralStability + globalHealth.coherenceFlow + 
     globalHealth.vitalityPulse - globalHealth.entropyPressure) * 25
  );
  
  const getGrade = (score) => {
    if (score >= 80) return 'Grade A';
    if (score >= 65) return 'Grade B';
    if (score >= 50) return 'Grade C';
    return 'Grade D';
  };

  const getRiskLevel = (val) => {
    if (val < 0.4) return { text: 'low risk', color: 'emerald' };
    if (val < 0.7) return { text: 'medium risk', color: 'amber' };
    return { text: 'high risk', color: 'red' };
  };

  const riftRisk = getRiskLevel(components.avgRift);

  return (
    <div className="min-h-screen text-slate-100" style={{
      background: 'radial-gradient(circle at top, #4d0d6f 0%, #000000 55%)'
    }}>
      <style>{`
        .glass {
          background: rgba(10, 10, 18, 0.86);
          backdrop-filter: blur(18px);
          border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .glow-ring {
          box-shadow: 0 0 18px rgba(136, 110, 157, 0.6);
        }
      `}</style>

      <div className="max-w-5xl mx-auto px-4 py-6 sm:py-10">
        {/* Header */}
        <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">
              Global System Health
            </h1>
            <p className="text-xs sm:text-sm text-slate-400">
              Rift AI · Anti-Rift · Dual Resonance · Singularity Monitor
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs sm:text-sm">
            <span className="inline-flex items-center rounded-full px-3 py-1 glass border border-emerald-400/40">
              <span className="w-2 h-2 rounded-full bg-emerald-400 mr-2 animate-pulse"></span>
              Live Monitor
            </span>
          </div>
        </header>

        {/* Top summary card */}
        <section className="glass rounded-2xl p-4 sm:p-5 mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="relative flex items-center justify-center w-20 h-20 rounded-full bg-black/60 glow-ring">
                <svg viewBox="0 0 36 36" className="w-16 h-16 -rotate-90">
                  <path
                    className="text-slate-700"
                    stroke="currentColor"
                    strokeWidth="3"
                    fill="none"
                    d="M18 2a16 16 0 1 1 0 32a16 16 0 0 1 0-32z"
                  />
                  <path
                    className="text-emerald-400"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeLinecap="round"
                    fill="none"
                    strokeDasharray="100"
                    strokeDashoffset={100 - overallScore}
                    d="M18 2a16 16 0 1 1 0 32a16 16 0 0 1 0-32z"
                  />
                </svg>
                <div className="absolute text-center">
                  <div className="text-xs text-slate-400">Score</div>
                  <div className="text-lg font-semibold">{overallScore}</div>
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-300">Overall Health</span>
                  <span className="inline-flex items-center rounded-full border border-emerald-400/60 px-2 py-0.5 text-xs text-emerald-300">
                    {getGrade(overallScore)}
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-400 max-w-xs">
                  System operating in stable range. Rift activity: {riftRisk.text}. Singularity risk low.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs sm:text-sm">
              <div className="flex flex-col">
                <span className="text-slate-400">Neural Stability</span>
                <span className="font-semibold text-slate-50">
                  {globalHealth.neuralStability.toFixed(2)}
                </span>
                <span className="text-[11px] text-emerald-300">balanced</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400">Coherence Flow</span>
                <span className="font-semibold text-slate-50">
                  {globalHealth.coherenceFlow.toFixed(2)}
                </span>
                <span className="text-[11px] text-slate-400">flowing</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400">Entropy Pressure</span>
                <span className="font-semibold text-slate-50">
                  {globalHealth.entropyPressure.toFixed(2)}
                </span>
                <span className="text-[11px] text-amber-300">mild</span>
              </div>
              <div className="flex flex-col">
                <span className="text-slate-400">Vitality Pulse</span>
                <span className="font-semibold text-slate-50">
                  {globalHealth.vitalityPulse.toFixed(2)}
                </span>
                <span className="text-[11px] text-emerald-300">strong</span>
              </div>
            </div>
          </div>
        </section>

        {/* Detail cards */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Rift AI */}
          <div className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-sm font-semibold">Rift AI</h2>
                <p className="text-[11px] text-slate-400">
                  Layer fractures & drift detection
                </p>
              </div>
              <span className={`text-[11px] px-2 py-0.5 rounded-full bg-${riftRisk.color}-500/10 text-${riftRisk.color}-300 border border-${riftRisk.color}-400/40`}>
                {riftRisk.text}
              </span>
            </div>
            <dl className="grid grid-cols-2 gap-3 text-[11px]">
              <div>
                <dt className="text-slate-400">Avg Rift Intensity</dt>
                <dd className="text-slate-50 font-semibold">{components.avgRift.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Max Rift</dt>
                <dd className="text-slate-50 font-semibold">{components.maxRift.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Resonance</dt>
                <dd className="text-slate-50 font-semibold">{components.resonance.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Variance</dt>
                <dd className="text-slate-50 font-semibold">{components.variance.toFixed(2)}</dd>
              </div>
            </dl>
          </div>

          {/* Anti-Rift */}
          <div className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-sm font-semibold">Anti-Rift Engine</h2>
                <p className="text-[11px] text-slate-400">
                  Neutralization & smoothing
                </p>
              </div>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-400/40">
                active
              </span>
            </div>
            <dl className="grid grid-cols-2 gap-3 text-[11px]">
              <div>
                <dt className="text-slate-400">Anti-Resonance</dt>
                <dd className="text-slate-50 font-semibold">{components.antiResonance.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Risk Level</dt>
                <dd className="text-slate-50 font-semibold">
                  {engines.riftData?.antiAnalysis?.riskLevel || 'N/A'}
                </dd>
              </div>
              <div className="col-span-2">
                <dt className="text-slate-400 mb-1">Status</dt>
                <dd className="text-[11px] text-slate-200">
                  Smoothing layers actively
                </dd>
              </div>
            </dl>
          </div>

          {/* Dual Resonance */}
          <div className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-sm font-semibold">Dual Resonance Engine</h2>
                <p className="text-[11px] text-slate-400">
                  Balance monitoring
                </p>
              </div>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-300 border border-sky-400/40">
                balanced
              </span>
            </div>
            <dl className="grid grid-cols-2 gap-3 text-[11px]">
              <div>
                <dt className="text-slate-400">Resonance</dt>
                <dd className="text-slate-50 font-semibold">{components.resonance.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Anti-Resonance</dt>
                <dd className="text-slate-50 font-semibold">{components.antiResonance.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Variance</dt>
                <dd className="text-slate-50 font-semibold">{components.variance.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">State</dt>
                <dd className="text-slate-50 font-semibold">BALANCED</dd>
              </div>
            </dl>
          </div>

          {/* Singularity */}
          <div className="glass rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-sm font-semibold">Singularity Monitor</h2>
                <p className="text-[11px] text-slate-400">
                  Proximity & trend analysis
                </p>
              </div>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-200 border border-purple-400/40">
                safe range
              </span>
            </div>
            <dl className="grid grid-cols-2 gap-3 text-[11px]">
              <div>
                <dt className="text-slate-400">Singularity Field</dt>
                <dd className="text-slate-50 font-semibold">{components.singularityField.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Collapse Risk</dt>
                <dd className="text-slate-50 font-semibold">{components.collapseRisk.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Cohesion</dt>
                <dd className="text-slate-50 font-semibold">{components.cohesion.toFixed(2)}</dd>
              </div>
              <div>
                <dt className="text-slate-400">Risk Level</dt>
                <dd className="text-slate-50 font-semibold">low</dd>
              </div>
            </dl>
          </div>
        </section>

        {/* Event feed */}
        <section className="glass rounded-2xl p-4 mb-10">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-semibold">Recent Health Events</h2>
              <p className="text-[11px] text-slate-400">
                Last system updates
              </p>
            </div>
          </div>
          <ul className="space-y-2 text-[11px]">
            {events.length === 0 ? (
              <li className="text-slate-400">No events yet</li>
            ) : (
              events.map((event, idx) => (
                <li key={idx} className="flex items-center justify-between">
                  <span className="text-slate-200">• {event.text}</span>
                  <span className="text-slate-500">{event.time}</span>
                </li>
              ))
            )}
          </ul>
        </section>
      </div>
    </div>
  );
}