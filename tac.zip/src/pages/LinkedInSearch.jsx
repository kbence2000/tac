import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Linkedin, ExternalLink, Sparkles, Star, Briefcase, Mail, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const experienceLevelColors = {
  junior: "bg-blue-600/20 text-blue-400 border-blue-600/30",
  mid: "bg-purple-600/20 text-purple-400 border-purple-600/30",
  senior: "bg-orange-600/20 text-orange-400 border-orange-600/30",
  lead: "bg-red-600/20 text-red-400 border-red-600/30"
};

const experienceLevelLabels = {
  junior: "Junior",
  mid: "Mid-Level",
  senior: "Senior",
  lead: "Lead/Principal"
};

export default function LinkedInSearch() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterLevel, setFilterLevel] = useState("all");

  const { data: profiles, isLoading } = useQuery({
    queryKey: ['expertProfiles'],
    queryFn: () => base44.entities.ExpertProfile.list('-created_date'),
    initialData: [],
  });

  const filteredProfiles = profiles
    .filter(profile => {
      const hasLinkedIn = profile.linkedin_url && profile.linkedin_url.trim() !== '';
      
      const matchesSearch = 
        profile.headline?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        profile.bio?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        profile.pitch?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        profile.skills?.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase())) ||
        profile.user_email?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesLevel = filterLevel === "all" || profile.experience_level === filterLevel;
      
      return hasLinkedIn && matchesSearch && matchesLevel;
    });

  return (
    <div className="min-h-screen">
      <div className="max-w-[1120px] mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-2xl" style={{
              background: 'radial-gradient(circle at 0 0, rgba(0, 119, 181, 0.3), transparent 70%)',
              border: '1px solid rgba(0, 119, 181, 0.5)'
            }}>
              <Linkedin className="w-8 h-8 text-[#0077b5]" />
            </div>
            <div>
              <h1 className="text-4xl font-black text-white">LinkedIn Talent Search</h1>
              <p className="text-gray-400 mt-1">Fedezd fel a legjobb szakértőket LinkedIn profiljaik alapján</p>
            </div>
          </div>

          {/* Search Bar */}
          <Card className="border p-6" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Keress szakértőkre név, skill, pozíció szerint..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12 border text-white placeholder:text-gray-500"
                  style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
                />
              </div>
              
              <select
                value={filterLevel}
                onChange={(e) => setFilterLevel(e.target.value)}
                className="h-12 px-4 rounded-lg border text-white"
                style={{ background: 'rgba(11, 16, 32, 0.9)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
              >
                <option value="all">Minden szint</option>
                <option value="junior">Junior</option>
                <option value="mid">Mid-Level</option>
                <option value="senior">Senior</option>
                <option value="lead">Lead/Principal</option>
              </select>

              <Button className="h-12 px-8 font-bold" style={{ 
                background: 'radial-gradient(circle at 0 0, var(--accent-alt), transparent 45%), var(--accent)',
                color: 'white'
              }}>
                <Search className="w-5 h-5 mr-2" />
                Keresés
              </Button>
            </div>
          </Card>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-400">
            <span className="font-bold text-white">{filteredProfiles.length}</span> LinkedIn profil találat
          </p>
        </div>

        {/* Profiles Grid */}
        {isLoading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-t-transparent" style={{ borderColor: 'var(--accent)' }}></div>
            <p className="text-gray-400 mt-4">Betöltés...</p>
          </div>
        ) : filteredProfiles.length === 0 ? (
          <Card className="border p-12 text-center" style={{
            background: 'rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(148, 163, 184, 0.35)'
          }}>
            <Linkedin className="w-16 h-16 mx-auto mb-4 text-gray-600" />
            <h3 className="text-xl font-bold text-white mb-2">Nincs találat</h3>
            <p className="text-gray-400 mb-6">Próbálj más keresési feltételeket vagy szinteket!</p>
            <Link to={createPageUrl("ExpertProfiles")}>
              <Button variant="outline" className="border-[#1a1f2e] text-white">
                Összes szakértő megtekintése
              </Button>
            </Link>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredProfiles.map(profile => (
              <Card 
                key={profile.id}
                className="border p-6 transition-all hover:scale-[1.02] relative overflow-hidden group"
                style={{
                  background: 'rgba(15, 23, 42, 0.95)',
                  borderColor: 'rgba(148, 163, 184, 0.35)',
                  boxShadow: '0 12px 28px rgba(15, 23, 42, 0.8)',
                  borderRadius: '18px'
                }}
              >
                {/* Hover glow */}
                <div 
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                  style={{
                    background: 'radial-gradient(circle at 50% 0%, rgba(0, 119, 181, 0.2), transparent 70%)'
                  }}
                />

                <div className="relative z-10">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white mb-1">{profile.headline}</h3>
                      <p className="text-sm text-gray-400">{profile.user_email}</p>
                    </div>
                    <Badge className={`border ${experienceLevelColors[profile.experience_level || 'mid']}`}>
                      {experienceLevelLabels[profile.experience_level || 'mid']}
                    </Badge>
                  </div>

                  {/* Pitch - Kiemelten */}
                  {profile.pitch && (
                    <div className="mb-4 p-4 rounded-xl border" style={{
                      background: 'radial-gradient(circle at 0 0, rgba(139, 92, 255, 0.1), transparent 70%)',
                      borderColor: 'rgba(139, 92, 255, 0.3)'
                    }}>
                      <div className="flex items-start gap-2">
                        <Sparkles className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--accent-alt)' }} />
                        <p className="text-white font-medium leading-relaxed">"{profile.pitch}"</p>
                      </div>
                    </div>
                  )}

                  {/* Stats */}
                  <div className="flex items-center gap-4 mb-4 text-sm text-gray-400">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span>{profile.rating?.toFixed(1) || '0.0'}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Briefcase className="w-4 h-4" />
                      <span>{profile.completed_tasks || 0} projekt</span>
                    </div>
                    {profile.hourly_rate && (
                      <div className="font-bold" style={{ color: 'var(--accent-alt)' }}>
                        {profile.hourly_rate} EUR/óra
                      </div>
                    )}
                  </div>

                  {/* Bio */}
                  {profile.bio && (
                    <p className="text-gray-300 text-sm mb-4 line-clamp-2 leading-relaxed">
                      {profile.bio}
                    </p>
                  )}

                  {/* Skills */}
                  {profile.skills && profile.skills.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {profile.skills.slice(0, 5).map((skill, idx) => (
                        <Badge 
                          key={idx}
                          variant="outline"
                          className="text-xs"
                          style={{ borderColor: 'rgba(148, 163, 184, 0.5)', color: 'var(--text-muted)' }}
                        >
                          {skill}
                        </Badge>
                      ))}
                      {profile.skills.length > 5 && (
                        <Badge variant="outline" className="text-xs" style={{ borderColor: 'rgba(148, 163, 184, 0.5)' }}>
                          +{profile.skills.length - 5}
                        </Badge>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2 pt-4 border-t" style={{ borderColor: 'rgba(31, 41, 55, 0.9)' }}>
                    <a
                      href={profile.linkedin_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1"
                    >
                      <Button
                        className="w-full text-white font-semibold"
                        style={{
                          background: 'linear-gradient(135deg, #0077b5, #00a0dc)',
                          border: 'none'
                        }}
                      >
                        <Linkedin className="w-4 h-4 mr-2" />
                        LinkedIn Profil
                      </Button>
                    </a>
                    <Link to={createPageUrl("TaskDetail") + `?expert=${profile.user_email}`} className="flex-1">
                      <Button
                        variant="outline"
                        className="w-full border text-white"
                        style={{ borderColor: 'rgba(148, 163, 184, 0.5)' }}
                      >
                        <Mail className="w-4 h-4 mr-2" />
                        Kapcsolat
                      </Button>
                    </Link>
                  </div>

                  {/* Availability Badge */}
                  {profile.available && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-green-400">
                      <span className="w-2 h-2 rounded-full bg-green-400" style={{ boxShadow: '0 0 8px rgba(74, 222, 128, 0.8)' }} />
                      Elérhető új projektekhez
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}