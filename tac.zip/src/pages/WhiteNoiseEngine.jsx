import React, { useState } from 'react';
import { Waves, Zap, CheckCircle2, AlertTriangle, Activity, FileText } from 'lucide-react';

export default function WhiteNoiseEngine() {
  const [inputText, setInputText] = useState('');
  const [mode, setMode] = useState('medium');
  const [isCleaning, setIsCleaning] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const modes = [
    { id: 'soft', name: 'Soft', color: '#4eff8b', desc: 'Minimális tisztítás, alapvető whitespace fix' },
    { id: 'medium', name: 'Medium', color: '#24e4ff', desc: 'Kiegyensúlyozott, sornormalizálás + noise szűrés' },
    { id: 'hard', name: 'Hard', color: '#ff6ec7', desc: 'Agresszív tisztítás, hosszú sorok rövidítése' },
    { id: 'semantic', name: 'Semantic', color: '#b788ff', desc: 'Szöveglogikai simítás, dupla üres sorok eltávolítása' },
    { id: 'strict', name: 'Strict', color: '#ff4b81', desc: 'Extrém trimmelés, max 1000 karakter' }
  ];

  const handleClean = async () => {
    setIsCleaning(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('http://localhost:3000/whitenoise/clean', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          input: inputText,
          mode
        })
      });

      if (!response.ok) throw new Error('Cleaning failed');
      
      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsCleaning(false);
    }
  };

  const loadExample = (type) => {
    if (type === 'repetition') {
      setInputText(`Heeeeey!!!!! This is sooooooo cooool!!!!!! 
Loooooove it!!!! Really really really really really amazing!!`);
    } else if (type === 'noise') {
      setInputText(`Hello world asdfghjkl this is a test!!!!!!
Some text here qwertyuiop and more text zxcvbnm
Normal sentence with random keyboard mash: asdfasdfasdf`);
    } else if (type === 'whitespace') {
      setInputText(`Too     many      spaces    here
  
  
  
Multiple empty lines above


And weird   spacing    everywhere`);
    }
  };

  const getModeColor = (modeId) => {
    return modes.find(m => m.id === modeId)?.color || '#9094b2';
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .noise-panel {
          background: #0a0a12;
          border: 1px solid #1a1a26;
        }

        .mode-card {
          transition: all 0.2s ease-out;
          cursor: pointer;
        }

        .mode-card.active {
          box-shadow: 0 0 0 2px currentColor;
        }

        .result-panel {
          background: #05050d;
          border: 1px solid #1a1a26;
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{
                background: 'radial-gradient(circle at 20% 0, #ffffff, #24e4ff 40%, #0b6b6f)',
                boxShadow: '0 0 30px rgba(36, 228, 255, 0.6)'
              }}
            >
              <Waves className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white tracking-wide">
                WHITE NOISE ENGINE
              </div>
              <div className="text-xs text-gray-400 tracking-wider">
                Text & Logic Noise Filter • 5 Intensity Modes
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{
            background: 'rgba(36, 228, 255, 0.12)',
            border: '1px solid rgba(36, 228, 255, 0.6)'
          }}>
            <div className="w-2 h-2 rounded-full pulse-dot" style={{ background: '#24e4ff' }} />
            <span className="text-xs font-semibold" style={{ color: '#24e4ff' }}>
              READY
            </span>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 rounded-xl border border-red-500/50 bg-red-900/10 flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Error</div>
              <div className="text-xs text-gray-300 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Mode Selection */}
          <div className="lg:col-span-3 noise-panel rounded-2xl p-4">
            <div className="mb-4">
              <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold mb-1">
                Cleaning Mode
              </div>
              <div className="text-[10px] text-gray-500">
                Select noise filter intensity
              </div>
            </div>

            <div className="space-y-2">
              {modes.map(m => {
                const isActive = mode === m.id;
                return (
                  <div
                    key={m.id}
                    onClick={() => setMode(m.id)}
                    className={`mode-card rounded-xl p-3 border ${isActive ? 'active' : ''}`}
                    style={{
                      background: isActive ? 'rgba(255, 255, 255, 0.03)' : '#060612',
                      borderColor: isActive ? m.color : 'transparent',
                      color: isActive ? m.color : '#9094b2'
                    }}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <div 
                        className="w-2 h-2 rounded-full"
                        style={{ background: m.color }}
                      />
                      <span className="text-xs font-semibold text-white">{m.name}</span>
                    </div>
                    <div className="text-[10px] text-gray-400">
                      {m.desc}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Mode Details */}
            <div className="mt-4 rounded-xl p-3 border" style={{
              background: '#05050d',
              borderColor: '#1a1a26'
            }}>
              <div className="text-xs text-gray-400 mb-2">Active Filters</div>
              <div className="space-y-1 text-[10px] text-gray-300">
                {mode === 'soft' && (
                  <>
                    <div>• Whitespace normalization</div>
                    <div>• Max 4 char repetitions</div>
                    <div>• Basic noise tokens</div>
                  </>
                )}
                {mode === 'medium' && (
                  <>
                    <div>• Whitespace normalization</div>
                    <div>• Max 3 char repetitions</div>
                    <div>• Noise token filter</div>
                    <div>• Line trimming</div>
                    <div>• Semantic smoothing</div>
                  </>
                )}
                {mode === 'hard' && (
                  <>
                    <div>• Aggressive whitespace fix</div>
                    <div>• Max 2 char repetitions</div>
                    <div>• Full noise removal</div>
                    <div>• Long line cutting (300 chars)</div>
                    <div>• Semantic smoothing</div>
                  </>
                )}
                {mode === 'semantic' && (
                  <>
                    <div>• Semantic text analysis</div>
                    <div>• Duplicate empty lines removal</div>
                    <div>• Word repetition limiting</div>
                    <div>• Context-aware cleaning</div>
                  </>
                )}
                {mode === 'strict' && (
                  <>
                    <div>• Maximum compression</div>
                    <div>• Max 1000 chars total</div>
                    <div>• No empty lines</div>
                    <div>• Extreme trimming</div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Center: Input */}
          <div className="lg:col-span-5 space-y-4">
            <div className="noise-panel rounded-2xl p-4">
              <div className="mb-3">
                <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  Input Text
                </div>
                <div className="text-[10px] text-gray-500">
                  Paste noisy text here for cleaning
                </div>
              </div>

              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="w-full h-[400px] rounded-xl p-4 text-xs font-mono resize-none"
                style={{
                  background: '#05050d',
                  border: '1px solid #1a1a26',
                  color: '#a3a7cf'
                }}
                placeholder="Enter text with noise, repetitions, extra spaces..."
              />

              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => loadExample('repetition')}
                  className="flex-1 px-3 py-2 rounded-xl text-[10px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Repetition
                </button>
                <button
                  onClick={() => loadExample('noise')}
                  className="flex-1 px-3 py-2 rounded-xl text-[10px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Noise Tokens
                </button>
                <button
                  onClick={() => loadExample('whitespace')}
                  className="flex-1 px-3 py-2 rounded-xl text-[10px] font-semibold uppercase tracking-wider transition-all hover:bg-white/5"
                  style={{
                    background: 'rgba(255, 255, 255, 0.02)',
                    color: '#9094b2',
                    border: '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  Whitespace
                </button>
              </div>
            </div>

            <button
              onClick={handleClean}
              disabled={isCleaning || !inputText}
              className="w-full px-4 py-3 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
              style={{
                background: `radial-gradient(circle at 20% 0, #ffffff, ${getModeColor(mode)} 40%, ${getModeColor(mode)}aa 70%)`,
                color: '#020206',
                boxShadow: isCleaning ? 'none' : `0 8px 24px ${getModeColor(mode)}66`
              }}
            >
              {isCleaning ? (
                <>
                  <Activity className="w-4 h-4 animate-spin" />
                  CLEANING...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  CLEAN TEXT
                </>
              )}
            </button>
          </div>

          {/* Right: Output */}
          <div className="lg:col-span-4 space-y-4">
            {!result ? (
              <div className="noise-panel rounded-2xl p-6 h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Waves className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <div className="text-sm font-semibold">No Results Yet</div>
                  <div className="text-xs mt-1">Enter text and click "Clean Text"</div>
                </div>
              </div>
            ) : (
              <>
                {/* Stats */}
                <div className="noise-panel rounded-2xl p-4">
                  <div className="text-xs text-gray-400 uppercase tracking-wider mb-3">
                    Cleaning Stats
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-gray-500">Original Length:</span>
                      <span className="text-white font-mono">{result.originalLength || inputText.length}</span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="text-gray-500">Cleaned Length:</span>
                      <span className="text-white font-mono">{result.cleanedLength || result.cleaned?.length}</span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="text-gray-500">Reduction:</span>
                      <span className="text-cyan-400 font-mono">
                        {result.reduction || Math.round(((inputText.length - (result.cleaned?.length || 0)) / inputText.length) * 100)}%
                      </span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="text-gray-500">Mode Used:</span>
                      <span className="text-white uppercase font-semibold">{result.mode || mode}</span>
                    </div>
                  </div>
                </div>

                {/* Cleaned Output */}
                <div className="noise-panel rounded-2xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="text-xs uppercase tracking-wider text-gray-400 font-semibold">
                      Cleaned Output
                    </div>
                    <div className="px-2 py-1 rounded-full text-[9px] uppercase tracking-wider" style={{
                      background: 'rgba(78, 255, 139, 0.16)',
                      color: '#4eff8b',
                      border: '1px solid rgba(78, 255, 139, 0.4)'
                    }}>
                      CLEANED
                    </div>
                  </div>

                  <div className="result-panel rounded-xl p-4 max-h-[400px] overflow-auto">
                    <pre className="text-xs text-gray-300 font-mono whitespace-pre-wrap">
                      {result.cleaned || result.output}
                    </pre>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}