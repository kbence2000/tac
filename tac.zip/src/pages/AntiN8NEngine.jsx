import React, { useState, useRef, useEffect } from 'react';
import { Shield, Zap, AlertTriangle, CheckCircle2, Loader2, TrendingDown, GitBranch, Eye, BarChart3, Radio, Flame, ArrowRight, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function AntiN8NEngine() {
  const [workflowInput, setWorkflowInput] = useState(JSON.stringify({
    name: "Customer Onboarding Flow",
    nodes: [
      { id: "webhook", type: "webhook", name: "Trigger" },
      { id: "validate", type: "function", name: "Validate Input" },
      { id: "crm", type: "http", name: "Update CRM" },
      { id: "email", type: "email", name: "Send Welcome" },
      { id: "analytics", type: "http", name: "Track Event" }
    ],
    connections: {
      "webhook": [{ node: "validate" }],
      "validate": [{ node: "crm" }, { node: "email" }],
      "crm": [{ node: "analytics" }],
      "email": [{ node: "analytics" }]
    }
  }, null, 2));

  const [runsInput, setRunsInput] = useState(JSON.stringify([
    { status: "success", durationMs: 3200, finishedAt: "2025-01-14T10:00:00Z" },
    { status: "success", durationMs: 2800, finishedAt: "2025-01-14T10:05:00Z" },
    { status: "error", durationMs: 5600, errorMessage: "CRM timeout", finishedAt: "2025-01-14T10:10:00Z" },
    { status: "success", durationMs: 3100, finishedAt: "2025-01-14T10:15:00Z" },
    { status: "error", durationMs: 8200, errorMessage: "Email service down", finishedAt: "2025-01-14T10:20:00Z" }
  ], null, 2));

  const [isEvaluating, setIsEvaluating] = useState(false);
  const [isComparing, setIsComparing] = useState(false);
  const [evaluationResult, setEvaluationResult] = useState(null);
  const [comparisonResult, setComparisonResult] = useState(null);
  const [error, setError] = useState(null);
  const [backendUrl] = useState('http://localhost:9966');
  const queryClient = useQueryClient();

  // Fetch analysis history
  const { data: analysisHistory = [] } = useQuery({
    queryKey: ['antin8n-analysis'],
    queryFn: async () => {
      const list = await base44.entities.AntiN8NAnalysis.list('-created_date', 20);
      return list;
    },
    refetchInterval: 10000
  });

  // Save analysis mutation
  const saveAnalysisMutation = useMutation({
    mutationFn: async (analysisData) => {
      return await base44.entities.AntiN8NAnalysis.create(analysisData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['antin8n-analysis'] });
    }
  });

  const runEvaluation = async () => {
    setIsEvaluating(true);
    setError(null);
    setEvaluationResult(null);

    try {
      const workflow = JSON.parse(workflowInput);
      const runs = JSON.parse(runsInput);

      const response = await fetch(`${backendUrl}/api/antin8n/evaluate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workflow,
          runs,
          context: { targetDurationMs: 4000 }
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      setEvaluationResult(data);

      // Save to database
      await saveAnalysisMutation.mutateAsync({
        workflowId: workflow.id || `wf_${Date.now()}`,
        workflowName: workflow.name || 'Unnamed Workflow',
        stats: data.stats,
        antiPlan: data.antiPlan,
        narrative: data.narrative,
        analysisType: 'evaluate',
        status: 'completed',
        recommendAnti: data.antiPlan?.meta?.highLatency || data.antiPlan?.meta?.unstable || false
      });

    } catch (err) {
      console.error('Evaluation error:', err);
      setError(err.message);
    } finally {
      setIsEvaluating(false);
    }
  };

  const runComparison = async () => {
    if (!evaluationResult) {
      setError('Run evaluation first to get antiPlan');
      return;
    }

    setIsComparing(true);
    setError(null);
    setComparisonResult(null);

    try {
      const n8nResult = {
        status: 'success',
        durationMs: 4200,
        errors: [],
        qualityScore: 0.75
      };

      const response = await fetch(`${backendUrl}/api/antin8n/compare`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          n8nResult,
          antiPlan: evaluationResult.antiPlan
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      setComparisonResult(data);

      // Update analysis with comparison
      const workflow = JSON.parse(workflowInput);
      await saveAnalysisMutation.mutateAsync({
        workflowId: workflow.id || `wf_${Date.now()}`,
        workflowName: workflow.name || 'Unnamed Workflow',
        stats: evaluationResult.stats,
        antiPlan: evaluationResult.antiPlan,
        narrative: data.narrative,
        audit: data.audit,
        n8nResult,
        analysisType: 'compare',
        status: 'completed',
        recommendAnti: data.audit?.antiPotential > 0.6
      });

    } catch (err) {
      console.error('Comparison error:', err);
      setError(err.message);
    } finally {
      setIsComparing(false);
    }
  };

  const getRiskColor = (level) => {
    switch (level) {
      case 'low': return '#4cffa8';
      case 'medium': return '#ffdb7c';
      case 'high': return '#ff4b81';
      default: return '#8c8faf';
    }
  };

  return (
    <div className="min-h-screen p-4" style={{
      background: 'radial-gradient(circle at top, #0a0a14 0, #030306 55%)'
    }}>
      <style>{`
        .anti-wrapper {
          background: linear-gradient(135deg, rgba(139, 0, 139, 0.15), rgba(255, 75, 129, 0.1), rgba(0, 0, 0, 0.9));
          padding: 2px;
          box-shadow: 0 0 60px rgba(255, 75, 129, 0.3);
        }

        .stat-badge {
          transition: all 0.3s;
        }

        .stat-badge:hover {
          transform: scale(1.05);
        }
      `}</style>

      <div className="max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <Shield className="w-10 h-10 text-purple-400" />
            <h1 className="text-3xl md:text-4xl font-black tracking-wider uppercase text-white">
              ANTI-N8N SHADOW ENGINE
            </h1>
            <Radio className="w-10 h-10 text-pink-400" />
          </div>
          <p className="text-sm text-gray-400 tracking-wide">
            Alternative Automation Strategies • n8n Workflow Auditor • Shadow Path Generator
          </p>
        </div>

        {/* Info Banner */}
        <div className="mb-6 p-4 rounded-2xl border" style={{
          background: 'rgba(139, 0, 139, 0.1)',
          borderColor: 'rgba(139, 0, 139, 0.4)'
        }}>
          <div className="flex items-start gap-3">
            <Eye className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-gray-300">
              <strong className="text-purple-300">What is Anti-n8n?</strong> Analyzes your n8n workflows and generates alternative "shadow" strategies. When n8n is slow or unstable, Anti-n8n suggests inverted execution paths, parallel optimizations, and risk-aware fallbacks.
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 rounded-xl border border-red-500/50 bg-red-900/20 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <div className="text-sm font-bold text-red-400">Backend Connection Error</div>
              <div className="text-xs text-gray-300 mt-1">{error}</div>
              <div className="text-xs text-gray-400 mt-2">
                Make sure backend is running: <code className="bg-black/40 px-2 py-0.5 rounded">node anti-n8n-engine.js</code> on port 9966
              </div>
            </div>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
          {/* Left: Input */}
          <div className="lg:col-span-5 space-y-4">
            {/* Workflow Input */}
            <div className="rounded-2xl border p-4" style={{
              borderColor: 'rgba(168, 85, 247, 0.3)',
              background: 'rgba(7, 7, 18, 0.95)'
            }}>
              <label className="block text-xs tracking-widest uppercase text-purple-400 mb-3">
                N8N WORKFLOW (JSON)
              </label>
              <textarea
                value={workflowInput}
                onChange={(e) => setWorkflowInput(e.target.value)}
                disabled={isEvaluating}
                rows={10}
                className="w-full rounded-xl border px-3 py-2 text-xs font-mono resize-none"
                style={{
                  borderColor: 'rgba(168, 85, 247, 0.3)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
              />
            </div>

            {/* Runs Input */}
            <div className="rounded-2xl border p-4" style={{
              borderColor: 'rgba(255, 110, 199, 0.3)',
              background: 'rgba(7, 7, 18, 0.95)'
            }}>
              <label className="block text-xs tracking-widest uppercase text-pink-400 mb-3">
                RUN HISTORY (JSON)
              </label>
              <textarea
                value={runsInput}
                onChange={(e) => setRunsInput(e.target.value)}
                disabled={isEvaluating}
                rows={8}
                className="w-full rounded-xl border px-3 py-2 text-xs font-mono resize-none"
                style={{
                  borderColor: 'rgba(255, 110, 199, 0.3)',
                  background: 'rgba(2, 0, 12, 0.9)',
                  color: '#f6fff6'
                }}
              />
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={runEvaluation}
                disabled={isEvaluating}
                className="flex-1 px-4 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'linear-gradient(135deg, #8b008b, #ff4b81)',
                  color: '#fff',
                  boxShadow: isEvaluating ? 'none' : '0 0 30px rgba(139, 0, 139, 0.6)'
                }}
              >
                {isEvaluating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    EVALUATING...
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4" />
                    EVALUATE
                  </>
                )}
              </button>

              <button
                onClick={runComparison}
                disabled={isComparing || !evaluationResult}
                className="flex-1 px-4 py-3 rounded-xl text-sm font-bold tracking-wider uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background: 'rgba(255, 110, 199, 0.2)',
                  border: '1px solid rgba(255, 110, 199, 0.5)',
                  color: '#ff6ec7'
                }}
              >
                {isComparing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    COMPARING...
                  </>
                ) : (
                  <>
                    <BarChart3 className="w-4 h-4" />
                    COMPARE
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right: Results */}
          <div className="lg:col-span-7">
            {!evaluationResult && !isEvaluating && (
              <div className="rounded-2xl border p-12 text-center" style={{
                background: 'rgba(7, 7, 18, 0.95)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
                minHeight: '600px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <div>
                  <Radio className="w-20 h-20 mx-auto mb-4 text-purple-400/30" />
                  <p className="text-sm text-gray-400">
                    No evaluation yet.
                    <br />
                    Enter n8n workflow and run history, then click EVALUATE.
                  </p>
                </div>
              </div>
            )}

            {isEvaluating && (
              <div className="rounded-2xl border p-12 text-center" style={{
                background: 'rgba(7, 7, 18, 0.95)',
                borderColor: 'rgba(139, 0, 139, 0.4)',
                minHeight: '600px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <div>
                  <Loader2 className="w-20 h-20 mx-auto mb-4 text-purple-400 animate-spin" />
                  <p className="text-sm text-gray-400">
                    Analyzing n8n workflow...
                    <br />
                    <span className="text-xs text-gray-600">Generating anti-n8n shadow strategy</span>
                  </p>
                </div>
              </div>
            )}

            {evaluationResult && (
              <div className="space-y-4">
                {/* Stats Panel */}
                <div className="rounded-2xl border p-5" style={{
                  borderColor: 'rgba(79, 124, 255, 0.4)',
                  background: 'rgba(7, 7, 18, 0.95)'
                }}>
                  <div className="text-xs font-bold text-blue-400 mb-4 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    N8N WORKFLOW STATISTICS
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="stat-badge p-3 rounded-xl text-center" style={{
                      background: 'rgba(36, 228, 255, 0.1)',
                      border: '1px solid rgba(36, 228, 255, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Total Runs</div>
                      <div className="text-2xl font-bold text-cyan-400">{evaluationResult.stats.total}</div>
                    </div>
                    <div className="stat-badge p-3 rounded-xl text-center" style={{
                      background: 'rgba(76, 255, 168, 0.1)',
                      border: '1px solid rgba(76, 255, 168, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Success Rate</div>
                      <div className="text-2xl font-bold text-green-400">
                        {(evaluationResult.stats.successRate * 100).toFixed(0)}%
                      </div>
                    </div>
                    <div className="stat-badge p-3 rounded-xl text-center" style={{
                      background: 'rgba(255, 219, 124, 0.1)',
                      border: '1px solid rgba(255, 219, 124, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Avg Duration</div>
                      <div className="text-2xl font-bold text-yellow-400">
                        {(evaluationResult.stats.avgDurationMs / 1000).toFixed(1)}s
                      </div>
                    </div>
                    <div className="stat-badge p-3 rounded-xl text-center" style={{
                      background: 'rgba(255, 75, 129, 0.1)',
                      border: '1px solid rgba(255, 75, 129, 0.3)'
                    }}>
                      <div className="text-xs text-gray-400 mb-1">Error Rate</div>
                      <div className="text-2xl font-bold text-red-400">
                        {(evaluationResult.stats.errorRate * 100).toFixed(0)}%
                      </div>
                    </div>
                  </div>

                  {evaluationResult.stats.recentErrors?.length > 0 && (
                    <div className="mt-4 p-3 rounded-xl" style={{ background: 'rgba(255, 75, 129, 0.1)' }}>
                      <div className="text-xs font-bold text-red-400 mb-2">Recent Errors:</div>
                      <div className="space-y-1">
                        {evaluationResult.stats.recentErrors.map((err, i) => (
                          <div key={i} className="text-xs text-gray-300">
                            • {err.message}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Anti-Plan Panel */}
                <div className="anti-wrapper rounded-2xl p-5">
                  <div className="rounded-xl p-5" style={{ background: '#0a0a14' }}>
                    <div className="text-xs font-bold text-purple-400 mb-4 flex items-center gap-2">
                      <Flame className="w-4 h-4" />
                      ANTI-N8N SHADOW STRATEGY
                    </div>

                    {/* Meta Indicators */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {evaluationResult.antiPlan.meta.highLatency && (
                        <div className="px-3 py-1 rounded-full text-[10px] font-bold uppercase" style={{
                          background: 'rgba(255, 153, 102, 0.2)',
                          border: '1px solid rgba(255, 153, 102, 0.5)',
                          color: '#ff9966'
                        }}>
                          HIGH LATENCY
                        </div>
                      )}
                      {evaluationResult.antiPlan.meta.unstable && (
                        <div className="px-3 py-1 rounded-full text-[10px] font-bold uppercase" style={{
                          background: 'rgba(255, 75, 129, 0.2)',
                          border: '1px solid rgba(255, 75, 129, 0.5)',
                          color: '#ff4b81'
                        }}>
                          UNSTABLE
                        </div>
                      )}
                      {evaluationResult.antiPlan.meta.underused && (
                        <div className="px-3 py-1 rounded-full text-[10px] font-bold uppercase" style={{
                          background: 'rgba(140, 143, 175, 0.2)',
                          border: '1px solid rgba(140, 143, 175, 0.5)',
                          color: '#8c8faf'
                        }}>
                          UNDERUSED
                        </div>
                      )}
                    </div>

                    {/* Strategies */}
                    <div className="mb-4">
                      <div className="text-xs text-gray-400 mb-2">Recommended Strategies:</div>
                      <div className="space-y-2">
                        {evaluationResult.antiPlan.strategies.map((strategy, i) => (
                          <div key={i} className="flex items-center gap-2 p-2 rounded-lg" style={{
                            background: 'rgba(139, 0, 139, 0.1)',
                            border: '1px solid rgba(139, 0, 139, 0.3)'
                          }}>
                            <ArrowRight className="w-3 h-3 text-purple-400 flex-shrink-0" />
                            <span className="text-xs text-gray-300">{strategy}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Anti-Nodes (Inverted Order) */}
                    {evaluationResult.antiPlan.antiNodes?.length > 0 && (
                      <div>
                        <div className="text-xs text-gray-400 mb-2">Inverted Node Execution Order:</div>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {evaluationResult.antiPlan.antiNodes.slice(0, 6).map((node, i) => (
                            <div key={i} className="p-2 rounded-lg border text-center" style={{
                              background: 'rgba(0, 0, 0, 0.4)',
                              borderColor: 'rgba(255, 110, 199, 0.3)'
                            }}>
                              <div className="text-[10px] text-pink-400 font-bold mb-1">
                                Priority {node.suggestedPriority}
                              </div>
                              <div className="text-xs text-gray-300 truncate">
                                {node.id}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Alt Branches */}
                    {evaluationResult.antiPlan.altBranches?.length > 0 && (
                      <div className="mt-4">
                        <div className="text-xs text-gray-400 mb-2">Alternative Branching:</div>
                        <div className="space-y-2">
                          {evaluationResult.antiPlan.altBranches.map((branch, i) => (
                            <div key={i} className="p-2 rounded-lg text-xs" style={{
                              background: 'rgba(0, 0, 0, 0.3)',
                              border: '1px solid rgba(255, 110, 199, 0.2)'
                            }}>
                              <div className="text-pink-400 font-bold mb-1">From: {branch.from}</div>
                              <div className="text-gray-400">{branch.suggestion}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Narrative Panel */}
                {evaluationResult.narrative && !evaluationResult.narrative.error && (
                  <div className="rounded-2xl border p-5" style={{
                    borderColor: 'rgba(168, 85, 247, 0.4)',
                    background: 'rgba(7, 7, 18, 0.95)',
                    boxShadow: '0 0 30px rgba(168, 85, 247, 0.2)'
                  }}>
                    <div className="text-xs font-bold text-purple-400 mb-4 flex items-center gap-2">
                      <Brain className="w-4 h-4" />
                      AI NARRATIVE ANALYSIS
                    </div>

                    <div className="space-y-3">
                      <div className="p-3 rounded-xl" style={{ background: 'rgba(168, 85, 247, 0.1)' }}>
                        <div className="text-xs text-gray-400 mb-1">Summary:</div>
                        <div className="text-sm text-white">{evaluationResult.narrative.summary}</div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-xs text-gray-400">Risk Level:</div>
                        <div 
                          className="px-3 py-1 rounded-full text-xs font-bold uppercase"
                          style={{
                            background: `${getRiskColor(evaluationResult.narrative.riskLevel)}20`,
                            border: `1px solid ${getRiskColor(evaluationResult.narrative.riskLevel)}60`,
                            color: getRiskColor(evaluationResult.narrative.riskLevel)
                          }}
                        >
                          {evaluationResult.narrative.riskLevel}
                        </div>
                      </div>

                      {evaluationResult.narrative.whenToUseAnti?.length > 0 && (
                        <div className="p-3 rounded-xl" style={{ background: 'rgba(0, 0, 0, 0.4)' }}>
                          <div className="text-xs font-bold text-purple-300 mb-2">When to Use Anti-n8n:</div>
                          <ul className="space-y-1">
                            {evaluationResult.narrative.whenToUseAnti.map((item, i) => (
                              <li key={i} className="text-xs text-gray-300 flex items-start gap-2">
                                <CheckCircle2 className="w-3 h-3 text-purple-400 mt-0.5 flex-shrink-0" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {evaluationResult.narrative.adviceToFounder && (
                        <div className="p-3 rounded-xl" style={{
                          background: 'rgba(255, 215, 0, 0.1)',
                          border: '1px solid rgba(255, 215, 0, 0.3)'
                        }}>
                          <div className="text-xs font-bold text-yellow-400 mb-1">Founder Advice:</div>
                          <div className="text-xs text-gray-300">{evaluationResult.narrative.adviceToFounder}</div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Comparison Results */}
                {comparisonResult && (
                  <div className="rounded-2xl border p-5" style={{
                    borderColor: 'rgba(255, 110, 199, 0.4)',
                    background: 'rgba(7, 7, 18, 0.95)',
                    boxShadow: '0 0 30px rgba(255, 110, 199, 0.2)'
                  }}>
                    <div className="text-xs font-bold text-pink-400 mb-4 flex items-center gap-2">
                      <GitBranch className="w-4 h-4" />
                      N8N vs ANTI-N8N AUDIT
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
                      <div className="p-3 rounded-xl text-center" style={{
                        background: 'rgba(255, 75, 129, 0.1)',
                        border: '1px solid rgba(255, 75, 129, 0.3)'
                      }}>
                        <div className="text-xs text-gray-400 mb-1">Risk Score</div>
                        <div className="text-2xl font-bold text-red-400">
                          {(comparisonResult.audit.riskScore * 100).toFixed(0)}%
                        </div>
                      </div>
                      <div className="p-3 rounded-xl text-center" style={{
                        background: 'rgba(139, 0, 139, 0.1)',
                        border: '1px solid rgba(139, 0, 139, 0.3)'
                      }}>
                        <div className="text-xs text-gray-400 mb-1">Anti Potential</div>
                        <div className="text-2xl font-bold text-purple-400">
                          {(comparisonResult.audit.antiPotential * 100).toFixed(0)}%
                        </div>
                      </div>
                      <div className="p-3 rounded-xl text-center" style={{
                        background: 'rgba(79, 124, 255, 0.1)',
                        border: '1px solid rgba(79, 124, 255, 0.3)'
                      }}>
                        <div className="text-xs text-gray-400 mb-1">Duration</div>
                        <div className="text-2xl font-bold text-blue-400">
                          {(comparisonResult.audit.duration / 1000).toFixed(1)}s
                        </div>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl" style={{
                      background: comparisonResult.audit.suggestion === 'consider-testing-anti-n8n-path' 
                        ? 'rgba(255, 110, 199, 0.15)' 
                        : 'rgba(76, 255, 168, 0.1)',
                      border: `1px solid ${comparisonResult.audit.suggestion === 'consider-testing-anti-n8n-path' ? 'rgba(255, 110, 199, 0.4)' : 'rgba(76, 255, 168, 0.3)'}`
                    }}>
                      <div className="text-xs font-bold mb-2" style={{
                        color: comparisonResult.audit.suggestion === 'consider-testing-anti-n8n-path' ? '#ff6ec7' : '#4cffa8'
                      }}>
                        RECOMMENDATION:
                      </div>
                      <div className="text-sm text-white">
                        {comparisonResult.audit.suggestion.replace(/-/g, ' ').toUpperCase()}
                      </div>
                    </div>

                    {comparisonResult.narrative && !comparisonResult.narrative.error && (
                      <div className="mt-4 p-3 rounded-xl" style={{
                        background: 'rgba(0, 0, 0, 0.4)'
                      }}>
                        <div className="text-xs text-gray-400 mb-1">AI Advice:</div>
                        <div className="text-xs text-gray-300">
                          {comparisonResult.narrative.adviceToFounder || comparisonResult.narrative.summary}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Analysis History */}
        <div className="rounded-2xl border p-5" style={{
          borderColor: 'rgba(255, 255, 255, 0.1)',
          background: 'rgba(7, 7, 18, 0.95)'
        }}>
          <div className="text-xs font-bold text-gray-400 mb-4 flex items-center gap-2">
            <RefreshCw className="w-4 h-4" />
            ANALYSIS HISTORY ({analysisHistory.length})
          </div>

          {analysisHistory.length === 0 && (
            <div className="text-center py-8 text-sm text-gray-600">
              No analysis history yet. Run your first evaluation.
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {analysisHistory.map((analysis) => (
              <div
                key={analysis.id}
                className="p-3 rounded-xl border transition-all hover:border-purple-400/50"
                style={{
                  background: 'rgba(0, 0, 0, 0.4)',
                  borderColor: analysis.recommendAnti ? 'rgba(255, 110, 199, 0.4)' : 'rgba(255, 255, 255, 0.1)'
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-white truncate">
                    {analysis.workflowName}
                  </span>
                  {analysis.recommendAnti && (
                    <Shield className="w-4 h-4 text-pink-400 flex-shrink-0" />
                  )}
                </div>
                <div className="text-[10px] text-gray-500 space-y-1">
                  <div>Type: {analysis.analysisType}</div>
                  <div>Status: {analysis.status}</div>
                  {analysis.stats && (
                    <div>Success: {(analysis.stats.successRate * 100).toFixed(0)}%</div>
                  )}
                  {analysis.audit && (
                    <div>Anti Potential: {(analysis.audit.antiPotential * 100).toFixed(0)}%</div>
                  )}
                  <div className="text-gray-600">
                    {new Date(analysis.created_date).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}