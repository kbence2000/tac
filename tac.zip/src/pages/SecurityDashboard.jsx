import React from "react";
import SecurityDashboard from "../components/SecurityDashboard";

export default function SecurityDashboardPage() {
  return <SecurityDashboard />;
}