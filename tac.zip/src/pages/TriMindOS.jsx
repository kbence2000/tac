import React, { useState } from "react";
import { Code2, X, TrendingUp, Brain, Eye, Zap, Lock, Clock, Layers, GitBranch } from "lucide-react";
import NeuroEvolutionPanel from "../components/NeuroEvolutionPanel";
import ChaosArchitectPanel from "../components/ChaosArchitectPanel";
import DreamRendererPanel from "../components/DreamRendererPanel";
import TriMindDashboardPanel from "../components/TriMindDashboardPanel";
import GlitchEngineerPanel from "../components/GlitchEngineerPanel";
import ShadowArchivistPanel from "../components/ShadowArchivistPanel";
import TemporalEnginePanel from "../components/TemporalEnginePanel";
import ParallelArchitectPanel from "../components/ParallelArchitectPanel";
import FractalEngineerPanel from "../components/FractalEngineerPanel";
import { TriMindProvider } from "../components/TriMindContext";

export default function TriMindOS() {
  const [coreOpen, setCoreOpen] = useState(false);
  const [neuroOpen, setNeuroOpen] = useState(false);
  const [chaosOpen, setChaosOpen] = useState(false);
  const [dreamOpen, setDreamOpen] = useState(false);
  const [triOpen, setTriOpen] = useState(false);
  const [glitchOpen, setGlitchOpen] = useState(false);
  const [shadowOpen, setShadowOpen] = useState(false);
  const [temporalOpen, setTemporalOpen] = useState(false);
  const [parallelOpen, setParallelOpen] = useState(false);
  const [fractalOpen, setFractalOpen] = useState(false);

  const modules = [
    { id: 'neuro', name: 'Neuro\nEvolution', icon: TrendingUp, angleDeg: -80, color: '#9fa8ff' },
    { id: 'chaos', name: 'Chaos\nArchitect', icon: Brain, angleDeg: -20, color: '#ff66e7' },
    { id: 'dream', name: 'Dream\nRenderer', icon: Eye, angleDeg: 40, color: '#3bd3ff' },
    { id: 'glitch', name: 'Glitch\nEngineer', icon: Zap, angleDeg: 100, color: '#ff4b5c' },
    { id: 'shadow', name: 'Shadow\nArchivist', icon: Lock, angleDeg: 160, color: '#9b9bbb' },
    { id: 'temporal', name: 'Temporal\nEngine', icon: Clock, angleDeg: 220, color: '#b788ff' },
    { id: 'parallel', name: 'Parallel\nArchitect', icon: Layers, angleDeg: 280, color: '#24e4ff' },
    { id: 'fractal', name: 'Fractal\nEngineer', icon: GitBranch, angleDeg: 340, color: '#4eff8b' },
  ];

  const getModulePosition = (angleDeg) => {
    const cx = typeof window !== 'undefined' ? window.innerWidth / 2 : 500;
    const cy = typeof window !== 'undefined' ? window.innerHeight / 2 : 400;
    const radius = Math.min(cx, cy) / 3.0;
    const rad = angleDeg * Math.PI / 180;
    return {
      x: cx + Math.cos(rad) * radius,
      y: cy + Math.sin(rad) * radius
    };
  };

  const handleModuleClick = (moduleId) => {
    switch(moduleId) {
      case 'neuro':
        setNeuroOpen(true);
        break;
      case 'chaos':
        setChaosOpen(true);
        break;
      case 'dream':
        setDreamOpen(true);
        break;
      case 'glitch':
        setGlitchOpen(true);
        break;
      case 'shadow':
        setShadowOpen(true);
        break;
      case 'temporal':
        setTemporalOpen(true);
        break;
      case 'parallel':
        setParallelOpen(true);
        break;
      case 'fractal':
        setFractalOpen(true);
        break;
    }
  };

  return (
    <TriMindProvider>
      <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900">
        <style>{`
          @keyframes corePulse {
            0% {
              transform: translate(-50%, -50%) scale(1);
              box-shadow: 0 0 40px rgba(123, 63, 246, 0.7), 0 0 140px rgba(22, 0, 60, 0.95);
            }
            50% {
              transform: translate(-50%, -50%) scale(1.08);
              box-shadow: 0 0 115px rgba(123, 63, 246, 1), 0 0 200px rgba(22, 0, 60, 1);
            }
            100% {
              transform: translate(-50%, -50%) scale(1);
              box-shadow: 0 0 40px rgba(123, 63, 246, 0.7), 0 0 140px rgba(22, 0, 60, 0.95);
            }
          }

          .tri-core {
            position: fixed;
            top: 50%;
            left: 50%;
            width: 140px;
            height: 140px;
            transform: translate(-50%, -50%);
            background: 
              radial-gradient(circle at 50% 30%, #ffffff 0%, transparent 40%),
              radial-gradient(circle at 40% 75%, #b98cff 0%, transparent 55%),
              radial-gradient(circle at 50% 50%, #7b3ff6 0%, #471869 45%, #140717 80%, #05030a 100%);
            border-radius: 50%;
            box-shadow: 
              0 0 40px rgba(123, 63, 246, 0.7),
              0 0 140px rgba(22, 0, 60, 0.95),
              inset 0 0 40px rgba(223, 205, 255, 0.4);
            animation: corePulse 3.6s infinite ease-in-out;
            z-index: 10;
            cursor: pointer;
            transition: all 0.45s cubic-bezier(0.4, 0, 0.2, 1);
          }

          .tri-core.expanded {
            animation: none;
            box-shadow: 0 0 80px rgba(123, 63, 246, 0.9), 0 0 140px rgba(22, 0, 60, 0.6);
          }

          @keyframes node-appear {
            from {
              opacity: 0;
              transform: translate(-50%, -50%) scale(0.8);
            }
            to {
              opacity: 1;
              transform: translate(-50%, -50%) scale(1);
            }
          }

          .tri-module {
            position: fixed;
            width: 88px;
            height: 88px;
            transform: translate(-50%, -50%);
            background: rgba(6, 6, 16, 0.96);
            backdrop-filter: blur(12px) saturate(180%);
            border-radius: 18px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            cursor: pointer;
            z-index: 20;
            animation: node-appear 0.45s cubic-bezier(0.4, 0, 0.2, 1) forwards;
            transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 0 18px rgba(123, 63, 246, 0.5);
            opacity: 0;
          }

          .tri-module.visible {
            opacity: 1;
          }

          .tri-module:hover {
            transform: translate(-50%, -50%) scale(1.06);
            box-shadow: 0 0 26px rgba(123, 63, 246, 0.85), 0 0 50px rgba(59, 211, 255, 0.45);
          }

          .tri-menu {
            position: fixed;
            left: 50%;
            bottom: 76px;
            transform: translateX(-50%) translateY(12px);
            min-width: 280px;
            max-width: 480px;
            padding: 14px;
            border-radius: 18px;
            border: 1px solid rgba(255, 255, 255, 0.16);
            background: rgba(7, 7, 18, 0.94);
            backdrop-filter: blur(20px) saturate(180%);
            box-shadow: 
              0 0 26px rgba(123, 63, 246, 0.7),
              0 0 60px rgba(0, 0, 0, 0.9);
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.35s ease-out, transform 0.35s ease-out;
            z-index: 15;
          }

          .tri-menu.visible {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
            pointer-events: auto;
          }

          .tri-menu-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
          }

          @media (max-width: 640px) {
            .tri-menu-grid {
              grid-template-columns: 1fr;
            }
          }
        `}</style>

        {/* HUD Top */}
        <div className="fixed top-4 left-4 right-4 flex justify-between items-center text-sm z-[5] pointer-events-none" style={{ mixBlendMode: 'screen' }}>
          <div className="flex items-center gap-2 text-gray-200 tracking-widest uppercase">
            <div 
              className="w-4 h-4 rounded-full"
              style={{
                background: 'conic-gradient(from 0deg, #5a1d8e, #3bd3ff, #47ffb0, #5a1d8e)',
                boxShadow: '0 0 10px rgba(147, 102, 235, 0.9)'
              }}
            />
            <span className="hidden sm:inline">MDC · MULTI-MIND COUNCIL</span>
            <span className="sm:hidden">MULTI-MIND</span>
          </div>
          <div className="flex gap-2 pointer-events-auto">
            <div className="px-3 py-1 rounded-full border border-white/20 bg-black/90 text-gray-400 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400" style={{ boxShadow: '0 0 8px rgba(71, 255, 176, 0.9)' }} />
              <span className="hidden sm:inline">COUNCIL: ONLINE</span>
              <span className="sm:hidden">ONLINE</span>
            </div>
            <div className="px-3 py-1 rounded-full border border-white/20 bg-black/90 text-gray-400">
              BRAINS: <span>8</span>
            </div>
          </div>
        </div>

        {/* Central Core Orb */}
        <button
          onClick={() => setCoreOpen(!coreOpen)}
          className={`tri-core ${coreOpen ? 'expanded' : ''}`}
        >
          <div className="absolute inset-0 flex items-center justify-center" style={{ zIndex: 2 }}>
            {!coreOpen ? (
              <Code2 className="w-12 h-12 text-white" style={{ filter: 'drop-shadow(0 0 10px rgba(255, 255, 255, 0.8))' }} />
            ) : (
              <X className="w-10 h-10 text-white" style={{ filter: 'drop-shadow(0 0 8px rgba(255, 255, 255, 0.8))' }} />
            )}
          </div>
        </button>

        {/* Core Label */}
        {!coreOpen && (
          <div className="fixed top-[calc(50%+95px)] left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-full border border-white/20 bg-black/90 text-xs tracking-widest uppercase text-gray-400 z-[4] pointer-events-none">
            NEURAL CORE
          </div>
        )}

        {/* Radial Module Chips */}
        {coreOpen && modules.map((module, index) => {
          const Icon = module.icon;
          const pos = getModulePosition(module.angleDeg);

          return (
            <button
              key={module.id}
              onClick={() => handleModuleClick(module.id)}
              className="tri-module visible"
              style={{
                left: `${pos.x}px`,
                top: `${pos.y}px`,
                animationDelay: `${index * 0.08}s`,
              }}
            >
              <div className="relative z-10 h-full flex flex-col items-center justify-center p-2">
                <Icon className="w-7 h-7 mb-1" style={{ color: module.color }} />
                <div className="text-[10px] font-bold text-white text-center leading-tight whitespace-pre-line">
                  {module.name}
                </div>
              </div>
            </button>
          );
        })}

        {/* Core Actions Menu */}
        <div className={`tri-menu ${coreOpen ? 'visible' : ''}`}>
          <div className="text-xs tracking-widest uppercase text-gray-400 mb-3 font-semibold">
            COUNCIL ACCESS
          </div>
          <div className="tri-menu-grid">
            <button
              onClick={() => { setTriOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Multi-Mind Council</div>
                <div className="text-xs text-gray-400 mt-0.5">Council overview & state</div>
              </div>
            </button>
            <button
              onClick={() => { setNeuroOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Neuro Evolution</div>
                <div className="text-xs text-gray-400 mt-0.5">Behavior & optimization brain</div>
              </div>
            </button>
            <button
              onClick={() => { setChaosOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Chaos Architect</div>
                <div className="text-xs text-gray-400 mt-0.5">Radical generative brain</div>
              </div>
            </button>
            <button
              onClick={() => { setDreamOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Dream Renderer</div>
                <div className="text-xs text-gray-400 mt-0.5">Visual blueprint brain</div>
              </div>
            </button>
            <button
              onClick={() => { setGlitchOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Glitch Engineer</div>
                <div className="text-xs text-gray-400 mt-0.5">Controlled UI corruption</div>
              </div>
            </button>
            <button
              onClick={() => { setShadowOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Shadow Archivist</div>
                <div className="text-xs text-gray-400 mt-0.5">Hidden patterns & secrets</div>
              </div>
            </button>
            <button
              onClick={() => { setTemporalOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Temporal Engine</div>
                <div className="text-xs text-gray-400 mt-0.5">Time-based behavior logic</div>
              </div>
            </button>
            <button
              onClick={() => { setParallelOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Parallel Architect</div>
                <div className="text-xs text-gray-400 mt-0.5">Multiverse UI variants</div>
              </div>
            </button>
            <button
              onClick={() => { setFractalOpen(true); setCoreOpen(false); }}
              className="px-3 py-2.5 rounded-xl border border-white/20 transition-all hover:border-purple-500/70 hover:bg-purple-900/10 text-left"
              style={{ background: 'linear-gradient(135deg, rgba(35, 20, 60, 0.95), rgba(12, 12, 24, 0.98))' }}
            >
              <div>
                <div className="text-sm font-semibold text-white">Fractal Engineer</div>
                <div className="text-xs text-gray-400 mt-0.5">Recursive layouts & flows</div>
              </div>
            </button>
          </div>
        </div>

        {/* Panel Trigger Buttons */}
        <div className="fixed top-20 right-5 flex flex-col gap-2 z-[99]">
          <button
            onClick={() => setTriOpen(true)}
            className="backdrop-blur-md px-4 py-2 rounded-xl text-xs font-semibold border transition-all hover:scale-105 min-w-[150px] text-left"
            style={{ background: 'rgba(10, 10, 20, 0.6)', borderColor: 'rgba(255, 224, 131, 0.4)', color: '#eee' }}
          >
            <div>Multi-Mind Council</div>
            <div className="text-[0.65rem] opacity-80 mt-0.5">All 8 brains</div>
          </button>
          <button
            onClick={() => setGlitchOpen(true)}
            className="backdrop-blur-md px-4 py-2 rounded-xl text-xs font-semibold border transition-all hover:scale-105 min-w-[150px] text-left"
            style={{ background: 'rgba(10, 10, 20, 0.6)', borderColor: 'rgba(255, 75, 92, 0.4)', color: '#eee' }}
          >
            <div>Glitch Engineer</div>
            <div className="text-[0.65rem] opacity-80 mt-0.5">Broken UI logic</div>
          </button>
          <button
            onClick={() => setShadowOpen(true)}
            className="backdrop-blur-md px-4 py-2 rounded-xl text-xs font-semibold border transition-all hover:scale-105 min-w-[150px] text-left"
            style={{ background: 'rgba(10, 10, 20, 0.6)', borderColor: 'rgba(155, 155, 187, 0.4)', color: '#eee' }}
          >
            <div>Shadow Archivist</div>
            <div className="text-xs opacity-80 mt-0.5">Hidden systems</div>
          </button>
          <button
            onClick={() => setTemporalOpen(true)}
            className="backdrop-blur-md px-4 py-2 rounded-xl text-xs font-semibold border transition-all hover:scale-105 min-w-[150px] text-left"
            style={{ background: 'rgba(10, 10, 20, 0.6)', borderColor: 'rgba(183, 136, 255, 0.4)', color: '#eee' }}
          >
            <div>Temporal Engine</div>
            <div className="text-[0.65rem] opacity-80 mt-0.5">Time mutation</div>
          </button>
          <button
            onClick={() => setParallelOpen(true)}
            className="backdrop-blur-md px-4 py-2 rounded-xl text-xs font-semibold border transition-all hover:scale-105 min-w-[150px] text-left"
            style={{ background: 'rgba(10, 10, 20, 0.6)', borderColor: 'rgba(36, 228, 255, 0.4)', color: '#eee' }}
          >
            <div>Parallel Architect</div>
            <div className="text-[0.65rem] opacity-80 mt-0.5">Multiverse layouts</div>
          </button>
          <button
            onClick={() => setFractalOpen(true)}
            className="backdrop-blur-md px-4 py-2 rounded-xl text-xs font-semibold border transition-all hover:scale-105 min-w-[150px] text-left"
            style={{ background: 'rgba(10, 10, 20, 0.6)', borderColor: 'rgba(78, 255, 139, 0.4)', color: '#eee' }}
          >
            <div>Fractal Engineer</div>
            <div className="text-[0.65rem] opacity-80 mt-0.5">Recursive UI maps</div>
          </button>
        </div>

        {/* HUD Bottom */}
        {!coreOpen && (
          <div className="fixed bottom-4 left-0 right-0 flex justify-center pointer-events-none z-[5]">
            <div className="px-4 py-2 rounded-full border border-white/20 bg-black/90 text-xs text-gray-400 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" style={{ boxShadow: '0 0 6px rgba(59, 211, 255, 0.9)' }} />
              <span className="hidden sm:inline">Tap the Neural Core to access the Multi-Mind Council's 8 brains</span>
              <span className="sm:hidden">Tap Neural Core</span>
            </div>
          </div>
        )}

        {/* Panels */}
        <NeuroEvolutionPanel isOpen={neuroOpen} onClose={() => setNeuroOpen(false)} />
        <ChaosArchitectPanel isOpen={chaosOpen} onClose={() => setChaosOpen(false)} />
        <DreamRendererPanel isOpen={dreamOpen} onClose={() => setDreamOpen(false)} />
        <TriMindDashboardPanel isOpen={triOpen} onClose={() => setTriOpen(false)} />
        <GlitchEngineerPanel isOpen={glitchOpen} onClose={() => setGlitchOpen(false)} />
        <ShadowArchivistPanel isOpen={shadowOpen} onClose={() => setShadowOpen(false)} />
        <TemporalEnginePanel isOpen={temporalOpen} onClose={() => setTemporalOpen(false)} />
        <ParallelArchitectPanel isOpen={parallelOpen} onClose={() => setParallelOpen(false)} />
        <FractalEngineerPanel isOpen={fractalOpen} onClose={() => setFractalOpen(false)} />
      </div>
    </TriMindProvider>
  );
}