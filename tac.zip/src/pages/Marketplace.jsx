import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, TrendingUp, Award, Code2, Zap, Users, Star, Sparkles, Swords, Trophy, Target, Package } from "lucide-react";
import AppCard from "../components/AppCard";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import AppBattleRoyale from "../components/AppBattleRoyale";
import DemigodCollection from "../components/DemigodCollection";
import AIAppRecommendations from "../components/AIAppRecommendations";
import LiveCodeBillboard from "../components/LiveCodeBillboard";
import GlobalHealthWidget from "../components/GlobalHealthWidget";

const categories = [
  { value: "all", label: "All Categories" },
  { value: "productivity", label: "Productivity" },
  { value: "development", label: "Development" },
  { value: "design", label: "Design" },
  { value: "business", label: "Business" },
  { value: "games", label: "Games" },
  { value: "education", label: "Education" },
  { value: "utilities", label: "Utilities" },
  { value: "other", label: "Other" }
];

const licenseTypes = [
  { value: "all", label: "All Licenses" },
  { value: "BASIC", label: "Basic" },
  { value: "EXTENDED", label: "Extended" },
  { value: "EXCLUSIVE", label: "Exclusive" }
];

export default function Marketplace() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedLicense, setSelectedLicense] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [showFeatured, setShowFeatured] = useState(false);
  const [showVerified, setShowVerified] = useState(false);
  const [activeTab, setActiveTab] = useState("browse");

  const { data: apps, isLoading } = useQuery({
    queryKey: ['apps'],
    queryFn: () => base44.entities.App.list('-created_date'),
    initialData: [],
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const filteredApps = apps
    .filter(app => {
      const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           app.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           app.developer.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           (app.tech_stack && app.tech_stack.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())));
      const matchesCategory = selectedCategory === "all" || app.category === selectedCategory;
      const matchesLicense = selectedLicense === "all" || app.license_type === selectedLicense;
      const matchesFeatured = !showFeatured || app.featured;
      const matchesVerified = !showVerified || app.verified;
      return matchesSearch && matchesCategory && matchesLicense && matchesFeatured && matchesVerified;
    })
    .sort((a, b) => {
      if (sortBy === "newest") return new Date(b.created_date) - new Date(a.created_date);
      if (sortBy === "rating") return (b.rating || 0) - (a.rating || 0);
      if (sortBy === "downloads") return (b.downloads || 0) - (a.downloads || 0);
      if (sortBy === "price-low") return (a.price || 0) - (b.price || 0);
      if (sortBy === "price-high") return (b.price || 0) - (a.price || 0);
      if (sortBy === "innovation") return (b.innovation_score || 0) - (a.innovation_score || 0);
      return 0;
    });

  const featuredApps = apps.filter(app => app.featured).slice(0, 4);

  return (
    <div className="min-h-screen">
      <div className="max-w-[1120px] mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="mb-12 grid lg:grid-cols-[1.2fr_1fr] gap-8 items-center">
          {/* Left: Hero Text */}
          <div>
            <div className="inline-flex items-center gap-2 px-2 py-1 pr-3 rounded-full border mb-4" style={{ 
              borderColor: 'rgba(148, 163, 184, 0.4)',
              background: 'linear-gradient(to right, rgba(15, 23, 42, 0.9), rgba(15, 23, 42, 0.4))'
            }}>
              <div className="w-5 h-5 rounded-full flex items-center justify-center text-[0.65rem] font-bold" style={{
                background: 'radial-gradient(circle at 30% 0, var(--accent), transparent 50%), radial-gradient(circle at 80% 100%, var(--accent-alt), transparent 60%)',
                fontFamily: 'JetBrains Mono, monospace'
              }}>
                AI
              </div>
              <span className="text-[0.7rem] uppercase tracking-[0.16em] text-gray-400">
                AI-Ranked Marketplace
              </span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-bold leading-tight tracking-tight mb-3">
              Discover <span style={{ background: 'linear-gradient(to right, var(--accent), var(--accent-alt))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Elite Code</span>
            </h1>

            <div className="mono-font text-sm uppercase tracking-[0.18em] mb-3" style={{ color: 'var(--accent-alt)', fontFamily: 'JetBrains Mono, monospace' }}>
              Where Demigods Build
            </div>

            <p className="text-gray-400 text-base leading-relaxed max-w-md mb-6">
              The <strong className="text-gray-200 font-semibold">dark-tech hub</strong> where hidden dev talents rise and get <strong className="text-gray-200 font-semibold">AI-ranked</strong> for companies hunting real skill.
            </p>

            <div className="flex flex-wrap gap-3 mb-4">
              <Link to={createPageUrl("ExpertMarketplace")}>
                <button className="px-5 py-2.5 rounded-full text-sm font-medium text-black transition-all hover:brightness-105" style={{ 
                  background: 'radial-gradient(circle at 0 0, var(--accent-alt), transparent 45%), var(--accent)',
                  boxShadow: 'var(--shadow-glow)'
                }}>
                  <Zap className="w-4 h-4 inline mr-2" />
                  Hire Experts
                </button>
              </Link>
              <button className="px-5 py-2.5 rounded-full text-sm font-medium border transition-all" style={{ 
                borderColor: 'rgba(148, 163, 184, 0.7)',
                color: 'var(--text-muted)'
              }}>
                <Code2 className="w-4 h-4 inline mr-2" />
                Browse Apps
              </button>
            </div>

            <div className="flex items-center gap-2 text-[0.75rem] text-gray-400">
              <span className="w-[5px] h-[5px] rounded-full" style={{ background: 'var(--accent-alt)', boxShadow: '0 0 10px rgba(36, 228, 255, 0.9)' }} />
              Live developers • AI-verified projects
            </div>
          </div>

          {/* Right: Stats Panel */}
          <div className="rounded-[26px] p-4 border relative overflow-hidden" style={{
            background: 'radial-gradient(circle at 0 0, rgba(139, 92, 255, 0.14), transparent 55%), radial-gradient(circle at 100% 100%, rgba(36, 228, 255, 0.14), transparent 60%), rgba(15, 23, 42, 0.95)',
            borderColor: 'rgba(31, 41, 55, 0.9)',
            boxShadow: '0 18px 45px rgba(15, 23, 42, 0.9)'
          }}>
            <div className="flex justify-between items-center mb-4">
              <div className="text-[0.78rem] uppercase tracking-[0.16em] text-gray-400">
                Live Stats
              </div>
              <div className="px-3 py-1 rounded-full border text-[0.7rem] flex items-center gap-2" style={{
                borderColor: 'rgba(56, 189, 248, 0.7)',
                background: 'rgba(8, 47, 73, 0.7)',
                color: '#e0f2fe'
              }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: 'var(--accent-alt)', boxShadow: '0 0 12px rgba(36, 228, 255, 0.9)' }} />
                Active
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="rounded-xl p-2 border" style={{ background: 'rgba(15, 23, 42, 0.88)', borderColor: 'rgba(30, 64, 175, 0.8)' }}>
                <div className="text-[0.6rem] text-gray-400 mb-1">Total Apps</div>
                <div className="text-base font-semibold">{apps.length}</div>
                <div className="text-[0.62rem] text-gray-500">published</div>
              </div>
              <div className="rounded-xl p-2 border" style={{ background: 'rgba(15, 23, 42, 0.88)', borderColor: 'rgba(30, 64, 175, 0.8)' }}>
                <div className="text-[0.6rem] text-gray-400 mb-1">Verified</div>
                <div className="text-base font-semibold">{apps.filter(a => a.verified).length}</div>
                <div className="text-[0.62rem] text-gray-500">elite</div>
              </div>
              <div className="rounded-xl p-2 border" style={{ background: 'rgba(15, 23, 42, 0.88)', borderColor: 'rgba(30, 64, 175, 0.8)' }}>
                <div className="text-[0.6rem] text-gray-400 mb-1">Featured</div>
                <div className="text-base font-semibold">{featuredApps.length}</div>
                <div className="text-[0.62rem] text-gray-500">hot</div>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5">
              <span className="text-[0.68rem] px-2 py-1 rounded-full border" style={{ borderColor: 'rgba(148, 163, 184, 0.5)', color: 'var(--text-muted)', background: 'rgba(15, 23, 42, 0.9)' }}>React</span>
              <span className="text-[0.68rem] px-2 py-1 rounded-full border" style={{ borderColor: 'rgba(148, 163, 184, 0.5)', color: 'var(--text-muted)', background: 'rgba(15, 23, 42, 0.9)' }}>Node.js</span>
              <span className="text-[0.68rem] px-2 py-1 rounded-full border" style={{ borderColor: 'rgba(139, 92, 255, 0.8)', color: '#e5e7eb', background: 'rgba(30, 64, 175, 0.6)' }}>AI-Powered</span>
            </div>
          </div>
        </div>

        {/* GLOBAL HEALTH WIDGET */}
        <div className="mb-12">
          <GlobalHealthWidget />
        </div>

        {/* LIVE CODE BILLBOARD */}
        <div className="mb-12">
          <LiveCodeBillboard autoRotate={true} rotateInterval={8000} />
        </div>

        {/* Tabs for different views */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="bg-[#0f1419] border border-[#1a1f2e]">
            <TabsTrigger value="browse" className="data-[state=active]:bg-purple-600/20">
              <Package className="w-4 h-4 mr-2" />
              Browse All
            </TabsTrigger>
            <TabsTrigger value="foryou" className="data-[state=active]:bg-cyan-600/20">
              <Sparkles className="w-4 h-4 mr-2" />
              For You (AI)
            </TabsTrigger>
            <TabsTrigger value="battle" className="data-[state=active]:bg-orange-600/20">
              <Swords className="w-4 h-4 mr-2" />
              App Battle Royale
            </TabsTrigger>
            <TabsTrigger value="curated" className="data-[state=active]:bg-yellow-600/20">
              <Trophy className="w-4 h-4 mr-2" />
              Demigod Collections
            </TabsTrigger>
          </TabsList>

          {/* TAB 1: Browse All */}
          <TabsContent value="browse" className="space-y-8">
            {/* Featured Apps */}
            {featuredApps.length > 0 && (
              <div className="mb-12">
                <div className="flex items-center gap-3 mb-6">
                  <Award className="w-6 h-6" style={{ color: 'var(--accent)' }} />
                  <h2 className="text-2xl font-bold">Elite Picks</h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {featuredApps.map(app => (
                    <AppCard key={app.id} app={app} showTryButton={true} />
                  ))}
                </div>
              </div>
            )}

            {/* Search and Filters */}
            <div className="mb-8 space-y-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Search apps, tech, developers..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12 border text-white placeholder:text-gray-500"
                    style={{ background: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(148, 163, 184, 0.35)' }}
                  />
                </div>
                <Button className="h-12 px-8 font-bold text-black" style={{ 
                  background: 'radial-gradient(circle at 0 0, var(--accent-alt), transparent 45%), var(--accent)'
                }}>
                  Search
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="border text-white" style={{ background: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(148, 163, 184, 0.35)' }}>
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedLicense} onValueChange={setSelectedLicense}>
                  <SelectTrigger className="border text-white" style={{ background: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(148, 163, 184, 0.35)' }}>
                    <SelectValue placeholder="License" />
                  </SelectTrigger>
                  <SelectContent>
                    {licenseTypes.map(lic => (
                      <SelectItem key={lic.value} value={lic.value}>
                        {lic.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="border text-white" style={{ background: 'rgba(15, 23, 42, 0.95)', borderColor: 'rgba(148, 163, 184, 0.35)' }}>
                    <SelectValue placeholder="Sort" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="rating">Best Rated</SelectItem>
                    <SelectItem value="downloads">Most Downloads</SelectItem>
                    <SelectItem value="innovation">Most Innovative</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  variant={showFeatured ? "default" : "outline"}
                  size="sm"
                  onClick={() => setShowFeatured(!showFeatured)}
                  className={showFeatured ? "" : "border text-white"}
                  style={showFeatured ? { background: 'linear-gradient(to right, #eab308, #f97316)' } : { borderColor: 'rgba(148, 163, 184, 0.35)' }}
                >
                  <Award className="w-4 h-4 mr-2" />
                  Featured
                </Button>
                <Button
                  variant={showVerified ? "default" : "outline"}
                  size="sm"
                  onClick={() => setShowVerified(!showVerified)}
                  className={showVerified ? "bg-blue-600" : "border text-white"}
                  style={!showVerified ? { borderColor: 'rgba(148, 163, 184, 0.35)' } : {}}
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Verified
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="mb-8">
              <p className="text-gray-400">
                <span className="font-bold text-white">{filteredApps.length}</span> apps found
              </p>
            </div>

            {/* Apps Grid */}
            {isLoading ? (
              <div className="text-center py-20">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-t-transparent" style={{ borderColor: 'var(--accent)' }}></div>
                <p className="text-gray-400 mt-4">Loading...</p>
              </div>
            ) : filteredApps.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-6xl mb-4">📦</div>
                <h3 className="text-2xl font-bold text-white mb-2">No Results</h3>
                <p className="text-gray-400">Try different filters</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredApps.map(app => (
                  <AppCard key={app.id} app={app} showTryButton={true} />
                ))}
              </div>
            )}
          </TabsContent>

          {/* TAB 2: For You (AI Recommendations) */}
          <TabsContent value="foryou">
            <AIAppRecommendations user={user} allApps={apps} />
          </TabsContent>

          {/* TAB 3: App Battle Royale */}
          <TabsContent value="battle">
            <AppBattleRoyale apps={apps} />
          </TabsContent>

          {/* TAB 4: Demigod Collections */}
          <TabsContent value="curated">
            <DemigodCollection apps={apps} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}