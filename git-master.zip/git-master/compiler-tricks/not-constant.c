#include <git-compat-util.h>
int false_but_the_compiler_does_not_know_it_ = 0;
