#ifndef __MSVC__HEAD
#define __MSVC__HEAD

#include "msvc-posix.h"
#include "mingw.h"

#endif
