# libgit-sys

A small proof-of-concept crate showing how to provide a Rust FFI to Git
internals.
