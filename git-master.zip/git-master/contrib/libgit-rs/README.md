# libgit-rs

Proof-of-concept Git bindings for Rust.

```toml
[dependencies]
libgit = "0.1.0"
```

## Rust version requirements

libgit-rs should support Rust versions at least as old as the version included
in Debian stable (currently 1.63).
